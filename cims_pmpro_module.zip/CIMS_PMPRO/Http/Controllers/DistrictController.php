<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\PmproDistrict;
use Modules\CIMS_PMPRO\Models\PmproProvince;

class DistrictController extends Controller
{
    public function index(Request $request)
    {
        $query = PmproDistrict::with('province')->withCount('localMunicipalities');

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        if ($request->filled('province_id')) {
            $query->where('province_id', $request->province_id);
        }

        if ($request->filled('status')) {
            $query->where('is_active', $request->status === 'active');
        }

        $districts = $query->orderBy('name')->paginate(15);

        $stats = [
            'total' => PmproDistrict::count(),
            'active' => PmproDistrict::where('is_active', true)->count(),
            'inactive' => PmproDistrict::where('is_active', false)->count(),
        ];

        $provinces = PmproProvince::where('is_active', true)->orderBy('name')->get();

        return view('cims_pmpro::districts.index', compact('districts', 'stats', 'provinces'));
    }

    public function create()
    {
        $provinces = PmproProvince::where('is_active', true)->orderBy('name')->get();
        return view('cims_pmpro::districts.form', compact('provinces'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:200',
            'code' => 'required|string|max:10|unique:pmpro_districts,code',
            'province_id' => 'required|exists:pmpro_provinces,id',
        ]);

        PmproDistrict::create([
            'name' => $request->name,
            'code' => strtoupper($request->code),
            'province_id' => $request->province_id,
            'is_active' => true,
        ]);

        return redirect()->route('pmpro.districts.index')
            ->with('success', 'District municipality created successfully.');
    }

    public function show($id)
    {
        $district = PmproDistrict::with('province')->findOrFail($id);
        $localMunicipalities = $district->localMunicipalities()->orderBy('name')->get();
        return view('cims_pmpro::districts.show', compact('district', 'localMunicipalities'));
    }

    public function edit($id)
    {
        $district = PmproDistrict::findOrFail($id);
        $provinces = PmproProvince::where('is_active', true)->orderBy('name')->get();
        return view('cims_pmpro::districts.form', compact('district', 'provinces'));
    }

    public function update(Request $request, $id)
    {
        $district = PmproDistrict::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:200',
            'code' => 'required|string|max:10|unique:pmpro_districts,code,' . $id,
            'province_id' => 'required|exists:pmpro_provinces,id',
        ]);

        $district->update([
            'name' => $request->name,
            'code' => strtoupper($request->code),
            'province_id' => $request->province_id,
            'is_active' => $request->boolean('is_active', true),
        ]);

        return redirect()->route('pmpro.districts.index')
            ->with('success', 'District municipality updated successfully.');
    }

    public function destroy($id)
    {
        $district = PmproDistrict::findOrFail($id);
        $district->delete();
        return redirect()->route('pmpro.districts.index')
            ->with('success', 'District municipality deleted successfully.');
    }

    public function toggle($id)
    {
        $district = PmproDistrict::findOrFail($id);
        $district->update(['is_active' => !$district->is_active]);
        return redirect()->back()->with('success', 'District municipality status updated.');
    }
}
