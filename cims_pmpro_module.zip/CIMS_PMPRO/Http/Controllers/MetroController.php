<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\PmproMetro;
use Modules\CIMS_PMPRO\Models\PmproProvince;

class MetroController extends Controller
{
    public function index(Request $request)
    {
        $query = PmproMetro::with('province');

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        if ($request->filled('province_id')) {
            $query->where('province_id', $request->province_id);
        }

        if ($request->filled('status')) {
            $query->where('is_active', $request->status === 'active');
        }

        $metros = $query->orderBy('name')->paginate(15);

        $stats = [
            'total' => PmproMetro::count(),
            'active' => PmproMetro::where('is_active', true)->count(),
            'inactive' => PmproMetro::where('is_active', false)->count(),
        ];

        $provinces = PmproProvince::where('is_active', true)->orderBy('name')->get();

        return view('cims_pmpro::metros.index', compact('metros', 'stats', 'provinces'));
    }

    public function create()
    {
        $provinces = PmproProvince::where('is_active', true)->orderBy('name')->get();
        return view('cims_pmpro::metros.form', compact('provinces'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:200',
            'code' => 'required|string|max:10|unique:pmpro_metropolitan_municipalities,code',
            'province_id' => 'required|exists:pmpro_provinces,id',
        ]);

        PmproMetro::create([
            'name' => $request->name,
            'code' => strtoupper($request->code),
            'province_id' => $request->province_id,
            'description' => $request->description,
            'is_active' => true,
        ]);

        return redirect()->route('pmpro.metros.index')
            ->with('success', 'Metropolitan municipality created successfully.');
    }

    public function show($id)
    {
        $metro = PmproMetro::with('province')->findOrFail($id);
        $mainPlaces = $metro->cities()->orderBy('name')->get();
        return view('cims_pmpro::metros.show', compact('metro', 'mainPlaces'));
    }

    public function edit($id)
    {
        $metro = PmproMetro::findOrFail($id);
        $provinces = PmproProvince::where('is_active', true)->orderBy('name')->get();
        return view('cims_pmpro::metros.form', compact('metro', 'provinces'));
    }

    public function update(Request $request, $id)
    {
        $metro = PmproMetro::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:200',
            'code' => 'required|string|max:10|unique:pmpro_metropolitan_municipalities,code,' . $id,
            'province_id' => 'required|exists:pmpro_provinces,id',
        ]);

        $metro->update([
            'name' => $request->name,
            'code' => strtoupper($request->code),
            'province_id' => $request->province_id,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
        ]);

        return redirect()->route('pmpro.metros.index')
            ->with('success', 'Metropolitan municipality updated successfully.');
    }

    public function destroy($id)
    {
        $metro = PmproMetro::findOrFail($id);
        $metro->delete();
        return redirect()->route('pmpro.metros.index')
            ->with('success', 'Metropolitan municipality deleted successfully.');
    }

    public function toggle($id)
    {
        $metro = PmproMetro::findOrFail($id);
        $metro->update(['is_active' => !$metro->is_active]);
        return redirect()->back()->with('success', 'Metropolitan municipality status updated.');
    }
}
