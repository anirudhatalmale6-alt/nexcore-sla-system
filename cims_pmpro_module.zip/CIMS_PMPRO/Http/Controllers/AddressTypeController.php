<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemAddressType;

class AddressTypeController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemAddressType::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        $addressTypes = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemAddressType::count(),
            'active' => NexcorSystemAddressType::where('is_active', true)->count(),
            'inactive' => NexcorSystemAddressType::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::address-types.index', compact('addressTypes', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::address-types.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        NexcorSystemAddressType::create([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.address-types.index')
            ->with('success', 'Address type created successfully.');
    }

    public function show($id)
    {
        $addressType = NexcorSystemAddressType::findOrFail($id);
        return view('cims_pmpro::address-types.show', compact('addressType'));
    }

    public function edit($id)
    {
        $addressType = NexcorSystemAddressType::findOrFail($id);
        return view('cims_pmpro::address-types.form', compact('addressType'));
    }

    public function update(Request $request, $id)
    {
        $addressType = NexcorSystemAddressType::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        $addressType->update([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.address-types.show', $addressType->id)
            ->with('success', 'Address type updated successfully.');
    }

    public function destroy($id)
    {
        $addressType = NexcorSystemAddressType::findOrFail($id);
        $addressType->delete();
        return redirect()->route('system-settings.address-types.index')
            ->with('success', 'Address type deleted successfully.');
    }

    public function toggle($id)
    {
        $addressType = NexcorSystemAddressType::findOrFail($id);
        $addressType->update(['is_active' => !$addressType->is_active]);
        return redirect()->back()->with('success', 'Address type status updated.');
    }
}
