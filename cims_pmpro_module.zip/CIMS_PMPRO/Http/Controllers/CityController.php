<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Modules\CIMS_PMPRO\Models\PmproCity;
use Modules\CIMS_PMPRO\Models\PmproSuburb;
use Modules\CIMS_PMPRO\Models\PmproWard;

class CityController extends Controller
{
    public function show($id)
    {
        $city = PmproCity::with(['province', 'metro', 'localMunicipality', 'localMunicipality.district'])->findOrFail($id);
        $suburbs = PmproSuburb::where('city_id', $city->id)->orderBy('name')->get();

        if ($city->metropolitan_municipality_id) {
            $wards = PmproWard::where('metro_id', $city->metropolitan_municipality_id)->orderBy('ward_number')->get();
        } elseif ($city->local_municipality_id) {
            $wards = PmproWard::where('local_municipality_id', $city->local_municipality_id)->orderBy('ward_number')->get();
        } else {
            $wards = collect();
        }

        return view('cims_pmpro::cities.show', compact('city', 'suburbs', 'wards'));
    }
}
