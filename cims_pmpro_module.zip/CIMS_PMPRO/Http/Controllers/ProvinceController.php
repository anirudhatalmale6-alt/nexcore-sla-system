<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\PmproProvince;

class ProvinceController extends Controller
{
    public function index(Request $request)
    {
        $query = PmproProvince::withCount(['districts', 'metros']);

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        if ($request->filled('status')) {
            $query->where('is_active', $request->status === 'active');
        }

        $provinces = $query->orderBy('name')->paginate(15);

        $stats = [
            'total' => PmproProvince::count(),
            'active' => PmproProvince::where('is_active', true)->count(),
            'inactive' => PmproProvince::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::provinces.index', compact('provinces', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::provinces.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100|unique:pmpro_provinces,name',
            'code' => 'required|string|max:5|unique:pmpro_provinces,code',
            'map_image' => 'nullable|image|max:2048',
        ]);

        $data = [
            'name' => $request->name,
            'code' => strtoupper($request->code),
            'native_name' => $request->native_name,
            'capital' => $request->capital,
            'largest_city' => $request->largest_city,
            'area_km2' => $request->area_km2,
            'population' => $request->population,
            'density' => $request->density,
            'description' => $request->description,
            'is_active' => true,
        ];

        if ($request->hasFile('map_image')) {
            $path = $request->file('map_image')->store('provinces/maps', 'public');
            $data['map_image'] = 'storage/' . $path;
        }

        PmproProvince::create($data);

        return redirect()->route('pmpro.provinces.index')
            ->with('success', 'Province created successfully.');
    }

    public function show($id)
    {
        $province = PmproProvince::withCount(['districts', 'metros'])->findOrFail($id);
        $districts = $province->districts()->withCount('localMunicipalities')->orderBy('name')->get();
        $metros = $province->metros()->orderBy('name')->get();
        return view('cims_pmpro::provinces.show', compact('province', 'districts', 'metros'));
    }

    public function edit($id)
    {
        $province = PmproProvince::findOrFail($id);
        return view('cims_pmpro::provinces.form', compact('province'));
    }

    public function update(Request $request, $id)
    {
        $province = PmproProvince::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100|unique:pmpro_provinces,name,' . $id,
            'code' => 'required|string|max:5|unique:pmpro_provinces,code,' . $id,
            'map_image' => 'nullable|image|max:2048',
        ]);

        $data = [
            'name' => $request->name,
            'code' => strtoupper($request->code),
            'native_name' => $request->native_name,
            'capital' => $request->capital,
            'largest_city' => $request->largest_city,
            'area_km2' => $request->area_km2,
            'population' => $request->population,
            'density' => $request->density,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
        ];

        if ($request->hasFile('map_image')) {
            $path = $request->file('map_image')->store('provinces/maps', 'public');
            $data['map_image'] = 'storage/' . $path;
        }

        $province->update($data);

        return redirect()->route('pmpro.provinces.show', $province->id)
            ->with('success', 'Province updated successfully.');
    }

    public function destroy($id)
    {
        $province = PmproProvince::findOrFail($id);
        $province->delete();
        return redirect()->route('pmpro.provinces.index')
            ->with('success', 'Province deleted successfully.');
    }

    public function toggle($id)
    {
        $province = PmproProvince::findOrFail($id);
        $province->update(['is_active' => !$province->is_active]);
        return redirect()->back()->with('success', 'Province status updated.');
    }
}
