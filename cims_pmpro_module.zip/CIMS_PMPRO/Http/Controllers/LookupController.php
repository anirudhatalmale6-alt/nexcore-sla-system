<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\PmproProvince;
use Modules\CIMS_PMPRO\Models\PmproDistrict;
use Modules\CIMS_PMPRO\Models\PmproLocalMunicipality;
use Modules\CIMS_PMPRO\Models\PmproMetro;
use Modules\CIMS_PMPRO\Models\PmproWard;
use Modules\CIMS_PMPRO\Models\PmproCity;
use Modules\CIMS_PMPRO\Models\PmproSuburb;

class LookupController extends Controller
{
    public function provinces()
    {
        return response()->json(
            PmproProvince::where('is_active', true)->orderBy('name')->get()
        );
    }

    public function districts($province_id)
    {
        return response()->json(
            PmproDistrict::where('province_id', $province_id)
                ->where('is_active', true)
                ->orderBy('name')
                ->get()
        );
    }

    public function municipalities($district_id)
    {
        return response()->json(
            PmproLocalMunicipality::where('district_id', $district_id)
                ->where('is_active', true)
                ->orderBy('name')
                ->get()
        );
    }

    public function metros($province_id)
    {
        return response()->json(
            PmproMetro::where('province_id', $province_id)
                ->where('is_active', true)
                ->orderBy('name')
                ->get()
        );
    }

    public function localMunicipalitiesByProvince($province_id)
    {
        return response()->json(
            PmproLocalMunicipality::whereHas('district', function($q) use ($province_id) {
                $q->where('province_id', $province_id);
            })
            ->where('is_active', true)
            ->orderBy('name')
            ->get()
        );
    }

    public function wards($municipality_id)
    {
        return response()->json(
            PmproWard::where(function($q) use ($municipality_id) {
                $q->where('local_municipality_id', $municipality_id)
                  ->orWhere('metro_id', $municipality_id);
            })
            ->where('is_active', true)
            ->orderBy('ward_number')
            ->get()
        );
    }

    public function cities($province_id)
    {
        return response()->json(
            PmproCity::where('province_id', $province_id)
                ->where('is_active', true)
                ->orderBy('name')
                ->get()
        );
    }

    public function suburbs($city_id)
    {
        return response()->json(
            PmproSuburb::where('city_id', $city_id)
                ->where('is_active', true)
                ->orderBy('name')
                ->get()
        );
    }

    public function searchSuburbs(Request $request)
    {
        $term = $request->input('q', '');
        if (strlen($term) < 2) {
            return response()->json([]);
        }

        return response()->json(
            PmproSuburb::where('name', 'like', "%{$term}%")
                ->where('is_active', true)
                ->with('city')
                ->limit(20)
                ->get()
                ->map(function ($s) {
                    $city = $s->city;
                    return [
                        'id' => $s->id,
                        'name' => $s->name,
                        'city' => $city->name ?? '',
                        'city_id' => $city->id ?? null,
                        'postal_code' => $s->postal_code,
                        'province_id' => $city->province_id ?? null,
                        'metro_id' => $city->metropolitan_municipality_id ?? null,
                        'local_municipality_id' => $city->local_municipality_id ?? null,
                        'district_id' => $city->district_id ?? null,
                    ];
                })
        );
    }

    public function findOrCreateSuburb(Request $request)
    {
        $name = trim($request->input('name', ''));
        $cityName = trim($request->input('city', ''));
        $postalCode = trim($request->input('postal_code', ''));

        if (!$name) {
            return response()->json(['error' => 'Name required'], 400);
        }

        $suburb = PmproSuburb::with('city')->where('name', $name)->first();
        if ($suburb) {
            $city = $suburb->city;
            return response()->json([
                'id' => $suburb->id,
                'name' => $suburb->name,
                'city' => $city->name ?? '',
                'city_id' => $city->id ?? null,
                'postal_code' => $suburb->postal_code,
                'province_id' => $city->province_id ?? null,
                'metro_id' => $city->metropolitan_municipality_id ?? null,
                'local_municipality_id' => $city->local_municipality_id ?? null,
                'district_id' => $city->district_id ?? null,
            ]);
        }

        $cityId = null;
        $cityObj = null;
        if ($cityName) {
            $cityObj = PmproCity::where('name', 'like', "%{$cityName}%")->first();
            if ($cityObj) $cityId = $cityObj->id;
        }

        $suburb = PmproSuburb::create([
            'name' => $name,
            'city_id' => $cityId,
            'postal_code' => $postalCode,
            'is_active' => true,
        ]);

        return response()->json([
            'id' => $suburb->id,
            'name' => $suburb->name,
            'city' => $cityName,
            'city_id' => $cityId,
            'postal_code' => $postalCode,
            'province_id' => $cityObj->province_id ?? null,
            'metro_id' => $cityObj->metropolitan_municipality_id ?? null,
            'local_municipality_id' => $cityObj->local_municipality_id ?? null,
            'district_id' => $cityObj->district_id ?? null,
            'created' => true,
        ]);
    }
}
