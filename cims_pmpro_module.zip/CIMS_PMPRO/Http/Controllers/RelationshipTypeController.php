<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemRelationshipType;

class RelationshipTypeController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemRelationshipType::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        $relationshipTypes = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemRelationshipType::count(),
            'active' => NexcorSystemRelationshipType::where('is_active', true)->count(),
            'inactive' => NexcorSystemRelationshipType::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::relationship-types.index', compact('relationshipTypes', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::relationship-types.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        NexcorSystemRelationshipType::create([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.relationship-types.index')
            ->with('success', 'Relationship Type created successfully.');
    }

    public function show($id)
    {
        $relationshipType = NexcorSystemRelationshipType::findOrFail($id);
        return view('cims_pmpro::relationship-types.show', compact('relationshipType'));
    }

    public function edit($id)
    {
        $relationshipType = NexcorSystemRelationshipType::findOrFail($id);
        return view('cims_pmpro::relationship-types.form', compact('relationshipType'));
    }

    public function update(Request $request, $id)
    {
        $relationshipType = NexcorSystemRelationshipType::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        $relationshipType->update([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.relationship-types.show', $relationshipType->id)
            ->with('success', 'Relationship Type updated successfully.');
    }

    public function destroy($id)
    {
        $relationshipType = NexcorSystemRelationshipType::findOrFail($id);
        $relationshipType->delete();
        return redirect()->route('system-settings.relationship-types.index')
            ->with('success', 'Relationship Type deleted successfully.');
    }

    public function toggle($id)
    {
        $relationshipType = NexcorSystemRelationshipType::findOrFail($id);
        $relationshipType->update(['is_active' => !$relationshipType->is_active]);
        return redirect()->back()->with('success', 'Relationship Type status updated.');
    }
}