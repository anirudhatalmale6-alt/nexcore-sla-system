<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemBankAccountType;

class BankAccountTypeController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemBankAccountType::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        $bankAccountTypes = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemBankAccountType::count(),
            'active' => NexcorSystemBankAccountType::where('is_active', true)->count(),
            'inactive' => NexcorSystemBankAccountType::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::bank-account-types.index', compact('bankAccountTypes', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::bank-account-types.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        NexcorSystemBankAccountType::create([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.bank-account-types.index')
            ->with('success', 'Bank account type created successfully.');
    }

    public function show($id)
    {
        $bankAccountType = NexcorSystemBankAccountType::findOrFail($id);
        return view('cims_pmpro::bank-account-types.show', compact('bankAccountType'));
    }

    public function edit($id)
    {
        $bankAccountType = NexcorSystemBankAccountType::findOrFail($id);
        return view('cims_pmpro::bank-account-types.form', compact('bankAccountType'));
    }

    public function update(Request $request, $id)
    {
        $bankAccountType = NexcorSystemBankAccountType::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        $bankAccountType->update([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.bank-account-types.show', $bankAccountType->id)
            ->with('success', 'Bank account type updated successfully.');
    }

    public function destroy($id)
    {
        $bankAccountType = NexcorSystemBankAccountType::findOrFail($id);
        $bankAccountType->delete();
        return redirect()->route('system-settings.bank-account-types.index')
            ->with('success', 'Bank account type deleted successfully.');
    }

    public function toggle($id)
    {
        $bankAccountType = NexcorSystemBankAccountType::findOrFail($id);
        $bankAccountType->update(['is_active' => !$bankAccountType->is_active]);
        return redirect()->back()->with('success', 'Bank account type status updated.');
    }
}
