<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\PmproCountry;
use Modules\CIMS_PMPRO\Models\PmproProvince;

class CountryController extends Controller
{
    public function index(Request $request)
    {
        $query = PmproCountry::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('iso_code_2', 'like', "%{$s}%")
                  ->orWhere('iso_code_3', 'like', "%{$s}%")
                  ->orWhere('capital', 'like', "%{$s}%")
                  ->orWhere('currency_code', 'like', "%{$s}%")
                  ->orWhere('calling_code', 'like', "%{$s}%");
            });
        }

        if ($request->filled('continent')) {
            $query->where('continent', $request->continent);
        }

        if ($request->filled('status')) {
            $query->where('is_active', $request->status === 'active');
        }

        $countries = $query->orderByRaw("CASE WHEN iso_code_2 = 'ZA' THEN 0 ELSE 1 END")->orderBy('name')->paginate(15);

        $stats = [
            'total' => PmproCountry::count(),
            'active' => PmproCountry::where('is_active', true)->count(),
            'inactive' => PmproCountry::where('is_active', false)->count(),
        ];

        $continents = PmproCountry::select('continent')->distinct()->whereNotNull('continent')->orderBy('continent')->pluck('continent');

        return view('cims_pmpro::countries.index', compact('countries', 'stats', 'continents'));
    }

    public function create()
    {
        return view('cims_pmpro::countries.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:200|unique:pmpro_countries,name',
            'iso_code_2' => 'required|string|size:2|unique:pmpro_countries,iso_code_2',
            'iso_code_3' => 'required|string|size:3|unique:pmpro_countries,iso_code_3',
            'continent' => 'required|string|max:50',
            'flag_image' => 'nullable|image|max:2048',
            'coat_of_arms_image' => 'nullable|image|max:2048',
            'map_image' => 'nullable|image|max:2048',
        ]);

        $data = array_merge(
            $request->only([
                'name', 'official_name', 'iso_code_2', 'iso_code_3', 'numeric_code',
                'continent', 'region', 'capital', 'currency_code', 'currency_name',
                'currency_symbol', 'calling_code', 'timezone', 'languages', 'flag_emoji',
                'description',
            ]),
            [
                'iso_code_2' => strtoupper($request->iso_code_2),
                'iso_code_3' => strtoupper($request->iso_code_3),
                'is_active' => true,
            ]
        );

        foreach (['flag_image', 'coat_of_arms_image', 'map_image'] as $field) {
            if ($request->hasFile($field)) {
                $file = $request->file($field);
                $filename = strtolower($request->iso_code_2) . '_' . $field . '_' . time() . '.' . $file->getClientOriginalExtension();
                $file->move(public_path('uploads/countries'), $filename);
                $data[$field] = 'uploads/countries/' . $filename;
            }
        }

        PmproCountry::create($data);

        return redirect()->route('pmpro.countries.index')
            ->with('success', 'Country created successfully.');
    }

    public function show($id)
    {
        $country = PmproCountry::with(['countryLanguages', 'ethnicGroups', 'religions'])->findOrFail($id);
        $provinces = collect();
        if ($country->iso_code_2 === 'ZA') {
            $provinces = PmproProvince::withCount(['districts', 'metros'])
                ->where('is_active', true)
                ->orderBy('name')
                ->get();
        }
        return view('cims_pmpro::countries.show', compact('country', 'provinces'));
    }

    public function edit($id)
    {
        $country = PmproCountry::with(['countryLanguages', 'ethnicGroups', 'religions'])->findOrFail($id);
        return view('cims_pmpro::countries.form', compact('country'));
    }

    public function update(Request $request, $id)
    {
        $country = PmproCountry::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:200|unique:pmpro_countries,name,' . $id,
            'iso_code_2' => 'required|string|size:2|unique:pmpro_countries,iso_code_2,' . $id,
            'iso_code_3' => 'required|string|size:3|unique:pmpro_countries,iso_code_3,' . $id,
            'continent' => 'required|string|max:50',
            'flag_image' => 'nullable|image|max:2048',
            'coat_of_arms_image' => 'nullable|image|max:2048',
            'map_image' => 'nullable|image|max:2048',
        ]);

        $data = array_merge(
            $request->only([
                'name', 'official_name', 'iso_code_2', 'iso_code_3', 'numeric_code',
                'continent', 'region', 'capital', 'currency_code', 'currency_name',
                'currency_symbol', 'calling_code', 'timezone', 'languages', 'flag_emoji',
                'description',
            ]),
            [
                'iso_code_2' => strtoupper($request->iso_code_2),
                'iso_code_3' => strtoupper($request->iso_code_3),
                'is_active' => $request->boolean('is_active', true),
            ]
        );

        foreach (['flag_image', 'coat_of_arms_image', 'map_image'] as $field) {
            if ($request->hasFile($field)) {
                if ($country->$field && file_exists(public_path($country->$field))) {
                    @unlink(public_path($country->$field));
                }
                $file = $request->file($field);
                $filename = strtolower($request->iso_code_2) . '_' . $field . '_' . time() . '.' . $file->getClientOriginalExtension();
                $file->move(public_path('uploads/countries'), $filename);
                $data[$field] = 'uploads/countries/' . $filename;
            }
        }

        $country->update($data);

        return redirect()->route('pmpro.countries.show', $country->id)
            ->with('success', 'Country updated successfully.');
    }

    public function destroy($id)
    {
        $country = PmproCountry::findOrFail($id);
        foreach (['flag_image', 'coat_of_arms_image', 'map_image'] as $field) {
            if ($country->$field && file_exists(public_path($country->$field))) {
                @unlink(public_path($country->$field));
            }
        }
        $country->delete();
        return redirect()->route('pmpro.countries.index')
            ->with('success', 'Country deleted successfully.');
    }

    public function toggle($id)
    {
        $country = PmproCountry::findOrFail($id);
        $country->update(['is_active' => !$country->is_active]);
        return redirect()->back()->with('success', 'Country status updated.');
    }
}
