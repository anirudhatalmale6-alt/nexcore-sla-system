<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemCompanyStatus;

class CompanyStatusController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemCompanyStatus::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        $companyStatuses = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemCompanyStatus::count(),
            'active' => NexcorSystemCompanyStatus::where('is_active', true)->count(),
            'inactive' => NexcorSystemCompanyStatus::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::company-statuses.index', compact('companyStatuses', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::company-statuses.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        NexcorSystemCompanyStatus::create([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.company-statuses.index')
            ->with('success', 'Company Status created successfully.');
    }

    public function show($id)
    {
        $companyStatus = NexcorSystemCompanyStatus::findOrFail($id);
        return view('cims_pmpro::company-statuses.show', compact('companyStatus'));
    }

    public function edit($id)
    {
        $companyStatus = NexcorSystemCompanyStatus::findOrFail($id);
        return view('cims_pmpro::company-statuses.form', compact('companyStatus'));
    }

    public function update(Request $request, $id)
    {
        $companyStatus = NexcorSystemCompanyStatus::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        $companyStatus->update([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.company-statuses.show', $companyStatus->id)
            ->with('success', 'Company Status updated successfully.');
    }

    public function destroy($id)
    {
        $companyStatus = NexcorSystemCompanyStatus::findOrFail($id);
        $companyStatus->delete();
        return redirect()->route('system-settings.company-statuses.index')
            ->with('success', 'Company Status deleted successfully.');
    }

    public function toggle($id)
    {
        $companyStatus = NexcorSystemCompanyStatus::findOrFail($id);
        $companyStatus->update(['is_active' => !$companyStatus->is_active]);
        return redirect()->back()->with('success', 'Company Status status updated.');
    }
}