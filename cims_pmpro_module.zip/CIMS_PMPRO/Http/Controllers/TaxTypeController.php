<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemTaxType;

class TaxTypeController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemTaxType::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        $taxTypes = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemTaxType::count(),
            'active' => NexcorSystemTaxType::where('is_active', true)->count(),
            'inactive' => NexcorSystemTaxType::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::tax-types.index', compact('taxTypes', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::tax-types.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        NexcorSystemTaxType::create([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.tax-types.index')
            ->with('success', 'Tax Type created successfully.');
    }

    public function show($id)
    {
        $taxType = NexcorSystemTaxType::findOrFail($id);
        return view('cims_pmpro::tax-types.show', compact('taxType'));
    }

    public function edit($id)
    {
        $taxType = NexcorSystemTaxType::findOrFail($id);
        return view('cims_pmpro::tax-types.form', compact('taxType'));
    }

    public function update(Request $request, $id)
    {
        $taxType = NexcorSystemTaxType::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        $taxType->update([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.tax-types.show', $taxType->id)
            ->with('success', 'Tax Type updated successfully.');
    }

    public function destroy($id)
    {
        $taxType = NexcorSystemTaxType::findOrFail($id);
        $taxType->delete();
        return redirect()->route('system-settings.tax-types.index')
            ->with('success', 'Tax Type deleted successfully.');
    }

    public function toggle($id)
    {
        $taxType = NexcorSystemTaxType::findOrFail($id);
        $taxType->update(['is_active' => !$taxType->is_active]);
        return redirect()->back()->with('success', 'Tax Type status updated.');
    }
}