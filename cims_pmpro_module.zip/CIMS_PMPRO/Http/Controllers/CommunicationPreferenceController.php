<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemCommunicationPreference;

class CommunicationPreferenceController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemCommunicationPreference::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        $communicationPreferences = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemCommunicationPreference::count(),
            'active' => NexcorSystemCommunicationPreference::where('is_active', true)->count(),
            'inactive' => NexcorSystemCommunicationPreference::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::communication-preferences.index', compact('communicationPreferences', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::communication-preferences.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        NexcorSystemCommunicationPreference::create([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.communication-preferences.index')
            ->with('success', 'Communication Preference created successfully.');
    }

    public function show($id)
    {
        $communicationPreference = NexcorSystemCommunicationPreference::findOrFail($id);
        return view('cims_pmpro::communication-preferences.show', compact('communicationPreference'));
    }

    public function edit($id)
    {
        $communicationPreference = NexcorSystemCommunicationPreference::findOrFail($id);
        return view('cims_pmpro::communication-preferences.form', compact('communicationPreference'));
    }

    public function update(Request $request, $id)
    {
        $communicationPreference = NexcorSystemCommunicationPreference::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        $communicationPreference->update([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.communication-preferences.show', $communicationPreference->id)
            ->with('success', 'Communication Preference updated successfully.');
    }

    public function destroy($id)
    {
        $communicationPreference = NexcorSystemCommunicationPreference::findOrFail($id);
        $communicationPreference->delete();
        return redirect()->route('system-settings.communication-preferences.index')
            ->with('success', 'Communication Preference deleted successfully.');
    }

    public function toggle($id)
    {
        $communicationPreference = NexcorSystemCommunicationPreference::findOrFail($id);
        $communicationPreference->update(['is_active' => !$communicationPreference->is_active]);
        return redirect()->back()->with('success', 'Communication Preference status updated.');
    }
}