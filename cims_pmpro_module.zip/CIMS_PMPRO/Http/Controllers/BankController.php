<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemBank;

class BankController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemBank::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%")
                  ->orWhere('bank_code', 'like', "%{$s}%")
                  ->orWhere('branch_code', 'like', "%{$s}%")
                  ->orWhere('swift_code', 'like', "%{$s}%");
            });
        }

        $banks = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemBank::count(),
            'active' => NexcorSystemBank::where('is_active', true)->count(),
            'inactive' => NexcorSystemBank::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::banks.index', compact('banks', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::banks.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
            'bank_code' => 'nullable|string|max:10',
            'branch_code' => 'nullable|string|max:10',
            'swift_code' => 'nullable|string|max:15',
            'bank_logo' => 'nullable|file|mimes:png,jpg,jpeg,svg,webp|max:2048',
        ]);

        $logoPath = null;
        if ($request->hasFile('bank_logo')) {
            $logoPath = $this->uploadLogo($request->file('bank_logo'), $request->code);
        }

        NexcorSystemBank::create([
            'name' => $request->name,
            'code' => $request->code,
            'bank_code' => $request->bank_code,
            'branch_code' => $request->branch_code,
            'swift_code' => $request->swift_code,
            'bank_logo' => $logoPath,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.banks.index')
            ->with('success', 'Bank created successfully.');
    }

    public function show($id)
    {
        $bank = NexcorSystemBank::findOrFail($id);
        return view('cims_pmpro::banks.show', compact('bank'));
    }

    public function edit($id)
    {
        $bank = NexcorSystemBank::findOrFail($id);
        return view('cims_pmpro::banks.form', compact('bank'));
    }

    public function update(Request $request, $id)
    {
        $bank = NexcorSystemBank::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
            'bank_code' => 'nullable|string|max:10',
            'branch_code' => 'nullable|string|max:10',
            'swift_code' => 'nullable|string|max:15',
            'bank_logo' => 'nullable|file|mimes:png,jpg,jpeg,svg,webp|max:2048',
        ]);

        $data = [
            'name' => $request->name,
            'code' => $request->code,
            'bank_code' => $request->bank_code,
            'branch_code' => $request->branch_code,
            'swift_code' => $request->swift_code,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ];

        if ($request->boolean('remove_logo')) {
            if ($bank->bank_logo && file_exists(base_path('../' . $bank->bank_logo))) {
                @unlink(base_path('../' . $bank->bank_logo));
            }
            $data['bank_logo'] = null;
        }

        if ($request->hasFile('bank_logo')) {
            if ($bank->bank_logo && file_exists(base_path('../' . $bank->bank_logo))) {
                @unlink(base_path('../' . $bank->bank_logo));
            }
            $data['bank_logo'] = $this->uploadLogo($request->file('bank_logo'), $request->code ?? $bank->code);
        }

        $bank->update($data);

        return redirect()->route('system-settings.banks.show', $bank->id)
            ->with('success', 'Bank updated successfully.');
    }

    public function destroy($id)
    {
        $bank = NexcorSystemBank::findOrFail($id);
        $bank->delete();
        return redirect()->route('system-settings.banks.index')
            ->with('success', 'Bank deleted successfully.');
    }

    public function toggle($id)
    {
        $bank = NexcorSystemBank::findOrFail($id);
        $bank->update(['is_active' => !$bank->is_active]);
        return redirect()->back()->with('success', 'Bank status updated.');
    }

    private function uploadLogo($file, $code)
    {
        $dir = base_path('../uploads/banks');
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }

        $ext = $file->getClientOriginalExtension() ?: 'png';
        $filename = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $code ?: 'bank')) . '_' . time() . '.' . $ext;
        $file->move($dir, $filename);

        return 'uploads/banks/' . $filename;
    }
}