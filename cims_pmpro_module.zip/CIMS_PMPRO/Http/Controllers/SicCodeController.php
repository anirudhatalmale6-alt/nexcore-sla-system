<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSicCode;

class SicCodeController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSicCode::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('sic_code', 'like', "%{$s}%")
                  ->orWhere('description', 'like', "%{$s}%")
                  ->orWhere('section_code', 'like', "%{$s}%")
                  ->orWhere('section_name', 'like', "%{$s}%")
                  ->orWhere('profit_code', 'like', "%{$s}%")
                  ->orWhere('loss_code', 'like', "%{$s}%");
            });
        }

        if ($request->filled('section')) {
            $query->where('section_code', $request->section);
        }

        $sicCodes = $query->orderBy('sic_code')
            ->paginate(25)
            ->appends($request->only(['search', 'section']));

        $stats = [
            'total' => NexcorSicCode::count(),
            'active' => NexcorSicCode::where('is_active', true)->count(),
            'inactive' => NexcorSicCode::where('is_active', false)->count(),
            'sections' => NexcorSicCode::distinct('section_code')->count('section_code'),
        ];

        $sections = NexcorSicCode::select('section_code', 'section_name')
            ->distinct()
            ->orderBy('section_code')
            ->get();

        return view('cims_pmpro::sic-codes.index', compact('sicCodes', 'stats', 'sections'));
    }

    public function create()
    {
        $sections = NexcorSicCode::select('section_code', 'section_name')
            ->distinct()
            ->orderBy('section_code')
            ->get();
        return view('cims_pmpro::sic-codes.form', compact('sections'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'sic_code' => 'required|string|max:10|unique:nexcore_sic_codes,sic_code',
            'description' => 'required|string|max:500',
            'section_code' => 'required|string|max:10',
            'section_name' => 'required|string|max:255',
            'profit_code' => 'nullable|string|max:10',
            'loss_code' => 'nullable|string|max:10',
        ]);

        NexcorSicCode::create([
            'sic_code' => $request->sic_code,
            'description' => $request->description,
            'section_code' => $request->section_code,
            'section_name' => $request->section_name,
            'profit_code' => $request->profit_code,
            'loss_code' => $request->loss_code,
            'is_active' => true,
        ]);

        return redirect()->route('system-settings.sic-codes.index')
            ->with('success', 'SIC Code created successfully.');
    }

    public function show($id)
    {
        $sicCode = NexcorSicCode::findOrFail($id);
        $linkedIndustries = $sicCode->industries()->where('is_active', true)->get();
        return view('cims_pmpro::sic-codes.show', compact('sicCode', 'linkedIndustries'));
    }

    public function edit($id)
    {
        $sicCode = NexcorSicCode::findOrFail($id);
        $sections = NexcorSicCode::select('section_code', 'section_name')
            ->distinct()
            ->orderBy('section_code')
            ->get();
        return view('cims_pmpro::sic-codes.form', compact('sicCode', 'sections'));
    }

    public function update(Request $request, $id)
    {
        $sicCode = NexcorSicCode::findOrFail($id);

        $request->validate([
            'sic_code' => 'required|string|max:10|unique:nexcore_sic_codes,sic_code,'.$id,
            'description' => 'required|string|max:500',
            'section_code' => 'required|string|max:10',
            'section_name' => 'required|string|max:255',
            'profit_code' => 'nullable|string|max:10',
            'loss_code' => 'nullable|string|max:10',
        ]);

        $sicCode->update([
            'sic_code' => $request->sic_code,
            'description' => $request->description,
            'section_code' => $request->section_code,
            'section_name' => $request->section_name,
            'profit_code' => $request->profit_code,
            'loss_code' => $request->loss_code,
            'is_active' => $request->boolean('is_active', true),
        ]);

        return redirect()->route('system-settings.sic-codes.show', $sicCode->id)
            ->with('success', 'SIC Code updated successfully.');
    }

    public function destroy($id)
    {
        $sicCode = NexcorSicCode::findOrFail($id);
        $sicCode->delete();
        return redirect()->route('system-settings.sic-codes.index')
            ->with('success', 'SIC Code deleted successfully.');
    }

    public function toggle($id)
    {
        $sicCode = NexcorSicCode::findOrFail($id);
        $sicCode->update(['is_active' => !$sicCode->is_active]);
        return redirect()->back()->with('success', 'SIC Code status updated.');
    }
}
