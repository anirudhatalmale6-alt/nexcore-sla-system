<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\PmproAddressMain;
use Modules\CIMS_PMPRO\Models\PmproAddressSecondary;
use Modules\CIMS_PMPRO\Models\PmproProvince;
use Modules\CIMS_PMPRO\Models\PmproCity;
use Modules\CIMS_PMPRO\Models\PmproSuburb;

class AddressController extends Controller
{
    public function index(Request $request)
    {
        $query = PmproAddressMain::with(['province', 'suburb', 'localMunicipality', 'metro']);

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('street_name', 'like', "%{$s}%")
                  ->orWhere('complex_name', 'like', "%{$s}%")
                  ->orWhere('city', 'like', "%{$s}%")
                  ->orWhere('postal_code', 'like', "%{$s}%")
                  ->orWhere('google_formatted_address', 'like', "%{$s}%");
            });
        }

        if ($request->filled('province_id')) {
            $query->where('province_id', $request->province_id);
        }

        if ($request->filled('category')) {
            $query->where('address_category', $request->category);
        }

        if ($request->filled('status')) {
            $query->where('is_active', $request->status === 'active');
        }

        $addresses = $query->orderBy('created_at', 'desc')->paginate(10);

        $stats = [
            'total_addresses' => PmproAddressMain::count(),
            'active_addresses' => PmproAddressMain::where('is_active', true)->count(),
            'inactive_addresses' => PmproAddressMain::where('is_active', false)->count(),
            'residential' => PmproAddressMain::where('address_category', 'Residential')->count(),
            'commercial' => PmproAddressMain::where('address_category', 'Commercial')->count(),
            'industrial' => PmproAddressMain::where('address_category', 'Industrial')->count(),
        ];

        $provinces = PmproProvince::where('is_active', true)->orderBy('name')->get();

        return view('cims_pmpro::addresses.index', compact('addresses', 'stats', 'provinces'));
    }

    public function create()
    {
        $provinces = PmproProvince::where('is_active', true)->orderBy('name')->get();
        return view('cims_pmpro::addresses.form', compact('provinces'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'street_number' => 'required|string|max:20',
            'street_name' => 'required|string|max:255',
            'city' => 'required|string|max:255',
            'postal_code' => 'required|string|max:10',
            'province_id' => 'required|exists:pmpro_provinces,id',
            'address_category' => 'required|in:Residential,Commercial,Industrial,Agricultural,Mixed Use',
        ]);

        if (!$request->input('force_create')) {
            $duplicate = $this->findDuplicate($request);
            if ($duplicate) {
                $provinces = PmproProvince::where('is_active', true)->orderBy('name')->get();
                return view('cims_pmpro::addresses.form', compact('provinces'))
                    ->with('duplicate', $duplicate)
                    ->with('oldInput', $request->all());
            }
        }

        $address = PmproAddressMain::create(array_merge(
            $request->only([
                'unit_number', 'complex_name', 'street_number', 'street_name',
                'suburb_id', 'city', 'postal_code', 'province_id', 'municipality_id',
                'ward_id', 'country', 'latitude', 'longitude',
                'google_formatted_address', 'address_category',
            ]),
            [
                'is_active' => true,
                'country' => $request->input('country', 'ZA'),
                'created_by' => auth()->id(),
                'updated_by' => auth()->id(),
            ]
        ));

        if ($request->hasAny(['floor_level', 'building_name', 'estate_name', 'farm_name', 'erf_number', 'sg_code'])) {
            PmproAddressSecondary::create(array_merge(
                $request->only([
                    'floor_level', 'building_name', 'estate_name', 'section_number',
                    'farm_name', 'farm_number', 'stand_number', 'erf_number',
                    'sg_code', 'municipal_account_number', 'plus_code', 'what3words',
                    'google_place_id', 'map_url', 'address_source',
                ]),
                ['address_id' => $address->id]
            ));
        }

        return redirect()->route('pmpro.addresses.index')
            ->with('success', 'Address created successfully.');
    }

    private function findDuplicate(Request $request)
    {
        $googlePlaceId = $request->input('google_place_id');
        if ($googlePlaceId) {
            $match = PmproAddressMain::whereHas('secondary', function ($q) use ($googlePlaceId) {
                $q->where('google_place_id', $googlePlaceId);
            })->with(['province', 'suburb'])->first();
            if ($match) return $match;
        }

        $query = PmproAddressMain::where('street_number', $request->input('street_number'))
            ->where('street_name', $request->input('street_name'));

        $unit = $request->input('unit_number');
        if ($unit) {
            $query->where('unit_number', $unit);
        } else {
            $query->where(function ($q) {
                $q->whereNull('unit_number')->orWhere('unit_number', '');
            });
        }

        $complex = $request->input('complex_name');
        if ($complex) {
            $query->where('complex_name', $complex);
        } else {
            $query->where(function ($q) {
                $q->whereNull('complex_name')->orWhere('complex_name', '');
            });
        }

        $suburbId = $request->input('suburb_id');
        if ($suburbId) {
            $query->where('suburb_id', $suburbId);
        }

        return $query->with(['province', 'suburb'])->first();
    }

    public function show($id)
    {
        $address = PmproAddressMain::with(['province', 'suburb', 'localMunicipality', 'metro', 'ward', 'secondary', 'links'])
            ->findOrFail($id);
        return view('cims_pmpro::addresses.show', compact('address'));
    }

    public function edit($id)
    {
        $address = PmproAddressMain::with('secondary')->findOrFail($id);
        $provinces = PmproProvince::where('is_active', true)->orderBy('name')->get();
        return view('cims_pmpro::addresses.form', compact('address', 'provinces'));
    }

    public function update(Request $request, $id)
    {
        $address = PmproAddressMain::findOrFail($id);

        $request->validate([
            'street_number' => 'required|string|max:20',
            'street_name' => 'required|string|max:255',
            'city' => 'required|string|max:255',
            'postal_code' => 'required|string|max:10',
            'province_id' => 'required|exists:pmpro_provinces,id',
            'address_category' => 'required|in:Residential,Commercial,Industrial,Agricultural,Mixed Use',
        ]);

        $address->update(array_merge(
            $request->only([
                'unit_number', 'complex_name', 'street_number', 'street_name',
                'suburb_id', 'city', 'postal_code', 'province_id', 'municipality_id',
                'ward_id', 'country', 'latitude', 'longitude',
                'google_formatted_address', 'address_category', 'is_active',
            ]),
            ['updated_by' => auth()->id()]
        ));

        $secondaryData = $request->only([
            'floor_level', 'building_name', 'estate_name', 'section_number',
            'farm_name', 'farm_number', 'stand_number', 'erf_number',
            'sg_code', 'municipal_account_number', 'plus_code', 'what3words',
            'google_place_id', 'map_url', 'address_source', 'is_verified', 'verified_date',
        ]);

        if (array_filter($secondaryData)) {
            PmproAddressSecondary::updateOrCreate(
                ['address_id' => $address->id],
                $secondaryData
            );
        }

        return redirect()->route('pmpro.addresses.index')
            ->with('success', 'Address updated successfully.');
    }

    public function destroy($id)
    {
        $address = PmproAddressMain::findOrFail($id);
        $address->delete();
        return redirect()->route('pmpro.addresses.index')
            ->with('success', 'Address archived successfully.');
    }

    public function toggle($id)
    {
        $address = PmproAddressMain::findOrFail($id);
        $address->update(['is_active' => !$address->is_active]);
        return redirect()->back()->with('success', 'Address status updated.');
    }

    public function restore($id)
    {
        $address = PmproAddressMain::withTrashed()->findOrFail($id);
        $address->restore();
        return redirect()->route('pmpro.addresses.index')
            ->with('success', 'Address restored successfully.');
    }

    public function forceDelete($id)
    {
        $address = PmproAddressMain::withTrashed()->findOrFail($id);
        $address->secondary()->delete();
        $address->links()->delete();
        $address->forceDelete();
        return redirect()->route('pmpro.addresses.index')
            ->with('success', 'Address permanently deleted.');
    }
}
