<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemEducation;

class EducationController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemEducation::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        $educationLevels = $query->orderBy('sort_order')->paginate(20);

        $stats = [
            'total' => NexcorSystemEducation::count(),
            'active' => NexcorSystemEducation::where('is_active', true)->count(),
            'inactive' => NexcorSystemEducation::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::education.index', compact('educationLevels', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::education.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
            'sort_order' => 'nullable|integer|min:0',
        ]);

        NexcorSystemEducation::create([
            'name' => $request->name,
            'code' => $request->code,
            'sort_order' => $request->sort_order ?? 0,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.education.index')
            ->with('success', 'Education level created successfully.');
    }

    public function show($id)
    {
        $education = NexcorSystemEducation::findOrFail($id);
        return view('cims_pmpro::education.show', compact('education'));
    }

    public function edit($id)
    {
        $education = NexcorSystemEducation::findOrFail($id);
        return view('cims_pmpro::education.form', compact('education'));
    }

    public function update(Request $request, $id)
    {
        $education = NexcorSystemEducation::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
            'sort_order' => 'nullable|integer|min:0',
        ]);

        $education->update([
            'name' => $request->name,
            'code' => $request->code,
            'sort_order' => $request->sort_order ?? 0,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.education.show', $education->id)
            ->with('success', 'Education level updated successfully.');
    }

    public function destroy($id)
    {
        $education = NexcorSystemEducation::findOrFail($id);
        $education->delete();
        return redirect()->route('system-settings.education.index')
            ->with('success', 'Education level deleted successfully.');
    }

    public function toggle($id)
    {
        $education = NexcorSystemEducation::findOrFail($id);
        $education->update(['is_active' => !$education->is_active]);
        return redirect()->back()->with('success', 'Education level status updated.');
    }
}
