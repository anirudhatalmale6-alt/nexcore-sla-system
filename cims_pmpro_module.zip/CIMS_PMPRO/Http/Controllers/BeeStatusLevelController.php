<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemBeeStatusLevel;

class BeeStatusLevelController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemBeeStatusLevel::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        $beeStatusLevels = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemBeeStatusLevel::count(),
            'active' => NexcorSystemBeeStatusLevel::where('is_active', true)->count(),
            'inactive' => NexcorSystemBeeStatusLevel::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::bee-status-levels.index', compact('beeStatusLevels', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::bee-status-levels.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        NexcorSystemBeeStatusLevel::create([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.bee-status-levels.index')
            ->with('success', 'BEE Status Level created successfully.');
    }

    public function show($id)
    {
        $beeStatusLevel = NexcorSystemBeeStatusLevel::findOrFail($id);
        return view('cims_pmpro::bee-status-levels.show', compact('beeStatusLevel'));
    }

    public function edit($id)
    {
        $beeStatusLevel = NexcorSystemBeeStatusLevel::findOrFail($id);
        return view('cims_pmpro::bee-status-levels.form', compact('beeStatusLevel'));
    }

    public function update(Request $request, $id)
    {
        $beeStatusLevel = NexcorSystemBeeStatusLevel::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        $beeStatusLevel->update([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.bee-status-levels.show', $beeStatusLevel->id)
            ->with('success', 'BEE Status Level updated successfully.');
    }

    public function destroy($id)
    {
        $beeStatusLevel = NexcorSystemBeeStatusLevel::findOrFail($id);
        $beeStatusLevel->delete();
        return redirect()->route('system-settings.bee-status-levels.index')
            ->with('success', 'BEE Status Level deleted successfully.');
    }

    public function toggle($id)
    {
        $beeStatusLevel = NexcorSystemBeeStatusLevel::findOrFail($id);
        $beeStatusLevel->update(['is_active' => !$beeStatusLevel->is_active]);
        return redirect()->back()->with('success', 'BEE Status Level status updated.');
    }
}