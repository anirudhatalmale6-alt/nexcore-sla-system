<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemEmploymentStatus;

class EmploymentStatusController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemEmploymentStatus::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        $employmentStatuses = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemEmploymentStatus::count(),
            'active' => NexcorSystemEmploymentStatus::where('is_active', true)->count(),
            'inactive' => NexcorSystemEmploymentStatus::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::employment-statuses.index', compact('employmentStatuses', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::employment-statuses.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        NexcorSystemEmploymentStatus::create([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.employment-statuses.index')
            ->with('success', 'Employment Status created successfully.');
    }

    public function show($id)
    {
        $employmentStatus = NexcorSystemEmploymentStatus::findOrFail($id);
        return view('cims_pmpro::employment-statuses.show', compact('employmentStatus'));
    }

    public function edit($id)
    {
        $employmentStatus = NexcorSystemEmploymentStatus::findOrFail($id);
        return view('cims_pmpro::employment-statuses.form', compact('employmentStatus'));
    }

    public function update(Request $request, $id)
    {
        $employmentStatus = NexcorSystemEmploymentStatus::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        $employmentStatus->update([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.employment-statuses.show', $employmentStatus->id)
            ->with('success', 'Employment Status updated successfully.');
    }

    public function destroy($id)
    {
        $employmentStatus = NexcorSystemEmploymentStatus::findOrFail($id);
        $employmentStatus->delete();
        return redirect()->route('system-settings.employment-statuses.index')
            ->with('success', 'Employment Status deleted successfully.');
    }

    public function toggle($id)
    {
        $employmentStatus = NexcorSystemEmploymentStatus::findOrFail($id);
        $employmentStatus->update(['is_active' => !$employmentStatus->is_active]);
        return redirect()->back()->with('success', 'Employment Status status updated.');
    }
}