<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemCompanyType;

class CompanyTypeController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemCompanyType::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        $companyTypes = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemCompanyType::count(),
            'active' => NexcorSystemCompanyType::where('is_active', true)->count(),
            'inactive' => NexcorSystemCompanyType::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::company-types.index', compact('companyTypes', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::company-types.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        NexcorSystemCompanyType::create([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.company-types.index')
            ->with('success', 'Company Type created successfully.');
    }

    public function show($id)
    {
        $companyType = NexcorSystemCompanyType::findOrFail($id);
        return view('cims_pmpro::company-types.show', compact('companyType'));
    }

    public function edit($id)
    {
        $companyType = NexcorSystemCompanyType::findOrFail($id);
        return view('cims_pmpro::company-types.form', compact('companyType'));
    }

    public function update(Request $request, $id)
    {
        $companyType = NexcorSystemCompanyType::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        $companyType->update([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.company-types.show', $companyType->id)
            ->with('success', 'Company Type updated successfully.');
    }

    public function destroy($id)
    {
        $companyType = NexcorSystemCompanyType::findOrFail($id);
        $companyType->delete();
        return redirect()->route('system-settings.company-types.index')
            ->with('success', 'Company Type deleted successfully.');
    }

    public function toggle($id)
    {
        $companyType = NexcorSystemCompanyType::findOrFail($id);
        $companyType->update(['is_active' => !$companyType->is_active]);
        return redirect()->back()->with('success', 'Company Type status updated.');
    }
}