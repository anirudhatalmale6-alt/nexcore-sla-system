<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\PmproLocalMunicipality;
use Modules\CIMS_PMPRO\Models\PmproDistrict;
use Modules\CIMS_PMPRO\Models\PmproProvince;

class LocalMunicipalityController extends Controller
{
    public function index(Request $request)
    {
        $query = PmproLocalMunicipality::with(['district', 'district.province']);

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        if ($request->filled('district_id')) {
            $query->where('district_id', $request->district_id);
        }

        if ($request->filled('province_id')) {
            $query->whereHas('district', function ($q) use ($request) {
                $q->where('province_id', $request->province_id);
            });
        }

        if ($request->filled('status')) {
            $query->where('is_active', $request->status === 'active');
        }

        $municipalities = $query->orderBy('name')->paginate(15);

        $stats = [
            'total' => PmproLocalMunicipality::count(),
            'active' => PmproLocalMunicipality::where('is_active', true)->count(),
            'inactive' => PmproLocalMunicipality::where('is_active', false)->count(),
        ];

        $provinces = PmproProvince::where('is_active', true)->orderBy('name')->get();
        $districts = PmproDistrict::where('is_active', true)->orderBy('name')->get();

        return view('cims_pmpro::local-municipalities.index', compact('municipalities', 'stats', 'provinces', 'districts'));
    }

    public function create()
    {
        $districts = PmproDistrict::with('province')->where('is_active', true)->orderBy('name')->get();
        return view('cims_pmpro::local-municipalities.form', compact('districts'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:200',
            'code' => 'nullable|string|max:10|unique:pmpro_local_municipalities,code',
            'district_id' => 'required|exists:pmpro_districts,id',
        ]);

        PmproLocalMunicipality::create([
            'name' => $request->name,
            'code' => $request->code ? strtoupper($request->code) : null,
            'district_id' => $request->district_id,
            'is_active' => true,
        ]);

        return redirect()->route('pmpro.local-municipalities.index')
            ->with('success', 'Local municipality created successfully.');
    }

    public function show($id)
    {
        $municipality = PmproLocalMunicipality::with(['district', 'district.province'])->findOrFail($id);
        $mainPlaces = $municipality->cities()->orderBy('name')->get();
        return view('cims_pmpro::local-municipalities.show', compact('municipality', 'mainPlaces'));
    }

    public function edit($id)
    {
        $municipality = PmproLocalMunicipality::findOrFail($id);
        $districts = PmproDistrict::with('province')->where('is_active', true)->orderBy('name')->get();
        return view('cims_pmpro::local-municipalities.form', compact('municipality', 'districts'));
    }

    public function update(Request $request, $id)
    {
        $municipality = PmproLocalMunicipality::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:200',
            'code' => 'nullable|string|max:10|unique:pmpro_local_municipalities,code,' . $id,
            'district_id' => 'required|exists:pmpro_districts,id',
        ]);

        $municipality->update([
            'name' => $request->name,
            'code' => $request->code ? strtoupper($request->code) : null,
            'district_id' => $request->district_id,
            'is_active' => $request->boolean('is_active', true),
        ]);

        return redirect()->route('pmpro.local-municipalities.index')
            ->with('success', 'Local municipality updated successfully.');
    }

    public function destroy($id)
    {
        $municipality = PmproLocalMunicipality::findOrFail($id);
        $municipality->delete();
        return redirect()->route('pmpro.local-municipalities.index')
            ->with('success', 'Local municipality deleted successfully.');
    }

    public function toggle($id)
    {
        $municipality = PmproLocalMunicipality::findOrFail($id);
        $municipality->update(['is_active' => !$municipality->is_active]);
        return redirect()->back()->with('success', 'Local municipality status updated.');
    }
}
