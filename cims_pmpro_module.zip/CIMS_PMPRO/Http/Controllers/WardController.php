<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\PmproWard;
use Modules\CIMS_PMPRO\Models\PmproMetro;
use Modules\CIMS_PMPRO\Models\PmproLocalMunicipality;

class WardController extends Controller
{
    public function index(Request $request)
    {
        $query = PmproWard::with(['metro', 'localMunicipality']);

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('code', 'like', "%{$s}%")
                  ->orWhere('ward_label', 'like', "%{$s}%")
                  ->orWhere('ward_id_official', 'like', "%{$s}%")
                  ->orWhere('ward_number', $s);
            });
        }

        if ($request->filled('metro_id')) {
            $query->where('metro_id', $request->metro_id);
        }

        if ($request->filled('local_municipality_id')) {
            $query->where('local_municipality_id', $request->local_municipality_id);
        }

        if ($request->filled('status')) {
            $query->where('is_active', $request->status === 'active');
        }

        $wards = $query->orderBy('ward_number')->paginate(20);

        $stats = [
            'total' => PmproWard::count(),
            'active' => PmproWard::where('is_active', true)->count(),
            'inactive' => PmproWard::where('is_active', false)->count(),
        ];

        $metros = PmproMetro::where('is_active', true)->orderBy('name')->get();

        return view('cims_pmpro::wards.index', compact('wards', 'stats', 'metros'));
    }

    public function create(Request $request)
    {
        $metros = PmproMetro::where('is_active', true)->orderBy('name')->get();
        $localMunicipalities = PmproLocalMunicipality::with('district')->where('is_active', true)->orderBy('name')->get();
        $prefill = [
            'metro_id' => $request->metro_id,
            'local_municipality_id' => $request->local_municipality_id,
        ];
        return view('cims_pmpro::wards.form', compact('metros', 'localMunicipalities', 'prefill'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'ward_number' => 'required|integer|min:1',
            'code' => 'nullable|string|max:20',
        ]);

        $ward = PmproWard::create([
            'metro_id' => $request->metro_id ?: null,
            'local_municipality_id' => $request->local_municipality_id ?: null,
            'ward_number' => $request->ward_number,
            'code' => $request->code,
            'ward_id_official' => $request->ward_id_official,
            'ward_label' => $request->ward_label,
            'municipality_name' => $request->municipality_name,
            'district_name' => $request->district_name,
            'district_code' => $request->district_code,
            'province_name' => $request->province_name,
            'cat_b' => $request->cat_b,
            'demarcation_date' => $request->demarcation_date,
            'objectid' => $request->objectid,
            'objectid_1' => $request->objectid_1,
            'shape_length' => $request->shape_length,
            'shape_area' => $request->shape_area,
            'shape_perimeter' => $request->shape_perimeter,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        if ($request->metro_id) {
            return redirect()->route('pmpro.metros.show', $request->metro_id)
                ->with('success', 'Ward ' . $ward->ward_number . ' created successfully.');
        } elseif ($request->local_municipality_id) {
            return redirect()->route('pmpro.local-municipalities.show', $request->local_municipality_id)
                ->with('success', 'Ward ' . $ward->ward_number . ' created successfully.');
        }

        return redirect()->route('pmpro.wards.index')
            ->with('success', 'Ward created successfully.');
    }

    public function show($id)
    {
        $ward = PmproWard::with(['metro', 'metro.province', 'localMunicipality', 'localMunicipality.district', 'localMunicipality.district.province'])->findOrFail($id);
        return view('cims_pmpro::wards.show', compact('ward'));
    }

    public function edit($id)
    {
        $ward = PmproWard::findOrFail($id);
        $metros = PmproMetro::where('is_active', true)->orderBy('name')->get();
        $localMunicipalities = PmproLocalMunicipality::with('district')->where('is_active', true)->orderBy('name')->get();
        return view('cims_pmpro::wards.form', compact('ward', 'metros', 'localMunicipalities'));
    }

    public function update(Request $request, $id)
    {
        $ward = PmproWard::findOrFail($id);

        $request->validate([
            'ward_number' => 'required|integer|min:1',
            'code' => 'nullable|string|max:20',
        ]);

        $ward->update([
            'metro_id' => $request->metro_id ?: null,
            'local_municipality_id' => $request->local_municipality_id ?: null,
            'ward_number' => $request->ward_number,
            'code' => $request->code,
            'ward_id_official' => $request->ward_id_official,
            'ward_label' => $request->ward_label,
            'municipality_name' => $request->municipality_name,
            'district_name' => $request->district_name,
            'district_code' => $request->district_code,
            'province_name' => $request->province_name,
            'cat_b' => $request->cat_b,
            'demarcation_date' => $request->demarcation_date,
            'objectid' => $request->objectid,
            'objectid_1' => $request->objectid_1,
            'shape_length' => $request->shape_length,
            'shape_area' => $request->shape_area,
            'shape_perimeter' => $request->shape_perimeter,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('pmpro.wards.show', $ward->id)
            ->with('success', 'Ward ' . $ward->ward_number . ' updated successfully.');
    }

    public function destroy($id)
    {
        $ward = PmproWard::findOrFail($id);
        $metroId = $ward->metro_id;
        $lmId = $ward->local_municipality_id;
        $ward->delete();

        if ($metroId) {
            return redirect()->route('pmpro.metros.show', $metroId)
                ->with('success', 'Ward deleted successfully.');
        } elseif ($lmId) {
            return redirect()->route('pmpro.local-municipalities.show', $lmId)
                ->with('success', 'Ward deleted successfully.');
        }

        return redirect()->route('pmpro.wards.index')
            ->with('success', 'Ward deleted successfully.');
    }

    public function toggle($id)
    {
        $ward = PmproWard::findOrFail($id);
        $ward->update(['is_active' => !$ward->is_active]);
        return redirect()->back()->with('success', 'Ward ' . $ward->ward_number . ' status updated.');
    }
}
