<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemReligion;
use Modules\CIMS_PMPRO\Models\PmproCountry;

class ReligionController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemReligion::with('country');

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where('name', 'like', "%{$s}%");
        }

        if ($request->filled('country_id')) {
            $query->where('country_id', $request->country_id);
        }

        $religions = $query->orderBy('percentage', 'desc')->paginate(20);

        $stats = [
            'total' => NexcorSystemReligion::count(),
            'active' => NexcorSystemReligion::where('is_active', true)->count(),
            'inactive' => NexcorSystemReligion::where('is_active', false)->count(),
        ];

        $countries = PmproCountry::where('is_active', true)->orderBy('name')->get();

        return view('cims_pmpro::religions.index', compact('religions', 'stats', 'countries'));
    }

    public function create()
    {
        $countries = PmproCountry::where('is_active', true)->orderBy('name')->get();
        return view('cims_pmpro::religions.form', compact('countries'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'country_id' => 'required|exists:pmpro_countries,id',
            'percentage' => 'nullable|numeric|min:0|max:100',
        ]);

        NexcorSystemReligion::create([
            'country_id' => $request->country_id,
            'name' => $request->name,
            'percentage' => $request->percentage,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.religions.index')
            ->with('success', 'Religion created successfully.');
    }

    public function show($id)
    {
        $religion = NexcorSystemReligion::with('country')->findOrFail($id);
        return view('cims_pmpro::religions.show', compact('religion'));
    }

    public function edit($id)
    {
        $religion = NexcorSystemReligion::findOrFail($id);
        $countries = PmproCountry::where('is_active', true)->orderBy('name')->get();
        return view('cims_pmpro::religions.form', compact('religion', 'countries'));
    }

    public function update(Request $request, $id)
    {
        $religion = NexcorSystemReligion::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'country_id' => 'required|exists:pmpro_countries,id',
            'percentage' => 'nullable|numeric|min:0|max:100',
        ]);

        $religion->update([
            'country_id' => $request->country_id,
            'name' => $request->name,
            'percentage' => $request->percentage,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.religions.show', $religion->id)
            ->with('success', 'Religion updated successfully.');
    }

    public function destroy($id)
    {
        $religion = NexcorSystemReligion::findOrFail($id);
        $religion->delete();
        return redirect()->route('system-settings.religions.index')
            ->with('success', 'Religion deleted successfully.');
    }

    public function toggle($id)
    {
        $religion = NexcorSystemReligion::findOrFail($id);
        $religion->update(['is_active' => !$religion->is_active]);
        return redirect()->back()->with('success', 'Religion status updated.');
    }
}
