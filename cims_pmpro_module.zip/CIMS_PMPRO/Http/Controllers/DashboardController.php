<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Modules\CIMS_PMPRO\Models\PmproAddressMain;
use Modules\CIMS_PMPRO\Models\PmproProvince;
use Modules\CIMS_PMPRO\Models\PmproSuburb;
use Modules\CIMS_PMPRO\Models\PmproCity;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'total_addresses' => PmproAddressMain::count(),
            'active_addresses' => PmproAddressMain::where('is_active', true)->count(),
            'provinces' => PmproProvince::where('is_active', true)->count(),
            'cities' => PmproCity::where('is_active', true)->count(),
            'suburbs' => PmproSuburb::where('is_active', true)->count(),
        ];

        return view('cims_pmpro::addresses.index', compact('stats'));
    }
}
