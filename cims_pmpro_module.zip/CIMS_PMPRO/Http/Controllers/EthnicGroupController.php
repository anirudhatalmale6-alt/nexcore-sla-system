<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemEthnicGroup;
use Modules\CIMS_PMPRO\Models\PmproCountry;

class EthnicGroupController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemEthnicGroup::with('country');

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where('name', 'like', "%{$s}%");
        }

        if ($request->filled('country_id')) {
            $query->where('country_id', $request->country_id);
        }

        $ethnicGroups = $query->orderBy('percentage', 'desc')->paginate(20);

        $stats = [
            'total' => NexcorSystemEthnicGroup::count(),
            'active' => NexcorSystemEthnicGroup::where('is_active', true)->count(),
            'inactive' => NexcorSystemEthnicGroup::where('is_active', false)->count(),
        ];

        $countries = PmproCountry::where('is_active', true)->orderBy('name')->get();

        return view('cims_pmpro::ethnic-groups.index', compact('ethnicGroups', 'stats', 'countries'));
    }

    public function create()
    {
        $countries = PmproCountry::where('is_active', true)->orderBy('name')->get();
        return view('cims_pmpro::ethnic-groups.form', compact('countries'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'country_id' => 'required|exists:pmpro_countries,id',
            'percentage' => 'nullable|numeric|min:0|max:100',
        ]);

        NexcorSystemEthnicGroup::create([
            'country_id' => $request->country_id,
            'name' => $request->name,
            'percentage' => $request->percentage,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.ethnic-groups.index')
            ->with('success', 'Ethnic group created successfully.');
    }

    public function show($id)
    {
        $ethnicGroup = NexcorSystemEthnicGroup::with('country')->findOrFail($id);
        return view('cims_pmpro::ethnic-groups.show', compact('ethnicGroup'));
    }

    public function edit($id)
    {
        $ethnicGroup = NexcorSystemEthnicGroup::findOrFail($id);
        $countries = PmproCountry::where('is_active', true)->orderBy('name')->get();
        return view('cims_pmpro::ethnic-groups.form', compact('ethnicGroup', 'countries'));
    }

    public function update(Request $request, $id)
    {
        $ethnicGroup = NexcorSystemEthnicGroup::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'country_id' => 'required|exists:pmpro_countries,id',
            'percentage' => 'nullable|numeric|min:0|max:100',
        ]);

        $ethnicGroup->update([
            'country_id' => $request->country_id,
            'name' => $request->name,
            'percentage' => $request->percentage,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.ethnic-groups.show', $ethnicGroup->id)
            ->with('success', 'Ethnic group updated successfully.');
    }

    public function destroy($id)
    {
        $ethnicGroup = NexcorSystemEthnicGroup::findOrFail($id);
        $ethnicGroup->delete();
        return redirect()->route('system-settings.ethnic-groups.index')
            ->with('success', 'Ethnic group deleted successfully.');
    }

    public function toggle($id)
    {
        $ethnicGroup = NexcorSystemEthnicGroup::findOrFail($id);
        $ethnicGroup->update(['is_active' => !$ethnicGroup->is_active]);
        return redirect()->back()->with('success', 'Ethnic group status updated.');
    }
}
