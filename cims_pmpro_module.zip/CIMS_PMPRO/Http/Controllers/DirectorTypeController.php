<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemDirectorType;

class DirectorTypeController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemDirectorType::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        $directorTypes = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemDirectorType::count(),
            'active' => NexcorSystemDirectorType::where('is_active', true)->count(),
            'inactive' => NexcorSystemDirectorType::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::director-types.index', compact('directorTypes', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::director-types.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        NexcorSystemDirectorType::create([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.director-types.index')
            ->with('success', 'Director type created successfully.');
    }

    public function show($id)
    {
        $directorType = NexcorSystemDirectorType::findOrFail($id);
        return view('cims_pmpro::director-types.show', compact('directorType'));
    }

    public function edit($id)
    {
        $directorType = NexcorSystemDirectorType::findOrFail($id);
        return view('cims_pmpro::director-types.form', compact('directorType'));
    }

    public function update(Request $request, $id)
    {
        $directorType = NexcorSystemDirectorType::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        $directorType->update([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.director-types.show', $directorType->id)
            ->with('success', 'Director type updated successfully.');
    }

    public function destroy($id)
    {
        $directorType = NexcorSystemDirectorType::findOrFail($id);
        $directorType->delete();
        return redirect()->route('system-settings.director-types.index')
            ->with('success', 'Director type deleted successfully.');
    }

    public function toggle($id)
    {
        $directorType = NexcorSystemDirectorType::findOrFail($id);
        $directorType->update(['is_active' => !$directorType->is_active]);
        return redirect()->back()->with('success', 'Director type status updated.');
    }
}
