<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemTelephoneType;

class TelephoneTypeController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemTelephoneType::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        $telephoneTypes = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemTelephoneType::count(),
            'active' => NexcorSystemTelephoneType::where('is_active', true)->count(),
            'inactive' => NexcorSystemTelephoneType::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::telephone-types.index', compact('telephoneTypes', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::telephone-types.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        NexcorSystemTelephoneType::create([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.telephone-types.index')
            ->with('success', 'Telephone type created successfully.');
    }

    public function show($id)
    {
        $telephoneType = NexcorSystemTelephoneType::findOrFail($id);
        return view('cims_pmpro::telephone-types.show', compact('telephoneType'));
    }

    public function edit($id)
    {
        $telephoneType = NexcorSystemTelephoneType::findOrFail($id);
        return view('cims_pmpro::telephone-types.form', compact('telephoneType'));
    }

    public function update(Request $request, $id)
    {
        $telephoneType = NexcorSystemTelephoneType::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        $telephoneType->update([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.telephone-types.show', $telephoneType->id)
            ->with('success', 'Telephone type updated successfully.');
    }

    public function destroy($id)
    {
        $telephoneType = NexcorSystemTelephoneType::findOrFail($id);
        $telephoneType->delete();
        return redirect()->route('system-settings.telephone-types.index')
            ->with('success', 'Telephone type deleted successfully.');
    }

    public function toggle($id)
    {
        $telephoneType = NexcorSystemTelephoneType::findOrFail($id);
        $telephoneType->update(['is_active' => !$telephoneType->is_active]);
        return redirect()->back()->with('success', 'Telephone type status updated.');
    }
}
