<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\PmproMunicipalityType;

class MunicipalityTypeController extends Controller
{
    public function index(Request $request)
    {
        $query = PmproMunicipalityType::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%")
                  ->orWhere('description', 'like', "%{$s}%");
            });
        }

        $types = $query->orderBy('name')->paginate(15);

        $stats = [
            'total' => PmproMunicipalityType::count(),
            'active' => PmproMunicipalityType::where('is_active', true)->count(),
            'inactive' => PmproMunicipalityType::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::municipality-types.index', compact('types', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::municipality-types.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100|unique:pmpro_municipality_types,name',
            'code' => 'required|string|max:5|unique:pmpro_municipality_types,code',
            'description' => 'nullable|string|max:500',
        ]);

        PmproMunicipalityType::create([
            'name' => $request->name,
            'code' => strtoupper($request->code),
            'description' => $request->description,
            'is_active' => true,
        ]);

        return redirect()->route('pmpro.municipality-types.index')
            ->with('success', 'Municipality type created successfully.');
    }

    public function show($id)
    {
        $type = PmproMunicipalityType::findOrFail($id);
        return view('cims_pmpro::municipality-types.show', compact('type'));
    }

    public function edit($id)
    {
        $type = PmproMunicipalityType::findOrFail($id);
        return view('cims_pmpro::municipality-types.form', compact('type'));
    }

    public function update(Request $request, $id)
    {
        $type = PmproMunicipalityType::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100|unique:pmpro_municipality_types,name,' . $id,
            'code' => 'required|string|max:5|unique:pmpro_municipality_types,code,' . $id,
            'description' => 'nullable|string|max:500',
        ]);

        $type->update([
            'name' => $request->name,
            'code' => strtoupper($request->code),
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
        ]);

        return redirect()->route('pmpro.municipality-types.index')
            ->with('success', 'Municipality type updated successfully.');
    }

    public function destroy($id)
    {
        $type = PmproMunicipalityType::findOrFail($id);
        $type->delete();
        return redirect()->route('pmpro.municipality-types.index')
            ->with('success', 'Municipality type deleted successfully.');
    }

    public function toggle($id)
    {
        $type = PmproMunicipalityType::findOrFail($id);
        $type->update(['is_active' => !$type->is_active]);
        return redirect()->back()->with('success', 'Municipality type status updated.');
    }
}
