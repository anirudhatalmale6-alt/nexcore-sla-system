<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemGender;

class GenderController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemGender::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        $genders = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemGender::count(),
            'active' => NexcorSystemGender::where('is_active', true)->count(),
            'inactive' => NexcorSystemGender::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::genders.index', compact('genders', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::genders.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:50',
            'code' => 'nullable|string|max:10',
        ]);

        NexcorSystemGender::create([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.genders.index')
            ->with('success', 'Gender created successfully.');
    }

    public function show($id)
    {
        $gender = NexcorSystemGender::findOrFail($id);
        return view('cims_pmpro::genders.show', compact('gender'));
    }

    public function edit($id)
    {
        $gender = NexcorSystemGender::findOrFail($id);
        return view('cims_pmpro::genders.form', compact('gender'));
    }

    public function update(Request $request, $id)
    {
        $gender = NexcorSystemGender::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:50',
            'code' => 'nullable|string|max:10',
        ]);

        $gender->update([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.genders.show', $gender->id)
            ->with('success', 'Gender updated successfully.');
    }

    public function destroy($id)
    {
        $gender = NexcorSystemGender::findOrFail($id);
        $gender->delete();
        return redirect()->route('system-settings.genders.index')
            ->with('success', 'Gender deleted successfully.');
    }

    public function toggle($id)
    {
        $gender = NexcorSystemGender::findOrFail($id);
        $gender->update(['is_active' => !$gender->is_active]);
        return redirect()->back()->with('success', 'Gender status updated.');
    }
}
