<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSysLanguage;
use Modules\CIMS_PMPRO\Models\PmproCountry;

class LanguageController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSysLanguage::with('country');

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('native_name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        if ($request->filled('status')) {
            $query->where('is_active', $request->status === 'active');
        }

        if ($request->filled('official')) {
            $query->where('is_official', $request->official === 'yes');
        }

        if ($request->filled('country_id')) {
            $query->where('country_id', $request->country_id);
        }

        $languages = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSysLanguage::count(),
            'active' => NexcorSysLanguage::where('is_active', true)->count(),
            'official' => NexcorSysLanguage::where('is_official', true)->count(),
            'inactive' => NexcorSysLanguage::where('is_active', false)->count(),
        ];

        $countries = PmproCountry::where('is_active', true)->orderBy('name')->get();

        return view('cims_pmpro::languages.index', compact('languages', 'stats', 'countries'));
    }

    public function create()
    {
        $countries = PmproCountry::where('is_active', true)->orderBy('name')->get();
        return view('cims_pmpro::languages.form', compact('countries'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100|unique:nexcor_sys_languages,name',
            'code' => 'required|string|max:10|unique:nexcor_sys_languages,code',
            'lang_image' => 'nullable|image|max:2048',
        ]);

        $data = [
            'country_id' => $request->country_id ?: null,
            'name' => $request->name,
            'native_name' => $request->native_name,
            'code' => strtolower($request->code),
            'description' => $request->description,
            'caption' => $request->caption,
            'is_official' => $request->boolean('is_official'),
            'is_active' => true,
            'is_deleted' => false,
        ];

        if ($request->hasFile('lang_image')) {
            $file = $request->file('lang_image');
            $filename = strtolower($request->code) . '_lang_' . time() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('uploads/languages'), $filename);
            $data['lang_image'] = 'uploads/languages/' . $filename;
        }

        NexcorSysLanguage::create($data);

        return redirect()->route('system-settings.languages.index')
            ->with('success', 'Language created successfully.');
    }

    public function show($id)
    {
        $language = NexcorSysLanguage::with('country')->findOrFail($id);
        return view('cims_pmpro::languages.show', compact('language'));
    }

    public function edit($id)
    {
        $language = NexcorSysLanguage::findOrFail($id);
        $countries = PmproCountry::where('is_active', true)->orderBy('name')->get();
        return view('cims_pmpro::languages.form', compact('language', 'countries'));
    }

    public function update(Request $request, $id)
    {
        $language = NexcorSysLanguage::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100|unique:nexcor_sys_languages,name,' . $id,
            'code' => 'required|string|max:10|unique:nexcor_sys_languages,code,' . $id,
            'lang_image' => 'nullable|image|max:2048',
        ]);

        $data = [
            'country_id' => $request->country_id ?: null,
            'name' => $request->name,
            'native_name' => $request->native_name,
            'code' => strtolower($request->code),
            'description' => $request->description,
            'caption' => $request->caption,
            'is_official' => $request->boolean('is_official'),
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ];

        if ($request->hasFile('lang_image')) {
            if ($language->lang_image && file_exists(public_path($language->lang_image))) {
                @unlink(public_path($language->lang_image));
            }
            $file = $request->file('lang_image');
            $filename = strtolower($request->code) . '_lang_' . time() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('uploads/languages'), $filename);
            $data['lang_image'] = 'uploads/languages/' . $filename;
        }

        $language->update($data);

        return redirect()->route('system-settings.languages.show', $language->id)
            ->with('success', 'Language updated successfully.');
    }

    public function destroy($id)
    {
        $language = NexcorSysLanguage::findOrFail($id);
        if ($language->lang_image && file_exists(public_path($language->lang_image))) {
            @unlink(public_path($language->lang_image));
        }
        $language->delete();
        return redirect()->route('system-settings.languages.index')
            ->with('success', 'Language deleted successfully.');
    }

    public function toggle($id)
    {
        $language = NexcorSysLanguage::findOrFail($id);
        $language->update(['is_active' => !$language->is_active]);
        return redirect()->back()->with('success', 'Language status updated.');
    }
}
