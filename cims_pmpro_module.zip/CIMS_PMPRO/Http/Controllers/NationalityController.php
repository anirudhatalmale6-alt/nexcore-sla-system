<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemNationality;
use Modules\CIMS_PMPRO\Models\PmproCountry;

class NationalityController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemNationality::with('country');

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%")
                  ->orWhereHas('country', function ($cq) use ($s) {
                      $cq->where('name', 'like', "%{$s}%");
                  });
            });
        }

        $nationalities = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemNationality::count(),
            'active' => NexcorSystemNationality::where('is_active', true)->count(),
            'inactive' => NexcorSystemNationality::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::nationalities.index', compact('nationalities', 'stats'));
    }

    public function create()
    {
        $countries = PmproCountry::where('is_active', true)->orderBy('name')->get();
        return view('cims_pmpro::nationalities.form', compact('countries'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
            'country_id' => 'nullable|exists:pmpro_countries,id',
        ]);

        NexcorSystemNationality::create([
            'name' => $request->name,
            'code' => $request->code,
            'country_id' => $request->country_id,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.nationalities.index')
            ->with('success', 'Nationality created successfully.');
    }

    public function show($id)
    {
        $nationality = NexcorSystemNationality::with('country')->findOrFail($id);
        return view('cims_pmpro::nationalities.show', compact('nationality'));
    }

    public function edit($id)
    {
        $nationality = NexcorSystemNationality::findOrFail($id);
        $countries = PmproCountry::where('is_active', true)->orderBy('name')->get();
        return view('cims_pmpro::nationalities.form', compact('nationality', 'countries'));
    }

    public function update(Request $request, $id)
    {
        $nationality = NexcorSystemNationality::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
            'country_id' => 'nullable|exists:pmpro_countries,id',
        ]);

        $nationality->update([
            'name' => $request->name,
            'code' => $request->code,
            'country_id' => $request->country_id,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.nationalities.show', $nationality->id)
            ->with('success', 'Nationality updated successfully.');
    }

    public function destroy($id)
    {
        $nationality = NexcorSystemNationality::findOrFail($id);
        $nationality->delete();
        return redirect()->route('system-settings.nationalities.index')
            ->with('success', 'Nationality deleted successfully.');
    }

    public function toggle($id)
    {
        $nationality = NexcorSystemNationality::findOrFail($id);
        $nationality->update(['is_active' => !$nationality->is_active]);
        return redirect()->back()->with('success', 'Nationality status updated.');
    }
}
