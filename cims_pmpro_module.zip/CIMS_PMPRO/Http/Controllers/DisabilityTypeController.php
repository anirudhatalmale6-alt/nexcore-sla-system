<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemDisabilityType;

class DisabilityTypeController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemDisabilityType::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        $disabilityTypes = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemDisabilityType::count(),
            'active' => NexcorSystemDisabilityType::where('is_active', true)->count(),
            'inactive' => NexcorSystemDisabilityType::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::disability-types.index', compact('disabilityTypes', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::disability-types.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        NexcorSystemDisabilityType::create([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.disability-types.index')
            ->with('success', 'Disability Type created successfully.');
    }

    public function show($id)
    {
        $disabilityType = NexcorSystemDisabilityType::findOrFail($id);
        return view('cims_pmpro::disability-types.show', compact('disabilityType'));
    }

    public function edit($id)
    {
        $disabilityType = NexcorSystemDisabilityType::findOrFail($id);
        return view('cims_pmpro::disability-types.form', compact('disabilityType'));
    }

    public function update(Request $request, $id)
    {
        $disabilityType = NexcorSystemDisabilityType::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        $disabilityType->update([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.disability-types.show', $disabilityType->id)
            ->with('success', 'Disability Type updated successfully.');
    }

    public function destroy($id)
    {
        $disabilityType = NexcorSystemDisabilityType::findOrFail($id);
        $disabilityType->delete();
        return redirect()->route('system-settings.disability-types.index')
            ->with('success', 'Disability Type deleted successfully.');
    }

    public function toggle($id)
    {
        $disabilityType = NexcorSystemDisabilityType::findOrFail($id);
        $disabilityType->update(['is_active' => !$disabilityType->is_active]);
        return redirect()->back()->with('success', 'Disability Type status updated.');
    }
}