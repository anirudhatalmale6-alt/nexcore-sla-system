<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemIndustry;
use Modules\CIMS_PMPRO\Models\NexcorSicCode;

class IndustryController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemIndustry::with('sicCode');

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%")
                  ->orWhereHas('sicCode', function ($sq) use ($s) {
                      $sq->where('sic_code', 'like', "%{$s}%")
                         ->orWhere('description', 'like', "%{$s}%")
                         ->orWhere('section_name', 'like', "%{$s}%");
                  });
            });
        }

        $industries = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemIndustry::count(),
            'active' => NexcorSystemIndustry::where('is_active', true)->count(),
            'inactive' => NexcorSystemIndustry::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::industries.index', compact('industries', 'stats'));
    }

    public function create()
    {
        $sicCodes = NexcorSicCode::where('is_active', true)
            ->orderBy('section_code')
            ->orderBy('sic_code')
            ->get();
        return view('cims_pmpro::industries.form', compact('sicCodes'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
            'sic_code_id' => 'nullable|exists:nexcore_sic_codes,id',
        ]);

        NexcorSystemIndustry::create([
            'name' => $request->name,
            'code' => $request->code,
            'sic_code_id' => $request->sic_code_id,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.industries.index')
            ->with('success', 'Industry created successfully.');
    }

    public function show($id)
    {
        $industry = NexcorSystemIndustry::with('sicCode')->findOrFail($id);
        return view('cims_pmpro::industries.show', compact('industry'));
    }

    public function edit($id)
    {
        $industry = NexcorSystemIndustry::findOrFail($id);
        $sicCodes = NexcorSicCode::where('is_active', true)
            ->orderBy('section_code')
            ->orderBy('sic_code')
            ->get();
        return view('cims_pmpro::industries.form', compact('industry', 'sicCodes'));
    }

    public function update(Request $request, $id)
    {
        $industry = NexcorSystemIndustry::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
            'sic_code_id' => 'nullable|exists:nexcore_sic_codes,id',
        ]);

        $industry->update([
            'name' => $request->name,
            'code' => $request->code,
            'sic_code_id' => $request->sic_code_id,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.industries.show', $industry->id)
            ->with('success', 'Industry updated successfully.');
    }

    public function destroy($id)
    {
        $industry = NexcorSystemIndustry::findOrFail($id);
        $industry->delete();
        return redirect()->route('system-settings.industries.index')
            ->with('success', 'Industry deleted successfully.');
    }

    public function toggle($id)
    {
        $industry = NexcorSystemIndustry::findOrFail($id);
        $industry->update(['is_active' => !$industry->is_active]);
        return redirect()->back()->with('success', 'Industry status updated.');
    }
}
