<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemIdDocumentType;

class IdDocumentTypeController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemIdDocumentType::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        $idDocumentTypes = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemIdDocumentType::count(),
            'active' => NexcorSystemIdDocumentType::where('is_active', true)->count(),
            'inactive' => NexcorSystemIdDocumentType::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::id-document-types.index', compact('idDocumentTypes', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::id-document-types.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        NexcorSystemIdDocumentType::create([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.id-document-types.index')
            ->with('success', 'ID Document Type created successfully.');
    }

    public function show($id)
    {
        $idDocumentType = NexcorSystemIdDocumentType::findOrFail($id);
        return view('cims_pmpro::id-document-types.show', compact('idDocumentType'));
    }

    public function edit($id)
    {
        $idDocumentType = NexcorSystemIdDocumentType::findOrFail($id);
        return view('cims_pmpro::id-document-types.form', compact('idDocumentType'));
    }

    public function update(Request $request, $id)
    {
        $idDocumentType = NexcorSystemIdDocumentType::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        $idDocumentType->update([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.id-document-types.show', $idDocumentType->id)
            ->with('success', 'ID Document Type updated successfully.');
    }

    public function destroy($id)
    {
        $idDocumentType = NexcorSystemIdDocumentType::findOrFail($id);
        $idDocumentType->delete();
        return redirect()->route('system-settings.id-document-types.index')
            ->with('success', 'ID Document Type deleted successfully.');
    }

    public function toggle($id)
    {
        $idDocumentType = NexcorSystemIdDocumentType::findOrFail($id);
        $idDocumentType->update(['is_active' => !$idDocumentType->is_active]);
        return redirect()->back()->with('success', 'ID Document Type status updated.');
    }
}