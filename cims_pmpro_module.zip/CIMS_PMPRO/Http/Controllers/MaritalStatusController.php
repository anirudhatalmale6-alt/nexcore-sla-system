<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemMaritalStatus;

class MaritalStatusController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemMaritalStatus::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        $maritalStatuses = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemMaritalStatus::count(),
            'active' => NexcorSystemMaritalStatus::where('is_active', true)->count(),
            'inactive' => NexcorSystemMaritalStatus::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::marital-statuses.index', compact('maritalStatuses', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::marital-statuses.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        NexcorSystemMaritalStatus::create([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.marital-statuses.index')
            ->with('success', 'Marital Status created successfully.');
    }

    public function show($id)
    {
        $maritalStatus = NexcorSystemMaritalStatus::findOrFail($id);
        return view('cims_pmpro::marital-statuses.show', compact('maritalStatus'));
    }

    public function edit($id)
    {
        $maritalStatus = NexcorSystemMaritalStatus::findOrFail($id);
        return view('cims_pmpro::marital-statuses.form', compact('maritalStatus'));
    }

    public function update(Request $request, $id)
    {
        $maritalStatus = NexcorSystemMaritalStatus::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        $maritalStatus->update([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.marital-statuses.show', $maritalStatus->id)
            ->with('success', 'Marital Status updated successfully.');
    }

    public function destroy($id)
    {
        $maritalStatus = NexcorSystemMaritalStatus::findOrFail($id);
        $maritalStatus->delete();
        return redirect()->route('system-settings.marital-statuses.index')
            ->with('success', 'Marital Status deleted successfully.');
    }

    public function toggle($id)
    {
        $maritalStatus = NexcorSystemMaritalStatus::findOrFail($id);
        $maritalStatus->update(['is_active' => !$maritalStatus->is_active]);
        return redirect()->back()->with('success', 'Marital Status status updated.');
    }
}