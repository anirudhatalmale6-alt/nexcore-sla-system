<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemTitle;

class TitleController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemTitle::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('abbreviation', 'like', "%{$s}%");
            });
        }

        $titles = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemTitle::count(),
            'active' => NexcorSystemTitle::where('is_active', true)->count(),
            'inactive' => NexcorSystemTitle::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::titles.index', compact('titles', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::titles.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:50',
            'abbreviation' => 'nullable|string|max:20',
        ]);

        NexcorSystemTitle::create([
            'name' => $request->name,
            'abbreviation' => $request->abbreviation,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.titles.index')
            ->with('success', 'Title created successfully.');
    }

    public function show($id)
    {
        $title = NexcorSystemTitle::findOrFail($id);
        return view('cims_pmpro::titles.show', compact('title'));
    }

    public function edit($id)
    {
        $title = NexcorSystemTitle::findOrFail($id);
        return view('cims_pmpro::titles.form', compact('title'));
    }

    public function update(Request $request, $id)
    {
        $title = NexcorSystemTitle::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:50',
            'abbreviation' => 'nullable|string|max:20',
        ]);

        $title->update([
            'name' => $request->name,
            'abbreviation' => $request->abbreviation,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.titles.show', $title->id)
            ->with('success', 'Title updated successfully.');
    }

    public function destroy($id)
    {
        $title = NexcorSystemTitle::findOrFail($id);
        $title->delete();
        return redirect()->route('system-settings.titles.index')
            ->with('success', 'Title deleted successfully.');
    }

    public function toggle($id)
    {
        $title = NexcorSystemTitle::findOrFail($id);
        $title->update(['is_active' => !$title->is_active]);
        return redirect()->back()->with('success', 'Title status updated.');
    }
}
