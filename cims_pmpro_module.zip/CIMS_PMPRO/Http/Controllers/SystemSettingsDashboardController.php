<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Modules\CIMS_PMPRO\Models\NexcorSysLanguage;

class SystemSettingsDashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'languages' => NexcorSysLanguage::count(),
            'active_languages' => NexcorSysLanguage::where('is_active', true)->count(),
            'official_languages' => NexcorSysLanguage::where('is_official', true)->count(),
        ];

        return view('cims_pmpro::system-settings.dashboard', compact('stats'));
    }
}
