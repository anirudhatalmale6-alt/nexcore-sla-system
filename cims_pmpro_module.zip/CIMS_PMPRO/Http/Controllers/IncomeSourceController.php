<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemIncomeSource;

class IncomeSourceController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemIncomeSource::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        $incomeSources = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemIncomeSource::count(),
            'active' => NexcorSystemIncomeSource::where('is_active', true)->count(),
            'inactive' => NexcorSystemIncomeSource::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::income-sources.index', compact('incomeSources', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::income-sources.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        NexcorSystemIncomeSource::create([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.income-sources.index')
            ->with('success', 'Income Source created successfully.');
    }

    public function show($id)
    {
        $incomeSource = NexcorSystemIncomeSource::findOrFail($id);
        return view('cims_pmpro::income-sources.show', compact('incomeSource'));
    }

    public function edit($id)
    {
        $incomeSource = NexcorSystemIncomeSource::findOrFail($id);
        return view('cims_pmpro::income-sources.form', compact('incomeSource'));
    }

    public function update(Request $request, $id)
    {
        $incomeSource = NexcorSystemIncomeSource::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        $incomeSource->update([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.income-sources.show', $incomeSource->id)
            ->with('success', 'Income Source updated successfully.');
    }

    public function destroy($id)
    {
        $incomeSource = NexcorSystemIncomeSource::findOrFail($id);
        $incomeSource->delete();
        return redirect()->route('system-settings.income-sources.index')
            ->with('success', 'Income Source deleted successfully.');
    }

    public function toggle($id)
    {
        $incomeSource = NexcorSystemIncomeSource::findOrFail($id);
        $incomeSource->update(['is_active' => !$incomeSource->is_active]);
        return redirect()->back()->with('success', 'Income Source status updated.');
    }
}