<?php

namespace Modules\CIMS_PMPRO\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CIMS_PMPRO\Models\NexcorSystemEmailType;

class EmailTypeController extends Controller
{
    public function index(Request $request)
    {
        $query = NexcorSystemEmailType::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('code', 'like', "%{$s}%");
            });
        }

        $emailTypes = $query->orderBy('name')->paginate(20);

        $stats = [
            'total' => NexcorSystemEmailType::count(),
            'active' => NexcorSystemEmailType::where('is_active', true)->count(),
            'inactive' => NexcorSystemEmailType::where('is_active', false)->count(),
        ];

        return view('cims_pmpro::email-types.index', compact('emailTypes', 'stats'));
    }

    public function create()
    {
        return view('cims_pmpro::email-types.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        NexcorSystemEmailType::create([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => true,
            'is_deleted' => false,
        ]);

        return redirect()->route('system-settings.email-types.index')
            ->with('success', 'Email type created successfully.');
    }

    public function show($id)
    {
        $emailType = NexcorSystemEmailType::findOrFail($id);
        return view('cims_pmpro::email-types.show', compact('emailType'));
    }

    public function edit($id)
    {
        $emailType = NexcorSystemEmailType::findOrFail($id);
        return view('cims_pmpro::email-types.form', compact('emailType'));
    }

    public function update(Request $request, $id)
    {
        $emailType = NexcorSystemEmailType::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
        ]);

        $emailType->update([
            'name' => $request->name,
            'code' => $request->code,
            'description' => $request->description,
            'is_active' => $request->boolean('is_active', true),
            'is_deleted' => $request->boolean('is_deleted', false),
        ]);

        return redirect()->route('system-settings.email-types.show', $emailType->id)
            ->with('success', 'Email type updated successfully.');
    }

    public function destroy($id)
    {
        $emailType = NexcorSystemEmailType::findOrFail($id);
        $emailType->delete();
        return redirect()->route('system-settings.email-types.index')
            ->with('success', 'Email type deleted successfully.');
    }

    public function toggle($id)
    {
        $emailType = NexcorSystemEmailType::findOrFail($id);
        $emailType->update(['is_active' => !$emailType->is_active]);
        return redirect()->back()->with('success', 'Email type status updated.');
    }
}
