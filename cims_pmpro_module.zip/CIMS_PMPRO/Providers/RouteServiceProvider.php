<?php

namespace Modules\CIMS_PMPRO\Providers;

use Illuminate\Support\Facades\Route;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;

class RouteServiceProvider extends ServiceProvider
{
    protected $moduleNamespace = 'Modules\CIMS_PMPRO\Http\Controllers';

    public function boot()
    {
        parent::boot();
    }

    public function map()
    {
        $this->mapWebRoutes();
        $this->mapSystemSettingsRoutes();
        $this->mapApiRoutes();
    }

    protected function mapWebRoutes()
    {
        Route::middleware(['web', 'auth'])
            ->namespace($this->moduleNamespace)
            ->prefix('pmpro')
            ->name('pmpro.')
            ->group(module_path('CIMS_PMPRO', '/Routes/web.php'));
    }

    protected function mapSystemSettingsRoutes()
    {
        Route::middleware(['web', 'auth'])
            ->namespace($this->moduleNamespace)
            ->prefix('system-settings')
            ->name('system-settings.')
            ->group(module_path('CIMS_PMPRO', '/Routes/system_settings.php'));
    }

    protected function mapApiRoutes()
    {
        $apiRoutesPath = module_path('CIMS_PMPRO', '/Routes/api.php');
        if (file_exists($apiRoutesPath)) {
            Route::prefix('api/pmpro')
                ->middleware('api')
                ->namespace($this->moduleNamespace)
                ->group($apiRoutesPath);
        }
    }
}
