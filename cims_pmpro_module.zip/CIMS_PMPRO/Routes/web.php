<?php

use Illuminate\Support\Facades\Route;
use Modules\CIMS_PMPRO\Http\Controllers\AddressController;
use Modules\CIMS_PMPRO\Http\Controllers\CountryController;
use Modules\CIMS_PMPRO\Http\Controllers\DashboardController;
use Modules\CIMS_PMPRO\Http\Controllers\DistrictController;
use Modules\CIMS_PMPRO\Http\Controllers\LocalMunicipalityController;
use Modules\CIMS_PMPRO\Http\Controllers\LookupController;
use Modules\CIMS_PMPRO\Http\Controllers\CityController;
use Modules\CIMS_PMPRO\Http\Controllers\MetroController;
use Modules\CIMS_PMPRO\Http\Controllers\WardController;
use Modules\CIMS_PMPRO\Http\Controllers\MunicipalityTypeController;
use Modules\CIMS_PMPRO\Http\Controllers\ProvinceController;
/*
|--------------------------------------------------------------------------
| CIMS PMPRO Module Routes
|--------------------------------------------------------------------------
| Prefix: /pmpro
| Name: pmpro.
*/

// Dashboard
Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

// Addresses
Route::prefix('addresses')->name('addresses.')->group(function () {
    Route::get('/', [AddressController::class, 'index'])->name('index');
    Route::get('/create', [AddressController::class, 'create'])->name('create');
    Route::post('/', [AddressController::class, 'store'])->name('store');
    Route::get('/{id}', [AddressController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [AddressController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [AddressController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [AddressController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [AddressController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
    Route::post('/{id}/restore', [AddressController::class, 'restore'])->name('restore')->where('id', '[0-9]+');
    Route::delete('/{id}/force', [AddressController::class, 'forceDelete'])->name('forceDelete')->where('id', '[0-9]+');
});

// Countries
Route::prefix('countries')->name('countries.')->group(function () {
    Route::get('/', [CountryController::class, 'index'])->name('index');
    Route::get('/create', [CountryController::class, 'create'])->name('create');
    Route::post('/', [CountryController::class, 'store'])->name('store');
    Route::get('/{id}', [CountryController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [CountryController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [CountryController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [CountryController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [CountryController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Provinces
Route::prefix('provinces')->name('provinces.')->group(function () {
    Route::get('/', [ProvinceController::class, 'index'])->name('index');
    Route::get('/create', [ProvinceController::class, 'create'])->name('create');
    Route::post('/', [ProvinceController::class, 'store'])->name('store');
    Route::get('/{id}', [ProvinceController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [ProvinceController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [ProvinceController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [ProvinceController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [ProvinceController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Municipality Types
Route::prefix('municipality-types')->name('municipality-types.')->group(function () {
    Route::get('/', [MunicipalityTypeController::class, 'index'])->name('index');
    Route::get('/create', [MunicipalityTypeController::class, 'create'])->name('create');
    Route::post('/', [MunicipalityTypeController::class, 'store'])->name('store');
    Route::get('/{id}', [MunicipalityTypeController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [MunicipalityTypeController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [MunicipalityTypeController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [MunicipalityTypeController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [MunicipalityTypeController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Metropolitan Municipalities
Route::prefix('metros')->name('metros.')->group(function () {
    Route::get('/', [MetroController::class, 'index'])->name('index');
    Route::get('/create', [MetroController::class, 'create'])->name('create');
    Route::post('/', [MetroController::class, 'store'])->name('store');
    Route::get('/{id}', [MetroController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [MetroController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [MetroController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [MetroController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [MetroController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// District Municipalities
Route::prefix('districts')->name('districts.')->group(function () {
    Route::get('/', [DistrictController::class, 'index'])->name('index');
    Route::get('/create', [DistrictController::class, 'create'])->name('create');
    Route::post('/', [DistrictController::class, 'store'])->name('store');
    Route::get('/{id}', [DistrictController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [DistrictController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [DistrictController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [DistrictController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [DistrictController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Local Municipalities
Route::prefix('local-municipalities')->name('local-municipalities.')->group(function () {
    Route::get('/', [LocalMunicipalityController::class, 'index'])->name('index');
    Route::get('/create', [LocalMunicipalityController::class, 'create'])->name('create');
    Route::post('/', [LocalMunicipalityController::class, 'store'])->name('store');
    Route::get('/{id}', [LocalMunicipalityController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [LocalMunicipalityController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [LocalMunicipalityController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [LocalMunicipalityController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [LocalMunicipalityController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Main Places / Cities
Route::prefix('cities')->name('cities.')->group(function () {
    Route::get('/{id}', [CityController::class, 'show'])->name('show')->where('id', '[0-9]+');
});

// Wards
Route::prefix('wards')->name('wards.')->group(function () {
    Route::get('/', [WardController::class, 'index'])->name('index');
    Route::get('/create', [WardController::class, 'create'])->name('create');
    Route::post('/', [WardController::class, 'store'])->name('store');
    Route::get('/{id}', [WardController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [WardController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [WardController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [WardController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [WardController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Lookups (AJAX for cascading dropdowns)
Route::prefix('lookup')->name('lookup.')->group(function () {
    Route::get('/provinces', [LookupController::class, 'provinces'])->name('provinces');
    Route::get('/districts/{province_id}', [LookupController::class, 'districts'])->name('districts');
    Route::get('/municipalities/{district_id}', [LookupController::class, 'municipalities'])->name('municipalities');
    Route::get('/metros/{province_id}', [LookupController::class, 'metros'])->name('metros');
    Route::get('/local-municipalities/{province_id}', [LookupController::class, 'localMunicipalitiesByProvince'])->name('localMunicipalities');
    Route::get('/wards/{municipality_id}', [LookupController::class, 'wards'])->name('wards');
    Route::get('/cities/{province_id}', [LookupController::class, 'cities'])->name('cities');
    Route::get('/suburbs/{city_id}', [LookupController::class, 'suburbs'])->name('suburbs');
    Route::get('/search-suburbs', [LookupController::class, 'searchSuburbs'])->name('searchSuburbs');
    Route::post('/find-or-create-suburb', [LookupController::class, 'findOrCreateSuburb'])->name('findOrCreateSuburb');
});
