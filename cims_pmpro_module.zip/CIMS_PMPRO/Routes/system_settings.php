<?php

use Illuminate\Support\Facades\Route;
use Modules\CIMS_PMPRO\Http\Controllers\SystemSettingsDashboardController;
use Modules\CIMS_PMPRO\Http\Controllers\LanguageController;
use Modules\CIMS_PMPRO\Http\Controllers\EthnicGroupController;
use Modules\CIMS_PMPRO\Http\Controllers\ReligionController;
use Modules\CIMS_PMPRO\Http\Controllers\TitleController;
use Modules\CIMS_PMPRO\Http\Controllers\GenderController;
use Modules\CIMS_PMPRO\Http\Controllers\EducationController;
use Modules\CIMS_PMPRO\Http\Controllers\AddressTypeController;
use Modules\CIMS_PMPRO\Http\Controllers\EmailTypeController;
use Modules\CIMS_PMPRO\Http\Controllers\TelephoneTypeController;
use Modules\CIMS_PMPRO\Http\Controllers\DirectorTypeController;
use Modules\CIMS_PMPRO\Http\Controllers\BankAccountTypeController;
use Modules\CIMS_PMPRO\Http\Controllers\MaritalStatusController;
use Modules\CIMS_PMPRO\Http\Controllers\RelationshipTypeController;
use Modules\CIMS_PMPRO\Http\Controllers\IdDocumentTypeController;
use Modules\CIMS_PMPRO\Http\Controllers\EmploymentStatusController;
use Modules\CIMS_PMPRO\Http\Controllers\DisabilityTypeController;
use Modules\CIMS_PMPRO\Http\Controllers\CompanyTypeController;
use Modules\CIMS_PMPRO\Http\Controllers\BankController;
use Modules\CIMS_PMPRO\Http\Controllers\IncomeSourceController;
use Modules\CIMS_PMPRO\Http\Controllers\TaxTypeController;
use Modules\CIMS_PMPRO\Http\Controllers\BeeStatusLevelController;
use Modules\CIMS_PMPRO\Http\Controllers\CommunicationPreferenceController;
use Modules\CIMS_PMPRO\Http\Controllers\IndustryController;
use Modules\CIMS_PMPRO\Http\Controllers\CompanyStatusController;
use Modules\CIMS_PMPRO\Http\Controllers\NationalityController;
use Modules\CIMS_PMPRO\Http\Controllers\SicCodeController;

/*
|--------------------------------------------------------------------------
| NexCore System Settings Routes
|--------------------------------------------------------------------------
| Prefix: /system-settings
| Name: system-settings.
*/

// Dashboard
Route::get('/', [SystemSettingsDashboardController::class, 'index'])->name('dashboard');

// Languages
Route::prefix('languages')->name('languages.')->group(function () {
    Route::get('/', [LanguageController::class, 'index'])->name('index');
    Route::get('/create', [LanguageController::class, 'create'])->name('create');
    Route::post('/', [LanguageController::class, 'store'])->name('store');
    Route::get('/{id}', [LanguageController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [LanguageController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [LanguageController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [LanguageController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [LanguageController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Ethnic Groups
Route::prefix('ethnic-groups')->name('ethnic-groups.')->group(function () {
    Route::get('/', [EthnicGroupController::class, 'index'])->name('index');
    Route::get('/create', [EthnicGroupController::class, 'create'])->name('create');
    Route::post('/', [EthnicGroupController::class, 'store'])->name('store');
    Route::get('/{id}', [EthnicGroupController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [EthnicGroupController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [EthnicGroupController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [EthnicGroupController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [EthnicGroupController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Religions
Route::prefix('religions')->name('religions.')->group(function () {
    Route::get('/', [ReligionController::class, 'index'])->name('index');
    Route::get('/create', [ReligionController::class, 'create'])->name('create');
    Route::post('/', [ReligionController::class, 'store'])->name('store');
    Route::get('/{id}', [ReligionController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [ReligionController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [ReligionController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [ReligionController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [ReligionController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Titles
Route::prefix('titles')->name('titles.')->group(function () {
    Route::get('/', [TitleController::class, 'index'])->name('index');
    Route::get('/create', [TitleController::class, 'create'])->name('create');
    Route::post('/', [TitleController::class, 'store'])->name('store');
    Route::get('/{id}', [TitleController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [TitleController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [TitleController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [TitleController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [TitleController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Genders
Route::prefix('genders')->name('genders.')->group(function () {
    Route::get('/', [GenderController::class, 'index'])->name('index');
    Route::get('/create', [GenderController::class, 'create'])->name('create');
    Route::post('/', [GenderController::class, 'store'])->name('store');
    Route::get('/{id}', [GenderController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [GenderController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [GenderController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [GenderController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [GenderController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Education Levels
Route::prefix('education')->name('education.')->group(function () {
    Route::get('/', [EducationController::class, 'index'])->name('index');
    Route::get('/create', [EducationController::class, 'create'])->name('create');
    Route::post('/', [EducationController::class, 'store'])->name('store');
    Route::get('/{id}', [EducationController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [EducationController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [EducationController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [EducationController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [EducationController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Address Types
Route::prefix('address-types')->name('address-types.')->group(function () {
    Route::get('/', [AddressTypeController::class, 'index'])->name('index');
    Route::get('/create', [AddressTypeController::class, 'create'])->name('create');
    Route::post('/', [AddressTypeController::class, 'store'])->name('store');
    Route::get('/{id}', [AddressTypeController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [AddressTypeController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [AddressTypeController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [AddressTypeController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [AddressTypeController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Email Types
Route::prefix('email-types')->name('email-types.')->group(function () {
    Route::get('/', [EmailTypeController::class, 'index'])->name('index');
    Route::get('/create', [EmailTypeController::class, 'create'])->name('create');
    Route::post('/', [EmailTypeController::class, 'store'])->name('store');
    Route::get('/{id}', [EmailTypeController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [EmailTypeController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [EmailTypeController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [EmailTypeController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [EmailTypeController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Telephone Types
Route::prefix('telephone-types')->name('telephone-types.')->group(function () {
    Route::get('/', [TelephoneTypeController::class, 'index'])->name('index');
    Route::get('/create', [TelephoneTypeController::class, 'create'])->name('create');
    Route::post('/', [TelephoneTypeController::class, 'store'])->name('store');
    Route::get('/{id}', [TelephoneTypeController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [TelephoneTypeController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [TelephoneTypeController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [TelephoneTypeController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [TelephoneTypeController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Director Types
Route::prefix('director-types')->name('director-types.')->group(function () {
    Route::get('/', [DirectorTypeController::class, 'index'])->name('index');
    Route::get('/create', [DirectorTypeController::class, 'create'])->name('create');
    Route::post('/', [DirectorTypeController::class, 'store'])->name('store');
    Route::get('/{id}', [DirectorTypeController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [DirectorTypeController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [DirectorTypeController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [DirectorTypeController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [DirectorTypeController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Bank Account Types
Route::prefix('bank-account-types')->name('bank-account-types.')->group(function () {
    Route::get('/', [BankAccountTypeController::class, 'index'])->name('index');
    Route::get('/create', [BankAccountTypeController::class, 'create'])->name('create');
    Route::post('/', [BankAccountTypeController::class, 'store'])->name('store');
    Route::get('/{id}', [BankAccountTypeController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [BankAccountTypeController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [BankAccountTypeController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [BankAccountTypeController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [BankAccountTypeController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Marital Statuses
Route::prefix('marital-statuses')->name('marital-statuses.')->group(function () {
    Route::get('/', [MaritalStatusController::class, 'index'])->name('index');
    Route::get('/create', [MaritalStatusController::class, 'create'])->name('create');
    Route::post('/', [MaritalStatusController::class, 'store'])->name('store');
    Route::get('/{id}', [MaritalStatusController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [MaritalStatusController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [MaritalStatusController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [MaritalStatusController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [MaritalStatusController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Relationship Types
Route::prefix('relationship-types')->name('relationship-types.')->group(function () {
    Route::get('/', [RelationshipTypeController::class, 'index'])->name('index');
    Route::get('/create', [RelationshipTypeController::class, 'create'])->name('create');
    Route::post('/', [RelationshipTypeController::class, 'store'])->name('store');
    Route::get('/{id}', [RelationshipTypeController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [RelationshipTypeController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [RelationshipTypeController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [RelationshipTypeController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [RelationshipTypeController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// ID Document Types
Route::prefix('id-document-types')->name('id-document-types.')->group(function () {
    Route::get('/', [IdDocumentTypeController::class, 'index'])->name('index');
    Route::get('/create', [IdDocumentTypeController::class, 'create'])->name('create');
    Route::post('/', [IdDocumentTypeController::class, 'store'])->name('store');
    Route::get('/{id}', [IdDocumentTypeController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [IdDocumentTypeController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [IdDocumentTypeController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [IdDocumentTypeController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [IdDocumentTypeController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Employment Statuses
Route::prefix('employment-statuses')->name('employment-statuses.')->group(function () {
    Route::get('/', [EmploymentStatusController::class, 'index'])->name('index');
    Route::get('/create', [EmploymentStatusController::class, 'create'])->name('create');
    Route::post('/', [EmploymentStatusController::class, 'store'])->name('store');
    Route::get('/{id}', [EmploymentStatusController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [EmploymentStatusController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [EmploymentStatusController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [EmploymentStatusController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [EmploymentStatusController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Disability Types
Route::prefix('disability-types')->name('disability-types.')->group(function () {
    Route::get('/', [DisabilityTypeController::class, 'index'])->name('index');
    Route::get('/create', [DisabilityTypeController::class, 'create'])->name('create');
    Route::post('/', [DisabilityTypeController::class, 'store'])->name('store');
    Route::get('/{id}', [DisabilityTypeController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [DisabilityTypeController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [DisabilityTypeController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [DisabilityTypeController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [DisabilityTypeController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Company Types
Route::prefix('company-types')->name('company-types.')->group(function () {
    Route::get('/', [CompanyTypeController::class, 'index'])->name('index');
    Route::get('/create', [CompanyTypeController::class, 'create'])->name('create');
    Route::post('/', [CompanyTypeController::class, 'store'])->name('store');
    Route::get('/{id}', [CompanyTypeController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [CompanyTypeController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [CompanyTypeController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [CompanyTypeController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [CompanyTypeController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Banks
Route::prefix('banks')->name('banks.')->group(function () {
    Route::get('/', [BankController::class, 'index'])->name('index');
    Route::get('/create', [BankController::class, 'create'])->name('create');
    Route::post('/', [BankController::class, 'store'])->name('store');
    Route::get('/{id}', [BankController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [BankController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [BankController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [BankController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [BankController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Income Sources
Route::prefix('income-sources')->name('income-sources.')->group(function () {
    Route::get('/', [IncomeSourceController::class, 'index'])->name('index');
    Route::get('/create', [IncomeSourceController::class, 'create'])->name('create');
    Route::post('/', [IncomeSourceController::class, 'store'])->name('store');
    Route::get('/{id}', [IncomeSourceController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [IncomeSourceController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [IncomeSourceController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [IncomeSourceController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [IncomeSourceController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Tax Types
Route::prefix('tax-types')->name('tax-types.')->group(function () {
    Route::get('/', [TaxTypeController::class, 'index'])->name('index');
    Route::get('/create', [TaxTypeController::class, 'create'])->name('create');
    Route::post('/', [TaxTypeController::class, 'store'])->name('store');
    Route::get('/{id}', [TaxTypeController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [TaxTypeController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [TaxTypeController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [TaxTypeController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [TaxTypeController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// BEE Status Levels
Route::prefix('bee-status-levels')->name('bee-status-levels.')->group(function () {
    Route::get('/', [BeeStatusLevelController::class, 'index'])->name('index');
    Route::get('/create', [BeeStatusLevelController::class, 'create'])->name('create');
    Route::post('/', [BeeStatusLevelController::class, 'store'])->name('store');
    Route::get('/{id}', [BeeStatusLevelController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [BeeStatusLevelController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [BeeStatusLevelController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [BeeStatusLevelController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [BeeStatusLevelController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Communication Preferences
Route::prefix('communication-preferences')->name('communication-preferences.')->group(function () {
    Route::get('/', [CommunicationPreferenceController::class, 'index'])->name('index');
    Route::get('/create', [CommunicationPreferenceController::class, 'create'])->name('create');
    Route::post('/', [CommunicationPreferenceController::class, 'store'])->name('store');
    Route::get('/{id}', [CommunicationPreferenceController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [CommunicationPreferenceController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [CommunicationPreferenceController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [CommunicationPreferenceController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [CommunicationPreferenceController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Industries
Route::prefix('industries')->name('industries.')->group(function () {
    Route::get('/', [IndustryController::class, 'index'])->name('index');
    Route::get('/create', [IndustryController::class, 'create'])->name('create');
    Route::post('/', [IndustryController::class, 'store'])->name('store');
    Route::get('/{id}', [IndustryController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [IndustryController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [IndustryController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [IndustryController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [IndustryController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Company Statuses
Route::prefix('company-statuses')->name('company-statuses.')->group(function () {
    Route::get('/', [CompanyStatusController::class, 'index'])->name('index');
    Route::get('/create', [CompanyStatusController::class, 'create'])->name('create');
    Route::post('/', [CompanyStatusController::class, 'store'])->name('store');
    Route::get('/{id}', [CompanyStatusController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [CompanyStatusController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [CompanyStatusController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [CompanyStatusController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [CompanyStatusController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// SIC Codes
Route::prefix('sic-codes')->name('sic-codes.')->group(function () {
    Route::get('/', [SicCodeController::class, 'index'])->name('index');
    Route::get('/create', [SicCodeController::class, 'create'])->name('create');
    Route::post('/', [SicCodeController::class, 'store'])->name('store');
    Route::get('/{id}', [SicCodeController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [SicCodeController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [SicCodeController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [SicCodeController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [SicCodeController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});

// Nationalities
Route::prefix('nationalities')->name('nationalities.')->group(function () {
    Route::get('/', [NationalityController::class, 'index'])->name('index');
    Route::get('/create', [NationalityController::class, 'create'])->name('create');
    Route::post('/', [NationalityController::class, 'store'])->name('store');
    Route::get('/{id}', [NationalityController::class, 'show'])->name('show')->where('id', '[0-9]+');
    Route::get('/{id}/edit', [NationalityController::class, 'edit'])->name('edit')->where('id', '[0-9]+');
    Route::put('/{id}', [NationalityController::class, 'update'])->name('update')->where('id', '[0-9]+');
    Route::delete('/{id}', [NationalityController::class, 'destroy'])->name('destroy')->where('id', '[0-9]+');
    Route::post('/{id}/toggle', [NationalityController::class, 'toggle'])->name('toggle')->where('id', '[0-9]+');
});
