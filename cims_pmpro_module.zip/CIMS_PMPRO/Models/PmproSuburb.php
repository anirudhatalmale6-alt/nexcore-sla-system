<?php

namespace Modules\CIMS_PMPRO\Models;

use Illuminate\Database\Eloquent\Model;

class PmproSuburb extends Model
{
    protected $table = 'pmpro_suburbs';
    public $timestamps = false;

    protected $fillable = ['city_id', 'municipality_id', 'name', 'postal_code', 'is_active'];

    public function city()
    {
        return $this->belongsTo(PmproCity::class, 'city_id');
    }
}
