<?php

namespace Modules\CIMS_PMPRO\Models;

use Illuminate\Database\Eloquent\Model;

class NexcorSystemDirectorType extends Model
{
    protected $table = 'nexcore_system_director_types';

    protected $fillable = [
        'name', 'code', 'description',
        'is_active', 'is_deleted',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'is_deleted' => 'boolean',
    ];
}
