<?php

namespace Modules\CIMS_PMPRO\Models;

use Illuminate\Database\Eloquent\Model;

class PmproCountry extends Model
{
    protected $table = 'pmpro_countries';
    public $timestamps = false;

    protected $fillable = [
        'name', 'official_name', 'iso_code_2', 'iso_code_3', 'numeric_code',
        'continent', 'region', 'capital', 'currency_code', 'currency_name',
        'currency_symbol', 'calling_code', 'timezone', 'languages',
        'flag_emoji', 'description', 'flag_image', 'coat_of_arms_image', 'map_image',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function countryLanguages()
    {
        return $this->hasMany(\Modules\CIMS_PMPRO\Models\NexcorSysLanguage::class, 'country_id');
    }

    public function ethnicGroups()
    {
        return $this->hasMany(\Modules\CIMS_PMPRO\Models\NexcorSystemEthnicGroup::class, 'country_id');
    }

    public function religions()
    {
        return $this->hasMany(\Modules\CIMS_PMPRO\Models\NexcorSystemReligion::class, 'country_id');
    }
}
