<?php

namespace Modules\CIMS_PMPRO\Models;

use Illuminate\Database\Eloquent\Model;

class PmproWard extends Model
{
    protected $table = 'pmpro_wards';
    public $timestamps = false;

    protected $fillable = [
        'local_municipality_id', 'metro_id', 'ward_number', 'code',
        'ward_id_official', 'ward_label', 'municipality_name', 'district_name',
        'district_code', 'province_name', 'cat_b', 'demarcation_date',
        'objectid', 'objectid_1', 'shape_length', 'shape_area', 'shape_perimeter',
        'is_active', 'is_deleted',
    ];

    protected $casts = [
        'demarcation_date' => 'date',
        'is_active' => 'boolean',
        'is_deleted' => 'boolean',
    ];

    public function localMunicipality()
    {
        return $this->belongsTo(PmproLocalMunicipality::class, 'local_municipality_id');
    }

    public function metro()
    {
        return $this->belongsTo(PmproMetro::class, 'metro_id');
    }
}
