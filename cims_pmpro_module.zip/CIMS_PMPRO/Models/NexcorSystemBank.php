<?php

namespace Modules\CIMS_PMPRO\Models;

use Illuminate\Database\Eloquent\Model;

class NexcorSystemBank extends Model
{
    protected $table = 'nexcore_system_banks';

    protected $fillable = [
        'name', 'code', 'bank_code', 'branch_code',
        'swift_code', 'bank_logo', 'description',
        'is_active', 'is_deleted',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'is_deleted' => 'boolean',
    ];
}