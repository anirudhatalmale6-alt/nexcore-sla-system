<?php

namespace Modules\CIMS_PMPRO\Models;

use Illuminate\Database\Eloquent\Model;

class NexcorSystemEmploymentStatus extends Model
{
    protected $table = 'nexcore_system_employment_statuses';

    protected $fillable = [
        'name', 'code', 'description',
        'is_active', 'is_deleted',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'is_deleted' => 'boolean',
    ];
}