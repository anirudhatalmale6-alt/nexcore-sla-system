<?php

namespace Modules\CIMS_PMPRO\Models;

use Illuminate\Database\Eloquent\Model;

class PmproCity extends Model
{
    protected $table = 'pmpro_cities';
    public $timestamps = false;

    protected $fillable = ['province_id', 'metropolitan_municipality_id', 'district_id', 'local_municipality_id', 'name', 'is_active'];

    public function province()
    {
        return $this->belongsTo(PmproProvince::class, 'province_id');
    }

    public function localMunicipality()
    {
        return $this->belongsTo(PmproLocalMunicipality::class, 'local_municipality_id');
    }

    public function metro()
    {
        return $this->belongsTo(PmproMetro::class, 'metropolitan_municipality_id');
    }

    public function district()
    {
        return $this->belongsTo(PmproDistrict::class, 'district_id');
    }

    public function suburbs()
    {
        return $this->hasMany(PmproSuburb::class, 'city_id');
    }
}
