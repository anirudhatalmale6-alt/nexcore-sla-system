<?php

namespace Modules\CIMS_PMPRO\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PmproAddressMain extends Model
{
    use SoftDeletes;

    protected $table = 'pmpro_address_main';

    protected $fillable = [
        'unit_number',
        'complex_name',
        'street_number',
        'street_name',
        'suburb_id',
        'city',
        'postal_code',
        'province_id',
        'municipality_id',
        'ward_id',
        'country',
        'latitude',
        'longitude',
        'google_formatted_address',
        'address_category',
        'is_active',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'latitude' => 'decimal:8',
        'longitude' => 'decimal:8',
    ];

    public function province()
    {
        return $this->belongsTo(PmproProvince::class, 'province_id');
    }

    public function localMunicipality()
    {
        return $this->belongsTo(PmproLocalMunicipality::class, 'municipality_id');
    }

    public function metro()
    {
        return $this->belongsTo(PmproMetro::class, 'municipality_id');
    }

    public function getMunicipalityNameAttribute()
    {
        if ($this->localMunicipality) return $this->localMunicipality->name;
        if ($this->metro) return $this->metro->name;
        return null;
    }

    public function getMunicipalityTypeAttribute()
    {
        if ($this->localMunicipality) return 'Local Municipality';
        if ($this->metro) return 'Metropolitan Municipality';
        return null;
    }

    public function getMunicipalityCodeAttribute()
    {
        if ($this->localMunicipality) return $this->localMunicipality->code ?? null;
        if ($this->metro) return $this->metro->code ?? null;
        return null;
    }

    public function ward()
    {
        return $this->belongsTo(PmproWard::class, 'ward_id');
    }

    public function suburb()
    {
        return $this->belongsTo(PmproSuburb::class, 'suburb_id');
    }

    public function secondary()
    {
        return $this->hasOne(PmproAddressSecondary::class, 'address_id');
    }

    public function links()
    {
        return $this->hasMany(PmproAddressLink::class, 'address_id');
    }
}
