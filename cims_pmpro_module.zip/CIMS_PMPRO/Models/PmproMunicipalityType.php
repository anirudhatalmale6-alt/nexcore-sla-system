<?php

namespace Modules\CIMS_PMPRO\Models;

use Illuminate\Database\Eloquent\Model;

class PmproMunicipalityType extends Model
{
    protected $table = 'pmpro_municipality_types';
    public $timestamps = false;

    protected $fillable = ['name', 'code', 'description', 'is_active'];
}
