<?php

namespace Modules\CIMS_PMPRO\Models;

use Illuminate\Database\Eloquent\Model;

class NexcorSysLanguage extends Model
{
    protected $table = 'nexcor_sys_languages';

    protected $fillable = [
        'country_id', 'name', 'native_name', 'code', 'description', 'lang_image', 'caption',
        'is_official', 'is_active', 'is_deleted',
    ];

    protected $casts = [
        'is_official' => 'boolean',
        'is_active' => 'boolean',
        'is_deleted' => 'boolean',
    ];

    public function country()
    {
        return $this->belongsTo(\Modules\CIMS_PMPRO\Models\PmproCountry::class, 'country_id');
    }
}
