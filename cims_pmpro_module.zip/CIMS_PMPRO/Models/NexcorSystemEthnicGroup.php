<?php

namespace Modules\CIMS_PMPRO\Models;

use Illuminate\Database\Eloquent\Model;

class NexcorSystemEthnicGroup extends Model
{
    protected $table = 'nexcore_system_ethnic_groups';

    protected $fillable = [
        'country_id', 'name', 'percentage', 'description',
        'is_active', 'is_deleted',
    ];

    protected $casts = [
        'percentage' => 'decimal:1',
        'is_active' => 'boolean',
        'is_deleted' => 'boolean',
    ];

    public function country()
    {
        return $this->belongsTo(PmproCountry::class, 'country_id');
    }
}
