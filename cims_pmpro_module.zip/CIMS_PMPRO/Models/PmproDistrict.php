<?php

namespace Modules\CIMS_PMPRO\Models;

use Illuminate\Database\Eloquent\Model;

class PmproDistrict extends Model
{
    protected $table = 'pmpro_districts';
    public $timestamps = false;

    protected $fillable = ['province_id', 'name', 'code', 'is_active'];

    public function province()
    {
        return $this->belongsTo(PmproProvince::class, 'province_id');
    }

    public function localMunicipalities()
    {
        return $this->hasMany(PmproLocalMunicipality::class, 'district_id');
    }
}
