<?php

namespace Modules\CIMS_PMPRO\Models;

use Illuminate\Database\Eloquent\Model;

class PmproMetro extends Model
{
    protected $table = 'pmpro_metropolitan_municipalities';
    public $timestamps = false;

    protected $fillable = ['province_id', 'name', 'code', 'description', 'is_active'];

    public function province()
    {
        return $this->belongsTo(PmproProvince::class, 'province_id');
    }

    public function wards()
    {
        return $this->hasMany(PmproWard::class, 'metro_id');
    }

    public function cities()
    {
        return $this->hasMany(PmproCity::class, 'metropolitan_municipality_id');
    }
}
