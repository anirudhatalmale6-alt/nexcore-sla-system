<?php

namespace Modules\CIMS_PMPRO\Models;

use Illuminate\Database\Eloquent\Model;

class NexcorSicCode extends Model
{
    protected $table = 'nexcore_sic_codes';

    protected $fillable = [
        'sic_code', 'description',
        'section_code', 'section_name',
        'profit_code', 'loss_code',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function industries()
    {
        return $this->hasMany(NexcorSystemIndustry::class, 'sic_code_id');
    }
}
