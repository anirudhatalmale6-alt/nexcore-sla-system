<?php

namespace Modules\CIMS_PMPRO\Models;

use Illuminate\Database\Eloquent\Model;

class PmproProvince extends Model
{
    protected $table = 'pmpro_provinces';
    public $timestamps = false;

    protected $fillable = [
        'name', 'code', 'native_name', 'capital', 'largest_city',
        'area_km2', 'population', 'density', 'description', 'map_image',
        'is_active',
    ];

    public function districts()
    {
        return $this->hasMany(PmproDistrict::class, 'province_id');
    }

    public function metros()
    {
        return $this->hasMany(PmproMetro::class, 'province_id');
    }

    public function cities()
    {
        return $this->hasMany(PmproCity::class, 'province_id');
    }
}
