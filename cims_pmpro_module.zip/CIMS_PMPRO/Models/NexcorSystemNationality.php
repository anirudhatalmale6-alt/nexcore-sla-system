<?php

namespace Modules\CIMS_PMPRO\Models;

use Illuminate\Database\Eloquent\Model;

class NexcorSystemNationality extends Model
{
    protected $table = 'nexcore_system_nationalities';

    protected $fillable = [
        'name', 'code', 'country_id', 'description',
        'is_active', 'is_deleted',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'is_deleted' => 'boolean',
    ];

    public function country()
    {
        return $this->belongsTo(PmproCountry::class, 'country_id');
    }
}