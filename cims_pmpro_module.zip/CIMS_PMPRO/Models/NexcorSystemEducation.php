<?php

namespace Modules\CIMS_PMPRO\Models;

use Illuminate\Database\Eloquent\Model;

class NexcorSystemEducation extends Model
{
    protected $table = 'nexcore_system_education_levels';

    protected $fillable = [
        'name', 'code', 'sort_order', 'description',
        'is_active', 'is_deleted',
    ];

    protected $casts = [
        'sort_order' => 'integer',
        'is_active' => 'boolean',
        'is_deleted' => 'boolean',
    ];
}
