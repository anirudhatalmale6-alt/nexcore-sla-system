<?php

namespace Modules\CIMS_PMPRO\Models;

use Illuminate\Database\Eloquent\Model;

class PmproLocalMunicipality extends Model
{
    protected $table = 'pmpro_local_municipalities';
    public $timestamps = false;

    protected $fillable = ['district_id', 'name', 'code', 'is_active'];

    public function district()
    {
        return $this->belongsTo(PmproDistrict::class, 'district_id');
    }

    public function wards()
    {
        return $this->hasMany(PmproWard::class, 'local_municipality_id');
    }

    public function cities()
    {
        return $this->hasMany(PmproCity::class, 'local_municipality_id');
    }
}
