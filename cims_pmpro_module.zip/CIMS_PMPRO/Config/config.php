<?php

return [
    'name' => 'CIMS_PMPRO',
    'description' => 'Practice Manager Pro - Address Management System',
];
