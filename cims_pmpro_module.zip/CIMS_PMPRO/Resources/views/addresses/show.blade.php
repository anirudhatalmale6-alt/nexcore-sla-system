@extends('cims_pmpro::layouts.pmpro')

@section('title', 'View Address')
@section('page_heading', 'VIEW ADDRESS')

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">Address #{{ $address->id }}</h1>
        <span class="sl-page-subtitle">Full address details</span>
        <div style="margin-left:auto; display:flex; gap:8px;">
            <a href="{{ route('pmpro.addresses.edit', $address->id) }}" class="neon-btn neon-btn-blue">
                <i class="fas fa-pen"></i> Edit
            </a>
            <a href="{{ route('pmpro.addresses.index') }}" class="neon-btn neon-btn-ghost">
                <i class="fas fa-arrow-left"></i> Back
            </a>
        </div>
    </div>
</div>

<div class="sl-grid-2 sl-animate d2">
    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-map-marker-alt"></i> Main Address</div>
            @if($address->is_active)
                <span class="sl-tag sl-tag-green">Active</span>
            @else
                <span class="sl-tag sl-tag-red">Inactive</span>
            @endif
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Full Address</span>
            <span class="sl-result-value" style="font-size:15px;">
                {{ $address->unit_number ? 'Unit '.$address->unit_number.', ' : '' }}{{ $address->complex_name ? $address->complex_name.', ' : '' }}{{ $address->street_number }} {{ $address->street_name }}
            </span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Suburb</span>
            <span class="sl-result-value">{{ $address->suburb->name ?? '-' }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">City</span>
            <span class="sl-result-value">{{ $address->city }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Postal Code</span>
            <span class="sl-result-value" style="color:var(--accent-cyan);">{{ $address->postal_code }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Province</span>
            <span class="sl-result-value">{{ $address->province->name ?? '-' }} ({{ $address->province->code ?? '-' }})</span>
        </div>
        @if($address->municipality_name)
        <div class="sl-result-row">
            <span class="sl-result-label">Municipality Type</span>
            <span class="sl-result-value">
                <span class="sl-tag sl-tag-{{ $address->municipality_type === 'Metropolitan Municipality' ? 'purple' : 'blue' }}">{{ $address->municipality_type }}</span>
            </span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Municipality</span>
            <span class="sl-result-value">{{ $address->municipality_name }}@if($address->municipality_code) <span style="color:var(--accent-cyan);">({{ $address->municipality_code }})</span>@endif</span>
        </div>
        @endif
        @if($address->ward)
        <div class="sl-result-row">
            <span class="sl-result-label">Ward</span>
            <span class="sl-result-value">Ward {{ $address->ward->ward_number }}@if($address->ward->code) <span style="color:var(--accent-cyan);">({{ $address->ward->code }})</span>@endif</span>
        </div>
        @endif
        <div class="sl-result-row">
            <span class="sl-result-label">Category</span>
            <span class="sl-result-value">
                @php
                    $catColors = ['Residential'=>'blue','Commercial'=>'purple','Industrial'=>'amber','Agricultural'=>'green','Mixed Use'=>'cyan'];
                @endphp
                <span class="sl-tag sl-tag-{{ $catColors[$address->address_category] ?? 'blue' }}">{{ $address->address_category }}</span>
            </span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Country</span>
            <span class="sl-result-value">{{ $address->country }}</span>
        </div>
        @if($address->latitude && $address->longitude)
        <div class="sl-result-row">
            <span class="sl-result-label">GPS</span>
            <span class="sl-result-value" style="color:var(--accent-cyan); font-size:14px;">{{ $address->latitude }}, {{ $address->longitude }}</span>
        </div>
        @endif
        @if($address->google_formatted_address)
        <div class="sl-result-row">
            <span class="sl-result-label">Google Address</span>
            <span class="sl-result-value" style="font-size:13px; white-space:normal; text-align:right;">{{ $address->google_formatted_address }}</span>
        </div>
        @endif
    </div>

    @if($address->secondary)
    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-layer-group"></i> Extended Details</div>
        </div>
        @php $s = $address->secondary; @endphp
        @foreach([
            'Floor Level' => $s->floor_level,
            'Building Name' => $s->building_name,
            'Estate Name' => $s->estate_name,
            'Section Number' => $s->section_number,
            'Farm Name' => $s->farm_name,
            'Farm Number' => $s->farm_number,
            'Stand Number' => $s->stand_number,
            'ERF Number' => $s->erf_number,
            'SG Code' => $s->sg_code,
            'Municipal Account' => $s->municipal_account_number,
            'Plus Code' => $s->plus_code,
            'What3Words' => $s->what3words,
            'Source' => $s->address_source,
            'Verified' => $s->is_verified ? 'Yes ('.$s->verified_date.')' : 'No',
        ] as $label => $val)
            @if($val)
            <div class="sl-result-row">
                <span class="sl-result-label">{{ $label }}</span>
                <span class="sl-result-value">{{ $val }}</span>
            </div>
            @endif
        @endforeach
    </div>
    @endif
</div>

{{-- Google Map --}}
@if($address->latitude && $address->longitude)
<div class="sl-card sl-animate d3" style="margin-top:20px; overflow:hidden;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-globe-africa"></i> Location Map</div>
        <a href="https://www.google.com/maps/search/?api=1&query={{ $address->latitude }},{{ $address->longitude }}" target="_blank" class="neon-btn neon-btn-cyan" style="padding:6px 14px; font-size:11px;">
            <i class="fas fa-external-link-alt"></i> Open in Google Maps
        </a>
    </div>
    <div style="position:relative; width:100%; height:400px; border-radius:0 0 var(--radius-lg) var(--radius-lg); overflow:hidden;">
        <iframe
            width="100%"
            height="400"
            style="border:0; filter:invert(90%) hue-rotate(180deg) brightness(1.1) contrast(1.1);"
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"
            src="https://www.google.com/maps/embed/v1/place?key=AIzaSyDlFzdbBe7bMPm9jrCo6C8340ELKtsZjEw&q={{ $address->latitude }},{{ $address->longitude }}&zoom=16&maptype=roadmap">
        </iframe>
        <div style="position:absolute; bottom:12px; left:12px; background:rgba(0,0,0,0.7); backdrop-filter:blur(8px); padding:8px 14px; border-radius:6px; display:flex; align-items:center; gap:8px;">
            <i class="fas fa-map-pin" style="color:var(--accent-green); font-size:14px;"></i>
            <span style="font-family:var(--font-mono); font-size:13px; color:var(--accent-cyan);">{{ $address->latitude }}, {{ $address->longitude }}</span>
        </div>
    </div>
</div>
@elseif($address->google_formatted_address)
<div class="sl-card sl-animate d3" style="margin-top:20px; overflow:hidden;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-globe-africa"></i> Location Map</div>
        <a href="https://www.google.com/maps/search/?api=1&query={{ urlencode($address->google_formatted_address) }}" target="_blank" class="neon-btn neon-btn-cyan" style="padding:6px 14px; font-size:11px;">
            <i class="fas fa-external-link-alt"></i> Open in Google Maps
        </a>
    </div>
    <div style="position:relative; width:100%; height:400px; border-radius:0 0 var(--radius-lg) var(--radius-lg); overflow:hidden;">
        <iframe
            width="100%"
            height="400"
            style="border:0; filter:invert(90%) hue-rotate(180deg) brightness(1.1) contrast(1.1);"
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"
            src="https://www.google.com/maps/embed/v1/place?key=AIzaSyDlFzdbBe7bMPm9jrCo6C8340ELKtsZjEw&q={{ urlencode($address->google_formatted_address) }}&zoom=16&maptype=roadmap">
        </iframe>
    </div>
</div>
@endif

{{-- Linked Entities --}}
@if($address->links && $address->links->count())
<div class="sl-card sl-animate d3 sl-mb-md" style="margin-top:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-link"></i> Linked Entities</div>
    </div>
    <div class="sl-table-wrap">
        <table class="sl-table">
            <thead><tr><th>Type</th><th>Entity</th><th>Address Type</th><th class="center">Primary</th></tr></thead>
            <tbody>
                @foreach($address->links as $link)
                <tr>
                    <td>{{ class_basename($link->linkable_type) }}</td>
                    <td>{{ $link->linkable_id }}</td>
                    <td>{{ $link->addressType->name ?? '-' }}</td>
                    <td class="center">
                        @if($link->is_primary) <span class="sl-status-dot pass"></span>
                        @else <span class="sl-status-dot fail"></span>
                        @endif
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endif
@endsection
