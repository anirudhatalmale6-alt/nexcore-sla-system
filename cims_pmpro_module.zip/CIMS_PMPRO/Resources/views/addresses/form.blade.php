@extends('cims_pmpro::layouts.pmpro')

@section('title', isset($address) ? 'Edit Address' : 'New Address')
@section('page_heading', isset($address) ? 'EDIT ADDRESS' : 'NEW ADDRESS')

@push('styles')
<style>
.sl-form-section {
    background: var(--bg-surface);
    border: 1px solid var(--border-subtle);
    border-radius: var(--radius-lg);
    padding: 24px;
    margin-bottom: 20px;
    box-shadow: var(--shadow-card);
}
.sl-form-section-title {
    font-size: 15px;
    font-weight: 700;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: var(--accent-green);
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid var(--border-subtle);
    display: flex;
    align-items: center;
    gap: 10px;
}
.sl-form-section-title i { font-size: 16px; }
.sl-form-grid { display: grid; gap: 16px; }
.sl-form-grid.cols-2 { grid-template-columns: 1fr 1fr; }
.sl-form-grid.cols-3 { grid-template-columns: 1fr 1fr 1fr; }
.sl-form-grid.cols-4 { grid-template-columns: 1fr 1fr 1fr 1fr; }
.sl-form-grid.cols-2-1 { grid-template-columns: 2fr 1fr; }
.sl-form-grid.cols-1-2 { grid-template-columns: 1fr 2fr; }

.sl-field label .required { color: var(--accent-red); margin-left: 2px; }
.sl-field select {
    background: var(--bg-raised);
    border: 1px solid var(--border-default);
    border-radius: var(--radius-sm);
    padding: 9px 12px;
    color: var(--text-primary);
    font-size: 15px;
    font-family: var(--font-mono);
    transition: var(--transition-fast);
    outline: none;
    width: 100%;
    appearance: none;
    -webkit-appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%235a6478' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 12px center;
    padding-right: 32px;
}
.sl-field select:focus { border-color: var(--accent-green); box-shadow: 0 0 0 2px rgba(34,197,94,0.15); }
.sl-field textarea {
    background: var(--bg-raised);
    border: 1px solid var(--border-default);
    border-radius: var(--radius-sm);
    padding: 9px 12px;
    color: var(--text-primary);
    font-size: 15px;
    font-family: var(--font-mono);
    transition: var(--transition-fast);
    outline: none;
    width: 100%;
    resize: vertical;
    min-height: 60px;
}
.sl-field textarea:focus { border-color: var(--accent-green); box-shadow: 0 0 0 2px rgba(34,197,94,0.15); }
.sl-field input { width: 100%; }

.sl-secondary-toggle {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 14px 20px;
    background: var(--bg-raised);
    border: 1px solid var(--border-default);
    border-radius: var(--radius-md);
    cursor: pointer;
    transition: var(--transition-fast);
    margin-bottom: 20px;
    color: var(--text-secondary);
    font-size: 15px;
    font-weight: 600;
    letter-spacing: 0.5px;
}
.sl-secondary-toggle:hover { border-color: var(--accent-green); color: var(--text-primary); }
.sl-secondary-toggle i { transition: transform 0.3s; }
.sl-secondary-toggle.open i { transform: rotate(180deg); }
.sl-secondary-panel { display: none; }
.sl-secondary-panel.open { display: block; }

.sl-google-autocomplete-wrap {
    position: relative;
}
.sl-google-autocomplete-wrap .sl-autofill-badge {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 1px;
    text-transform: uppercase;
    color: var(--accent-green);
    background: var(--accent-green-dim);
    padding: 2px 8px;
    border-radius: var(--radius-sm);
    pointer-events: none;
}

.sl-radio-group {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}
.sl-radio-pill {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 7px 14px;
    border-radius: 20px;
    background: var(--bg-raised);
    border: 1px solid var(--border-default);
    cursor: pointer;
    transition: var(--transition-fast);
    font-size: 14px;
    font-weight: 600;
    color: var(--text-muted);
}
.sl-radio-pill:hover { border-color: var(--border-strong); color: var(--text-secondary); }
.sl-radio-pill input[type="radio"] { display: none; }
.sl-radio-pill.active {
    background: var(--accent-green-dim);
    border-color: rgba(34,197,94,0.3);
    color: var(--accent-green);
}

.sl-gps-display {
    display: flex;
    gap: 16px;
    padding: 12px 16px;
    background: var(--bg-raised);
    border: 1px solid var(--border-subtle);
    border-radius: var(--radius-sm);
}
.sl-gps-item {
    display: flex;
    align-items: center;
    gap: 6px;
    font-family: var(--font-mono);
    font-size: 14px;
    color: var(--text-secondary);
}
.sl-gps-item i { color: var(--accent-cyan); font-size: 13px; }

@media (max-width: 768px) {
    .sl-form-grid.cols-2, .sl-form-grid.cols-3, .sl-form-grid.cols-4 { grid-template-columns: 1fr; }
    .sl-form-grid.cols-2-1, .sl-form-grid.cols-1-2 { grid-template-columns: 1fr; }
}
</style>
@endpush

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ isset($address) ? 'Edit Address #'.$address->id : 'Create New Address' }}</h1>
        <span class="sl-page-subtitle">{{ isset($address) ? 'Update address details' : 'Add a new South African address' }}</span>
        <div style="margin-left:auto;">
            <a href="{{ route('pmpro.addresses.index') }}" class="neon-btn neon-btn-ghost">
                <i class="fas fa-arrow-left"></i> Back to List
            </a>
        </div>
    </div>
</div>

@if(isset($duplicate))
<div class="sl-card sl-animate d1" style="margin-bottom:20px; border:2px solid var(--accent-amber); background:rgba(217,119,6,0.08);">
    <div class="sl-card-header" style="border-bottom-color:rgba(217,119,6,0.2);">
        <div class="sl-card-title" style="color:var(--accent-amber);"><i class="fas fa-exclamation-triangle"></i> Duplicate Address Found</div>
    </div>
    <div style="padding:20px;">
        <p style="color:var(--text-secondary); font-size:14px; margin-bottom:16px;">
            An address matching your input already exists in the system. You can use the existing address or create a new one anyway.
        </p>
        <div style="background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-md); padding:16px; margin-bottom:16px;">
            <div style="font-size:15px; font-weight:600; color:var(--text-primary); margin-bottom:6px;">
                {{ $duplicate->unit_number ? 'Unit '.$duplicate->unit_number.', ' : '' }}{{ $duplicate->complex_name ? $duplicate->complex_name.', ' : '' }}{{ $duplicate->street_number }} {{ $duplicate->street_name }}
            </div>
            <div style="font-size:14px; color:var(--text-secondary);">
                {{ $duplicate->suburb->name ?? '' }}{{ $duplicate->suburb ? ', ' : '' }}{{ $duplicate->city }}, {{ $duplicate->postal_code }}
            </div>
            <div style="font-size:13px; color:var(--text-muted); margin-top:4px;">
                {{ $duplicate->province->name ?? '' }} | {{ $duplicate->address_category }} | ID: #{{ $duplicate->id }}
            </div>
        </div>
        <div style="display:flex; gap:12px;">
            <a href="{{ route('pmpro.addresses.show', $duplicate->id) }}" class="neon-btn neon-btn-green" style="flex:1; justify-content:center;">
                <i class="fas fa-check"></i> Use Existing Address
            </a>
            <form method="POST" action="{{ route('pmpro.addresses.store') }}" style="flex:1;">
                @csrf
                <input type="hidden" name="force_create" value="1">
                @foreach($oldInput as $key => $val)
                    @if($key !== '_token' && !is_array($val))
                    <input type="hidden" name="{{ $key }}" value="{{ $val }}">
                    @endif
                @endforeach
                <button type="submit" class="neon-btn neon-btn-amber" style="width:100%; justify-content:center;">
                    <i class="fas fa-plus"></i> Create Anyway
                </button>
            </form>
        </div>
    </div>
</div>
@endif

<form method="POST" action="{{ isset($address) ? route('pmpro.addresses.update', $address->id) : route('pmpro.addresses.store') }}" id="addressForm">
    @csrf
    @if(isset($address))
        @method('PUT')
    @endif

    {{-- Google Autocomplete Search --}}
    <div class="sl-form-section sl-animate d2">
        <div class="sl-form-section-title">
            <i class="fab fa-google"></i> Quick Address Search
        </div>
        <div class="sl-field">
            <label>Start typing to search via Google</label>
            <div class="sl-google-autocomplete-wrap">
                <input type="text" id="googleAutocomplete" placeholder="e.g. 14 Rivonia Road, Sandton, Johannesburg..." autocomplete="off" style="width:100%; padding-right:80px;">
                <span class="sl-autofill-badge">Auto-Fill</span>
            </div>
            <div style="margin-top:6px; font-size:12px; color:var(--text-muted); letter-spacing:0.5px;">
                Select a result to auto-fill the address fields below. You can also fill them manually.
            </div>
        </div>
    </div>

    {{-- Main Address (Compulsory) --}}
    <div class="sl-form-section sl-animate d3">
        <div class="sl-form-section-title">
            <i class="fas fa-map-marker-alt"></i> Main Address <span style="font-size:12px; color:var(--text-muted); font-weight:500; letter-spacing:0.5px; margin-left:8px;">( required fields )</span>
        </div>

        <div class="sl-form-grid cols-4" style="margin-bottom:16px;">
            <div class="sl-field">
                <label>Unit Number</label>
                <input type="text" name="unit_number" value="{{ old('unit_number', $address->unit_number ?? '') }}" placeholder="e.g. 5, 12A">
            </div>
            <div class="sl-field">
                <label>Complex / Estate Name</label>
                <input type="text" name="complex_name" value="{{ old('complex_name', $address->complex_name ?? '') }}" placeholder="e.g. Willowbrook Estate">
            </div>
            <div class="sl-field">
                <label>Street Number <span class="required">*</span></label>
                <input type="text" name="street_number" value="{{ old('street_number', $address->street_number ?? '') }}" placeholder="e.g. 144" required>
            </div>
            <div class="sl-field">
                <label>Street Name <span class="required">*</span></label>
                <input type="text" name="street_name" value="{{ old('street_name', $address->street_name ?? '') }}" placeholder="e.g. Rivonia Road" required>
            </div>
        </div>

        <div class="sl-form-grid cols-3" style="margin-bottom:16px;">
            <div class="sl-field">
                <label>Suburb</label>
                <input type="text" id="suburbSearch" placeholder="Type to search suburbs..." autocomplete="off" value="{{ old('suburb_name', isset($address) && $address->suburb ? $address->suburb->name : '') }}">
                <input type="hidden" name="suburb_id" id="suburbId" value="{{ old('suburb_id', $address->suburb_id ?? '') }}">
                <div id="suburbDropdown" style="display:none; position:absolute; z-index:100; background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); max-height:200px; overflow-y:auto; width:100%; margin-top:2px;"></div>
            </div>
            <div class="sl-field">
                <label>City / Town <span class="required">*</span></label>
                <input type="text" name="city" id="cityField" value="{{ old('city', $address->city ?? '') }}" placeholder="e.g. Johannesburg" required>
            </div>
            <div class="sl-field">
                <label>Postal Code <span class="required">*</span></label>
                <input type="text" name="postal_code" id="postalCodeField" value="{{ old('postal_code', $address->postal_code ?? '') }}" placeholder="e.g. 2196" maxlength="10" required>
            </div>
        </div>

        <div class="sl-form-grid cols-3" style="margin-bottom:16px;">
            <div class="sl-field">
                <label>Province <span class="required">*</span></label>
                <select name="province_id" id="provinceSelect" required>
                    <option value="">Select Province</option>
                    @foreach($provinces as $prov)
                        <option value="{{ $prov->id }}" {{ old('province_id', $address->province_id ?? '') == $prov->id ? 'selected' : '' }}>{{ $prov->name }} ({{ $prov->code }})</option>
                    @endforeach
                </select>
            </div>
            <div class="sl-field">
                <label>Municipality</label>
                <select name="municipality_id" id="municipalitySelect">
                    <option value="">Select Municipality</option>
                </select>
            </div>
            <div class="sl-field">
                <label>Ward</label>
                <select name="ward_id" id="wardSelect">
                    <option value="">Select Ward</option>
                </select>
            </div>
        </div>

        <div class="sl-form-grid cols-2" style="margin-bottom:16px;">
            <div class="sl-field">
                <label>Country</label>
                <select name="country">
                    <option value="ZA" {{ old('country', $address->country ?? 'ZA') == 'ZA' ? 'selected' : '' }}>South Africa (ZA)</option>
                </select>
            </div>
            <div class="sl-field">
                <label>Address Category <span class="required">*</span></label>
                <div class="sl-radio-group" id="categoryGroup">
                    @php $cat = old('address_category', $address->address_category ?? 'Residential'); @endphp
                    @foreach(['Residential', 'Commercial', 'Industrial', 'Agricultural', 'Mixed Use'] as $c)
                    <label class="sl-radio-pill {{ $cat == $c ? 'active' : '' }}">
                        <input type="radio" name="address_category" value="{{ $c }}" {{ $cat == $c ? 'checked' : '' }}>
                        {{ $c }}
                    </label>
                    @endforeach
                </div>
            </div>
        </div>

        {{-- GPS Coordinates --}}
        <div class="sl-form-grid cols-2">
            <div class="sl-field">
                <label>Google Formatted Address</label>
                <textarea name="google_formatted_address" id="googleFormatted" rows="2">{{ old('google_formatted_address', $address->google_formatted_address ?? '') }}</textarea>
            </div>
            <div class="sl-field">
                <label>GPS Coordinates</label>
                <div class="sl-gps-display">
                    <div class="sl-gps-item">
                        <i class="fas fa-location-crosshairs"></i>
                        <span>Lat:</span>
                        <input type="text" name="latitude" id="latField" value="{{ old('latitude', $address->latitude ?? '') }}" placeholder="--" style="width:120px; background:transparent; border:none; color:var(--accent-cyan); font-family:var(--font-mono); font-size:14px; outline:none;">
                    </div>
                    <div class="sl-gps-item">
                        <i class="fas fa-location-crosshairs"></i>
                        <span>Lng:</span>
                        <input type="text" name="longitude" id="lngField" value="{{ old('longitude', $address->longitude ?? '') }}" placeholder="--" style="width:120px; background:transparent; border:none; color:var(--accent-cyan); font-family:var(--font-mono); font-size:14px; outline:none;">
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Secondary Address (Optional - Expandable) --}}
    <div class="sl-secondary-toggle sl-animate d4" id="secondaryToggle" onclick="toggleSecondary()">
        <i class="fas fa-chevron-down"></i>
        <span>Extended Address Details</span>
        <span style="font-size:12px; color:var(--text-muted); margin-left:auto;">Optional - for farms, sectional titles, government compliance</span>
    </div>

    <div class="sl-secondary-panel" id="secondaryPanel">
        <div class="sl-form-section sl-animate">
            <div class="sl-form-section-title">
                <i class="fas fa-building"></i> Property Details
            </div>
            @php $sec = $address->secondary ?? null; @endphp
            <div class="sl-form-grid cols-4" style="margin-bottom:16px;">
                <div class="sl-field">
                    <label>Floor / Level</label>
                    <input type="text" name="floor_level" value="{{ old('floor_level', $sec->floor_level ?? '') }}" placeholder="e.g. 3rd Floor">
                </div>
                <div class="sl-field">
                    <label>Building Name</label>
                    <input type="text" name="building_name" value="{{ old('building_name', $sec->building_name ?? '') }}" placeholder="e.g. Sandton City Tower">
                </div>
                <div class="sl-field">
                    <label>Security Estate</label>
                    <input type="text" name="estate_name" value="{{ old('estate_name', $sec->estate_name ?? '') }}" placeholder="e.g. Dainfern Estate">
                </div>
                <div class="sl-field">
                    <label>Section Number</label>
                    <input type="text" name="section_number" value="{{ old('section_number', $sec->section_number ?? '') }}" placeholder="Sectional title scheme #">
                </div>
            </div>

            <div class="sl-form-section-title" style="margin-top:20px;">
                <i class="fas fa-tractor"></i> Farm / Rural Address
            </div>
            <div class="sl-form-grid cols-3" style="margin-bottom:16px;">
                <div class="sl-field">
                    <label>Farm Name</label>
                    <input type="text" name="farm_name" value="{{ old('farm_name', $sec->farm_name ?? '') }}" placeholder="e.g. Farm Rietfontein">
                </div>
                <div class="sl-field">
                    <label>Farm Number</label>
                    <input type="text" name="farm_number" value="{{ old('farm_number', $sec->farm_number ?? '') }}" placeholder="e.g. 123">
                </div>
                <div class="sl-field">
                    <label>Stand Number</label>
                    <input type="text" name="stand_number" value="{{ old('stand_number', $sec->stand_number ?? '') }}" placeholder="Township/informal stand #">
                </div>
            </div>

            <div class="sl-form-section-title" style="margin-top:20px;">
                <i class="fas fa-landmark"></i> Government / Compliance
            </div>
            <div class="sl-form-grid cols-3" style="margin-bottom:16px;">
                <div class="sl-field">
                    <label>ERF Number</label>
                    <input type="text" name="erf_number" value="{{ old('erf_number', $sec->erf_number ?? '') }}" placeholder="Cadastral reference">
                </div>
                <div class="sl-field">
                    <label>SG Code</label>
                    <input type="text" name="sg_code" value="{{ old('sg_code', $sec->sg_code ?? '') }}" placeholder="Surveyor General code">
                </div>
                <div class="sl-field">
                    <label>Municipal Account Number</label>
                    <input type="text" name="municipal_account_number" value="{{ old('municipal_account_number', $sec->municipal_account_number ?? '') }}" placeholder="Council account #">
                </div>
            </div>

            <div class="sl-form-section-title" style="margin-top:20px;">
                <i class="fas fa-satellite"></i> Digital Addressing
            </div>
            <div class="sl-form-grid cols-3" style="margin-bottom:16px;">
                <div class="sl-field">
                    <label>Google Plus Code</label>
                    <input type="text" name="plus_code" value="{{ old('plus_code', $sec->plus_code ?? '') }}" placeholder="e.g. 2GCJ+Q4 Sandton">
                </div>
                <div class="sl-field">
                    <label>What3Words</label>
                    <input type="text" name="what3words" value="{{ old('what3words', $sec->what3words ?? '') }}" placeholder="e.g. ///filled.count.soap">
                </div>
                <div class="sl-field">
                    <label>Google Place ID</label>
                    <input type="text" name="google_place_id" value="{{ old('google_place_id', $sec->google_place_id ?? '') }}" placeholder="Auto-filled from search">
                </div>
            </div>
            <div class="sl-form-grid cols-2">
                <div class="sl-field">
                    <label>Map URL</label>
                    <input type="text" name="map_url" value="{{ old('map_url', $sec->map_url ?? '') }}" placeholder="Google Maps link">
                </div>
                <div class="sl-field">
                    <label>Address Source</label>
                    <select name="address_source">
                        @php $src = old('address_source', $sec->address_source ?? 'Manual'); @endphp
                        <option value="Manual" {{ $src == 'Manual' ? 'selected' : '' }}>Manual Entry</option>
                        <option value="Google" {{ $src == 'Google' ? 'selected' : '' }}>Google Autocomplete</option>
                        <option value="Imported" {{ $src == 'Imported' ? 'selected' : '' }}>Imported / Bulk Upload</option>
                        <option value="SARS" {{ $src == 'SARS' ? 'selected' : '' }}>SARS / Government</option>
                    </select>
                </div>
            </div>
        </div>
    </div>

    {{-- Form Actions --}}
    <div class="sl-form-actions sl-animate d5" style="border-top:none; padding-top:0;">
        <a href="{{ route('pmpro.addresses.index') }}" class="neon-btn neon-btn-red">
            <i class="fas fa-times"></i> Cancel
        </a>
        <button type="submit" class="neon-btn neon-btn-green neon-pulse">
            <i class="fas fa-save"></i> {{ isset($address) ? 'Update Address' : 'Save Address' }}
        </button>
    </div>
</form>
@endsection

@push('scripts')
<script>
// Radio pill toggling
document.querySelectorAll('.sl-radio-pill input[type="radio"]').forEach(function(r) {
    r.addEventListener('change', function() {
        document.querySelectorAll('.sl-radio-pill').forEach(function(p) { p.classList.remove('active'); });
        if (this.checked) this.closest('.sl-radio-pill').classList.add('active');
    });
});

// Toggle secondary panel
function toggleSecondary() {
    var toggle = document.getElementById('secondaryToggle');
    var panel = document.getElementById('secondaryPanel');
    toggle.classList.toggle('open');
    panel.classList.toggle('open');
}

// Auto-open secondary if editing and has secondary data
@if(isset($address) && $address->secondary)
document.addEventListener('DOMContentLoaded', function() { toggleSecondary(); });
@endif

// Suburb search with AJAX
var suburbTimer = null;
var suburbSearch = document.getElementById('suburbSearch');
var suburbDropdown = document.getElementById('suburbDropdown');
var suburbIdField = document.getElementById('suburbId');

if (suburbSearch) {
    suburbSearch.addEventListener('input', function() {
        clearTimeout(suburbTimer);
        var val = this.value.trim();
        if (val.length < 2) { suburbDropdown.style.display = 'none'; return; }
        suburbTimer = setTimeout(function() {
            fetch('/pmpro/lookup/search-suburbs?q=' + encodeURIComponent(val))
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (!data.length) { suburbDropdown.style.display = 'none'; return; }
                    var html = '';
                    data.forEach(function(s) {
                        var dataAttrs = 'data-id="' + s.id + '" data-name="' + (s.name || '').replace(/"/g,'&quot;') + '" data-city="' + (s.city || '').replace(/"/g,'&quot;') + '" data-postal="' + (s.postal_code || '') + '" data-prov="' + (s.province_id || '') + '" data-metro="' + (s.metro_id || '') + '" data-localmuni="' + (s.local_municipality_id || '') + '"';
                        html += '<div style="padding:8px 12px; cursor:pointer; font-size:14px; color:var(--text-secondary); border-bottom:1px solid var(--border-subtle); transition:background 0.15s;" ' +
                            'onmouseover="this.style.background=\'var(--bg-hover)\'" onmouseout="this.style.background=\'transparent\'" ' +
                            dataAttrs + ' onclick="selectSuburbEl(this)">' +
                            '<strong style="color:var(--text-primary);">' + s.name + '</strong>' +
                            '<span style="color:var(--text-muted); margin-left:8px;">' + (s.city || '') + '</span>' +
                            '<span style="float:right; font-family:var(--font-mono); color:var(--accent-cyan);">' + (s.postal_code || '') + '</span>' +
                            '</div>';
                    });
                    suburbDropdown.innerHTML = html;
                    suburbDropdown.style.display = 'block';
                });
        }, 300);
    });

    document.addEventListener('click', function(e) {
        if (!suburbSearch.contains(e.target) && !suburbDropdown.contains(e.target)) {
            suburbDropdown.style.display = 'none';
        }
    });
}

function selectSuburbEl(el) {
    var id = el.getAttribute('data-id');
    var name = el.getAttribute('data-name');
    var city = el.getAttribute('data-city');
    var postal = el.getAttribute('data-postal');
    var provId = el.getAttribute('data-prov');
    var metroId = el.getAttribute('data-metro');
    var localMuniId = el.getAttribute('data-localmuni');

    suburbIdField.value = id;
    suburbSearch.value = name;
    suburbDropdown.style.display = 'none';
    if (city) document.getElementById('cityField').value = city;
    if (postal) document.getElementById('postalCodeField').value = postal;

    if (provId) {
        provinceSelect.value = provId;
        loadMunicipalitiesForProvince(provId, metroId || localMuniId);
    }
}

function selectSuburb(id, name, city, postalCode) {
    suburbIdField.value = id;
    suburbSearch.value = name;
    suburbDropdown.style.display = 'none';
    if (city) document.getElementById('cityField').value = city;
    if (postalCode) document.getElementById('postalCodeField').value = postalCode;
}

// Province > Municipality > Ward cascade
var provinceSelect = document.getElementById('provinceSelect');
var municipalitySelect = document.getElementById('municipalitySelect');
var wardSelect = document.getElementById('wardSelect');
var _pendingMuniSelect = null;

function loadMunicipalitiesForProvince(pid, autoSelectId) {
    municipalitySelect.innerHTML = '<option value="">Loading...</option>';
    wardSelect.innerHTML = '<option value="">Select Ward</option>';
    _pendingMuniSelect = autoSelectId || null;

    Promise.all([
        fetch('/pmpro/lookup/local-municipalities/' + pid).then(function(r) { return r.json(); }),
        fetch('/pmpro/lookup/metros/' + pid).then(function(r) { return r.json(); })
    ]).then(function(results) {
        var locals = results[0];
        var metros = results[1];
        var html = '<option value="">Select Municipality</option>';

        if (metros.length) {
            html += '<optgroup label="Metropolitan">';
            metros.forEach(function(m) { html += '<option value="' + m.id + '">' + m.name + '</option>'; });
            html += '</optgroup>';
        }
        if (locals.length) {
            html += '<optgroup label="Local Municipality">';
            locals.forEach(function(l) { html += '<option value="' + l.id + '">' + l.name + '</option>'; });
            html += '</optgroup>';
        }
        municipalitySelect.innerHTML = html;

        if (_pendingMuniSelect) {
            municipalitySelect.value = _pendingMuniSelect;
            if (municipalitySelect.value == _pendingMuniSelect) {
                loadWardsForMunicipality(_pendingMuniSelect);
            }
            _pendingMuniSelect = null;
        }
    });
}

function loadWardsForMunicipality(muniId) {
    wardSelect.innerHTML = '<option value="">Loading...</option>';
    fetch('/pmpro/lookup/wards/' + muniId)
        .then(function(r) { return r.json(); })
        .then(function(wards) {
            var html = '<option value="">Select Ward</option>';
            wards.forEach(function(w) {
                var label = 'Ward ' + (w.ward_number || w.id);
                if (w.ward_label) label = w.ward_label;
                html += '<option value="' + w.id + '">' + label + '</option>';
            });
            wardSelect.innerHTML = html;
        });
}

function setProvinceFromGoogle(provName) {
    if (!provName) return;
    var opts = provinceSelect.options;
    for (var i = 0; i < opts.length; i++) {
        if (opts[i].text.indexOf(provName) !== -1) {
            opts[i].selected = true;
            loadMunicipalitiesForProvince(opts[i].value);
            break;
        }
    }
}

if (provinceSelect) {
    provinceSelect.addEventListener('change', function() {
        var pid = this.value;
        if (!pid) {
            municipalitySelect.innerHTML = '<option value="">Select Municipality</option>';
            wardSelect.innerHTML = '<option value="">Select Ward</option>';
            return;
        }
        loadMunicipalitiesForProvince(pid);
    });
}

if (municipalitySelect) {
    municipalitySelect.addEventListener('change', function() {
        var mid = this.value;
        if (!mid) { wardSelect.innerHTML = '<option value="">Select Ward</option>'; return; }
        loadWardsForMunicipality(mid);
    });
}

// Validation highlighting
document.getElementById('addressForm').addEventListener('submit', function(e) {
    var required = this.querySelectorAll('[required]');
    var valid = true;
    required.forEach(function(f) {
        if (!f.value.trim()) {
            f.style.borderColor = 'var(--accent-red)';
            f.style.boxShadow = '0 0 0 2px rgba(239,68,68,0.15)';
            valid = false;
        } else {
            f.style.borderColor = '';
            f.style.boxShadow = '';
        }
    });
    if (!valid) {
        e.preventDefault();
        var first = this.querySelector('[required]:invalid, [required][style*="border-color"]');
        if (first) first.focus();
    }
});

// Clear validation on input
document.querySelectorAll('[required]').forEach(function(f) {
    f.addEventListener('input', function() {
        this.style.borderColor = '';
        this.style.boxShadow = '';
    });
});
</script>

{{-- Google Places API --}}
<script>
function initGoogleAutocomplete() {
    var input = document.getElementById('googleAutocomplete');
    if (!input || typeof google === 'undefined') return;

    var autocomplete = new google.maps.places.Autocomplete(input, {
        componentRestrictions: { country: 'za' },
        fields: ['address_components', 'formatted_address', 'geometry', 'place_id', 'plus_code']
    });

    autocomplete.addListener('place_changed', function() {
        var place = autocomplete.getPlace();
        if (!place.address_components) return;

        // Extract all address component types
        var fields = {};
        place.address_components.forEach(function(c) {
            c.types.forEach(function(t) {
                fields[t] = c.long_name;
            });
        });

        // Fill form
        var streetNumEl = document.querySelector('[name="street_number"]');
        var streetNameEl = document.querySelector('[name="street_name"]');
        if (streetNumEl) streetNumEl.value = fields.street_number || '';
        if (streetNameEl) streetNameEl.value = fields.route || '';

        document.getElementById('cityField').value = fields.locality || fields.administrative_area_level_2 || '';
        document.getElementById('postalCodeField').value = fields.postal_code || '';

        // Auto-match suburb from Google result
        var googleSuburb = fields.sublocality_level_1 || fields.sublocality || fields.neighborhood || fields.sublocality_level_2 || '';

        // Fallback: parse suburb from formatted address (pattern: "Street, Suburb, City, PostalCode, Country")
        if (!googleSuburb && place.formatted_address) {
            var parts = place.formatted_address.split(',').map(function(p) { return p.trim(); });
            if (parts.length >= 4) {
                var candidate = parts[1];
                if (candidate && candidate !== (fields.locality || '') && candidate !== (fields.route || '') && !/^\d+$/.test(candidate)) {
                    googleSuburb = candidate;
                }
            }
        }

        // Second fallback: if locality differs from administrative_area_level_2, locality may be the suburb
        if (!googleSuburb && fields.locality && fields.administrative_area_level_2 && fields.locality !== fields.administrative_area_level_2) {
            googleSuburb = fields.locality;
            document.getElementById('cityField').value = fields.administrative_area_level_2;
        }

        var _googleProvince = fields.administrative_area_level_1 || '';
        var _googleLocality = fields.locality || '';

        function applyPmSuburbMatch(match, searchEl, idEl) {
            idEl.value = match.id;
            searchEl.value = match.name;
            searchEl.style.borderColor = 'var(--accent-green)';
            searchEl.style.boxShadow = '0 0 0 2px rgba(34,197,94,0.15)';
            setTimeout(function() { searchEl.style.borderColor = ''; searchEl.style.boxShadow = ''; }, 2000);
            if (match.province_id) {
                provinceSelect.value = match.province_id;
                loadMunicipalitiesForProvince(match.province_id, match.metro_id || match.local_municipality_id);
            } else {
                setProvinceFromGoogle(_googleProvince);
            }
        }

        if (googleSuburb) {
            var _subSearch = document.getElementById('suburbSearch');
            var _subId = document.getElementById('suburbId');
            var _city = document.getElementById('cityField').value;
            var _postal = document.getElementById('postalCodeField').value;
            if (_subSearch) {
                _subSearch.value = googleSuburb;
                fetch('/pmpro/lookup/search-suburbs?q=' + encodeURIComponent(googleSuburb))
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        if (data.length) {
                            var match = data.find(function(s) { return s.name.toLowerCase() === googleSuburb.toLowerCase(); }) || data[0];
                            applyPmSuburbMatch(match, _subSearch, _subId);
                        } else if (_googleLocality && _googleLocality.toLowerCase() !== googleSuburb.toLowerCase()) {
                            fetch('/pmpro/lookup/search-suburbs?q=' + encodeURIComponent(_googleLocality))
                                .then(function(r) { return r.json(); })
                                .then(function(data2) {
                                    if (data2.length) {
                                        var match2 = data2.find(function(s) { return s.name.toLowerCase() === _googleLocality.toLowerCase(); }) || data2[0];
                                        applyPmSuburbMatch(match2, _subSearch, _subId);
                                    } else {
                                        setProvinceFromGoogle(_googleProvince);
                                    }
                                });
                        } else {
                            setProvinceFromGoogle(_googleProvince);
                        }
                    });
            } else {
                setProvinceFromGoogle(_googleProvince);
            }
        } else if (_googleLocality) {
            var _subSearch = document.getElementById('suburbSearch');
            var _subId = document.getElementById('suburbId');
            if (_subSearch) {
                _subSearch.value = _googleLocality;
                fetch('/pmpro/lookup/search-suburbs?q=' + encodeURIComponent(_googleLocality))
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        if (data.length) {
                            var match = data.find(function(s) { return s.name.toLowerCase() === _googleLocality.toLowerCase(); }) || data[0];
                            applyPmSuburbMatch(match, _subSearch, _subId);
                        } else {
                            setProvinceFromGoogle(_googleProvince);
                        }
                    });
            } else {
                setProvinceFromGoogle(_googleProvince);
            }
        } else {
            setProvinceFromGoogle(_googleProvince);
        }

        if (place.formatted_address) document.getElementById('googleFormatted').value = place.formatted_address;
        if (place.geometry) {
            document.getElementById('latField').value = place.geometry.location.lat().toFixed(8);
            document.getElementById('lngField').value = place.geometry.location.lng().toFixed(8);
        }
        if (place.place_id) {
            var placeIdField = document.querySelector('[name="google_place_id"]');
            if (placeIdField) {
                placeIdField.value = place.place_id;
                if (!document.getElementById('secondaryPanel').classList.contains('open')) toggleSecondary();
            }
        }
        if (place.plus_code && place.plus_code.global_code) {
            var plusCodeField = document.querySelector('[name="plus_code"]');
            if (plusCodeField) plusCodeField.value = place.plus_code.global_code;
        }

        // Mark source as Google
        var sourceField = document.querySelector('[name="address_source"]');
        if (sourceField) sourceField.value = 'Google';
    });
}
</script>
<script>
(function() {
    var s = document.createElement('script');
    s.src = 'https://maps.googleapis.com/maps/api/js?key=AIzaSyDlFzdbBe7bMPm9jrCo6C8340ELKtsZjEw&libraries=places&callback=initGoogleAutocomplete';
    s.async = true;
    s.defer = true;
    document.body.appendChild(s);
})();
</script>
@endpush
