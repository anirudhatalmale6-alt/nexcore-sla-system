@extends('cims_pmpro::layouts.pmpro')

@section('title', 'Address Management')
@section('page_heading', 'ADDRESS MANAGEMENT')

@section('content')
<div class="sl-animate d1">
    {{-- Page Header with Action Button --}}
    <div class="sl-page-header">
        <h1 class="sl-page-title">Address Registry</h1>
        <span class="sl-page-subtitle">South African Address Source of Truth</span>
        <div style="margin-left:auto;">
            <a href="{{ route('pmpro.addresses.create') }}" class="neon-btn neon-btn-green">
                <i class="fas fa-plus"></i> New Address
            </a>
        </div>
    </div>
</div>

{{-- Stats Cards --}}
<div class="sl-stats-grid sl-animate d2">
    <div class="sl-stat-card green">
        <div class="sl-stat-label">Total</div>
        <div class="sl-stat-value" style="color:var(--accent-green);">{{ number_format($stats['total_addresses'] ?? 0) }}</div>
        <div class="sl-stat-meta">All records in system</div>
    </div>
    <div class="sl-stat-card blue">
        <div class="sl-stat-label">Active</div>
        <div class="sl-stat-value" style="color:var(--accent-blue);">{{ number_format($stats['active_addresses'] ?? 0) }}</div>
        <div class="sl-stat-meta">Currently active</div>
    </div>
    <div class="sl-stat-card amber">
        <div class="sl-stat-label">Inactive</div>
        <div class="sl-stat-value" style="color:var(--accent-amber);">{{ number_format($stats['inactive_addresses'] ?? 0) }}</div>
        <div class="sl-stat-meta">Archived records</div>
    </div>
    <div class="sl-stat-card purple">
        <div class="sl-stat-label">Residential</div>
        <div class="sl-stat-value" style="color:var(--accent-purple);">{{ number_format($stats['residential'] ?? 0) }}</div>
        <div class="sl-stat-meta">Home addresses</div>
    </div>
    <div class="sl-stat-card cyan">
        <div class="sl-stat-label">Commercial</div>
        <div class="sl-stat-value" style="color:var(--accent-cyan);">{{ number_format($stats['commercial'] ?? 0) }}</div>
        <div class="sl-stat-meta">Business premises</div>
    </div>
    <div class="sl-stat-card red">
        <div class="sl-stat-label">Industrial</div>
        <div class="sl-stat-value" style="color:var(--accent-red);">{{ number_format($stats['industrial'] ?? 0) }}</div>
        <div class="sl-stat-meta">Factory / warehouse</div>
    </div>
</div>

{{-- Search & Filters --}}
<div class="sl-card sl-animate d3 sl-mb-md">
    <form method="GET" action="{{ route('pmpro.addresses.index') }}" id="filterForm">
        <div class="sl-form-grid-3" style="gap:12px; align-items:end;">
            <div class="sl-field">
                <label>Search</label>
                <input type="text" name="search" value="{{ request('search') }}" placeholder="Street, suburb, city, postal code..." style="width:100%;">
            </div>
            <div class="sl-field">
                <label>Province</label>
                <select name="province_id" style="width:100%; background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:9px 12px; color:var(--text-primary); font-size:15px; font-family:var(--font-mono);">
                    <option value="">All Provinces</option>
                    @isset($provinces)
                    @foreach($provinces as $prov)
                        <option value="{{ $prov->id }}" {{ request('province_id') == $prov->id ? 'selected' : '' }}>{{ $prov->name }}</option>
                    @endforeach
                    @endisset
                </select>
            </div>
            <div style="display:flex; gap:8px;">
                <div class="sl-field" style="flex:1;">
                    <label>Category</label>
                    <select name="category" style="width:100%; background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:9px 12px; color:var(--text-primary); font-size:15px; font-family:var(--font-mono);">
                        <option value="">All</option>
                        <option value="Residential" {{ request('category') == 'Residential' ? 'selected' : '' }}>Residential</option>
                        <option value="Commercial" {{ request('category') == 'Commercial' ? 'selected' : '' }}>Commercial</option>
                        <option value="Industrial" {{ request('category') == 'Industrial' ? 'selected' : '' }}>Industrial</option>
                        <option value="Agricultural" {{ request('category') == 'Agricultural' ? 'selected' : '' }}>Agricultural</option>
                        <option value="Mixed Use" {{ request('category') == 'Mixed Use' ? 'selected' : '' }}>Mixed Use</option>
                    </select>
                </div>
                <div class="sl-field" style="flex-shrink:0; justify-content:flex-end;">
                    <label>&nbsp;</label>
                    <div style="display:flex; gap:8px;">
                        <button type="submit" class="neon-btn neon-btn-cyan" style="padding:9px 18px;">
                            <i class="fas fa-search"></i> Filter
                        </button>
                        <a href="{{ route('pmpro.addresses.index') }}" class="neon-btn neon-btn-ghost" style="padding:9px 18px;">
                            <i class="fas fa-times"></i> Clear
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

{{-- Address Table --}}
<div class="sl-card sl-animate d4">
    <div class="sl-card-header">
        <div class="sl-card-title">
            <i class="fas fa-map-marker-alt"></i> Address Records
        </div>
        <div style="font-size:13px; color:var(--text-muted);">
            @isset($addresses)
                Showing {{ $addresses->firstItem() ?? 0 }}-{{ $addresses->lastItem() ?? 0 }} of {{ $addresses->total() }}
            @else
                No records yet
            @endisset
        </div>
    </div>

    <div class="sl-table-wrap">
        <table class="sl-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Address</th>
                    <th>Suburb</th>
                    <th>City</th>
                    <th>Postal Code</th>
                    <th>Province</th>
                    <th>Category</th>
                    <th class="center">Status</th>
                    <th class="center">Actions</th>
                </tr>
            </thead>
            <tbody>
                @isset($addresses)
                @forelse($addresses as $addr)
                <tr>
                    <td class="mono">{{ $addr->id }}</td>
                    <td>
                        @if($addr->unit_number)<span style="color:var(--accent-cyan);">Unit {{ $addr->unit_number }}</span>, @endif
                        @if($addr->complex_name)<span style="color:var(--text-secondary);">{{ $addr->complex_name }}</span>, @endif
                        <span style="color:var(--text-primary);">{{ $addr->street_number }} {{ $addr->street_name }}</span>
                    </td>
                    <td>{{ $addr->suburb->name ?? '-' }}</td>
                    <td>{{ $addr->city }}</td>
                    <td class="mono">{{ $addr->postal_code }}</td>
                    <td>
                        @if($addr->province)
                            <span class="sl-tag sl-tag-green">{{ $addr->province->code }}</span>
                        @else
                            -
                        @endif
                    </td>
                    <td>
                        @php
                            $catColors = [
                                'Residential' => 'blue',
                                'Commercial' => 'purple',
                                'Industrial' => 'amber',
                                'Agricultural' => 'green',
                                'Mixed Use' => 'cyan',
                            ];
                            $catColor = $catColors[$addr->address_category] ?? 'blue';
                        @endphp
                        <span class="sl-tag sl-tag-{{ $catColor }}">{{ $addr->address_category }}</span>
                    </td>
                    <td class="center">
                        @if($addr->is_active)
                            <span class="sl-status-dot pass"></span>
                        @else
                            <span class="sl-status-dot fail"></span>
                        @endif
                    </td>
                    <td class="center">
                        <div style="display:flex; gap:6px; justify-content:center;">
                            <a href="{{ route('pmpro.addresses.edit', $addr->id) }}" style="color:var(--accent-blue); font-size:15px;" title="Edit">
                                <i class="fas fa-pen"></i>
                            </a>
                            <a href="{{ route('pmpro.addresses.show', $addr->id) }}" style="color:var(--accent-green); font-size:15px;" title="View">
                                <i class="fas fa-eye"></i>
                            </a>
                            <form method="POST" action="{{ route('pmpro.addresses.toggle', $addr->id) }}" style="display:inline;">
                                @csrf
                                <button type="submit" style="background:none; border:none; color:var(--accent-amber); cursor:pointer; font-size:15px;" title="Toggle Status">
                                    <i class="fas fa-power-off"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="9" style="text-align:center; padding:40px; color:var(--text-muted);">
                        <i class="fas fa-map-marker-alt" style="font-size:32px; opacity:0.3; margin-bottom:12px; display:block;"></i>
                        No addresses found. <a href="{{ route('pmpro.addresses.create') }}" style="color:var(--accent-green);">Create your first address</a>
                    </td>
                </tr>
                @endforelse
                @else
                <tr>
                    <td colspan="9" style="text-align:center; padding:40px; color:var(--text-muted);">
                        <i class="fas fa-database" style="font-size:32px; opacity:0.3; margin-bottom:12px; display:block;"></i>
                        Module initializing. Run migrations to set up tables.
                    </td>
                </tr>
                @endisset
            </tbody>
        </table>
    </div>

    {{-- Pagination --}}
    @isset($addresses)
    @if($addresses->hasPages())
    <div style="display:flex; justify-content:center; padding:16px 0 0; gap:4px;">
        @if($addresses->onFirstPage())
            <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Prev</span>
        @else
            <a href="{{ $addresses->previousPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Prev</a>
        @endif

        @foreach($addresses->getUrlRange(max(1, $addresses->currentPage()-2), min($addresses->lastPage(), $addresses->currentPage()+2)) as $page => $url)
            @if($page == $addresses->currentPage())
                <span class="sl-btn sl-btn-primary" style="padding:6px 12px; font-size:13px;">{{ $page }}</span>
            @else
                <a href="{{ $url }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">{{ $page }}</a>
            @endif
        @endforeach

        @if($addresses->hasMorePages())
            <a href="{{ $addresses->nextPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Next</a>
        @else
            <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Next</span>
        @endif
    </div>
    @endif
    @endisset
</div>
@endsection
