<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>PMPRO | @yield('title', 'Practice Manager Pro')</title>
    <link rel="shortcut icon" type="image/png" href="/public/smartdash/images/favicon.png">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="/public/css/nexcore_gl_master.css?v={{ time() }}" rel="stylesheet">
    <style>
    .sl-app { font-size: 15px; }
    .sl-field label { font-size: 13px; }
    .sl-field input, .sl-field select, .sl-field textarea { font-size: 15px; }
    .sl-stat-value { font-size: 22px; }
    .sl-stat-label { font-size: 13px; }
    .sl-table th { font-size: 13px; }
    .sl-table td { font-size: 14px; }
    .sl-result-label { font-size: 14px; }
    .sl-result-value { font-size: 14px; }
    .sl-tag { font-size: 12px; }
    .sl-page-title { font-size: 22px; }
    .sl-page-subtitle { font-size: 14px; }
    .sl-nav-item { font-size: 14px; }
    .sl-btn { font-size: 14px; }
    .sl-topbar-module, .sl-topbar-module-name { font-size: 14px; }
    .sl-card-title { font-size: 15px; }

    /* Neon Badge Buttons */
    .neon-btn {
        position: relative;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 22px;
        font-size: 13px;
        font-weight: 700;
        letter-spacing: 1.5px;
        text-transform: uppercase;
        text-decoration: none;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        overflow: hidden;
        font-family: var(--font-body);
        line-height: 1.4;
    }
    .neon-btn::before {
        content: '';
        position: absolute;
        inset: 0;
        border-radius: 6px;
        padding: 2px;
        background: linear-gradient(135deg, var(--neon-from), var(--neon-to));
        -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
        -webkit-mask-composite: xor;
        mask-composite: exclude;
        opacity: 0.8;
        transition: opacity 0.3s;
    }
    .neon-btn::after {
        content: '';
        position: absolute;
        inset: -2px;
        border-radius: 8px;
        background: linear-gradient(135deg, var(--neon-from), var(--neon-to));
        opacity: 0;
        filter: blur(12px);
        transition: opacity 0.4s;
        z-index: -1;
    }
    .neon-btn:hover::before { opacity: 1; }
    .neon-btn:hover::after { opacity: 0.4; }
    .neon-btn:hover { transform: translateY(-2px); }
    .neon-btn:active { transform: translateY(0) scale(0.98); }
    .neon-btn i { font-size: 12px; transition: transform 0.3s; }
    .neon-btn:hover i { transform: scale(1.15); }

    .neon-btn-green {
        --neon-from: #22c55e; --neon-to: #10b981;
        color: #22c55e; background: rgba(34, 197, 94, 0.08);
    }
    .neon-btn-green:hover {
        color: #4ade80; background: rgba(34, 197, 94, 0.15);
        box-shadow: 0 0 20px rgba(34, 197, 94, 0.2), 0 0 40px rgba(34, 197, 94, 0.1);
    }
    .neon-btn-green:hover i { filter: drop-shadow(0 0 4px rgba(34, 197, 94, 0.6)); }

    .neon-btn-cyan {
        --neon-from: #06b6d4; --neon-to: #0ea5e9;
        color: #06b6d4; background: rgba(6, 182, 212, 0.08);
    }
    .neon-btn-cyan:hover {
        color: #22d3ee; background: rgba(6, 182, 212, 0.15);
        box-shadow: 0 0 20px rgba(6, 182, 212, 0.2), 0 0 40px rgba(6, 182, 212, 0.1);
    }
    .neon-btn-cyan:hover i { filter: drop-shadow(0 0 4px rgba(6, 182, 212, 0.6)); }

    .neon-btn-blue {
        --neon-from: #3b82f6; --neon-to: #6366f1;
        color: #3b82f6; background: rgba(59, 130, 246, 0.08);
    }
    .neon-btn-blue:hover {
        color: #60a5fa; background: rgba(59, 130, 246, 0.15);
        box-shadow: 0 0 20px rgba(59, 130, 246, 0.2), 0 0 40px rgba(59, 130, 246, 0.1);
    }
    .neon-btn-blue:hover i { filter: drop-shadow(0 0 4px rgba(59, 130, 246, 0.6)); }

    .neon-btn-amber {
        --neon-from: #f59e0b; --neon-to: #d97706;
        color: #f59e0b; background: rgba(245, 158, 11, 0.08);
    }
    .neon-btn-amber:hover {
        color: #fbbf24; background: rgba(245, 158, 11, 0.15);
        box-shadow: 0 0 20px rgba(245, 158, 11, 0.2), 0 0 40px rgba(245, 158, 11, 0.1);
    }
    .neon-btn-amber:hover i { filter: drop-shadow(0 0 4px rgba(245, 158, 11, 0.6)); }

    .neon-btn-red {
        --neon-from: #ef4444; --neon-to: #dc2626;
        color: #ef4444; background: rgba(239, 68, 68, 0.08);
    }
    .neon-btn-red:hover {
        color: #f87171; background: rgba(239, 68, 68, 0.15);
        box-shadow: 0 0 20px rgba(239, 68, 68, 0.2), 0 0 40px rgba(239, 68, 68, 0.1);
    }
    .neon-btn-red:hover i { filter: drop-shadow(0 0 4px rgba(239, 68, 68, 0.6)); }

    .neon-btn-ghost {
        --neon-from: #64748b; --neon-to: #94a3b8;
        color: #94a3b8; background: rgba(148, 163, 184, 0.05);
    }
    .neon-btn-ghost:hover {
        color: #cbd5e1; background: rgba(148, 163, 184, 0.1);
        box-shadow: 0 0 15px rgba(148, 163, 184, 0.15), 0 0 30px rgba(148, 163, 184, 0.08);
    }

    @keyframes neonPulse {
        0%, 100% { box-shadow: 0 0 8px rgba(34, 197, 94, 0.15); }
        50% { box-shadow: 0 0 16px rgba(34, 197, 94, 0.25), 0 0 32px rgba(34, 197, 94, 0.1); }
    }
    .neon-pulse { animation: neonPulse 3s ease-in-out infinite; }
    .neon-pulse:hover { animation: none; }
    </style>
    @stack('styles')
</head>
<body>
<div class="sl-app">
    {{-- Sidebar --}}
    <aside class="sl-sidebar">
        <div class="sl-brand">
            <div class="sl-brand-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <rect x="2" y="2" width="9" height="9" rx="2" fill="#059669"/>
                    <rect x="13" y="2" width="9" height="9" rx="2" fill="#2563eb"/>
                    <rect x="2" y="13" width="9" height="9" rx="2" fill="#d97706"/>
                    <rect x="13" y="13" width="9" height="9" rx="2" fill="#7c3aed"/>
                </svg>
            </div>
            <div class="sl-brand-text">
                <span class="sl-brand-name">NexCore</span>
                <span class="sl-brand-module">PMPRO</span>
            </div>
        </div>

        <nav class="sl-nav-section">
            <div class="sl-nav-label">Navigation</div>
            <a href="{{ route('pmpro.dashboard') }}" class="sl-nav-item {{ request()->routeIs('pmpro.dashboard') ? 'active' : '' }}">
                <i class="fas fa-th-large"></i> Dashboard
            </a>
            <a href="{{ route('pmpro.addresses.index') }}" class="sl-nav-item {{ request()->routeIs('pmpro.addresses.*') ? 'active' : '' }}">
                <i class="fas fa-map-marker-alt"></i> Addresses
            </a>
        </nav>

        <nav class="sl-nav-section">
            <div class="sl-nav-label">Geography</div>
            <a href="{{ route('pmpro.countries.index') }}" class="sl-nav-item {{ request()->routeIs('pmpro.countries.*') ? 'active' : '' }}">
                <i class="fas fa-globe"></i> Countries
            </a>
            <a href="{{ route('pmpro.provinces.index') }}" class="sl-nav-item {{ request()->routeIs('pmpro.provinces.*') ? 'active' : '' }}">
                <i class="fas fa-globe-africa"></i> Provinces
            </a>
            <a href="{{ route('pmpro.municipality-types.index') }}" class="sl-nav-item {{ request()->routeIs('pmpro.municipality-types.*') ? 'active' : '' }}">
                <i class="fas fa-tags"></i> Municipality Types
            </a>
            <a href="{{ route('pmpro.metros.index') }}" class="sl-nav-item {{ request()->routeIs('pmpro.metros.*') ? 'active' : '' }}">
                <i class="fas fa-city"></i> Metropolitan
            </a>
            <a href="{{ route('pmpro.districts.index') }}" class="sl-nav-item {{ request()->routeIs('pmpro.districts.*') ? 'active' : '' }}">
                <i class="fas fa-building"></i> Districts
            </a>
            <a href="{{ route('pmpro.local-municipalities.index') }}" class="sl-nav-item {{ request()->routeIs('pmpro.local-municipalities.*') ? 'active' : '' }}">
                <i class="fas fa-map-signs"></i> Local Municipalities
            </a>
            <a href="{{ route('pmpro.wards.index') }}" class="sl-nav-item {{ request()->routeIs('pmpro.wards.*') ? 'active' : '' }}">
                <i class="fas fa-vector-square"></i> Wards
            </a>
        </nav>

        <nav class="sl-nav-section">
            <div class="sl-nav-label">Entities</div>
            <a href="#" class="sl-nav-item">
                <i class="fas fa-user"></i> Persons
            </a>
            <a href="#" class="sl-nav-item">
                <i class="fas fa-briefcase"></i> Businesses
            </a>
            <a href="#" class="sl-nav-item">
                <i class="fas fa-link"></i> Address Links
            </a>
        </nav>

        <nav class="sl-nav-section" style="margin-top:auto; padding-bottom:20px;">
            <div class="sl-nav-label">System</div>
            <a href="{{ route('system-settings.dashboard') }}" class="sl-nav-item">
                <i class="fas fa-cogs"></i> System Settings
            </a>
            <a href="/home" class="sl-nav-item">
                <i class="fas fa-arrow-left"></i> Back to CIMS
            </a>
        </nav>
    </aside>

    {{-- Main Content --}}
    <main class="sl-main">
        <header class="sl-topbar">
            <div class="sl-topbar-left">
                <span class="sl-topbar-module">PMPRO</span>
                <span class="sl-topbar-sep">/</span>
                <span class="sl-topbar-module-name">@yield('page_heading', 'Practice Manager Pro')</span>
            </div>
            <div class="sl-topbar-right">
                <div class="sl-topbar-datetime">
                    <i class="far fa-clock"></i>
                    <span id="pmpro-clock">--:--</span>
                    <span class="sl-topbar-sep">|</span>
                    <i class="far fa-calendar-alt"></i>
                    <span id="pmpro-date">--</span>
                </div>
            </div>
        </header>

        <section class="sl-content">
            @if(session('success'))
                <div class="sl-verdict accept sl-mb-md" style="padding:14px 20px;">
                    <div class="sl-verdict-icon" style="width:32px;height:32px;font-size:16px;"><i class="fas fa-check"></i></div>
                    <div>
                        <div class="sl-verdict-text" style="font-size:15px;">{{ session('success') }}</div>
                    </div>
                </div>
            @endif

            @yield('content')
        </section>
    </main>
</div>

<script>
function updateClock() {
    var now = new Date();
    var h = String(now.getHours()).padStart(2,'0');
    var m = String(now.getMinutes()).padStart(2,'0');
    document.getElementById('pmpro-clock').textContent = h + ':' + m;
    var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    document.getElementById('pmpro-date').textContent = now.getDate() + ' ' + months[now.getMonth()] + ' ' + now.getFullYear();
}
updateClock();
setInterval(updateClock, 30000);
</script>
@stack('scripts')
</body>
</html>
