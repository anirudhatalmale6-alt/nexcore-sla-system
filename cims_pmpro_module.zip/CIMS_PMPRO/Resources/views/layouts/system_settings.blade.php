<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>NexCore System Settings | @yield('title', 'System Settings')</title>
    <link rel="shortcut icon" type="image/png" href="/public/smartdash/images/favicon.png">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="/public/css/nexcore_gl_master.css?v={{ time() }}" rel="stylesheet">
    <style>
    .sl-app { font-size: 15px; }
    .sl-field label { font-size: 13px; }
    .sl-field input, .sl-field select, .sl-field textarea { font-size: 15px; }
    .sl-stat-value { font-size: 22px; }
    .sl-stat-label { font-size: 13px; }
    .sl-table th { font-size: 13px; }
    .sl-table td { font-size: 14px; }
    .sl-result-label { font-size: 14px; }
    .sl-result-value { font-size: 14px; }
    .sl-tag { font-size: 12px; }
    .sl-page-title { font-size: 22px; }
    .sl-page-subtitle { font-size: 14px; }
    .sl-nav-item { font-size: 14px; }
    .sl-btn { font-size: 14px; }
    .sl-topbar-module, .sl-topbar-module-name { font-size: 14px; }
    .sl-card-title { font-size: 15px; }

    /* Neon Badge Buttons */
    .neon-btn {
        position: relative;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 22px;
        font-size: 13px;
        font-weight: 700;
        letter-spacing: 1.5px;
        text-transform: uppercase;
        text-decoration: none;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        overflow: hidden;
        font-family: var(--font-body);
        line-height: 1.4;
    }
    .neon-btn::before {
        content: '';
        position: absolute;
        inset: 0;
        border-radius: 6px;
        padding: 2px;
        background: linear-gradient(135deg, var(--neon-from), var(--neon-to));
        -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
        -webkit-mask-composite: xor;
        mask-composite: exclude;
        opacity: 0.8;
        transition: opacity 0.3s;
    }
    .neon-btn::after {
        content: '';
        position: absolute;
        inset: -2px;
        border-radius: 8px;
        background: linear-gradient(135deg, var(--neon-from), var(--neon-to));
        opacity: 0;
        filter: blur(12px);
        transition: opacity 0.4s;
        z-index: -1;
    }
    .neon-btn:hover::before { opacity: 1; }
    .neon-btn:hover::after { opacity: 0.4; }
    .neon-btn:hover { transform: translateY(-2px); }
    .neon-btn:active { transform: translateY(0) scale(0.98); }
    .neon-btn i { font-size: 12px; transition: transform 0.3s; }
    .neon-btn:hover i { transform: scale(1.15); }

    .neon-btn-green {
        --neon-from: #22c55e; --neon-to: #10b981;
        color: #22c55e; background: rgba(34, 197, 94, 0.08);
    }
    .neon-btn-green:hover {
        color: #4ade80; background: rgba(34, 197, 94, 0.15);
        box-shadow: 0 0 20px rgba(34, 197, 94, 0.2), 0 0 40px rgba(34, 197, 94, 0.1);
    }
    .neon-btn-green:hover i { filter: drop-shadow(0 0 4px rgba(34, 197, 94, 0.6)); }

    .neon-btn-cyan {
        --neon-from: #06b6d4; --neon-to: #0ea5e9;
        color: #06b6d4; background: rgba(6, 182, 212, 0.08);
    }
    .neon-btn-cyan:hover {
        color: #22d3ee; background: rgba(6, 182, 212, 0.15);
        box-shadow: 0 0 20px rgba(6, 182, 212, 0.2), 0 0 40px rgba(6, 182, 212, 0.1);
    }
    .neon-btn-cyan:hover i { filter: drop-shadow(0 0 4px rgba(6, 182, 212, 0.6)); }

    .neon-btn-blue {
        --neon-from: #3b82f6; --neon-to: #6366f1;
        color: #3b82f6; background: rgba(59, 130, 246, 0.08);
    }
    .neon-btn-blue:hover {
        color: #60a5fa; background: rgba(59, 130, 246, 0.15);
        box-shadow: 0 0 20px rgba(59, 130, 246, 0.2), 0 0 40px rgba(59, 130, 246, 0.1);
    }
    .neon-btn-blue:hover i { filter: drop-shadow(0 0 4px rgba(59, 130, 246, 0.6)); }

    .neon-btn-amber {
        --neon-from: #f59e0b; --neon-to: #d97706;
        color: #f59e0b; background: rgba(245, 158, 11, 0.08);
    }
    .neon-btn-amber:hover {
        color: #fbbf24; background: rgba(245, 158, 11, 0.15);
        box-shadow: 0 0 20px rgba(245, 158, 11, 0.2), 0 0 40px rgba(245, 158, 11, 0.1);
    }
    .neon-btn-amber:hover i { filter: drop-shadow(0 0 4px rgba(245, 158, 11, 0.6)); }

    .neon-btn-red {
        --neon-from: #ef4444; --neon-to: #dc2626;
        color: #ef4444; background: rgba(239, 68, 68, 0.08);
    }
    .neon-btn-red:hover {
        color: #f87171; background: rgba(239, 68, 68, 0.15);
        box-shadow: 0 0 20px rgba(239, 68, 68, 0.2), 0 0 40px rgba(239, 68, 68, 0.1);
    }
    .neon-btn-red:hover i { filter: drop-shadow(0 0 4px rgba(239, 68, 68, 0.6)); }

    .neon-btn-ghost {
        --neon-from: #64748b; --neon-to: #94a3b8;
        color: #94a3b8; background: rgba(148, 163, 184, 0.05);
    }
    .neon-btn-ghost:hover {
        color: #cbd5e1; background: rgba(148, 163, 184, 0.1);
        box-shadow: 0 0 15px rgba(148, 163, 184, 0.15), 0 0 30px rgba(148, 163, 184, 0.08);
    }

    @keyframes neonPulse {
        0%, 100% { box-shadow: 0 0 8px rgba(34, 197, 94, 0.15); }
        50% { box-shadow: 0 0 16px rgba(34, 197, 94, 0.25), 0 0 32px rgba(34, 197, 94, 0.1); }
    }
    .neon-pulse { animation: neonPulse 3s ease-in-out infinite; }
    .neon-pulse:hover { animation: none; }
    </style>
    @stack('styles')
</head>
<body>
<div class="sl-app">
    {{-- Sidebar --}}
    <aside class="sl-sidebar">
        <div class="sl-brand">
            <div class="sl-brand-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <rect x="2" y="2" width="9" height="9" rx="2" fill="#059669"/>
                    <rect x="13" y="2" width="9" height="9" rx="2" fill="#2563eb"/>
                    <rect x="2" y="13" width="9" height="9" rx="2" fill="#d97706"/>
                    <rect x="13" y="13" width="9" height="9" rx="2" fill="#7c3aed"/>
                </svg>
            </div>
            <div class="sl-brand-text">
                <span class="sl-brand-name">NexCore</span>
                <span class="sl-brand-module">System Settings</span>
            </div>
        </div>

        <nav class="sl-nav-section">
            <div class="sl-nav-label">Navigation</div>
            <a href="{{ route('system-settings.dashboard') }}" class="sl-nav-item {{ request()->routeIs('system-settings.dashboard') ? 'active' : '' }}">
                <i class="fas fa-th-large"></i> Dashboard
            </a>
        </nav>

        <nav class="sl-nav-section">
            <div class="sl-nav-label">System</div>
            <a href="{{ route('system-settings.languages.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.languages.*') ? 'active' : '' }}">
                <i class="fas fa-language"></i> Languages
            </a>
            <a href="{{ route('system-settings.ethnic-groups.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.ethnic-groups.*') ? 'active' : '' }}">
                <i class="fas fa-users"></i> Ethnic Groups
            </a>
            <a href="{{ route('system-settings.religions.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.religions.*') ? 'active' : '' }}">
                <i class="fas fa-pray"></i> Religions
            </a>
            <a href="{{ route('system-settings.titles.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.titles.*') ? 'active' : '' }}">
                <i class="fas fa-id-badge"></i> Titles
            </a>
            <a href="{{ route('system-settings.genders.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.genders.*') ? 'active' : '' }}">
                <i class="fas fa-venus-mars"></i> Genders
            </a>
            <a href="{{ route('system-settings.education.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.education.*') ? 'active' : '' }}">
                <i class="fas fa-graduation-cap"></i> Education
            </a>
            <a href="{{ route('system-settings.address-types.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.address-types.*') ? 'active' : '' }}">
                <i class="fas fa-map-signs"></i> Address Types
            </a>
            <a href="{{ route('system-settings.email-types.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.email-types.*') ? 'active' : '' }}">
                <i class="fas fa-envelope"></i> Email Types
            </a>
            <a href="{{ route('system-settings.telephone-types.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.telephone-types.*') ? 'active' : '' }}">
                <i class="fas fa-phone-alt"></i> Telephone Types
            </a>
            <a href="{{ route('system-settings.director-types.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.director-types.*') ? 'active' : '' }}">
                <i class="fas fa-user-tie"></i> Director Types
            </a>
            <a href="{{ route('system-settings.bank-account-types.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.bank-account-types.*') ? 'active' : '' }}">
                <i class="fas fa-university"></i> Bank Account Types
            </a>
            <a href="{{ route('system-settings.marital-statuses.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.marital-statuses.*') ? 'active' : '' }}">
                <i class="fas fa-ring"></i> Marital Statuses
            </a>
            <a href="{{ route('system-settings.relationship-types.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.relationship-types.*') ? 'active' : '' }}">
                <i class="fas fa-people-arrows"></i> Relationship Types
            </a>
            <a href="{{ route('system-settings.id-document-types.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.id-document-types.*') ? 'active' : '' }}">
                <i class="fas fa-id-card"></i> ID Document Types
            </a>
            <a href="{{ route('system-settings.employment-statuses.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.employment-statuses.*') ? 'active' : '' }}">
                <i class="fas fa-briefcase"></i> Employment Statuses
            </a>
            <a href="{{ route('system-settings.disability-types.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.disability-types.*') ? 'active' : '' }}">
                <i class="fas fa-wheelchair"></i> Disability Types
            </a>
            <a href="{{ route('system-settings.nationalities.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.nationalities.*') ? 'active' : '' }}">
                <i class="fas fa-flag"></i> Nationalities
            </a>
        </nav>

        <nav class="sl-nav-section">
            <div class="sl-nav-label">Business & Financial</div>
            <a href="{{ route('system-settings.company-types.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.company-types.*') ? 'active' : '' }}">
                <i class="fas fa-building"></i> Company Types
            </a>
            <a href="{{ route('system-settings.company-statuses.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.company-statuses.*') ? 'active' : '' }}">
                <i class="fas fa-clipboard-check"></i> Company Statuses
            </a>
            <a href="{{ route('system-settings.industries.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.industries.*') ? 'active' : '' }}">
                <i class="fas fa-industry"></i> Industries
            </a>
            <a href="{{ route('system-settings.sic-codes.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.sic-codes.*') ? 'active' : '' }}">
                <i class="fas fa-file-invoice"></i> SARS SIC Codes
            </a>
            <a href="{{ route('system-settings.banks.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.banks.*') ? 'active' : '' }}">
                <i class="fas fa-landmark"></i> Banks
            </a>
            <a href="{{ route('system-settings.income-sources.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.income-sources.*') ? 'active' : '' }}">
                <i class="fas fa-money-bill-wave"></i> Income Sources
            </a>
            <a href="{{ route('system-settings.tax-types.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.tax-types.*') ? 'active' : '' }}">
                <i class="fas fa-file-invoice-dollar"></i> Tax Types
            </a>
            <a href="{{ route('system-settings.bee-status-levels.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.bee-status-levels.*') ? 'active' : '' }}">
                <i class="fas fa-chart-bar"></i> BEE Status Levels
            </a>
            <a href="{{ route('system-settings.communication-preferences.index') }}" class="sl-nav-item {{ request()->routeIs('system-settings.communication-preferences.*') ? 'active' : '' }}">
                <i class="fas fa-comments"></i> Comm. Preferences
            </a>
        </nav>

        <nav class="sl-nav-section" style="margin-top:auto; padding-bottom:20px;">
            <div class="sl-nav-label">Navigation</div>
            <a href="{{ route('pmpro.dashboard') }}" class="sl-nav-item">
                <i class="fas fa-map-marker-alt"></i> Back to PMPRO
            </a>
            <a href="/home" class="sl-nav-item">
                <i class="fas fa-arrow-left"></i> Back to CIMS
            </a>
        </nav>
    </aside>

    {{-- Main Content --}}
    <main class="sl-main">
        <header class="sl-topbar">
            <div class="sl-topbar-left">
                <span class="sl-topbar-module">System Settings</span>
                <span class="sl-topbar-sep">/</span>
                <span class="sl-topbar-module-name">@yield('page_heading', 'NexCore System Settings')</span>
            </div>
            <div class="sl-topbar-right">
                <div class="sl-topbar-datetime">
                    <i class="far fa-clock"></i>
                    <span id="ss-clock">--:--</span>
                    <span class="sl-topbar-sep">|</span>
                    <i class="far fa-calendar-alt"></i>
                    <span id="ss-date">--</span>
                </div>
            </div>
        </header>

        <section class="sl-content">
            @if(session('success'))
                <div class="sl-verdict accept sl-mb-md" style="padding:14px 20px;">
                    <div class="sl-verdict-icon" style="width:32px;height:32px;font-size:16px;"><i class="fas fa-check"></i></div>
                    <div>
                        <div class="sl-verdict-text" style="font-size:15px;">{{ session('success') }}</div>
                    </div>
                </div>
            @endif

            @yield('content')
        </section>
    </main>
</div>

<script>
function updateClock() {
    var now = new Date();
    var h = String(now.getHours()).padStart(2,'0');
    var m = String(now.getMinutes()).padStart(2,'0');
    document.getElementById('ss-clock').textContent = h + ':' + m;
    var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    document.getElementById('ss-date').textContent = now.getDate() + ' ' + months[now.getMonth()] + ' ' + now.getFullYear();
}
updateClock();
setInterval(updateClock, 30000);
</script>
@stack('scripts')
</body>
</html>
