@extends('cims_pmpro::layouts.pmpro')

@section('title', 'Wards')
@section('page_heading', 'WARDS')

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">Ward Registry</h1>
        <span class="sl-page-subtitle">Electoral wards linked to municipalities</span>
        <div style="margin-left:auto;">
            <a href="{{ route('pmpro.wards.create') }}" class="neon-btn neon-btn-green neon-pulse"><i class="fas fa-plus"></i> New Ward</a>
        </div>
    </div>
</div>

<div class="sl-stats-grid sl-animate d2">
    <div class="sl-stat-card green">
        <div class="sl-stat-label">Total</div>
        <div class="sl-stat-value" style="color:var(--accent-green);">{{ number_format($stats['total'] ?? 0) }}</div>
        <div class="sl-stat-meta">All wards</div>
    </div>
    <div class="sl-stat-card blue">
        <div class="sl-stat-label">Active</div>
        <div class="sl-stat-value" style="color:var(--accent-blue);">{{ number_format($stats['active'] ?? 0) }}</div>
        <div class="sl-stat-meta">Currently active</div>
    </div>
    <div class="sl-stat-card amber">
        <div class="sl-stat-label">Inactive</div>
        <div class="sl-stat-value" style="color:var(--accent-amber);">{{ number_format($stats['inactive'] ?? 0) }}</div>
        <div class="sl-stat-meta">Disabled</div>
    </div>
</div>

<div class="sl-card sl-animate d3 sl-mb-md">
    <form method="GET" action="{{ route('pmpro.wards.index') }}">
        <div style="display:flex; gap:12px; align-items:end; flex-wrap:wrap;">
            <div class="sl-field" style="flex:1; min-width:200px;">
                <label>Search</label>
                <input type="text" name="search" value="{{ request('search') }}" placeholder="Ward number, code, label, official ID..." style="width:100%;">
            </div>
            <div class="sl-field" style="min-width:200px;">
                <label>Metro</label>
                <select name="metro_id" style="width:100%; background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:9px 12px; color:var(--text-primary); font-size:15px; font-family:var(--font-mono);">
                    <option value="">All Metros</option>
                    @foreach($metros as $m)
                        <option value="{{ $m->id }}" {{ request('metro_id') == $m->id ? 'selected' : '' }}>{{ $m->name }}</option>
                    @endforeach
                </select>
            </div>
            <div style="display:flex; gap:8px;">
                <button type="submit" class="neon-btn neon-btn-cyan" style="padding:9px 18px;"><i class="fas fa-search"></i> Filter</button>
                <a href="{{ route('pmpro.wards.index') }}" class="neon-btn neon-btn-ghost" style="padding:9px 18px;"><i class="fas fa-times"></i> Clear</a>
            </div>
        </div>
    </form>
</div>

<div class="sl-card sl-animate d4">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-vector-square"></i> Wards</div>
        <div style="font-size:13px; color:var(--text-muted);">Showing {{ $wards->firstItem() ?? 0 }}-{{ $wards->lastItem() ?? 0 }} of {{ $wards->total() }}</div>
    </div>
    <div class="sl-table-wrap">
        <table class="sl-table">
            <thead><tr><th>Ward #</th><th>Code</th><th>Official ID</th><th>Municipality</th><th>Province</th><th class="center">Status</th><th class="center">Actions</th></tr></thead>
            <tbody>
                @forelse($wards as $w)
                <tr>
                    <td style="font-weight:600;"><a href="{{ route('pmpro.wards.show', $w->id) }}" style="color:var(--text-primary); text-decoration:none;" onmouseover="this.style.color='var(--accent-cyan)'" onmouseout="this.style.color='var(--text-primary)'">Ward {{ $w->ward_number }}</a></td>
                    <td><span class="sl-tag sl-tag-cyan">{{ $w->code ?? '-' }}</span></td>
                    <td class="mono">{{ $w->ward_id_official ?? '-' }}</td>
                    <td>{{ $w->metro->name ?? ($w->localMunicipality->name ?? '-') }}</td>
                    <td>{{ $w->province_name ?? '-' }}</td>
                    <td class="center">@if($w->is_active) <span class="sl-status-dot pass"></span> @else <span class="sl-status-dot fail"></span> @endif</td>
                    <td class="center">
                        <div style="display:flex; gap:6px; justify-content:center;">
                            <a href="{{ route('pmpro.wards.edit', $w->id) }}" style="color:var(--accent-blue); font-size:15px;" title="Edit"><i class="fas fa-pen"></i></a>
                            <a href="{{ route('pmpro.wards.show', $w->id) }}" style="color:var(--accent-green); font-size:15px;" title="View"><i class="fas fa-eye"></i></a>
                            <form method="POST" action="{{ route('pmpro.wards.toggle', $w->id) }}" style="display:inline;">@csrf
                                <button type="submit" style="background:none; border:none; color:var(--accent-amber); cursor:pointer; font-size:15px;" title="Toggle"><i class="fas fa-power-off"></i></button>
                            </form>
                            <form method="POST" action="{{ route('pmpro.wards.destroy', $w->id) }}" style="display:inline;" onsubmit="return confirm('Delete Ward {{ $w->ward_number }}?')">@csrf @method('DELETE')
                                <button type="submit" style="background:none; border:none; color:var(--accent-red); cursor:pointer; font-size:15px;" title="Delete"><i class="fas fa-trash"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="7" style="text-align:center; padding:40px; color:var(--text-muted);"><i class="fas fa-vector-square" style="font-size:32px; opacity:0.3; margin-bottom:12px; display:block;"></i>No wards found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($wards->hasPages())
    <div style="display:flex; justify-content:center; padding:16px 0 0; gap:4px;">
        @if($wards->onFirstPage()) <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Prev</span>
        @else <a href="{{ $wards->previousPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Prev</a> @endif
        @foreach($wards->getUrlRange(max(1, $wards->currentPage()-2), min($wards->lastPage(), $wards->currentPage()+2)) as $page => $url)
            @if($page == $wards->currentPage()) <span class="sl-btn sl-btn-primary" style="padding:6px 12px; font-size:13px;">{{ $page }}</span>
            @else <a href="{{ $url }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">{{ $page }}</a> @endif
        @endforeach
        @if($wards->hasMorePages()) <a href="{{ $wards->nextPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Next</a>
        @else <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Next</span> @endif
    </div>
    @endif
</div>
@endsection
