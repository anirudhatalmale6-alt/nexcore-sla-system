@extends('cims_pmpro::layouts.pmpro')

@section('title', isset($ward) ? 'Edit Ward' : 'New Ward')
@section('page_heading', isset($ward) ? 'EDIT WARD ' . $ward->ward_number : 'NEW WARD')

@push('styles')
<style>
.sl-form-section { background:var(--bg-surface); border:1px solid var(--border-subtle); border-radius:var(--radius-lg); padding:24px; margin-bottom:20px; box-shadow:var(--shadow-card); }
.sl-form-section-title { font-size:15px; font-weight:700; letter-spacing:2px; text-transform:uppercase; color:var(--accent-green); margin-bottom:20px; padding-bottom:10px; border-bottom:1px solid var(--border-subtle); display:flex; align-items:center; gap:10px; }
.sl-form-section-title i { font-size:16px; }
.sl-form-grid { display:grid; gap:16px; }
.sl-form-grid.cols-2 { grid-template-columns:1fr 1fr; }
.sl-form-grid.cols-3 { grid-template-columns:1fr 1fr 1fr; }
.sl-field label .required { color:var(--accent-red); margin-left:2px; }
.sl-field select { background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:9px 12px; color:var(--text-primary); font-size:15px; font-family:var(--font-mono); width:100%; outline:none; appearance:none; -webkit-appearance:none; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%235a6478' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 12px center; padding-right:32px; }
.sl-field select:focus { border-color:var(--accent-green); box-shadow:0 0 0 2px rgba(34,197,94,0.15); }
.sl-field input { width:100%; }
@media (max-width:768px) { .sl-form-grid.cols-2, .sl-form-grid.cols-3 { grid-template-columns:1fr; } }
</style>
@endpush

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ isset($ward) ? 'Edit Ward '.$ward->ward_number : 'Create New Ward' }}</h1>
        <span class="sl-page-subtitle">{{ isset($ward) ? 'Update ward details' : 'Add a new ward' }}</span>
        <div style="margin-left:auto;">
            <a href="{{ route('pmpro.wards.index') }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back to Wards</a>
        </div>
    </div>
</div>

<form method="POST" action="{{ isset($ward) ? route('pmpro.wards.update', $ward->id) : route('pmpro.wards.store') }}" class="sl-animate d2">
    @csrf
    @if(isset($ward)) @method('PUT') @endif

    @if($errors->any())
    <div class="sl-verdict reject sl-mb-md" style="padding:14px 20px;">
        <div class="sl-verdict-icon" style="width:32px;height:32px;font-size:16px;"><i class="fas fa-exclamation-triangle"></i></div>
        <div>@foreach($errors->all() as $error)<div class="sl-verdict-text" style="font-size:14px;">{{ $error }}</div>@endforeach</div>
    </div>
    @endif

    <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">

        <div class="sl-form-section">
            <div class="sl-form-section-title"><i class="fas fa-vector-square"></i> Ward Identification</div>
            <div class="sl-form-grid cols-2">
                <div class="sl-field">
                    <label>Ward Number <span class="required">*</span></label>
                    <input type="number" name="ward_number" value="{{ old('ward_number', $ward->ward_number ?? '') }}" placeholder="e.g. 1" min="1" required>
                </div>
                <div class="sl-field">
                    <label>Ward Code</label>
                    <input type="text" name="code" value="{{ old('code', $ward->code ?? '') }}" placeholder="e.g. ETH_1" maxlength="20">
                </div>
            </div>
            <div class="sl-form-grid cols-2" style="margin-top:16px;">
                <div class="sl-field">
                    <label>Ward Label</label>
                    <input type="text" name="ward_label" value="{{ old('ward_label', $ward->ward_label ?? '') }}" placeholder="e.g. ETH_1" maxlength="20">
                </div>
                <div class="sl-field">
                    <label>Official Ward ID</label>
                    <input type="text" name="ward_id_official" value="{{ old('ward_id_official', $ward->ward_id_official ?? '') }}" placeholder="e.g. 59500001" maxlength="20">
                </div>
            </div>
            <div class="sl-form-grid cols-2" style="margin-top:16px;">
                <div class="sl-field">
                    <label>OBJECTID</label>
                    <input type="number" name="objectid" value="{{ old('objectid', $ward->objectid ?? '') }}" placeholder="e.g. 1684">
                </div>
                <div class="sl-field">
                    <label>OBJECTID_1</label>
                    <input type="number" name="objectid_1" value="{{ old('objectid_1', $ward->objectid_1 ?? '') }}" placeholder="e.g. 1">
                </div>
            </div>
        </div>

        <div class="sl-form-section">
            <div class="sl-form-section-title"><i class="fas fa-building"></i> Administrative Location</div>
            <div class="sl-form-grid cols-1" style="grid-template-columns:1fr;">
                <div class="sl-field">
                    <label>Metropolitan Municipality</label>
                    <select name="metro_id">
                        <option value="">None</option>
                        @foreach($metros as $m)
                            <option value="{{ $m->id }}" {{ old('metro_id', $ward->metro_id ?? ($prefill['metro_id'] ?? '')) == $m->id ? 'selected' : '' }}>{{ $m->name }} ({{ $m->code }})</option>
                        @endforeach
                    </select>
                </div>
                <div class="sl-field">
                    <label>Local Municipality</label>
                    <select name="local_municipality_id">
                        <option value="">None</option>
                        @foreach($localMunicipalities as $lm)
                            <option value="{{ $lm->id }}" {{ old('local_municipality_id', $ward->local_municipality_id ?? ($prefill['local_municipality_id'] ?? '')) == $lm->id ? 'selected' : '' }}>{{ $lm->name }} ({{ $lm->district->name ?? '' }})</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="sl-form-grid cols-2" style="margin-top:16px;">
                <div class="sl-field">
                    <label>Municipality Name</label>
                    <input type="text" name="municipality_name" value="{{ old('municipality_name', $ward->municipality_name ?? '') }}" placeholder="e.g. Ethekwini Metropolitan Municipality" maxlength="200">
                </div>
                <div class="sl-field">
                    <label>District Name</label>
                    <input type="text" name="district_name" value="{{ old('district_name', $ward->district_name ?? '') }}" placeholder="e.g. eThekwini" maxlength="200">
                </div>
            </div>
            <div class="sl-form-grid cols-3" style="margin-top:16px;">
                <div class="sl-field">
                    <label>District Code</label>
                    <input type="text" name="district_code" value="{{ old('district_code', $ward->district_code ?? '') }}" placeholder="e.g. ETH" maxlength="10">
                </div>
                <div class="sl-field">
                    <label>Province</label>
                    <input type="text" name="province_name" value="{{ old('province_name', $ward->province_name ?? '') }}" placeholder="e.g. KwaZulu-Natal" maxlength="100">
                </div>
                <div class="sl-field">
                    <label>CAT_B</label>
                    <input type="text" name="cat_b" value="{{ old('cat_b', $ward->cat_b ?? '') }}" placeholder="e.g. ETH" maxlength="10">
                </div>
            </div>
        </div>

        <div class="sl-form-section">
            <div class="sl-form-section-title"><i class="fas fa-ruler-combined"></i> Geographic / Shape Data</div>
            <div class="sl-form-grid cols-1" style="grid-template-columns:1fr;">
                <div class="sl-field">
                    <label>Shape Length</label>
                    <input type="text" name="shape_length" value="{{ old('shape_length', $ward->shape_length ?? '') }}" placeholder="e.g. 0.70909831">
                </div>
                <div class="sl-field">
                    <label>Shape Area (sq m)</label>
                    <input type="text" name="shape_area" value="{{ old('shape_area', $ward->shape_area ?? '') }}" placeholder="e.g. 88205014.2307">
                </div>
                <div class="sl-field">
                    <label>Shape Perimeter (m)</label>
                    <input type="text" name="shape_perimeter" value="{{ old('shape_perimeter', $ward->shape_perimeter ?? '') }}" placeholder="e.g. 73100.004702753">
                </div>
            </div>
        </div>

        <div class="sl-form-section">
            <div class="sl-form-section-title"><i class="fas fa-cog"></i> Status & Date</div>
            <div class="sl-form-grid cols-1" style="grid-template-columns:1fr;">
                <div class="sl-field">
                    <label>Demarcation Date</label>
                    <input type="date" name="demarcation_date" value="{{ old('demarcation_date', isset($ward) && $ward->demarcation_date ? $ward->demarcation_date->format('Y-m-d') : '') }}">
                </div>
            </div>
            @if(isset($ward))
            <div class="sl-form-grid cols-2" style="margin-top:16px;">
                <div class="sl-field">
                    <label>Status</label>
                    <select name="is_active">
                        <option value="1" {{ old('is_active', $ward->is_active) ? 'selected' : '' }}>Active</option>
                        <option value="0" {{ old('is_active', $ward->is_active) ? '' : 'selected' }}>Inactive</option>
                    </select>
                </div>
                <div class="sl-field">
                    <label>Deleted</label>
                    <select name="is_deleted">
                        <option value="0" {{ old('is_deleted', $ward->is_deleted) ? '' : 'selected' }}>No</option>
                        <option value="1" {{ old('is_deleted', $ward->is_deleted) ? 'selected' : '' }}>Yes</option>
                    </select>
                </div>
            </div>
            @endif
        </div>

    </div>

    <div style="display:flex; gap:12px; justify-content:flex-end; margin-top:4px;">
        <a href="{{ route('pmpro.wards.index') }}" class="neon-btn neon-btn-red"><i class="fas fa-times"></i> Cancel</a>
        <button type="submit" class="neon-btn neon-btn-green neon-pulse"><i class="fas fa-check"></i> {{ isset($ward) ? 'Update Ward' : 'Save Ward' }}</button>
    </div>
</form>
@endsection
