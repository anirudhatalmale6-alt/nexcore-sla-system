@extends('cims_pmpro::layouts.pmpro')

@section('title', 'Ward ' . $ward->ward_number)
@section('page_heading', 'WARD ' . $ward->ward_number . ' DETAILS')

@section('content')
<div class="sl-animate d1">
    <div style="margin-bottom:12px; font-size:13px; color:var(--text-muted);">
        <a href="{{ route('pmpro.countries.index') }}" style="color:var(--accent-cyan); text-decoration:none;">Countries</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        <a href="{{ route('pmpro.countries.show', 129) }}" style="color:var(--accent-cyan); text-decoration:none;">South Africa</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        @if($ward->metro && $ward->metro->province)
        <a href="{{ route('pmpro.provinces.show', $ward->metro->province->id) }}" style="color:var(--accent-cyan); text-decoration:none;">{{ $ward->metro->province->name }}</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        <a href="{{ route('pmpro.metros.show', $ward->metro->id) }}" style="color:var(--accent-cyan); text-decoration:none;">{{ $ward->metro->name }}</a>
        @elseif($ward->localMunicipality && $ward->localMunicipality->district)
        <a href="{{ route('pmpro.provinces.show', $ward->localMunicipality->district->province->id) }}" style="color:var(--accent-cyan); text-decoration:none;">{{ $ward->localMunicipality->district->province->name }}</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        <a href="{{ route('pmpro.districts.show', $ward->localMunicipality->district->id) }}" style="color:var(--accent-cyan); text-decoration:none;">{{ $ward->localMunicipality->district->name }}</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        <a href="{{ route('pmpro.local-municipalities.show', $ward->localMunicipality->id) }}" style="color:var(--accent-cyan); text-decoration:none;">{{ $ward->localMunicipality->name }}</a>
        @endif
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        <span style="color:var(--text-primary);">Ward {{ $ward->ward_number }}</span>
    </div>
    <div class="sl-page-header">
        <h1 class="sl-page-title">Ward {{ $ward->ward_number }}</h1>
        <span class="sl-page-subtitle">Full ward demarcation details</span>
        <div style="margin-left:auto; display:flex; gap:8px;">
            @if($ward->metro)
            <a href="{{ route('pmpro.metros.show', $ward->metro->id) }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back to {{ $ward->metro->name }}</a>
            @elseif($ward->localMunicipality)
            <a href="{{ route('pmpro.local-municipalities.show', $ward->localMunicipality->id) }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back to {{ $ward->localMunicipality->name }}</a>
            @endif
        </div>
    </div>
</div>

<div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-top:4px;">

    <div class="sl-card sl-animate d2" style="min-height:100%;">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-vector-square"></i> Ward Identification</div>
            @if($ward->is_active) <span class="sl-tag sl-tag-green">Active</span>
            @else <span class="sl-tag sl-tag-red">Inactive</span> @endif
            @if($ward->is_deleted) <span class="sl-tag sl-tag-red">Deleted</span> @endif
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Ward Number</span>
            <span class="sl-result-value" style="font-weight:600; font-size:18px;">{{ $ward->ward_number }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Ward Code</span>
            <span class="sl-result-value"><span class="sl-tag sl-tag-cyan">{{ $ward->code ?? '-' }}</span></span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Ward Label</span>
            <span class="sl-result-value"><span class="sl-tag sl-tag-purple">{{ $ward->ward_label ?? '-' }}</span></span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Official Ward ID</span>
            <span class="sl-result-value"><span style="font-family:monospace; font-weight:600; color:var(--accent-green);">{{ $ward->ward_id_official ?? '-' }}</span></span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">OBJECTID</span>
            <span class="sl-result-value"><span class="mono">{{ $ward->objectid ?? '-' }}</span></span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">OBJECTID_1</span>
            <span class="sl-result-value"><span class="mono">{{ $ward->objectid_1 ?? '-' }}</span></span>
        </div>
    </div>

    <div class="sl-card sl-animate d3" style="min-height:100%;">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-building"></i> Administrative Location</div>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Municipality</span>
            <span class="sl-result-value" style="font-weight:600;">{{ $ward->municipality_name ?? ($ward->metro->name ?? ($ward->localMunicipality->name ?? '-')) }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">District</span>
            <span class="sl-result-value">
                <span class="sl-tag sl-tag-cyan">{{ $ward->district_code ?? '-' }}</span>
                {{ $ward->district_name ?? '-' }}
            </span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Province</span>
            <span class="sl-result-value"><span class="sl-tag sl-tag-green">{{ $ward->province_name ?? '-' }}</span></span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Category (CAT_B)</span>
            <span class="sl-result-value"><span class="sl-tag sl-tag-purple">{{ $ward->cat_b ?? '-' }}</span></span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Demarcation Date</span>
            <span class="sl-result-value"><span style="font-weight:600;">{{ $ward->demarcation_date ? $ward->demarcation_date->format('j M Y') : '-' }}</span></span>
        </div>
    </div>

    <div class="sl-card sl-animate d4" style="min-height:100%;">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-ruler-combined"></i> Geographic / Shape Data</div>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Shape Length</span>
            <span class="sl-result-value"><span class="mono" style="color:var(--accent-amber);">{{ $ward->shape_length !== null ? number_format($ward->shape_length, 10) : '-' }}</span></span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Shape Area (sq m)</span>
            <span class="sl-result-value"><span class="mono" style="color:var(--accent-green);">{{ $ward->shape_area !== null ? number_format($ward->shape_area, 4) : '-' }}</span></span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Shape Perimeter (m)</span>
            <span class="sl-result-value"><span class="mono" style="color:var(--accent-cyan);">{{ $ward->shape_perimeter !== null ? number_format($ward->shape_perimeter, 10) : '-' }}</span></span>
        </div>
        @if($ward->shape_area)
        <div class="sl-result-row">
            <span class="sl-result-label">Area (sq km)</span>
            <span class="sl-result-value"><span class="mono" style="font-weight:600; color:var(--accent-blue);">{{ number_format($ward->shape_area / 1000000, 2) }} km&sup2;</span></span>
        </div>
        @endif
    </div>

    <div class="sl-card sl-animate d5" style="min-height:100%;">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-cog"></i> Status</div>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Active</span>
            <span class="sl-result-value">@if($ward->is_active) <span class="sl-tag sl-tag-green">Yes</span> @else <span class="sl-tag sl-tag-red">No</span> @endif</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Deleted</span>
            <span class="sl-result-value">@if($ward->is_deleted) <span class="sl-tag sl-tag-red">Yes</span> @else <span class="sl-tag sl-tag-green">No</span> @endif</span>
        </div>
    </div>

</div>
@endsection
