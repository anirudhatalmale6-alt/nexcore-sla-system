@extends('cims_pmpro::layouts.pmpro')

@section('title', isset($province) ? 'Edit Province' : 'New Province')
@section('page_heading', isset($province) ? 'EDIT PROVINCE' : 'NEW PROVINCE')

@push('styles')
<style>
.sl-form-section { background:var(--bg-surface); border:1px solid var(--border-subtle); border-radius:var(--radius-lg); padding:24px; margin-bottom:20px; box-shadow:var(--shadow-card); }
.sl-form-section-title { font-size:15px; font-weight:700; letter-spacing:2px; text-transform:uppercase; color:var(--accent-green); margin-bottom:20px; padding-bottom:10px; border-bottom:1px solid var(--border-subtle); display:flex; align-items:center; gap:10px; }
.sl-form-section-title i { font-size:16px; }
.sl-form-grid { display:grid; gap:16px; }
.sl-form-grid.cols-2 { grid-template-columns:1fr 1fr; }
.sl-form-grid.cols-3 { grid-template-columns:1fr 1fr 1fr; }
.sl-field label .required { color:var(--accent-red); margin-left:2px; }
.sl-field select { background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:9px 12px; color:var(--text-primary); font-size:15px; font-family:var(--font-mono); width:100%; outline:none; appearance:none; -webkit-appearance:none; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%235a6478' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 12px center; padding-right:32px; }
.sl-field select:focus { border-color:var(--accent-green); box-shadow:0 0 0 2px rgba(34,197,94,0.15); }
.sl-field input, .sl-field textarea { width:100%; }
.sl-field textarea { background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:12px; color:var(--text-primary); font-size:14px; font-family:var(--font-body); line-height:1.6; resize:vertical; outline:none; }
.sl-field textarea:focus { border-color:var(--accent-green); box-shadow:0 0 0 2px rgba(34,197,94,0.15); }
.sl-field input[type="file"] { padding:8px; }
.map-preview { max-width:200px; max-height:150px; border-radius:6px; border:1px solid var(--border-subtle); margin-top:8px; }
@media (max-width:768px) { .sl-form-grid.cols-2, .sl-form-grid.cols-3 { grid-template-columns:1fr; } }
</style>
@endpush

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ isset($province) ? 'Edit '.$province->name : 'Create New Province' }}</h1>
        <span class="sl-page-subtitle">{{ isset($province) ? 'Update province details' : 'Add a new province to the system' }}</span>
        <div style="margin-left:auto;">
            <a href="{{ route('pmpro.provinces.index') }}" class="neon-btn neon-btn-ghost">
                <i class="fas fa-arrow-left"></i> Back to List
            </a>
        </div>
    </div>
</div>

<form method="POST" action="{{ isset($province) ? route('pmpro.provinces.update', $province->id) : route('pmpro.provinces.store') }}" enctype="multipart/form-data" class="sl-animate d2">
    @csrf
    @if(isset($province)) @method('PUT') @endif

    @if($errors->any())
    <div class="sl-verdict reject sl-mb-md" style="padding:14px 20px;">
        <div class="sl-verdict-icon" style="width:32px;height:32px;font-size:16px;"><i class="fas fa-exclamation-triangle"></i></div>
        <div>
            @foreach($errors->all() as $error)
                <div class="sl-verdict-text" style="font-size:14px;">{{ $error }}</div>
            @endforeach
        </div>
    </div>
    @endif

    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-globe-africa"></i> Province Details</div>
        <div class="sl-form-grid cols-3">
            <div class="sl-field">
                <label>Province Name <span class="required">*</span></label>
                <input type="text" name="name" value="{{ old('name', $province->name ?? '') }}" placeholder="e.g. Gauteng" required>
            </div>
            <div class="sl-field">
                <label>Province Code <span class="required">*</span></label>
                <input type="text" name="code" value="{{ old('code', $province->code ?? '') }}" placeholder="e.g. GP" maxlength="5" required style="text-transform:uppercase;">
            </div>
            <div class="sl-field">
                <label>Native Name</label>
                <input type="text" name="native_name" value="{{ old('native_name', $province->native_name ?? '') }}" placeholder="e.g. eGoli (Zulu)">
            </div>
        </div>

        <div class="sl-form-grid cols-2" style="margin-top:16px;">
            <div class="sl-field">
                <label>Capital</label>
                <input type="text" name="capital" value="{{ old('capital', $province->capital ?? '') }}" placeholder="e.g. Johannesburg">
            </div>
            <div class="sl-field">
                <label>Largest City</label>
                <input type="text" name="largest_city" value="{{ old('largest_city', $province->largest_city ?? '') }}" placeholder="e.g. Johannesburg">
            </div>
        </div>

        @if(isset($province))
        <div class="sl-form-grid cols-2" style="margin-top:16px;">
            <div class="sl-field">
                <label>Status</label>
                <select name="is_active">
                    <option value="1" {{ old('is_active', $province->is_active) ? 'selected' : '' }}>Active</option>
                    <option value="0" {{ old('is_active', $province->is_active) ? '' : 'selected' }}>Inactive</option>
                </select>
            </div>
        </div>
        @endif
    </div>

    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-chart-area"></i> Demographics & Geography</div>
        <div class="sl-form-grid cols-3">
            <div class="sl-field">
                <label>Area (km²)</label>
                <input type="number" name="area_km2" value="{{ old('area_km2', $province->area_km2 ?? '') }}" placeholder="e.g. 18178" step="1">
            </div>
            <div class="sl-field">
                <label>Population (2022)</label>
                <input type="number" name="population" value="{{ old('population', $province->population ?? '') }}" placeholder="e.g. 15099422" step="1">
            </div>
            <div class="sl-field">
                <label>Density (per km²)</label>
                <input type="number" name="density" value="{{ old('density', $province->density ?? '') }}" placeholder="e.g. 830.6" step="0.1">
            </div>
        </div>
    </div>

    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-map"></i> Map Image</div>
        <div class="sl-field">
            <label>Province Map</label>
            <input type="file" name="map_image" accept="image/*">
            @if(isset($province) && $province->map_image)
                <div style="margin-top:10px;">
                    <span style="font-size:12px; color:var(--text-muted);">Current map:</span><br>
                    <img src="/{{ $province->map_image }}" class="map-preview" alt="Current map">
                </div>
            @endif
        </div>
    </div>

    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-align-left"></i> Description</div>
        <div class="sl-field">
            <label>Province Description</label>
            <textarea name="description" rows="5" placeholder="Enter a description of this province...">{{ old('description', $province->description ?? '') }}</textarea>
        </div>
    </div>

    <div style="display:flex; gap:12px; justify-content:flex-end;">
        <a href="{{ route('pmpro.provinces.index') }}" class="neon-btn neon-btn-red">
            <i class="fas fa-times"></i> Cancel
        </a>
        <button type="submit" class="neon-btn neon-btn-green neon-pulse">
            <i class="fas fa-check"></i> {{ isset($province) ? 'Update Province' : 'Save Province' }}
        </button>
    </div>
</form>
@endsection
