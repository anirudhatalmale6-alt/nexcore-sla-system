@extends('cims_pmpro::layouts.pmpro')

@section('title', 'Provinces')
@section('page_heading', 'PROVINCES')

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">Province Registry</h1>
        <span class="sl-page-subtitle">South African Provinces</span>
        <div style="margin-left:auto;">
            <a href="{{ route('pmpro.provinces.create') }}" class="neon-btn neon-btn-green neon-pulse">
                <i class="fas fa-plus"></i> New Province
            </a>
        </div>
    </div>
</div>

<div class="sl-stats-grid sl-animate d2">
    <div class="sl-stat-card green">
        <div class="sl-stat-label">Total</div>
        <div class="sl-stat-value" style="color:var(--accent-green);">{{ number_format($stats['total'] ?? 0) }}</div>
        <div class="sl-stat-meta">All provinces</div>
    </div>
    <div class="sl-stat-card blue">
        <div class="sl-stat-label">Active</div>
        <div class="sl-stat-value" style="color:var(--accent-blue);">{{ number_format($stats['active'] ?? 0) }}</div>
        <div class="sl-stat-meta">Currently active</div>
    </div>
    <div class="sl-stat-card amber">
        <div class="sl-stat-label">Inactive</div>
        <div class="sl-stat-value" style="color:var(--accent-amber);">{{ number_format($stats['inactive'] ?? 0) }}</div>
        <div class="sl-stat-meta">Disabled</div>
    </div>
</div>

<div class="sl-card sl-animate d3 sl-mb-md">
    <form method="GET" action="{{ route('pmpro.provinces.index') }}">
        <div style="display:flex; gap:12px; align-items:end;">
            <div class="sl-field" style="flex:1;">
                <label>Search</label>
                <input type="text" name="search" value="{{ request('search') }}" placeholder="Province name or code..." style="width:100%;">
            </div>
            <div style="display:flex; gap:8px;">
                <button type="submit" class="neon-btn neon-btn-cyan" style="padding:9px 18px;">
                    <i class="fas fa-search"></i> Filter
                </button>
                <a href="{{ route('pmpro.provinces.index') }}" class="neon-btn neon-btn-ghost" style="padding:9px 18px;">
                    <i class="fas fa-times"></i> Clear
                </a>
            </div>
        </div>
    </form>
</div>

<div class="sl-card sl-animate d4">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-globe-africa"></i> Provinces</div>
        <div style="font-size:13px; color:var(--text-muted);">
            Showing {{ $provinces->firstItem() ?? 0 }}-{{ $provinces->lastItem() ?? 0 }} of {{ $provinces->total() }}
        </div>
    </div>
    <div class="sl-table-wrap">
        <table class="sl-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Code</th>
                    <th class="center">Districts</th>
                    <th class="center">Metros</th>
                    <th class="center">Status</th>
                    <th class="center">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($provinces as $prov)
                <tr>
                    <td class="mono">{{ $prov->id }}</td>
                    <td style="font-weight:600;"><a href="{{ route('pmpro.provinces.show', $prov->id) }}" style="color:var(--text-primary); text-decoration:none;" onmouseover="this.style.color='var(--accent-cyan)'" onmouseout="this.style.color='var(--text-primary)'">{{ $prov->name }}</a></td>
                    <td><span class="sl-tag sl-tag-green">{{ $prov->code }}</span></td>
                    <td class="center"><span class="sl-tag sl-tag-blue">{{ $prov->districts_count }}</span></td>
                    <td class="center"><span class="sl-tag sl-tag-purple">{{ $prov->metros_count }}</span></td>
                    <td class="center">
                        @if($prov->is_active)
                            <span class="sl-status-dot pass"></span>
                        @else
                            <span class="sl-status-dot fail"></span>
                        @endif
                    </td>
                    <td class="center">
                        <div style="display:flex; gap:6px; justify-content:center;">
                            <a href="{{ route('pmpro.provinces.edit', $prov->id) }}" style="color:var(--accent-blue); font-size:15px;" title="Edit"><i class="fas fa-pen"></i></a>
                            <a href="{{ route('pmpro.provinces.show', $prov->id) }}" style="color:var(--accent-green); font-size:15px;" title="View"><i class="fas fa-eye"></i></a>
                            <form method="POST" action="{{ route('pmpro.provinces.toggle', $prov->id) }}" style="display:inline;">
                                @csrf
                                <button type="submit" style="background:none; border:none; color:var(--accent-amber); cursor:pointer; font-size:15px;" title="Toggle Status"><i class="fas fa-power-off"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" style="text-align:center; padding:40px; color:var(--text-muted);">
                        <i class="fas fa-globe-africa" style="font-size:32px; opacity:0.3; margin-bottom:12px; display:block;"></i>
                        No provinces found.
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($provinces->hasPages())
    <div style="display:flex; justify-content:center; padding:16px 0 0; gap:4px;">
        @if($provinces->onFirstPage())
            <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Prev</span>
        @else
            <a href="{{ $provinces->previousPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Prev</a>
        @endif
        @foreach($provinces->getUrlRange(max(1, $provinces->currentPage()-2), min($provinces->lastPage(), $provinces->currentPage()+2)) as $page => $url)
            @if($page == $provinces->currentPage())
                <span class="sl-btn sl-btn-primary" style="padding:6px 12px; font-size:13px;">{{ $page }}</span>
            @else
                <a href="{{ $url }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">{{ $page }}</a>
            @endif
        @endforeach
        @if($provinces->hasMorePages())
            <a href="{{ $provinces->nextPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Next</a>
        @else
            <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Next</span>
        @endif
    </div>
    @endif
</div>
@endsection
