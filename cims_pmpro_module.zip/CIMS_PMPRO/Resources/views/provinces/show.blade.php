@extends('cims_pmpro::layouts.pmpro')

@section('title', 'View Province')
@section('page_heading', 'VIEW PROVINCE')

@section('content')
<div class="sl-animate d1">
    <div style="margin-bottom:12px; font-size:13px; color:var(--text-muted);">
        <a href="{{ route('pmpro.countries.index') }}" style="color:var(--accent-cyan); text-decoration:none;">Countries</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        <a href="{{ route('pmpro.countries.show', 129) }}" style="color:var(--accent-cyan); text-decoration:none;">South Africa</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        <span style="color:var(--text-primary);">{{ $province->name }}</span>
    </div>
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ $province->name }}</h1>
        <span class="sl-page-subtitle">{{ $province->native_name ? $province->native_name . ' — ' : '' }}Province details and linked municipalities</span>
        <div style="margin-left:auto; display:flex; gap:8px;">
            <a href="{{ route('pmpro.provinces.edit', $province->id) }}" class="neon-btn neon-btn-blue">
                <i class="fas fa-pen"></i> Edit
            </a>
            <a href="{{ route('pmpro.provinces.index') }}" class="neon-btn neon-btn-ghost">
                <i class="fas fa-arrow-left"></i> Back
            </a>
        </div>
    </div>
</div>

{{-- Stats Strip --}}
<div class="sl-stats-grid sl-animate d2">
    <div class="sl-stat-card green">
        <div class="sl-stat-label">Population</div>
        <div class="sl-stat-value" style="color:var(--accent-green); font-size:20px;">{{ $province->population ? number_format($province->population) : '-' }}</div>
        <div class="sl-stat-meta">Census 2022</div>
    </div>
    <div class="sl-stat-card blue">
        <div class="sl-stat-label">Area</div>
        <div class="sl-stat-value" style="color:var(--accent-blue); font-size:20px;">{{ $province->area_km2 ? number_format($province->area_km2) . ' km²' : '-' }}</div>
        <div class="sl-stat-meta">Total land area</div>
    </div>
    <div class="sl-stat-card amber">
        <div class="sl-stat-label">Density</div>
        <div class="sl-stat-value" style="color:var(--accent-amber); font-size:20px;">{{ $province->density ? number_format($province->density, 1) . '/km²' : '-' }}</div>
        <div class="sl-stat-meta">People per km²</div>
    </div>
    <div class="sl-stat-card purple">
        <div class="sl-stat-label">Municipalities</div>
        <div class="sl-stat-value" style="color:var(--accent-purple); font-size:20px;">{{ $province->districts_count + $province->metros_count }}</div>
        <div class="sl-stat-meta">{{ $province->districts_count }} district · {{ $province->metros_count }} metro</div>
    </div>
</div>

{{-- Province Info + Map --}}
<div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;" class="sl-animate d3">
    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-globe-africa"></i> Province Information</div>
            @if($province->is_active)
                <span class="sl-tag sl-tag-green">Active</span>
            @else
                <span class="sl-tag sl-tag-red">Inactive</span>
            @endif
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Name</span>
            <span class="sl-result-value" style="font-weight:600;">{{ $province->name }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Native Name</span>
            <span class="sl-result-value" style="font-style:italic;">{{ $province->native_name ?? '-' }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Code</span>
            <span class="sl-result-value"><span class="sl-tag sl-tag-green" style="font-family:var(--font-mono);">{{ $province->code }}</span></span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Capital</span>
            <span class="sl-result-value" style="font-weight:600;">{{ $province->capital ?? '-' }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Largest City</span>
            <span class="sl-result-value">{{ $province->largest_city ?? '-' }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Districts</span>
            <span class="sl-result-value"><span class="sl-tag sl-tag-blue">{{ $province->districts_count }}</span></span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Metropolitan Municipalities</span>
            <span class="sl-result-value"><span class="sl-tag sl-tag-purple">{{ $province->metros_count }}</span></span>
        </div>
    </div>

    <div class="sl-card" style="display:flex; flex-direction:column;">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-map"></i> Province Map</div>
        </div>
        <div style="flex:1; display:flex; align-items:center; justify-content:center; padding:20px;">
            @if($province->map_image)
                <img src="/{{ $province->map_image }}" alt="{{ $province->name }} Map" style="max-width:100%; max-height:280px; border-radius:8px; border:1px solid var(--border-subtle);">
            @else
                <div style="text-align:center; color:var(--text-muted); opacity:0.5;">
                    <i class="fas fa-map" style="font-size:64px; margin-bottom:12px; display:block;"></i>
                    <span style="font-size:13px;">No map image uploaded</span>
                </div>
            @endif
        </div>
    </div>
</div>

{{-- Description --}}
@if($province->description)
<div class="sl-card sl-animate d4" style="margin-top:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-align-left"></i> Description</div>
    </div>
    <div style="padding:20px; color:var(--text-secondary); font-size:14px; line-height:1.8;">
        {!! nl2br(e($province->description)) !!}
    </div>
</div>
@endif

@if($metros->count())
<div class="sl-card sl-animate d5" style="margin-top:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-city"></i> Metropolitan Municipalities ({{ $metros->count() }})</div>
        <span class="sl-tag sl-tag-purple">Category A</span>
    </div>
    <div class="sl-table-wrap">
        <table class="sl-table">
            <thead><tr><th>Name</th><th>Code</th><th class="center">Status</th><th class="center">Action</th></tr></thead>
            <tbody>
                @foreach($metros as $m)
                <tr style="cursor:pointer;" onclick="window.location='{{ route('pmpro.metros.show', $m->id) }}'">
                    <td style="font-weight:600;">{{ $m->name }}</td>
                    <td><span class="sl-tag sl-tag-purple">{{ $m->code }}</span></td>
                    <td class="center">
                        @if($m->is_active) <span class="sl-status-dot pass"></span>
                        @else <span class="sl-status-dot fail"></span> @endif
                    </td>
                    <td class="center">
                        <a href="{{ route('pmpro.metros.show', $m->id) }}" class="neon-btn neon-btn-cyan" style="padding:6px 14px; font-size:11px;">
                            <i class="fas fa-arrow-right"></i> Drill Down
                        </a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endif

@if($districts->count())
<div class="sl-card sl-animate d6" style="margin-top:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-building"></i> District Municipalities ({{ $districts->count() }})</div>
        <span class="sl-tag sl-tag-blue">Category C</span>
    </div>
    <div class="sl-table-wrap">
        <table class="sl-table">
            <thead><tr><th>Name</th><th>Code</th><th class="center">Local Municipalities</th><th class="center">Status</th><th class="center">Action</th></tr></thead>
            <tbody>
                @foreach($districts as $d)
                <tr style="cursor:pointer;" onclick="window.location='{{ route('pmpro.districts.show', $d->id) }}'">
                    <td style="font-weight:600;">{{ $d->name }}</td>
                    <td><span class="sl-tag sl-tag-cyan">{{ $d->code }}</span></td>
                    <td class="center"><span class="sl-tag sl-tag-blue">{{ $d->local_municipalities_count }}</span></td>
                    <td class="center">
                        @if($d->is_active) <span class="sl-status-dot pass"></span>
                        @else <span class="sl-status-dot fail"></span> @endif
                    </td>
                    <td class="center">
                        <a href="{{ route('pmpro.districts.show', $d->id) }}" class="neon-btn neon-btn-cyan" style="padding:6px 14px; font-size:11px;">
                            <i class="fas fa-arrow-right"></i> Drill Down
                        </a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endif
@endsection
