@extends('cims_pmpro::layouts.system_settings')

@section('title', 'View Nationality')
@section('page_heading', 'VIEW NATIONALITY')

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ $nationality->name }}</h1>
        <span class="sl-page-subtitle">Nationality details{{ $nationality->country ? ' — '.$nationality->country->name : '' }}</span>
        <div style="margin-left:auto; display:flex; gap:8px;">
            <a href="{{ route('system-settings.nationalities.edit', $nationality->id) }}" class="neon-btn neon-btn-blue"><i class="fas fa-pen"></i> Edit</a>
            <a href="{{ route('system-settings.nationalities.index') }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back</a>
        </div>
    </div>
</div>

<div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;" class="sl-animate d2">

    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-flag"></i> Nationality Information</div>
            @if($nationality->is_active) <span class="sl-tag sl-tag-green">Active</span>
            @else <span class="sl-tag sl-tag-red">Inactive</span> @endif
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Name</span>
            <span class="sl-result-value" style="font-weight:600;">{{ $nationality->name }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Code</span>
            <span class="sl-result-value"><span class="sl-tag sl-tag-amber" style="font-family:var(--font-mono);">{{ $nationality->code ?? '-' }}</span></span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Country</span>
            <span class="sl-result-value">
                @if($nationality->country)
                    @if($nationality->country->flag_image)<img src="/{{ $nationality->country->flag_image }}" alt="{{ $nationality->country->name }}" style="width:28px; height:21px; border-radius:3px; vertical-align:middle; margin-right:8px; border:1px solid rgba(255,255,255,0.1); object-fit:cover;">@endif
                    <a href="{{ route('pmpro.countries.show', $nationality->country->id) }}" style="color:var(--accent-cyan); text-decoration:none; font-weight:600;" onmouseover="this.style.textDecoration='underline'" onmouseout="this.style.textDecoration='none'">{{ $nationality->country->name }}</a>
                @else
                    <span style="color:var(--text-muted);">Not linked</span>
                @endif
            </span>
        </div>
    </div>

    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-cog"></i> Status & Audit</div>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Active</span>
            <span class="sl-result-value">@if($nationality->is_active) <span class="sl-status-dot pass"></span> Yes @else <span class="sl-status-dot fail"></span> No @endif</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Deleted</span>
            <span class="sl-result-value">@if($nationality->is_deleted) <span style="color:var(--accent-red);">Yes</span> @else No @endif</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Created</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-size:13px;">{{ $nationality->created_at ? $nationality->created_at->format('j M Y H:i') : '-' }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Last Updated</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-size:13px;">{{ $nationality->updated_at ? $nationality->updated_at->format('j M Y H:i') : '-' }}</span>
        </div>
    </div>

</div>

@if($nationality->description)
<div class="sl-card sl-animate d3" style="margin-top:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-align-left"></i> Description</div>
    </div>
    <div style="padding:20px; color:var(--text-secondary); font-size:14px; line-height:1.8;">
        {!! nl2br(e($nationality->description)) !!}
    </div>
</div>
@endif
@endsection
