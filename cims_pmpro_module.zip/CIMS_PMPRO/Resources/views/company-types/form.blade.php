@extends('cims_pmpro::layouts.system_settings')

@section('title', isset($companyType) ? 'Edit Company Type' : 'New Company Type')
@section('page_heading', isset($companyType) ? 'EDIT COMPANY TYPE' : 'NEW COMPANY TYPE')

@push('styles')
<style>
.sl-form-section { background:var(--bg-surface); border:1px solid var(--border-subtle); border-radius:var(--radius-lg); padding:24px; margin-bottom:20px; box-shadow:var(--shadow-card); }
.sl-form-section-title { font-size:15px; font-weight:700; letter-spacing:2px; text-transform:uppercase; color:var(--accent-green); margin-bottom:20px; padding-bottom:10px; border-bottom:1px solid var(--border-subtle); display:flex; align-items:center; gap:10px; }
.sl-form-section-title i { font-size:16px; }
.sl-form-grid { display:grid; gap:16px; }
.sl-form-grid.cols-2 { grid-template-columns:1fr 1fr; }
.sl-field label .required { color:var(--accent-red); margin-left:2px; }
.sl-field select { background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:9px 12px; color:var(--text-primary); font-size:15px; font-family:var(--font-mono); width:100%; outline:none; appearance:none; -webkit-appearance:none; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%235a6478' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 12px center; padding-right:32px; }
.sl-field select:focus { border-color:var(--accent-green); box-shadow:0 0 0 2px rgba(34,197,94,0.15); }
.sl-field input { width:100%; }
.sl-field textarea { width:100%; background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:12px; color:var(--text-primary); font-size:14px; font-family:var(--font-body); line-height:1.6; resize:vertical; outline:none; }
.sl-field textarea:focus { border-color:var(--accent-green); box-shadow:0 0 0 2px rgba(34,197,94,0.15); }
@media (max-width:768px) { .sl-form-grid.cols-2 { grid-template-columns:1fr; } }
</style>
@endpush

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ isset($companyType) ? 'Edit '.$companyType->name : 'Create New Company Type' }}</h1>
        <span class="sl-page-subtitle">{{ isset($companyType) ? 'Update company type details' : 'Add a new company type to the system' }}</span>
        <div style="margin-left:auto;">
            <a href="{{ route('system-settings.company-types.index') }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back to List</a>
        </div>
    </div>
</div>

<form method="POST" action="{{ isset($companyType) ? route('system-settings.company-types.update', $companyType->id) : route('system-settings.company-types.store') }}" class="sl-animate d2">
    @csrf
    @if(isset($companyType)) @method('PUT') @endif

    @if($errors->any())
    <div class="sl-verdict reject sl-mb-md" style="padding:14px 20px;">
        <div class="sl-verdict-icon" style="width:32px;height:32px;font-size:16px;"><i class="fas fa-exclamation-triangle"></i></div>
        <div>@foreach($errors->all() as $error)<div class="sl-verdict-text" style="font-size:14px;">{{ $error }}</div>@endforeach</div>
    </div>
    @endif

    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-building"></i> Company Type Details</div>
        <div class="sl-form-grid cols-2">
            <div class="sl-field">
                <label>Name <span class="required">*</span></label>
                <input type="text" name="name" value="{{ old('name', $companyType->name ?? '') }}" placeholder="e.g. Private Company (Pty) Ltd" required>
            </div>
            <div class="sl-field">
                <label>Code</label>
                <input type="text" name="code" value="{{ old('code', $companyType->code ?? '') }}" placeholder="e.g. PTY" maxlength="20" style="text-transform:uppercase;">
            </div>
        </div>
        @if(isset($companyType))
        <div class="sl-form-grid cols-2" style="margin-top:16px;">
            <div class="sl-field">
                <label>Status</label>
                <select name="is_active">
                    <option value="1" {{ old('is_active', $companyType->is_active) ? 'selected' : '' }}>Active</option>
                    <option value="0" {{ old('is_active', $companyType->is_active) ? '' : 'selected' }}>Inactive</option>
                </select>
            </div>
            <div class="sl-field">
                <label>Deleted</label>
                <select name="is_deleted">
                    <option value="0" {{ old('is_deleted', $companyType->is_deleted) ? '' : 'selected' }}>No</option>
                    <option value="1" {{ old('is_deleted', $companyType->is_deleted) ? 'selected' : '' }}>Yes</option>
                </select>
            </div>
        </div>
        @endif
    </div>

    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-align-left"></i> Description</div>
        <div class="sl-field">
            <label>Description</label>
            <textarea name="description" rows="4" placeholder="Enter a description...">{{ old('description', $companyType->description ?? '') }}</textarea>
        </div>
    </div>

    <div style="display:flex; gap:12px; justify-content:flex-end;">
        <a href="{{ route('system-settings.company-types.index') }}" class="neon-btn neon-btn-red"><i class="fas fa-times"></i> Cancel</a>
        <button type="submit" class="neon-btn neon-btn-green neon-pulse"><i class="fas fa-check"></i> {{ isset($companyType) ? 'Update' : 'Save' }}</button>
    </div>
</form>
@endsection