@extends('cims_pmpro::layouts.pmpro')

@section('title', 'Municipality Types')
@section('page_heading', 'MUNICIPALITY TYPES')

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">Municipality Types</h1>
        <span class="sl-page-subtitle">Classification of South African municipalities</span>
        <div style="margin-left:auto;">
            <a href="{{ route('pmpro.municipality-types.create') }}" class="neon-btn neon-btn-green neon-pulse">
                <i class="fas fa-plus"></i> New Type
            </a>
        </div>
    </div>
</div>

<div class="sl-stats-grid sl-animate d2">
    <div class="sl-stat-card green">
        <div class="sl-stat-label">Total</div>
        <div class="sl-stat-value" style="color:var(--accent-green);">{{ number_format($stats['total'] ?? 0) }}</div>
        <div class="sl-stat-meta">All types</div>
    </div>
    <div class="sl-stat-card blue">
        <div class="sl-stat-label">Active</div>
        <div class="sl-stat-value" style="color:var(--accent-blue);">{{ number_format($stats['active'] ?? 0) }}</div>
        <div class="sl-stat-meta">Currently active</div>
    </div>
    <div class="sl-stat-card amber">
        <div class="sl-stat-label">Inactive</div>
        <div class="sl-stat-value" style="color:var(--accent-amber);">{{ number_format($stats['inactive'] ?? 0) }}</div>
        <div class="sl-stat-meta">Disabled</div>
    </div>
</div>

<div class="sl-card sl-animate d3">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-tags"></i> Municipality Types</div>
        <div style="font-size:13px; color:var(--text-muted);">
            Showing {{ $types->firstItem() ?? 0 }}-{{ $types->lastItem() ?? 0 }} of {{ $types->total() }}
        </div>
    </div>
    <div class="sl-table-wrap">
        <table class="sl-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Code</th>
                    <th>Description</th>
                    <th class="center">Status</th>
                    <th class="center">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($types as $type)
                <tr>
                    <td class="mono">{{ $type->id }}</td>
                    <td style="font-weight:600;">{{ $type->name }}</td>
                    <td><span class="sl-tag sl-tag-cyan">{{ $type->code }}</span></td>
                    <td style="color:var(--text-secondary);">{{ $type->description ?? '-' }}</td>
                    <td class="center">
                        @if($type->is_active) <span class="sl-status-dot pass"></span>
                        @else <span class="sl-status-dot fail"></span>
                        @endif
                    </td>
                    <td class="center">
                        <div style="display:flex; gap:6px; justify-content:center;">
                            <a href="{{ route('pmpro.municipality-types.edit', $type->id) }}" style="color:var(--accent-blue); font-size:15px;" title="Edit"><i class="fas fa-pen"></i></a>
                            <a href="{{ route('pmpro.municipality-types.show', $type->id) }}" style="color:var(--accent-green); font-size:15px;" title="View"><i class="fas fa-eye"></i></a>
                            <form method="POST" action="{{ route('pmpro.municipality-types.toggle', $type->id) }}" style="display:inline;">
                                @csrf
                                <button type="submit" style="background:none; border:none; color:var(--accent-amber); cursor:pointer; font-size:15px;" title="Toggle Status"><i class="fas fa-power-off"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" style="text-align:center; padding:40px; color:var(--text-muted);">
                        <i class="fas fa-tags" style="font-size:32px; opacity:0.3; margin-bottom:12px; display:block;"></i>
                        No municipality types found.
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($types->hasPages())
    <div style="display:flex; justify-content:center; padding:16px 0 0; gap:4px;">
        @if($types->onFirstPage())
            <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Prev</span>
        @else
            <a href="{{ $types->previousPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Prev</a>
        @endif
        @foreach($types->getUrlRange(max(1, $types->currentPage()-2), min($types->lastPage(), $types->currentPage()+2)) as $page => $url)
            @if($page == $types->currentPage())
                <span class="sl-btn sl-btn-primary" style="padding:6px 12px; font-size:13px;">{{ $page }}</span>
            @else
                <a href="{{ $url }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">{{ $page }}</a>
            @endif
        @endforeach
        @if($types->hasMorePages())
            <a href="{{ $types->nextPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Next</a>
        @else
            <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Next</span>
        @endif
    </div>
    @endif
</div>
@endsection
