@extends('cims_pmpro::layouts.pmpro')

@section('title', 'View Municipality Type')
@section('page_heading', 'VIEW MUNICIPALITY TYPE')

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ $type->name }}</h1>
        <span class="sl-page-subtitle">Municipality type details</span>
        <div style="margin-left:auto; display:flex; gap:8px;">
            <a href="{{ route('pmpro.municipality-types.edit', $type->id) }}" class="neon-btn neon-btn-blue">
                <i class="fas fa-pen"></i> Edit
            </a>
            <a href="{{ route('pmpro.municipality-types.index') }}" class="neon-btn neon-btn-ghost">
                <i class="fas fa-arrow-left"></i> Back
            </a>
        </div>
    </div>
</div>

<div class="sl-card sl-animate d2">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-tags"></i> Type Information</div>
        @if($type->is_active)
            <span class="sl-tag sl-tag-green">Active</span>
        @else
            <span class="sl-tag sl-tag-red">Inactive</span>
        @endif
    </div>
    <div class="sl-result-row">
        <span class="sl-result-label">Name</span>
        <span class="sl-result-value" style="font-weight:600;">{{ $type->name }}</span>
    </div>
    <div class="sl-result-row">
        <span class="sl-result-label">Code</span>
        <span class="sl-result-value"><span class="sl-tag sl-tag-cyan">{{ $type->code }}</span></span>
    </div>
    <div class="sl-result-row">
        <span class="sl-result-label">Description</span>
        <span class="sl-result-value">{{ $type->description ?? '-' }}</span>
    </div>
</div>
@endsection
