@extends('cims_pmpro::layouts.system_settings')

@section('title', 'Employment Statuses')
@section('page_heading', 'EMPLOYMENT STATUSES')

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">Employment Status Registry</h1>
        <span class="sl-page-subtitle">System employment statuses classifications</span>
        <div style="margin-left:auto;">
            <a href="{{ route('system-settings.employment-statuses.create') }}" class="neon-btn neon-btn-green neon-pulse"><i class="fas fa-plus"></i> New Employment Status</a>
        </div>
    </div>
</div>

<div class="sl-stats-grid sl-animate d2">
    <div class="sl-stat-card green">
        <div class="sl-stat-label">Total</div>
        <div class="sl-stat-value" style="color:var(--accent-green);">{{ number_format($stats['total'] ?? 0) }}</div>
        <div class="sl-stat-meta">All entries</div>
    </div>
    <div class="sl-stat-card blue">
        <div class="sl-stat-label">Active</div>
        <div class="sl-stat-value" style="color:var(--accent-blue);">{{ number_format($stats['active'] ?? 0) }}</div>
        <div class="sl-stat-meta">Currently active</div>
    </div>
    <div class="sl-stat-card amber">
        <div class="sl-stat-label">Inactive</div>
        <div class="sl-stat-value" style="color:var(--accent-amber);">{{ number_format($stats['inactive'] ?? 0) }}</div>
        <div class="sl-stat-meta">Disabled</div>
    </div>
</div>

<div class="sl-card sl-animate d3 sl-mb-md">
    <form method="GET" action="{{ route('system-settings.employment-statuses.index') }}">
        <div style="display:flex; gap:12px; align-items:end; flex-wrap:wrap;">
            <div class="sl-field" style="flex:1; min-width:200px;">
                <label>Search</label>
                <input type="text" name="search" value="{{ request('search') }}" placeholder="Employment status name or code..." style="width:100%;">
            </div>
            <div style="display:flex; gap:8px;">
                <button type="submit" class="neon-btn neon-btn-cyan" style="padding:9px 18px;"><i class="fas fa-search"></i> Filter</button>
                <a href="{{ route('system-settings.employment-statuses.index') }}" class="neon-btn neon-btn-ghost" style="padding:9px 18px;"><i class="fas fa-times"></i> Clear</a>
            </div>
        </div>
    </form>
</div>

<div class="sl-card sl-animate d4">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-briefcase"></i> Employment Statuses</div>
        <div style="font-size:13px; color:var(--text-muted);">Showing {{ $employmentStatuses->firstItem() ?? 0 }}-{{ $employmentStatuses->lastItem() ?? 0 }} of {{ $employmentStatuses->total() }}</div>
    </div>
    <div class="sl-table-wrap">
        <table class="sl-table">
            <thead><tr><th>#</th><th>Employment Status</th><th>Code</th><th class="center">Status</th><th class="center">Actions</th></tr></thead>
            <tbody>
                @forelse($employmentStatuses as $idx => $item)
                <tr>
                    <td style="color:var(--text-muted);">{{ $employmentStatuses->firstItem() + $idx }}</td>
                    <td style="font-weight:600;"><a href="{{ route('system-settings.employment-statuses.show', $item->id) }}" style="color:var(--text-primary); text-decoration:none;" onmouseover="this.style.color='var(--accent-cyan)'" onmouseout="this.style.color='var(--text-primary)'">{{ $item->name }}</a></td>
                    <td><span class="sl-tag sl-tag-amber" style="font-family:var(--font-mono);">{{ $item->code ?? '-' }}</span></td>
                    <td class="center">@if($item->is_active) <span class="sl-status-dot pass"></span> @else <span class="sl-status-dot fail"></span> @endif</td>
                    <td class="center">
                        <div style="display:flex; gap:6px; justify-content:center;">
                            <a href="{{ route('system-settings.employment-statuses.edit', $item->id) }}" style="color:var(--accent-blue); font-size:15px;" title="Edit"><i class="fas fa-pen"></i></a>
                            <a href="{{ route('system-settings.employment-statuses.show', $item->id) }}" style="color:var(--accent-green); font-size:15px;" title="View"><i class="fas fa-eye"></i></a>
                            <form method="POST" action="{{ route('system-settings.employment-statuses.toggle', $item->id) }}" style="display:inline;">@csrf
                                <button type="submit" style="background:none; border:none; color:var(--accent-amber); cursor:pointer; font-size:15px;" title="Toggle"><i class="fas fa-power-off"></i></button>
                            </form>
                            <form method="POST" action="{{ route('system-settings.employment-statuses.destroy', $item->id) }}" style="display:inline;" onsubmit="return confirm('Delete {{ $item->name }}?')">@csrf @method('DELETE')
                                <button type="submit" style="background:none; border:none; color:var(--accent-red); cursor:pointer; font-size:15px;" title="Delete"><i class="fas fa-trash"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="5" style="text-align:center; padding:40px; color:var(--text-muted);"><i class="fas fa-briefcase" style="font-size:32px; opacity:0.3; margin-bottom:12px; display:block;"></i>No employment statuses found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($employmentStatuses->hasPages())
    <div style="display:flex; justify-content:center; padding:16px 0 0; gap:4px;">
        @if($employmentStatuses->onFirstPage()) <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Prev</span>
        @else <a href="{{ $employmentStatuses->previousPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Prev</a> @endif
        @foreach($employmentStatuses->getUrlRange(max(1, $employmentStatuses->currentPage()-2), min($employmentStatuses->lastPage(), $employmentStatuses->currentPage()+2)) as $page => $url)
            @if($page == $employmentStatuses->currentPage()) <span class="sl-btn sl-btn-primary" style="padding:6px 12px; font-size:13px;">{{ $page }}</span>
            @else <a href="{{ $url }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">{{ $page }}</a> @endif
        @endforeach
        @if($employmentStatuses->hasMorePages()) <a href="{{ $employmentStatuses->nextPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Next</a>
        @else <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Next</span> @endif
    </div>
    @endif
</div>
@endsection