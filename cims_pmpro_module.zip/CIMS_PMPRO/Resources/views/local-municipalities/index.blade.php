@extends('cims_pmpro::layouts.pmpro')

@section('title', 'Local Municipalities')
@section('page_heading', 'LOCAL MUNICIPALITIES')

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">Local Municipalities</h1>
        <span class="sl-page-subtitle">Category B - Local level municipalities</span>
        <div style="margin-left:auto;">
            <a href="{{ route('pmpro.local-municipalities.create') }}" class="neon-btn neon-btn-green neon-pulse"><i class="fas fa-plus"></i> New Local Municipality</a>
        </div>
    </div>
</div>

<div class="sl-stats-grid sl-animate d2">
    <div class="sl-stat-card green">
        <div class="sl-stat-label">Total</div>
        <div class="sl-stat-value" style="color:var(--accent-green);">{{ number_format($stats['total'] ?? 0) }}</div>
        <div class="sl-stat-meta">All local municipalities</div>
    </div>
    <div class="sl-stat-card blue">
        <div class="sl-stat-label">Active</div>
        <div class="sl-stat-value" style="color:var(--accent-blue);">{{ number_format($stats['active'] ?? 0) }}</div>
        <div class="sl-stat-meta">Currently active</div>
    </div>
    <div class="sl-stat-card amber">
        <div class="sl-stat-label">Inactive</div>
        <div class="sl-stat-value" style="color:var(--accent-amber);">{{ number_format($stats['inactive'] ?? 0) }}</div>
        <div class="sl-stat-meta">Disabled</div>
    </div>
</div>

<div class="sl-card sl-animate d3 sl-mb-md">
    <form method="GET" action="{{ route('pmpro.local-municipalities.index') }}">
        <div style="display:flex; gap:12px; align-items:end; flex-wrap:wrap;">
            <div class="sl-field" style="flex:1; min-width:200px;">
                <label>Search</label>
                <input type="text" name="search" value="{{ request('search') }}" placeholder="Municipality name or code..." style="width:100%;">
            </div>
            <div class="sl-field" style="min-width:180px;">
                <label>Province</label>
                <select name="province_id" style="width:100%; background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:9px 12px; color:var(--text-primary); font-size:15px; font-family:var(--font-mono);">
                    <option value="">All Provinces</option>
                    @foreach($provinces as $prov)
                        <option value="{{ $prov->id }}" {{ request('province_id') == $prov->id ? 'selected' : '' }}>{{ $prov->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="sl-field" style="min-width:180px;">
                <label>District</label>
                <select name="district_id" style="width:100%; background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:9px 12px; color:var(--text-primary); font-size:15px; font-family:var(--font-mono);">
                    <option value="">All Districts</option>
                    @foreach($districts as $dist)
                        <option value="{{ $dist->id }}" {{ request('district_id') == $dist->id ? 'selected' : '' }}>{{ $dist->name }}</option>
                    @endforeach
                </select>
            </div>
            <div style="display:flex; gap:8px;">
                <button type="submit" class="neon-btn neon-btn-cyan" style="padding:9px 18px;"><i class="fas fa-search"></i> Filter</button>
                <a href="{{ route('pmpro.local-municipalities.index') }}" class="neon-btn neon-btn-ghost" style="padding:9px 18px;"><i class="fas fa-times"></i> Clear</a>
            </div>
        </div>
    </form>
</div>

<div class="sl-card sl-animate d4">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-map-signs"></i> Local Municipalities</div>
        <div style="font-size:13px; color:var(--text-muted);">Showing {{ $municipalities->firstItem() ?? 0 }}-{{ $municipalities->lastItem() ?? 0 }} of {{ $municipalities->total() }}</div>
    </div>
    <div class="sl-table-wrap">
        <table class="sl-table">
            <thead><tr><th>#</th><th>Name</th><th>Code</th><th>District</th><th>Province</th><th class="center">Status</th><th class="center">Actions</th></tr></thead>
            <tbody>
                @forelse($municipalities as $mun)
                <tr>
                    <td class="mono">{{ $mun->id }}</td>
                    <td style="font-weight:600;"><a href="{{ route('pmpro.local-municipalities.show', $mun->id) }}" style="color:var(--text-primary); text-decoration:none;" onmouseover="this.style.color='var(--accent-cyan)'" onmouseout="this.style.color='var(--text-primary)'">{{ $mun->name }}</a></td>
                    <td><span class="sl-tag sl-tag-blue">{{ $mun->code ?? '-' }}</span></td>
                    <td>{{ $mun->district->name ?? '-' }}</td>
                    <td><span class="sl-tag sl-tag-green">{{ $mun->district->province->code ?? '-' }}</span></td>
                    <td class="center">@if($mun->is_active) <span class="sl-status-dot pass"></span> @else <span class="sl-status-dot fail"></span> @endif</td>
                    <td class="center">
                        <div style="display:flex; gap:6px; justify-content:center;">
                            <a href="{{ route('pmpro.local-municipalities.edit', $mun->id) }}" style="color:var(--accent-blue); font-size:15px;" title="Edit"><i class="fas fa-pen"></i></a>
                            <a href="{{ route('pmpro.local-municipalities.show', $mun->id) }}" style="color:var(--accent-green); font-size:15px;" title="View"><i class="fas fa-eye"></i></a>
                            <form method="POST" action="{{ route('pmpro.local-municipalities.toggle', $mun->id) }}" style="display:inline;">@csrf
                                <button type="submit" style="background:none; border:none; color:var(--accent-amber); cursor:pointer; font-size:15px;" title="Toggle"><i class="fas fa-power-off"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="7" style="text-align:center; padding:40px; color:var(--text-muted);"><i class="fas fa-map-signs" style="font-size:32px; opacity:0.3; margin-bottom:12px; display:block;"></i>No local municipalities found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($municipalities->hasPages())
    <div style="display:flex; justify-content:center; padding:16px 0 0; gap:4px;">
        @if($municipalities->onFirstPage()) <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Prev</span>
        @else <a href="{{ $municipalities->previousPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Prev</a> @endif
        @foreach($municipalities->getUrlRange(max(1, $municipalities->currentPage()-2), min($municipalities->lastPage(), $municipalities->currentPage()+2)) as $page => $url)
            @if($page == $municipalities->currentPage()) <span class="sl-btn sl-btn-primary" style="padding:6px 12px; font-size:13px;">{{ $page }}</span>
            @else <a href="{{ $url }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">{{ $page }}</a> @endif
        @endforeach
        @if($municipalities->hasMorePages()) <a href="{{ $municipalities->nextPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Next</a>
        @else <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Next</span> @endif
    </div>
    @endif
</div>
@endsection
