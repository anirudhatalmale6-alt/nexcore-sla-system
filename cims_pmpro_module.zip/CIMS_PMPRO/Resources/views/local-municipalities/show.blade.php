@extends('cims_pmpro::layouts.pmpro')

@section('title', 'View Local Municipality')
@section('page_heading', 'VIEW LOCAL MUNICIPALITY')

@section('content')
<div class="sl-animate d1">
    <div style="margin-bottom:12px; font-size:13px; color:var(--text-muted);">
        <a href="{{ route('pmpro.countries.index') }}" style="color:var(--accent-cyan); text-decoration:none;">Countries</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        <a href="{{ route('pmpro.countries.show', 129) }}" style="color:var(--accent-cyan); text-decoration:none;">South Africa</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        <a href="{{ route('pmpro.provinces.show', $municipality->district->province->id) }}" style="color:var(--accent-cyan); text-decoration:none;">{{ $municipality->district->province->name }}</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        <a href="{{ route('pmpro.districts.show', $municipality->district->id) }}" style="color:var(--accent-cyan); text-decoration:none;">{{ $municipality->district->name }}</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        <span style="color:var(--text-primary);">{{ $municipality->name }}</span>
    </div>
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ $municipality->name }}</h1>
        <span class="sl-page-subtitle">Local municipality details</span>
        <div style="margin-left:auto; display:flex; gap:8px;">
            <a href="{{ route('pmpro.local-municipalities.edit', $municipality->id) }}" class="neon-btn neon-btn-blue"><i class="fas fa-pen"></i> Edit</a>
            <a href="{{ route('pmpro.districts.show', $municipality->district->id) }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back to {{ $municipality->district->name }}</a>
        </div>
    </div>
</div>

<div class="sl-card sl-animate d2">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-map-signs"></i> Municipality Information</div>
        <span class="sl-tag sl-tag-green">Category B</span>
        @if($municipality->is_active) <span class="sl-tag sl-tag-green">Active</span>
        @else <span class="sl-tag sl-tag-red">Inactive</span> @endif
    </div>
    <div class="sl-result-row">
        <span class="sl-result-label">Name</span>
        <span class="sl-result-value" style="font-weight:600;">{{ $municipality->name }}</span>
    </div>
    <div class="sl-result-row">
        <span class="sl-result-label">Code</span>
        <span class="sl-result-value"><span class="sl-tag sl-tag-blue">{{ $municipality->code ?? '-' }}</span></span>
    </div>
    <div class="sl-result-row">
        <span class="sl-result-label">District</span>
        <span class="sl-result-value">
            <a href="{{ route('pmpro.districts.show', $municipality->district->id) }}" style="color:var(--accent-cyan); text-decoration:none;">
                <span class="sl-tag sl-tag-cyan">{{ $municipality->district->code ?? '-' }}</span> {{ $municipality->district->name ?? '-' }}
            </a>
        </span>
    </div>
    <div class="sl-result-row">
        <span class="sl-result-label">Province</span>
        <span class="sl-result-value">
            <a href="{{ route('pmpro.provinces.show', $municipality->district->province->id) }}" style="color:var(--accent-cyan); text-decoration:none;">
                <span class="sl-tag sl-tag-green">{{ $municipality->district->province->code ?? '-' }}</span> {{ $municipality->district->province->name ?? '-' }}
            </a>
        </span>
    </div>
    <div class="sl-result-row">
        <span class="sl-result-label">Main Places</span>
        <span class="sl-result-value"><span class="sl-tag sl-tag-amber">{{ $mainPlaces->count() }}</span></span>
    </div>
</div>

@if($mainPlaces->count())
<div class="sl-card sl-animate d3" style="margin-top:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-map-marker-alt"></i> Main Places / Cities & Towns ({{ $mainPlaces->count() }})</div>
        <div style="font-size:13px; color:var(--text-muted);">Click a name to view suburbs, postal codes & wards</div>
    </div>
    <div class="sl-table-wrap">
        <table class="sl-table">
            <thead><tr><th>#</th><th>Name</th><th class="center">Status</th><th class="center">Action</th></tr></thead>
            <tbody>
                @foreach($mainPlaces as $idx => $mp)
                <tr>
                    <td style="color:var(--text-muted);">{{ $idx + 1 }}</td>
                    <td style="font-weight:600;"><a href="{{ route('pmpro.cities.show', $mp->id) }}" style="color:var(--text-primary); text-decoration:none;" onmouseover="this.style.color='var(--accent-cyan)'" onmouseout="this.style.color='var(--text-primary)'">{{ $mp->name }}</a></td>
                    <td class="center">@if($mp->is_active) <span class="sl-status-dot pass"></span> @else <span class="sl-status-dot fail"></span> @endif</td>
                    <td class="center"><a href="{{ route('pmpro.cities.show', $mp->id) }}" class="neon-btn neon-btn-cyan" style="padding:4px 12px; font-size:12px;"><i class="fas fa-arrow-right"></i> Drill Down</a></td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@else
<div class="sl-card sl-animate d3" style="margin-top:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-map-marker-alt"></i> Main Places</div>
    </div>
    <div style="text-align:center; padding:40px; color:var(--text-muted);">
        <i class="fas fa-map-marker-alt" style="font-size:32px; opacity:0.3; margin-bottom:12px; display:block;"></i>
        No main places found for this municipality yet.
    </div>
</div>
@endif
@endsection
