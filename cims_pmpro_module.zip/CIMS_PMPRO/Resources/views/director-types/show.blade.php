@extends('cims_pmpro::layouts.system_settings')

@section('title', 'View Director Type')
@section('page_heading', 'VIEW DIRECTOR TYPE')

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ $directorType->name }}</h1>
        <span class="sl-page-subtitle">Director type details</span>
        <div style="margin-left:auto; display:flex; gap:8px;">
            <a href="{{ route('system-settings.director-types.edit', $directorType->id) }}" class="neon-btn neon-btn-blue"><i class="fas fa-pen"></i> Edit</a>
            <a href="{{ route('system-settings.director-types.index') }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back</a>
        </div>
    </div>
</div>

<div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;" class="sl-animate d2">

    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-user-tie"></i> Director Type Information</div>
            @if($directorType->is_active) <span class="sl-tag sl-tag-green">Active</span>
            @else <span class="sl-tag sl-tag-red">Inactive</span> @endif
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Name</span>
            <span class="sl-result-value" style="font-weight:600;">{{ $directorType->name }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Code</span>
            <span class="sl-result-value"><span class="sl-tag sl-tag-amber" style="font-family:var(--font-mono);">{{ $directorType->code ?? '-' }}</span></span>
        </div>
    </div>

    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-cog"></i> Status & Audit</div>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Active</span>
            <span class="sl-result-value">@if($directorType->is_active) <span class="sl-status-dot pass"></span> Yes @else <span class="sl-status-dot fail"></span> No @endif</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Deleted</span>
            <span class="sl-result-value">@if($directorType->is_deleted) <span style="color:var(--accent-red);">Yes</span> @else No @endif</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Created</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-size:13px;">{{ $directorType->created_at ? $directorType->created_at->format('j M Y H:i') : '-' }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Last Updated</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-size:13px;">{{ $directorType->updated_at ? $directorType->updated_at->format('j M Y H:i') : '-' }}</span>
        </div>
    </div>

</div>

@if($directorType->description)
<div class="sl-card sl-animate d3" style="margin-top:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-align-left"></i> Description</div>
    </div>
    <div style="padding:20px; color:var(--text-secondary); font-size:14px; line-height:1.8;">
        {!! nl2br(e($directorType->description)) !!}
    </div>
</div>
@endif
@endsection
