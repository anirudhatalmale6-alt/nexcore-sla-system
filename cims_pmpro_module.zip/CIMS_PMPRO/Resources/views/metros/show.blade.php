@extends('cims_pmpro::layouts.pmpro')

@section('title', 'View Metro')
@section('page_heading', 'VIEW METROPOLITAN MUNICIPALITY')

@section('content')
<div class="sl-animate d1">
    <div style="margin-bottom:12px; font-size:13px; color:var(--text-muted);">
        <a href="{{ route('pmpro.countries.index') }}" style="color:var(--accent-cyan); text-decoration:none;">Countries</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        <a href="{{ route('pmpro.countries.show', 129) }}" style="color:var(--accent-cyan); text-decoration:none;">South Africa</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        <a href="{{ route('pmpro.provinces.show', $metro->province->id) }}" style="color:var(--accent-cyan); text-decoration:none;">{{ $metro->province->name }}</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        <span style="color:var(--text-primary);">{{ $metro->name }}</span>
    </div>
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ $metro->name }}</h1>
        <span class="sl-page-subtitle">Metropolitan municipality details</span>
        <div style="margin-left:auto; display:flex; gap:8px;">
            <a href="{{ route('pmpro.metros.edit', $metro->id) }}" class="neon-btn neon-btn-blue"><i class="fas fa-pen"></i> Edit</a>
            <a href="{{ route('pmpro.provinces.show', $metro->province->id) }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back to {{ $metro->province->name }}</a>
        </div>
    </div>
</div>

<div class="sl-card sl-animate d2">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-city"></i> Metro Information</div>
        <span class="sl-tag sl-tag-purple">Category A</span>
        @if($metro->is_active) <span class="sl-tag sl-tag-green">Active</span>
        @else <span class="sl-tag sl-tag-red">Inactive</span> @endif
    </div>
    <div class="sl-result-row">
        <span class="sl-result-label">Name</span>
        <span class="sl-result-value" style="font-weight:600;">{{ $metro->name }}</span>
    </div>
    <div class="sl-result-row">
        <span class="sl-result-label">Code</span>
        <span class="sl-result-value"><span class="sl-tag sl-tag-purple">{{ $metro->code }}</span></span>
    </div>
    <div class="sl-result-row">
        <span class="sl-result-label">Province</span>
        <span class="sl-result-value">
            <a href="{{ route('pmpro.provinces.show', $metro->province->id) }}" style="color:var(--accent-cyan); text-decoration:none;">
                <span class="sl-tag sl-tag-green">{{ $metro->province->code ?? '-' }}</span> {{ $metro->province->name ?? '-' }}
            </a>
        </span>
    </div>
    <div class="sl-result-row">
        <span class="sl-result-label">Main Places</span>
        <span class="sl-result-value"><span class="sl-tag sl-tag-amber">{{ $mainPlaces->count() }}</span></span>
    </div>
</div>

@if($metro->description)
<div class="sl-card sl-animate d3" style="margin-top:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-align-left"></i> Description</div>
    </div>
    <div style="padding:20px; color:var(--text-secondary); font-size:14px; line-height:1.8;">
        {!! nl2br(e($metro->description)) !!}
    </div>
</div>
@endif

@if($mainPlaces->count())
<div class="sl-card sl-animate d4" style="margin-top:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-map-marker-alt"></i> Main Places / Cities & Towns ({{ $mainPlaces->count() }})</div>
        <div style="font-size:13px; color:var(--text-muted);">Click a name to view suburbs, postal codes & wards</div>
    </div>
    <div class="sl-table-wrap">
        <table class="sl-table">
            <thead><tr><th>#</th><th>Name</th><th class="center">Status</th><th class="center">Action</th></tr></thead>
            <tbody>
                @foreach($mainPlaces as $idx => $mp)
                <tr>
                    <td style="color:var(--text-muted);">{{ $idx + 1 }}</td>
                    <td style="font-weight:600;"><a href="{{ route('pmpro.cities.show', $mp->id) }}" style="color:var(--text-primary); text-decoration:none;" onmouseover="this.style.color='var(--accent-cyan)'" onmouseout="this.style.color='var(--text-primary)'">{{ $mp->name }}</a></td>
                    <td class="center">@if($mp->is_active) <span class="sl-status-dot pass"></span> @else <span class="sl-status-dot fail"></span> @endif</td>
                    <td class="center"><a href="{{ route('pmpro.cities.show', $mp->id) }}" class="neon-btn neon-btn-cyan" style="padding:4px 12px; font-size:12px;"><i class="fas fa-arrow-right"></i> Drill Down</a></td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endif
@endsection
