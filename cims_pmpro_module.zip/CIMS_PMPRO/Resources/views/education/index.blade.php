@extends('cims_pmpro::layouts.system_settings')

@section('title', 'Education Levels')
@section('page_heading', 'EDUCATION LEVELS')

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">Education Level Registry</h1>
        <span class="sl-page-subtitle">System highest education qualifications</span>
        <div style="margin-left:auto;">
            <a href="{{ route('system-settings.education.create') }}" class="neon-btn neon-btn-green neon-pulse"><i class="fas fa-plus"></i> New Level</a>
        </div>
    </div>
</div>

<div class="sl-stats-grid sl-animate d2">
    <div class="sl-stat-card green">
        <div class="sl-stat-label">Total</div>
        <div class="sl-stat-value" style="color:var(--accent-green);">{{ number_format($stats['total'] ?? 0) }}</div>
        <div class="sl-stat-meta">All levels</div>
    </div>
    <div class="sl-stat-card blue">
        <div class="sl-stat-label">Active</div>
        <div class="sl-stat-value" style="color:var(--accent-blue);">{{ number_format($stats['active'] ?? 0) }}</div>
        <div class="sl-stat-meta">Currently active</div>
    </div>
    <div class="sl-stat-card amber">
        <div class="sl-stat-label">Inactive</div>
        <div class="sl-stat-value" style="color:var(--accent-amber);">{{ number_format($stats['inactive'] ?? 0) }}</div>
        <div class="sl-stat-meta">Disabled</div>
    </div>
</div>

<div class="sl-card sl-animate d3 sl-mb-md">
    <form method="GET" action="{{ route('system-settings.education.index') }}">
        <div style="display:flex; gap:12px; align-items:end; flex-wrap:wrap;">
            <div class="sl-field" style="flex:1; min-width:200px;">
                <label>Search</label>
                <input type="text" name="search" value="{{ request('search') }}" placeholder="Education level or code..." style="width:100%;">
            </div>
            <div style="display:flex; gap:8px;">
                <button type="submit" class="neon-btn neon-btn-cyan" style="padding:9px 18px;"><i class="fas fa-search"></i> Filter</button>
                <a href="{{ route('system-settings.education.index') }}" class="neon-btn neon-btn-ghost" style="padding:9px 18px;"><i class="fas fa-times"></i> Clear</a>
            </div>
        </div>
    </form>
</div>

<div class="sl-card sl-animate d4">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-graduation-cap"></i> Education Levels</div>
        <div style="font-size:13px; color:var(--text-muted);">Showing {{ $educationLevels->firstItem() ?? 0 }}-{{ $educationLevels->lastItem() ?? 0 }} of {{ $educationLevels->total() }}</div>
    </div>
    <div class="sl-table-wrap">
        <table class="sl-table">
            <thead><tr><th>#</th><th>Education Level</th><th>Code</th><th class="center">Order</th><th class="center">Status</th><th class="center">Actions</th></tr></thead>
            <tbody>
                @forelse($educationLevels as $idx => $el)
                <tr>
                    <td style="color:var(--text-muted);">{{ $educationLevels->firstItem() + $idx }}</td>
                    <td style="font-weight:600;"><a href="{{ route('system-settings.education.show', $el->id) }}" style="color:var(--text-primary); text-decoration:none;" onmouseover="this.style.color='var(--accent-cyan)'" onmouseout="this.style.color='var(--text-primary)'">{{ $el->name }}</a></td>
                    <td><span class="sl-tag sl-tag-green" style="font-family:var(--font-mono);">{{ $el->code ?? '-' }}</span></td>
                    <td class="center"><span style="font-family:var(--font-mono); color:var(--text-muted);">{{ $el->sort_order }}</span></td>
                    <td class="center">@if($el->is_active) <span class="sl-status-dot pass"></span> @else <span class="sl-status-dot fail"></span> @endif</td>
                    <td class="center">
                        <div style="display:flex; gap:6px; justify-content:center;">
                            <a href="{{ route('system-settings.education.edit', $el->id) }}" style="color:var(--accent-blue); font-size:15px;" title="Edit"><i class="fas fa-pen"></i></a>
                            <a href="{{ route('system-settings.education.show', $el->id) }}" style="color:var(--accent-green); font-size:15px;" title="View"><i class="fas fa-eye"></i></a>
                            <form method="POST" action="{{ route('system-settings.education.toggle', $el->id) }}" style="display:inline;">@csrf
                                <button type="submit" style="background:none; border:none; color:var(--accent-amber); cursor:pointer; font-size:15px;" title="Toggle"><i class="fas fa-power-off"></i></button>
                            </form>
                            <form method="POST" action="{{ route('system-settings.education.destroy', $el->id) }}" style="display:inline;" onsubmit="return confirm('Delete {{ $el->name }}?')">@csrf @method('DELETE')
                                <button type="submit" style="background:none; border:none; color:var(--accent-red); cursor:pointer; font-size:15px;" title="Delete"><i class="fas fa-trash"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="6" style="text-align:center; padding:40px; color:var(--text-muted);"><i class="fas fa-graduation-cap" style="font-size:32px; opacity:0.3; margin-bottom:12px; display:block;"></i>No education levels found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($educationLevels->hasPages())
    <div style="display:flex; justify-content:center; padding:16px 0 0; gap:4px;">
        @if($educationLevels->onFirstPage()) <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Prev</span>
        @else <a href="{{ $educationLevels->previousPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Prev</a> @endif
        @foreach($educationLevels->getUrlRange(max(1, $educationLevels->currentPage()-2), min($educationLevels->lastPage(), $educationLevels->currentPage()+2)) as $page => $url)
            @if($page == $educationLevels->currentPage()) <span class="sl-btn sl-btn-primary" style="padding:6px 12px; font-size:13px;">{{ $page }}</span>
            @else <a href="{{ $url }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">{{ $page }}</a> @endif
        @endforeach
        @if($educationLevels->hasMorePages()) <a href="{{ $educationLevels->nextPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Next</a>
        @else <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Next</span> @endif
    </div>
    @endif
</div>
@endsection
