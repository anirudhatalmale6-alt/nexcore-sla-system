@extends('cims_pmpro::layouts.system_settings')

@section('title', 'View Bank')
@section('page_heading', 'VIEW BANK')

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ $bank->name }}</h1>
        <span class="sl-page-subtitle">Bank details and banking codes</span>
        <div style="margin-left:auto; display:flex; gap:8px;">
            <a href="{{ route('system-settings.banks.edit', $bank->id) }}" class="neon-btn neon-btn-blue"><i class="fas fa-pen"></i> Edit</a>
            <a href="{{ route('system-settings.banks.index') }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back</a>
        </div>
    </div>
</div>

<div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;" class="sl-animate d2">

    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-landmark"></i> Bank Information</div>
            @if($bank->is_active) <span class="sl-tag sl-tag-green">Active</span>
            @else <span class="sl-tag sl-tag-red">Inactive</span> @endif
        </div>
        <div style="display:flex; align-items:center; gap:16px; padding:16px 20px; border-bottom:1px solid var(--border-subtle);">
            @if($bank->bank_logo)
                <div style="width:56px; height:56px; border-radius:10px; background:rgba(255,255,255,0.08); border:1px solid var(--border-subtle); display:flex; align-items:center; justify-content:center; overflow:hidden; flex-shrink:0;">
                    <img src="{{ asset($bank->bank_logo) }}" alt="{{ $bank->code }}" style="width:100%; height:100%; object-fit:contain; padding:4px;">
                </div>
            @else
                <div style="width:56px; height:56px; border-radius:10px; background:var(--bg-raised); border:1px solid var(--border-subtle); display:flex; align-items:center; justify-content:center; font-size:16px; font-weight:800; color:var(--text-muted); font-family:var(--font-mono); letter-spacing:1px; flex-shrink:0;">{{ substr($bank->code ?? '?', 0, 3) }}</div>
            @endif
            <div>
                <div style="font-weight:700; font-size:18px; color:var(--text-primary);">{{ $bank->name }}</div>
                <div style="margin-top:4px;"><span class="sl-tag sl-tag-amber" style="font-family:var(--font-mono); font-size:14px; font-weight:700;">{{ $bank->code ?? '-' }}</span></div>
            </div>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Name</span>
            <span class="sl-result-value" style="font-weight:600;">{{ $bank->name }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Code</span>
            <span class="sl-result-value"><span class="sl-tag sl-tag-amber" style="font-family:var(--font-mono);">{{ $bank->code ?? '-' }}</span></span>
        </div>
    </div>

    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title" style="color:var(--accent-cyan);"><i class="fas fa-barcode"></i> Banking Codes</div>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Bank Code</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-size:20px; font-weight:700; color:var(--accent-cyan); letter-spacing:2px;">{{ $bank->bank_code ?? '-' }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Universal Branch Code</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-size:20px; font-weight:700; color:var(--accent-green); letter-spacing:2px;">{{ $bank->branch_code ?? '-' }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">SWIFT / BIC Code</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-size:20px; font-weight:700; color:var(--accent-blue); letter-spacing:2px;">{{ $bank->swift_code ?? '-' }}</span>
        </div>
        <div style="padding:12px 20px; background:var(--bg-raised); border-top:1px solid var(--border-subtle); font-size:12px; color:var(--text-muted); line-height:1.6;">
            <i class="fas fa-info-circle" style="color:var(--accent-cyan); margin-right:4px;"></i>
            Banking codes used for South African EFT and international transfers. UBC is the 6-digit Universal Branch Code for electronic payments.
        </div>
    </div>

</div>

<div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-top:20px;" class="sl-animate d3">

    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-cog"></i> Status & Audit</div>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Active</span>
            <span class="sl-result-value">@if($bank->is_active) <span class="sl-status-dot pass"></span> Yes @else <span class="sl-status-dot fail"></span> No @endif</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Deleted</span>
            <span class="sl-result-value">@if($bank->is_deleted) <span style="color:var(--accent-red);">Yes</span> @else No @endif</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Created</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-size:13px;">{{ $bank->created_at ? $bank->created_at->format('j M Y H:i') : '-' }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Last Updated</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-size:13px;">{{ $bank->updated_at ? $bank->updated_at->format('j M Y H:i') : '-' }}</span>
        </div>
    </div>

    @if($bank->description)
    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-align-left"></i> Description</div>
        </div>
        <div style="padding:20px; color:var(--text-secondary); font-size:14px; line-height:1.8;">
            {!! nl2br(e($bank->description)) !!}
        </div>
    </div>
    @endif

</div>
@endsection