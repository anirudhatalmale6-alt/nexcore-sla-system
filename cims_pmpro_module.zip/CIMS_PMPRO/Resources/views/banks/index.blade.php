@extends('cims_pmpro::layouts.system_settings')

@section('title', 'Banks')
@section('page_heading', 'BANKS')

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">South African Bank Registry</h1>
        <span class="sl-page-subtitle">Registered banks with Universal Branch Codes and SWIFT codes</span>
        <div style="margin-left:auto;">
            <a href="{{ route('system-settings.banks.create') }}" class="neon-btn neon-btn-green neon-pulse"><i class="fas fa-plus"></i> New Bank</a>
        </div>
    </div>
</div>

<div class="sl-stats-grid sl-animate d2">
    <div class="sl-stat-card green">
        <div class="sl-stat-label">Total</div>
        <div class="sl-stat-value" style="color:var(--accent-green);">{{ number_format($stats['total'] ?? 0) }}</div>
        <div class="sl-stat-meta">All banks</div>
    </div>
    <div class="sl-stat-card blue">
        <div class="sl-stat-label">Active</div>
        <div class="sl-stat-value" style="color:var(--accent-blue);">{{ number_format($stats['active'] ?? 0) }}</div>
        <div class="sl-stat-meta">Currently active</div>
    </div>
    <div class="sl-stat-card amber">
        <div class="sl-stat-label">Inactive</div>
        <div class="sl-stat-value" style="color:var(--accent-amber);">{{ number_format($stats['inactive'] ?? 0) }}</div>
        <div class="sl-stat-meta">Disabled</div>
    </div>
</div>

<div class="sl-card sl-animate d3 sl-mb-md">
    <form method="GET" action="{{ route('system-settings.banks.index') }}">
        <div style="display:flex; gap:12px; align-items:end; flex-wrap:wrap;">
            <div class="sl-field" style="flex:1; min-width:200px;">
                <label>Search</label>
                <input type="text" name="search" value="{{ request('search') }}" placeholder="Bank name, code, branch code or SWIFT..." style="width:100%;">
            </div>
            <div style="display:flex; gap:8px;">
                <button type="submit" class="neon-btn neon-btn-cyan" style="padding:9px 18px;"><i class="fas fa-search"></i> Filter</button>
                <a href="{{ route('system-settings.banks.index') }}" class="neon-btn neon-btn-ghost" style="padding:9px 18px;"><i class="fas fa-times"></i> Clear</a>
            </div>
        </div>
    </form>
</div>

<div class="sl-card sl-animate d4">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-landmark"></i> Banks</div>
        <div style="font-size:13px; color:var(--text-muted);">Showing {{ $banks->firstItem() ?? 0 }}-{{ $banks->lastItem() ?? 0 }} of {{ $banks->total() }}</div>
    </div>
    <div class="sl-table-wrap">
        <table class="sl-table">
            <thead><tr><th style="width:40px;">#</th><th style="width:44px;"></th><th>Bank</th><th>Code</th><th>Bank Code</th><th>Branch (UBC)</th><th>SWIFT</th><th class="center">Status</th><th class="center">Actions</th></tr></thead>
            <tbody>
                @forelse($banks as $idx => $item)
                <tr>
                    <td style="color:var(--text-muted);">{{ $banks->firstItem() + $idx }}</td>
                    <td>
                        @if($item->bank_logo)
                            <img src="{{ asset($item->bank_logo) }}" alt="{{ $item->code }}" style="width:32px; height:32px; object-fit:contain; border-radius:6px; background:rgba(255,255,255,0.08); padding:2px;">
                        @else
                            <div style="width:32px; height:32px; border-radius:6px; background:var(--bg-raised); display:flex; align-items:center; justify-content:center; font-size:10px; font-weight:700; color:var(--text-muted);">{{ substr($item->code ?? '?', 0, 3) }}</div>
                        @endif
                    </td>
                    <td style="font-weight:600;"><a href="{{ route('system-settings.banks.show', $item->id) }}" style="color:var(--text-primary); text-decoration:none;" onmouseover="this.style.color='var(--accent-cyan)'" onmouseout="this.style.color='var(--text-primary)'">{{ $item->name }}</a></td>
                    <td><span class="sl-tag sl-tag-amber" style="font-family:var(--font-mono);">{{ $item->code ?? '-' }}</span></td>
                    <td><span style="font-family:var(--font-mono); font-weight:600; color:var(--accent-cyan);">{{ $item->bank_code ?? '-' }}</span></td>
                    <td><span style="font-family:var(--font-mono); font-weight:600; color:var(--accent-green);">{{ $item->branch_code ?? '-' }}</span></td>
                    <td><span style="font-family:var(--font-mono); font-size:12px; color:var(--accent-blue);">{{ $item->swift_code ?? '-' }}</span></td>
                    <td class="center">@if($item->is_active) <span class="sl-status-dot pass"></span> @else <span class="sl-status-dot fail"></span> @endif</td>
                    <td class="center">
                        <div style="display:flex; gap:6px; justify-content:center;">
                            <a href="{{ route('system-settings.banks.edit', $item->id) }}" style="color:var(--accent-blue); font-size:15px;" title="Edit"><i class="fas fa-pen"></i></a>
                            <a href="{{ route('system-settings.banks.show', $item->id) }}" style="color:var(--accent-green); font-size:15px;" title="View"><i class="fas fa-eye"></i></a>
                            <form method="POST" action="{{ route('system-settings.banks.toggle', $item->id) }}" style="display:inline;">@csrf
                                <button type="submit" style="background:none; border:none; color:var(--accent-amber); cursor:pointer; font-size:15px;" title="Toggle"><i class="fas fa-power-off"></i></button>
                            </form>
                            <form method="POST" action="{{ route('system-settings.banks.destroy', $item->id) }}" style="display:inline;" onsubmit="return confirm('Delete {{ $item->name }}?')">@csrf @method('DELETE')
                                <button type="submit" style="background:none; border:none; color:var(--accent-red); cursor:pointer; font-size:15px;" title="Delete"><i class="fas fa-trash"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="9" style="text-align:center; padding:40px; color:var(--text-muted);"><i class="fas fa-landmark" style="font-size:32px; opacity:0.3; margin-bottom:12px; display:block;"></i>No banks found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($banks->hasPages())
    <div style="display:flex; justify-content:center; padding:16px 0 0; gap:4px;">
        @if($banks->onFirstPage()) <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Prev</span>
        @else <a href="{{ $banks->previousPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Prev</a> @endif
        @foreach($banks->getUrlRange(max(1, $banks->currentPage()-2), min($banks->lastPage(), $banks->currentPage()+2)) as $page => $url)
            @if($page == $banks->currentPage()) <span class="sl-btn sl-btn-primary" style="padding:6px 12px; font-size:13px;">{{ $page }}</span>
            @else <a href="{{ $url }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">{{ $page }}</a> @endif
        @endforeach
        @if($banks->hasMorePages()) <a href="{{ $banks->nextPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Next</a>
        @else <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Next</span> @endif
    </div>
    @endif
</div>
@endsection
