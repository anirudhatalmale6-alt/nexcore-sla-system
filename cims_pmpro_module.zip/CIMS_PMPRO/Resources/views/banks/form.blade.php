@extends('cims_pmpro::layouts.system_settings')

@section('title', isset($bank) ? 'Edit Bank' : 'New Bank')
@section('page_heading', isset($bank) ? 'EDIT BANK' : 'NEW BANK')

@push('styles')
<style>
.sl-form-section { background:var(--bg-surface); border:1px solid var(--border-subtle); border-radius:var(--radius-lg); padding:24px; margin-bottom:20px; box-shadow:var(--shadow-card); }
.sl-form-section-title { font-size:15px; font-weight:700; letter-spacing:2px; text-transform:uppercase; color:var(--accent-green); margin-bottom:20px; padding-bottom:10px; border-bottom:1px solid var(--border-subtle); display:flex; align-items:center; gap:10px; }
.sl-form-section-title i { font-size:16px; }
.sl-form-section-title.cyan { color:var(--accent-cyan); }
.sl-form-grid { display:grid; gap:16px; }
.sl-form-grid.cols-2 { grid-template-columns:1fr 1fr; }
.sl-form-grid.cols-3 { grid-template-columns:1fr 1fr 1fr; }
.sl-field label .required { color:var(--accent-red); margin-left:2px; }
.sl-field select { background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:9px 12px; color:var(--text-primary); font-size:15px; font-family:var(--font-mono); width:100%; outline:none; appearance:none; -webkit-appearance:none; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%235a6478' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 12px center; padding-right:32px; }
.sl-field select:focus { border-color:var(--accent-green); box-shadow:0 0 0 2px rgba(34,197,94,0.15); }
.sl-field input { width:100%; }
.sl-field textarea { width:100%; background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:12px; color:var(--text-primary); font-size:14px; font-family:var(--font-body); line-height:1.6; resize:vertical; outline:none; }
.sl-field textarea:focus { border-color:var(--accent-green); box-shadow:0 0 0 2px rgba(34,197,94,0.15); }
.sl-field-hint { font-size:12px; color:var(--text-muted); margin-top:4px; }
.sl-bank-logo-preview { width:64px; height:64px; border-radius:10px; background:rgba(255,255,255,0.06); border:1px solid var(--border-subtle); display:flex; align-items:center; justify-content:center; overflow:hidden; }
.sl-bank-logo-preview img { width:100%; height:100%; object-fit:contain; padding:4px; }
.sl-bank-logo-preview .initials { font-size:18px; font-weight:800; color:var(--text-muted); font-family:var(--font-mono); letter-spacing:1px; }
@media (max-width:768px) { .sl-form-grid.cols-2, .sl-form-grid.cols-3 { grid-template-columns:1fr; } }
</style>
@endpush

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ isset($bank) ? 'Edit '.$bank->name : 'Create New Bank' }}</h1>
        <span class="sl-page-subtitle">{{ isset($bank) ? 'Update bank details and banking codes' : 'Add a new bank with banking codes to the system' }}</span>
        <div style="margin-left:auto;">
            <a href="{{ route('system-settings.banks.index') }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back to List</a>
        </div>
    </div>
</div>

<form method="POST" action="{{ isset($bank) ? route('system-settings.banks.update', $bank->id) : route('system-settings.banks.store') }}" class="sl-animate d2" enctype="multipart/form-data">
    @csrf
    @if(isset($bank)) @method('PUT') @endif

    @if($errors->any())
    <div class="sl-verdict reject sl-mb-md" style="padding:14px 20px;">
        <div class="sl-verdict-icon" style="width:32px;height:32px;font-size:16px;"><i class="fas fa-exclamation-triangle"></i></div>
        <div>@foreach($errors->all() as $error)<div class="sl-verdict-text" style="font-size:14px;">{{ $error }}</div>@endforeach</div>
    </div>
    @endif

    <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">

        <div class="sl-form-section" style="margin-bottom:0;">
            <div class="sl-form-section-title"><i class="fas fa-landmark"></i> Bank Details</div>

            <div style="margin-bottom:20px;">
                <label style="display:block; font-size:13px; font-weight:600; color:var(--text-secondary); margin-bottom:8px;"><i class="fas fa-image" style="margin-right:6px; color:var(--accent-green);"></i> Bank Logo</label>
                @if(isset($bank) && $bank->bank_logo)
                <div style="display:flex; align-items:center; gap:16px; margin-bottom:12px; padding:14px; background:var(--bg-raised); border-radius:var(--radius-sm); border:1px solid var(--border-subtle);">
                    <div class="sl-bank-logo-preview">
                        <img src="{{ asset($bank->bank_logo) }}" alt="{{ $bank->code }}">
                    </div>
                    <div style="flex:1;">
                        <div style="font-weight:600; font-size:15px;">{{ $bank->name }}</div>
                        <div style="font-size:12px; color:var(--text-muted); margin-top:2px;">Current logo</div>
                    </div>
                    <label style="display:flex; align-items:center; gap:6px; cursor:pointer; font-size:13px; color:var(--accent-red); padding:6px 12px; border:1px solid rgba(239,68,68,0.3); border-radius:var(--radius-sm); background:rgba(239,68,68,0.06);">
                        <input type="checkbox" name="remove_logo" value="1" style="accent-color:var(--accent-red);"> Remove
                    </label>
                </div>
                @endif
                <div style="position:relative;">
                    <input type="file" name="bank_logo" id="bankLogoInput" accept="image/png,image/jpeg,image/svg+xml,image/webp" style="display:none;" onchange="previewLogo(this)">
                    <label for="bankLogoInput" style="display:flex; align-items:center; justify-content:center; gap:10px; padding:16px; border:2px dashed var(--border-default); border-radius:var(--radius-sm); cursor:pointer; color:var(--text-muted); font-size:13px; transition:all 0.2s;" onmouseover="this.style.borderColor='var(--accent-green)';this.style.color='var(--accent-green)'" onmouseout="this.style.borderColor='var(--border-default)';this.style.color='var(--text-muted)'">
                        <i class="fas fa-cloud-upload-alt" style="font-size:18px;"></i>
                        <span id="logoFileName">Click to upload logo (PNG, JPG, SVG, WEBP - max 2MB)</span>
                    </label>
                    <div id="logoPreviewWrap" style="display:none; margin-top:10px; padding:10px; background:var(--bg-raised); border-radius:var(--radius-sm); border:1px solid var(--border-subtle);">
                        <img id="logoPreviewImg" src="" alt="Preview" style="max-width:80px; max-height:80px; object-fit:contain; border-radius:8px;">
                        <span style="margin-left:12px; font-size:13px; color:var(--accent-green);"><i class="fas fa-check-circle"></i> New logo selected</span>
                    </div>
                </div>
                <div class="sl-field-hint">Square logos work best (e.g. 200x200px). Will be displayed at 32-56px.</div>
            </div>

            <div class="sl-form-grid cols-2">
                <div class="sl-field">
                    <label>Name <span class="required">*</span></label>
                    <input type="text" name="name" value="{{ old('name', $bank->name ?? '') }}" placeholder="e.g. First National Bank" required>
                </div>
                <div class="sl-field">
                    <label>Code</label>
                    <input type="text" name="code" value="{{ old('code', $bank->code ?? '') }}" placeholder="e.g. FNB" maxlength="20" style="text-transform:uppercase; font-family:var(--font-mono); font-size:16px; font-weight:700; color:var(--accent-amber);">
                    <div class="sl-field-hint">Short identifier (e.g. ABSA, FNB, STD, NED, CAP)</div>
                </div>
            </div>
            @if(isset($bank))
            <div class="sl-form-grid cols-2" style="margin-top:16px;">
                <div class="sl-field">
                    <label>Status</label>
                    <select name="is_active">
                        <option value="1" {{ old('is_active', $bank->is_active) ? 'selected' : '' }}>Active</option>
                        <option value="0" {{ old('is_active', $bank->is_active) ? '' : 'selected' }}>Inactive</option>
                    </select>
                </div>
                <div class="sl-field">
                    <label>Deleted</label>
                    <select name="is_deleted">
                        <option value="0" {{ old('is_deleted', $bank->is_deleted) ? '' : 'selected' }}>No</option>
                        <option value="1" {{ old('is_deleted', $bank->is_deleted) ? 'selected' : '' }}>Yes</option>
                    </select>
                </div>
            </div>
            @endif
        </div>

        <div class="sl-form-section" style="margin-bottom:0;">
            <div class="sl-form-section-title cyan"><i class="fas fa-barcode"></i> Banking Codes</div>
            <div class="sl-form-grid" style="gap:20px;">
                <div class="sl-field">
                    <label>Bank Code</label>
                    <input type="text" name="bank_code" value="{{ old('bank_code', $bank->bank_code ?? '') }}" placeholder="e.g. 250655" maxlength="10" style="font-family:var(--font-mono); font-size:18px; font-weight:700; color:var(--accent-cyan); letter-spacing:2px;">
                    <div class="sl-field-hint">Numeric bank identifier assigned by SARB</div>
                </div>
                <div class="sl-field">
                    <label>Universal Branch Code (UBC)</label>
                    <input type="text" name="branch_code" value="{{ old('branch_code', $bank->branch_code ?? '') }}" placeholder="e.g. 250655" maxlength="10" style="font-family:var(--font-mono); font-size:18px; font-weight:700; color:var(--accent-green); letter-spacing:2px;">
                    <div class="sl-field-hint">6-digit Universal Branch Code for electronic payments</div>
                </div>
                <div class="sl-field">
                    <label>SWIFT / BIC Code</label>
                    <input type="text" name="swift_code" value="{{ old('swift_code', $bank->swift_code ?? '') }}" placeholder="e.g. FIRNZAJJ" maxlength="15" style="font-family:var(--font-mono); font-size:18px; font-weight:700; color:var(--accent-blue); letter-spacing:2px; text-transform:uppercase;">
                    <div class="sl-field-hint">SWIFT/BIC code for international transfers (8 or 11 chars)</div>
                </div>
            </div>
        </div>

    </div>

    <div class="sl-form-section" style="margin-top:20px;">
        <div class="sl-form-section-title"><i class="fas fa-align-left"></i> Description</div>
        <div class="sl-field">
            <label>Description</label>
            <textarea name="description" rows="4" placeholder="Brief description of the bank...">{{ old('description', $bank->description ?? '') }}</textarea>
        </div>
    </div>

    <div style="display:flex; gap:12px; justify-content:flex-end;">
        <a href="{{ route('system-settings.banks.index') }}" class="neon-btn neon-btn-red"><i class="fas fa-times"></i> Cancel</a>
        <button type="submit" class="neon-btn neon-btn-green neon-pulse"><i class="fas fa-check"></i> {{ isset($bank) ? 'Update' : 'Save' }}</button>
    </div>
</form>

<script>
function previewLogo(input) {
    var wrap = document.getElementById('logoPreviewWrap');
    var img = document.getElementById('logoPreviewImg');
    var label = document.getElementById('logoFileName');
    if (input.files && input.files[0]) {
        var file = input.files[0];
        if (file.size > 2 * 1024 * 1024) {
            alert('File too large. Maximum 2MB allowed.');
            input.value = '';
            wrap.style.display = 'none';
            label.textContent = 'Click to upload logo (PNG, JPG, SVG, WEBP - max 2MB)';
            return;
        }
        var reader = new FileReader();
        reader.onload = function(e) {
            img.src = e.target.result;
            wrap.style.display = 'flex';
            wrap.style.alignItems = 'center';
        };
        reader.readAsDataURL(file);
        label.textContent = file.name;
    } else {
        wrap.style.display = 'none';
        label.textContent = 'Click to upload logo (PNG, JPG, SVG, WEBP - max 2MB)';
    }
}
</script>
@endsection