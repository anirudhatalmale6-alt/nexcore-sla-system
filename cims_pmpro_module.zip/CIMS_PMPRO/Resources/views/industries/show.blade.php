@extends('cims_pmpro::layouts.system_settings')

@section('title', 'View Industry')
@section('page_heading', 'VIEW INDUSTRY')

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ $industry->name }}</h1>
        <span class="sl-page-subtitle">Industry details{{ $industry->sicCode ? ' — SIC '.$industry->sicCode->sic_code : '' }}</span>
        <div style="margin-left:auto; display:flex; gap:8px;">
            <a href="{{ route('system-settings.industries.edit', $industry->id) }}" class="neon-btn neon-btn-blue"><i class="fas fa-pen"></i> Edit</a>
            <a href="{{ route('system-settings.industries.index') }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back</a>
        </div>
    </div>
</div>

<div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;" class="sl-animate d2">

    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-industry"></i> Industry Information</div>
            @if($industry->is_active) <span class="sl-tag sl-tag-green">Active</span>
            @else <span class="sl-tag sl-tag-red">Inactive</span> @endif
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Name</span>
            <span class="sl-result-value" style="font-weight:600;">{{ $industry->name }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Code</span>
            <span class="sl-result-value"><span class="sl-tag sl-tag-amber" style="font-family:var(--font-mono);">{{ $industry->code ?? '-' }}</span></span>
        </div>
    </div>

    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-cog"></i> Status & Audit</div>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Active</span>
            <span class="sl-result-value">@if($industry->is_active) <span class="sl-status-dot pass"></span> Yes @else <span class="sl-status-dot fail"></span> No @endif</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Deleted</span>
            <span class="sl-result-value">@if($industry->is_deleted) <span style="color:var(--accent-red);">Yes</span> @else No @endif</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Created</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-size:13px;">{{ $industry->created_at ? $industry->created_at->format('j M Y H:i') : '-' }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Last Updated</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-size:13px;">{{ $industry->updated_at ? $industry->updated_at->format('j M Y H:i') : '-' }}</span>
        </div>
    </div>

</div>

@if($industry->sicCode)
<div class="sl-card sl-animate d3" style="margin-top:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-file-invoice"></i> SARS SIC Classification</div>
        <span class="sl-tag sl-tag-cyan" style="font-family:var(--font-mono); font-size:14px;">{{ $industry->sicCode->sic_code }}</span>
    </div>
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:0;">
        <div class="sl-result-row">
            <span class="sl-result-label">SIC Code</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-weight:700; color:var(--accent-cyan); font-size:18px;">{{ $industry->sicCode->sic_code }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Section</span>
            <span class="sl-result-value"><span class="sl-tag sl-tag-blue">{{ $industry->sicCode->section_code }} - {{ $industry->sicCode->section_name }}</span></span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Profit Code</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-weight:700; color:var(--accent-green); font-size:18px;">{{ $industry->sicCode->profit_code ?? '-' }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Loss Code</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-weight:700; color:var(--accent-red); font-size:18px;">{{ $industry->sicCode->loss_code ?? '-' }}</span>
        </div>
        <div class="sl-result-row" style="grid-column:1/-1;">
            <span class="sl-result-label">Description</span>
            <span class="sl-result-value" style="font-weight:600;">{{ $industry->sicCode->description }}</span>
        </div>
    </div>
</div>
@endif

@if($industry->description)
<div class="sl-card sl-animate d4" style="margin-top:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-align-left"></i> Description</div>
    </div>
    <div style="padding:20px; color:var(--text-secondary); font-size:14px; line-height:1.8;">
        {!! nl2br(e($industry->description)) !!}
    </div>
</div>
@endif
@endsection
