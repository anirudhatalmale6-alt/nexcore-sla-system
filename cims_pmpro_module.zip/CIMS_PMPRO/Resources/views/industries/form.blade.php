@extends('cims_pmpro::layouts.system_settings')

@section('title', isset($industry) ? 'Edit Industry' : 'New Industry')
@section('page_heading', isset($industry) ? 'EDIT INDUSTRY' : 'NEW INDUSTRY')

@push('styles')
<style>
.sl-form-section { background:var(--bg-surface); border:1px solid var(--border-subtle); border-radius:var(--radius-lg); padding:24px; margin-bottom:20px; box-shadow:var(--shadow-card); }
.sl-form-section-title { font-size:15px; font-weight:700; letter-spacing:2px; text-transform:uppercase; color:var(--accent-green); margin-bottom:20px; padding-bottom:10px; border-bottom:1px solid var(--border-subtle); display:flex; align-items:center; gap:10px; }
.sl-form-section-title i { font-size:16px; }
.sl-form-grid { display:grid; gap:16px; }
.sl-form-grid.cols-2 { grid-template-columns:1fr 1fr; }
.sl-field label .required { color:var(--accent-red); margin-left:2px; }
.sl-field select { background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:9px 12px; color:var(--text-primary); font-size:15px; font-family:var(--font-mono); width:100%; outline:none; appearance:none; -webkit-appearance:none; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%235a6478' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 12px center; padding-right:32px; }
.sl-field select:focus { border-color:var(--accent-green); box-shadow:0 0 0 2px rgba(34,197,94,0.15); }
.sl-field input { width:100%; }
.sl-field textarea { width:100%; background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:12px; color:var(--text-primary); font-size:14px; font-family:var(--font-body); line-height:1.6; resize:vertical; outline:none; }
.sl-field textarea:focus { border-color:var(--accent-green); box-shadow:0 0 0 2px rgba(34,197,94,0.15); }
.sic-preview { background:var(--bg-raised); border:1px solid var(--border-subtle); border-radius:var(--radius-sm); padding:14px 18px; margin-top:12px; display:none; }
.sic-preview .sic-row { display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid var(--border-subtle); font-size:13px; }
.sic-preview .sic-row:last-child { border-bottom:none; }
.sic-preview .sic-label { color:var(--text-muted); font-weight:600; letter-spacing:0.5px; }
.sic-preview .sic-val { color:var(--accent-cyan); font-family:var(--font-mono); }
@media (max-width:768px) { .sl-form-grid.cols-2 { grid-template-columns:1fr; } }
</style>
@endpush

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ isset($industry) ? 'Edit '.$industry->name : 'Create New Industry' }}</h1>
        <span class="sl-page-subtitle">{{ isset($industry) ? 'Update industry details' : 'Add a new industry to the system' }}</span>
        <div style="margin-left:auto;">
            <a href="{{ route('system-settings.industries.index') }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back to List</a>
        </div>
    </div>
</div>

<form method="POST" action="{{ isset($industry) ? route('system-settings.industries.update', $industry->id) : route('system-settings.industries.store') }}" class="sl-animate d2">
    @csrf
    @if(isset($industry)) @method('PUT') @endif

    @if($errors->any())
    <div class="sl-verdict reject sl-mb-md" style="padding:14px 20px;">
        <div class="sl-verdict-icon" style="width:32px;height:32px;font-size:16px;"><i class="fas fa-exclamation-triangle"></i></div>
        <div>@foreach($errors->all() as $error)<div class="sl-verdict-text" style="font-size:14px;">{{ $error }}</div>@endforeach</div>
    </div>
    @endif

    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-industry"></i> Industry Details</div>
        <div class="sl-form-grid cols-2">
            <div class="sl-field">
                <label>Name <span class="required">*</span></label>
                <input type="text" name="name" value="{{ old('name', $industry->name ?? '') }}" placeholder="e.g. Financial Services" required>
            </div>
            <div class="sl-field">
                <label>Code</label>
                <input type="text" name="code" value="{{ old('code', $industry->code ?? '') }}" placeholder="e.g. FIN" maxlength="20" style="text-transform:uppercase;">
            </div>
        </div>
        @if(isset($industry))
        <div class="sl-form-grid cols-2" style="margin-top:16px;">
            <div class="sl-field">
                <label>Status</label>
                <select name="is_active">
                    <option value="1" {{ old('is_active', $industry->is_active) ? 'selected' : '' }}>Active</option>
                    <option value="0" {{ old('is_active', $industry->is_active) ? '' : 'selected' }}>Inactive</option>
                </select>
            </div>
            <div class="sl-field">
                <label>Deleted</label>
                <select name="is_deleted">
                    <option value="0" {{ old('is_deleted', $industry->is_deleted) ? '' : 'selected' }}>No</option>
                    <option value="1" {{ old('is_deleted', $industry->is_deleted) ? 'selected' : '' }}>Yes</option>
                </select>
            </div>
        </div>
        @endif
    </div>

    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-file-invoice"></i> SARS SIC Classification</div>
        <div class="sl-field">
            <label>SIC Code</label>
            <select name="sic_code_id" id="sicSelect">
                <option value="">-- Select SIC Code --</option>
                @php $currentGroup = ''; @endphp
                @foreach($sicCodes as $sic)
                    @if($sic->section_name !== $currentGroup)
                        @if($currentGroup !== '') </optgroup> @endif
                        <optgroup label="{{ $sic->section_code }} - {{ $sic->section_name }}">
                        @php $currentGroup = $sic->section_name; @endphp
                    @endif
                    <option value="{{ $sic->id }}"
                        data-desc="{{ $sic->description }}"
                        data-section="{{ $sic->section_code }} - {{ $sic->section_name }}"
                        data-code="{{ $sic->sic_code }}"
                        data-profit="{{ $sic->profit_code }}"
                        data-loss="{{ $sic->loss_code }}"
                        {{ old('sic_code_id', $industry->sic_code_id ?? '') == $sic->id ? 'selected' : '' }}>
                        {{ $sic->sic_code }} - {{ $sic->description }}
                    </option>
                @endforeach
                @if($currentGroup !== '') </optgroup> @endif
            </select>
        </div>
        <div class="sic-preview" id="sicPreview">
            <div class="sic-row"><span class="sic-label">SIC Code</span><span class="sic-val" id="sicCode" style="color:var(--accent-cyan); font-size:16px; font-weight:700;">-</span></div>
            <div class="sic-row"><span class="sic-label">Description</span><span class="sic-val" id="sicDesc">-</span></div>
            <div class="sic-row"><span class="sic-label">Section</span><span class="sic-val" id="sicSection" style="color:var(--accent-blue);">-</span></div>
            <div class="sic-row"><span class="sic-label">Profit Code</span><span class="sic-val" id="sicProfit" style="color:var(--accent-green); font-weight:700;">-</span></div>
            <div class="sic-row"><span class="sic-label">Loss Code</span><span class="sic-val" id="sicLoss" style="color:var(--accent-red); font-weight:700;">-</span></div>
        </div>
    </div>

    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-align-left"></i> Description</div>
        <div class="sl-field">
            <label>Description</label>
            <textarea name="description" rows="4" placeholder="Enter a description...">{{ old('description', $industry->description ?? '') }}</textarea>
        </div>
    </div>

    <div style="display:flex; gap:12px; justify-content:flex-end;">
        <a href="{{ route('system-settings.industries.index') }}" class="neon-btn neon-btn-red"><i class="fas fa-times"></i> Cancel</a>
        <button type="submit" class="neon-btn neon-btn-green neon-pulse"><i class="fas fa-check"></i> {{ isset($industry) ? 'Update' : 'Save' }}</button>
    </div>
</form>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    var sel = document.getElementById('sicSelect');
    var preview = document.getElementById('sicPreview');
    function updatePreview() {
        var opt = sel.options[sel.selectedIndex];
        if (sel.value && opt) {
            document.getElementById('sicCode').textContent = opt.getAttribute('data-code') || '-';
            document.getElementById('sicDesc').textContent = opt.getAttribute('data-desc') || '-';
            document.getElementById('sicSection').textContent = opt.getAttribute('data-section') || '-';
            document.getElementById('sicProfit').textContent = opt.getAttribute('data-profit') || '-';
            document.getElementById('sicLoss').textContent = opt.getAttribute('data-loss') || '-';
            preview.style.display = 'block';
        } else {
            preview.style.display = 'none';
        }
    }
    sel.addEventListener('change', updatePreview);
    updatePreview();
});
</script>
@endpush
