@extends('cims_pmpro::layouts.pmpro')

@section('title', 'View District')
@section('page_heading', 'VIEW DISTRICT MUNICIPALITY')

@section('content')
<div class="sl-animate d1">
    <div style="margin-bottom:12px; font-size:13px; color:var(--text-muted);">
        <a href="{{ route('pmpro.countries.index') }}" style="color:var(--accent-cyan); text-decoration:none;">Countries</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        <a href="{{ route('pmpro.countries.show', 129) }}" style="color:var(--accent-cyan); text-decoration:none;">South Africa</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        <a href="{{ route('pmpro.provinces.show', $district->province->id) }}" style="color:var(--accent-cyan); text-decoration:none;">{{ $district->province->name }}</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        <span style="color:var(--text-primary);">{{ $district->name }}</span>
    </div>
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ $district->name }}</h1>
        <span class="sl-page-subtitle">District municipality details</span>
        <div style="margin-left:auto; display:flex; gap:8px;">
            <a href="{{ route('pmpro.districts.edit', $district->id) }}" class="neon-btn neon-btn-blue"><i class="fas fa-pen"></i> Edit</a>
            <a href="{{ route('pmpro.provinces.show', $district->province->id) }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back to {{ $district->province->name }}</a>
        </div>
    </div>
</div>

<div class="sl-card sl-animate d2">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-building"></i> District Information</div>
        <span class="sl-tag sl-tag-blue">Category C</span>
        @if($district->is_active) <span class="sl-tag sl-tag-green">Active</span>
        @else <span class="sl-tag sl-tag-red">Inactive</span> @endif
    </div>
    <div class="sl-result-row">
        <span class="sl-result-label">Name</span>
        <span class="sl-result-value" style="font-weight:600;">{{ $district->name }}</span>
    </div>
    <div class="sl-result-row">
        <span class="sl-result-label">Code</span>
        <span class="sl-result-value"><span class="sl-tag sl-tag-cyan">{{ $district->code }}</span></span>
    </div>
    <div class="sl-result-row">
        <span class="sl-result-label">Province</span>
        <span class="sl-result-value">
            <a href="{{ route('pmpro.provinces.show', $district->province->id) }}" style="color:var(--accent-cyan); text-decoration:none;">
                <span class="sl-tag sl-tag-green">{{ $district->province->code ?? '-' }}</span> {{ $district->province->name ?? '-' }}
            </a>
        </span>
    </div>
    <div class="sl-result-row">
        <span class="sl-result-label">Local Municipalities</span>
        <span class="sl-result-value"><span class="sl-tag sl-tag-blue">{{ $localMunicipalities->count() }}</span></span>
    </div>
</div>

@if($localMunicipalities->count())
<div class="sl-card sl-animate d3" style="margin-top:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-map-signs"></i> Local Municipalities ({{ $localMunicipalities->count() }})</div>
        <span class="sl-tag sl-tag-green">Category B</span>
    </div>
    <div class="sl-table-wrap">
        <table class="sl-table">
            <thead><tr><th>Name</th><th>Code</th><th class="center">Status</th><th class="center">Action</th></tr></thead>
            <tbody>
                @foreach($localMunicipalities as $lm)
                <tr style="cursor:pointer;" onclick="window.location='{{ route('pmpro.local-municipalities.show', $lm->id) }}'">
                    <td style="font-weight:600;">{{ $lm->name }}</td>
                    <td><span class="sl-tag sl-tag-blue">{{ $lm->code ?? '-' }}</span></td>
                    <td class="center">@if($lm->is_active) <span class="sl-status-dot pass"></span> @else <span class="sl-status-dot fail"></span> @endif</td>
                    <td class="center">
                        <a href="{{ route('pmpro.local-municipalities.show', $lm->id) }}" class="neon-btn neon-btn-cyan" style="padding:6px 14px; font-size:11px;">
                            <i class="fas fa-arrow-right"></i> Drill Down
                        </a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endif
@endsection
