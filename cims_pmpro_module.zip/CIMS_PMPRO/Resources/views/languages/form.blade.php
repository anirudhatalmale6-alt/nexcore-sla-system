@extends('cims_pmpro::layouts.system_settings')

@section('title', isset($language) ? 'Edit Language' : 'New Language')
@section('page_heading', isset($language) ? 'EDIT LANGUAGE' : 'NEW LANGUAGE')

@push('styles')
<style>
.sl-form-section { background:var(--bg-surface); border:1px solid var(--border-subtle); border-radius:var(--radius-lg); padding:24px; margin-bottom:20px; box-shadow:var(--shadow-card); }
.sl-form-section-title { font-size:15px; font-weight:700; letter-spacing:2px; text-transform:uppercase; color:var(--accent-green); margin-bottom:20px; padding-bottom:10px; border-bottom:1px solid var(--border-subtle); display:flex; align-items:center; gap:10px; }
.sl-form-section-title i { font-size:16px; }
.sl-form-grid { display:grid; gap:16px; }
.sl-form-grid.cols-2 { grid-template-columns:1fr 1fr; }
.sl-form-grid.cols-3 { grid-template-columns:1fr 1fr 1fr; }
.sl-field label .required { color:var(--accent-red); margin-left:2px; }
.sl-field select { background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:9px 12px; color:var(--text-primary); font-size:15px; font-family:var(--font-mono); width:100%; outline:none; appearance:none; -webkit-appearance:none; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%235a6478' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 12px center; padding-right:32px; }
.sl-field select:focus { border-color:var(--accent-green); box-shadow:0 0 0 2px rgba(34,197,94,0.15); }
.sl-field input { width:100%; }
.sl-field textarea { width:100%; background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:12px; color:var(--text-primary); font-size:14px; font-family:var(--font-body); line-height:1.6; resize:vertical; outline:none; }
.sl-field textarea:focus { border-color:var(--accent-green); box-shadow:0 0 0 2px rgba(34,197,94,0.15); }
.sl-img-preview { width:180px; height:120px; border:2px dashed var(--border-default); border-radius:var(--radius-md); display:flex; align-items:center; justify-content:center; overflow:hidden; background:var(--bg-raised); margin-bottom:10px; }
.sl-img-preview img { max-width:100%; max-height:100%; object-fit:contain; }
.sl-img-preview .sl-img-placeholder { color:var(--text-muted); font-size:13px; text-align:center; padding:10px; }
.sl-img-preview .sl-img-placeholder i { font-size:24px; display:block; margin-bottom:6px; opacity:0.4; }
input[type="file"] { width:100%; font-size:13px; color:var(--text-secondary); }
input[type="file"]::file-selector-button { background:var(--accent-green); color:#fff; border:none; padding:6px 14px; border-radius:var(--radius-sm); font-size:12px; font-weight:600; cursor:pointer; margin-right:10px; }
@media (max-width:768px) { .sl-form-grid.cols-2, .sl-form-grid.cols-3 { grid-template-columns:1fr; } }
</style>
@endpush

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ isset($language) ? 'Edit '.$language->name : 'Create New Language' }}</h1>
        <span class="sl-page-subtitle">{{ isset($language) ? 'Update language details' : 'Add a new language to the system' }}</span>
        <div style="margin-left:auto;">
            <a href="{{ route('system-settings.languages.index') }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back to List</a>
        </div>
    </div>
</div>

<form method="POST" action="{{ isset($language) ? route('system-settings.languages.update', $language->id) : route('system-settings.languages.store') }}" enctype="multipart/form-data" class="sl-animate d2">
    @csrf
    @if(isset($language)) @method('PUT') @endif

    @if($errors->any())
    <div class="sl-verdict reject sl-mb-md" style="padding:14px 20px;">
        <div class="sl-verdict-icon" style="width:32px;height:32px;font-size:16px;"><i class="fas fa-exclamation-triangle"></i></div>
        <div>@foreach($errors->all() as $error)<div class="sl-verdict-text" style="font-size:14px;">{{ $error }}</div>@endforeach</div>
    </div>
    @endif

    <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">

        <div class="sl-form-section">
            <div class="sl-form-section-title"><i class="fas fa-language"></i> Language Details</div>
            <div class="sl-field" style="margin-bottom:16px;">
                <label>Country <span class="required">*</span></label>
                <select name="country_id" required>
                    <option value="">-- Select Country --</option>
                    @foreach($countries as $c)
                        <option value="{{ $c->id }}" {{ old('country_id', $language->country_id ?? '') == $c->id ? 'selected' : '' }}>{{ $c->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="sl-form-grid cols-2">
                <div class="sl-field">
                    <label>Language Name <span class="required">*</span></label>
                    <input type="text" name="name" value="{{ old('name', $language->name ?? '') }}" placeholder="e.g. English" required>
                </div>
                <div class="sl-field">
                    <label>Native Name</label>
                    <input type="text" name="native_name" value="{{ old('native_name', $language->native_name ?? '') }}" placeholder="e.g. English">
                </div>
            </div>
            <div class="sl-form-grid cols-2" style="margin-top:16px;">
                <div class="sl-field">
                    <label>Code <span class="required">*</span></label>
                    <input type="text" name="code" value="{{ old('code', $language->code ?? '') }}" placeholder="e.g. en" maxlength="10" required style="text-transform:lowercase;">
                </div>
                <div class="sl-field">
                    <label>Official Language</label>
                    <select name="is_official">
                        <option value="1" {{ old('is_official', $language->is_official ?? false) ? 'selected' : '' }}>Yes</option>
                        <option value="0" {{ old('is_official', $language->is_official ?? false) ? '' : 'selected' }}>No</option>
                    </select>
                </div>
            </div>
            @if(isset($language))
            <div class="sl-form-grid cols-2" style="margin-top:16px;">
                <div class="sl-field">
                    <label>Status</label>
                    <select name="is_active">
                        <option value="1" {{ old('is_active', $language->is_active) ? 'selected' : '' }}>Active</option>
                        <option value="0" {{ old('is_active', $language->is_active) ? '' : 'selected' }}>Inactive</option>
                    </select>
                </div>
                <div class="sl-field">
                    <label>Deleted</label>
                    <select name="is_deleted">
                        <option value="0" {{ old('is_deleted', $language->is_deleted) ? '' : 'selected' }}>No</option>
                        <option value="1" {{ old('is_deleted', $language->is_deleted) ? 'selected' : '' }}>Yes</option>
                    </select>
                </div>
            </div>
            @endif
        </div>

        <div class="sl-form-section">
            <div class="sl-form-section-title"><i class="fas fa-image"></i> Language Image</div>
            <div class="sl-field" style="display:flex; flex-direction:column; align-items:center;">
                <div class="sl-img-preview" id="lang_img_preview">
                    @if(isset($language) && $language->lang_image)
                        <img src="/{{ $language->lang_image }}" alt="{{ $language->name }}">
                    @else
                        <div class="sl-img-placeholder"><i class="fas fa-image"></i>No image uploaded</div>
                    @endif
                </div>
                <input type="file" name="lang_image" accept="image/*" onchange="previewImage(this, 'lang_img_preview')">
            </div>
            <div class="sl-field" style="margin-top:16px;">
                <label>Image Caption</label>
                <input type="text" name="caption" value="{{ old('caption', $language->caption ?? '') }}" placeholder="e.g. Proportion of Afrikaans speakers in South Africa">
            </div>
        </div>

    </div>

    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-align-left"></i> Description</div>
        <div class="sl-field">
            <label>Language Description</label>
            <textarea name="description" rows="6" placeholder="Enter a detailed description of this language...">{{ old('description', $language->description ?? '') }}</textarea>
        </div>
    </div>

    <div style="display:flex; gap:12px; justify-content:flex-end;">
        <a href="{{ route('system-settings.languages.index') }}" class="neon-btn neon-btn-red"><i class="fas fa-times"></i> Cancel</a>
        <button type="submit" class="neon-btn neon-btn-green neon-pulse"><i class="fas fa-check"></i> {{ isset($language) ? 'Update Language' : 'Save Language' }}</button>
    </div>
</form>

@push('scripts')
<script>
function previewImage(input, previewId) {
    var preview = document.getElementById(previewId);
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            preview.innerHTML = '<img src="' + e.target.result + '" alt="Preview">';
        };
        reader.readAsDataURL(input.files[0]);
    }
}
</script>
@endpush
@endsection
