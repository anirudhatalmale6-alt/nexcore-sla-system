@extends('cims_pmpro::layouts.system_settings')

@section('title', 'Languages')
@section('page_heading', 'LANGUAGES')

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">Language Registry</h1>
        <span class="sl-page-subtitle">System languages</span>
        <div style="margin-left:auto;">
            <a href="{{ route('system-settings.languages.create') }}" class="neon-btn neon-btn-green neon-pulse"><i class="fas fa-plus"></i> New Language</a>
        </div>
    </div>
</div>

<div class="sl-stats-grid sl-animate d2">
    <div class="sl-stat-card green">
        <div class="sl-stat-label">Total</div>
        <div class="sl-stat-value" style="color:var(--accent-green);">{{ number_format($stats['total'] ?? 0) }}</div>
        <div class="sl-stat-meta">All languages</div>
    </div>
    <div class="sl-stat-card blue">
        <div class="sl-stat-label">Active</div>
        <div class="sl-stat-value" style="color:var(--accent-blue);">{{ number_format($stats['active'] ?? 0) }}</div>
        <div class="sl-stat-meta">Currently active</div>
    </div>
    <div class="sl-stat-card purple">
        <div class="sl-stat-label">Official</div>
        <div class="sl-stat-value" style="color:var(--accent-purple);">{{ number_format($stats['official'] ?? 0) }}</div>
        <div class="sl-stat-meta">Official languages</div>
    </div>
    <div class="sl-stat-card amber">
        <div class="sl-stat-label">Inactive</div>
        <div class="sl-stat-value" style="color:var(--accent-amber);">{{ number_format($stats['inactive'] ?? 0) }}</div>
        <div class="sl-stat-meta">Disabled</div>
    </div>
</div>

<div class="sl-card sl-animate d3 sl-mb-md">
    <form method="GET" action="{{ route('system-settings.languages.index') }}">
        <div style="display:flex; gap:12px; align-items:end; flex-wrap:wrap;">
            <div class="sl-field" style="flex:1; min-width:200px;">
                <label>Search</label>
                <input type="text" name="search" value="{{ request('search') }}" placeholder="Name, native name, code..." style="width:100%;">
            </div>
            <div class="sl-field" style="min-width:180px;">
                <label>Country</label>
                <select name="country_id" style="width:100%; background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:9px 12px; color:var(--text-primary); font-size:15px; font-family:var(--font-mono);">
                    <option value="">All Countries</option>
                    @foreach($countries as $c)
                        <option value="{{ $c->id }}" {{ request('country_id') == $c->id ? 'selected' : '' }}>{{ $c->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="sl-field" style="min-width:160px;">
                <label>Official</label>
                <select name="official" style="width:100%; background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:9px 12px; color:var(--text-primary); font-size:15px; font-family:var(--font-mono);">
                    <option value="">All</option>
                    <option value="yes" {{ request('official') === 'yes' ? 'selected' : '' }}>Official</option>
                    <option value="no" {{ request('official') === 'no' ? 'selected' : '' }}>Non-Official</option>
                </select>
            </div>
            <div style="display:flex; gap:8px;">
                <button type="submit" class="neon-btn neon-btn-cyan" style="padding:9px 18px;"><i class="fas fa-search"></i> Filter</button>
                <a href="{{ route('system-settings.languages.index') }}" class="neon-btn neon-btn-ghost" style="padding:9px 18px;"><i class="fas fa-times"></i> Clear</a>
            </div>
        </div>
    </form>
</div>

<div class="sl-card sl-animate d4">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-language"></i> Languages</div>
        <div style="font-size:13px; color:var(--text-muted);">Showing {{ $languages->firstItem() ?? 0 }}-{{ $languages->lastItem() ?? 0 }} of {{ $languages->total() }}</div>
    </div>
    <div class="sl-table-wrap">
        <table class="sl-table">
            <thead><tr><th>#</th><th>Language</th><th>Native Name</th><th>Code</th><th>Country</th><th class="center">Official</th><th class="center">Status</th><th class="center">Actions</th></tr></thead>
            <tbody>
                @forelse($languages as $idx => $lang)
                <tr>
                    <td style="color:var(--text-muted);">{{ $languages->firstItem() + $idx }}</td>
                    <td style="font-weight:600;"><a href="{{ route('system-settings.languages.show', $lang->id) }}" style="color:var(--text-primary); text-decoration:none;" onmouseover="this.style.color='var(--accent-cyan)'" onmouseout="this.style.color='var(--text-primary)'">{{ $lang->name }}</a></td>
                    <td>{{ $lang->native_name ?? '-' }}</td>
                    <td><span class="sl-tag sl-tag-cyan">{{ $lang->code }}</span></td>
                    <td>{{ $lang->country->name ?? '-' }}</td>
                    <td class="center">@if($lang->is_official) <span class="sl-tag sl-tag-purple">Official</span> @else <span style="color:var(--text-muted);">-</span> @endif</td>
                    <td class="center">@if($lang->is_active) <span class="sl-status-dot pass"></span> @else <span class="sl-status-dot fail"></span> @endif</td>
                    <td class="center">
                        <div style="display:flex; gap:6px; justify-content:center;">
                            <a href="{{ route('system-settings.languages.edit', $lang->id) }}" style="color:var(--accent-blue); font-size:15px;" title="Edit"><i class="fas fa-pen"></i></a>
                            <a href="{{ route('system-settings.languages.show', $lang->id) }}" style="color:var(--accent-green); font-size:15px;" title="View"><i class="fas fa-eye"></i></a>
                            <form method="POST" action="{{ route('system-settings.languages.toggle', $lang->id) }}" style="display:inline;">@csrf
                                <button type="submit" style="background:none; border:none; color:var(--accent-amber); cursor:pointer; font-size:15px;" title="Toggle"><i class="fas fa-power-off"></i></button>
                            </form>
                            <form method="POST" action="{{ route('system-settings.languages.destroy', $lang->id) }}" style="display:inline;" onsubmit="return confirm('Delete {{ $lang->name }}?')">@csrf @method('DELETE')
                                <button type="submit" style="background:none; border:none; color:var(--accent-red); cursor:pointer; font-size:15px;" title="Delete"><i class="fas fa-trash"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="8" style="text-align:center; padding:40px; color:var(--text-muted);"><i class="fas fa-language" style="font-size:32px; opacity:0.3; margin-bottom:12px; display:block;"></i>No languages found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($languages->hasPages())
    <div style="display:flex; justify-content:center; padding:16px 0 0; gap:4px;">
        @if($languages->onFirstPage()) <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Prev</span>
        @else <a href="{{ $languages->previousPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Prev</a> @endif
        @foreach($languages->getUrlRange(max(1, $languages->currentPage()-2), min($languages->lastPage(), $languages->currentPage()+2)) as $page => $url)
            @if($page == $languages->currentPage()) <span class="sl-btn sl-btn-primary" style="padding:6px 12px; font-size:13px;">{{ $page }}</span>
            @else <a href="{{ $url }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">{{ $page }}</a> @endif
        @endforeach
        @if($languages->hasMorePages()) <a href="{{ $languages->nextPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Next</a>
        @else <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Next</span> @endif
    </div>
    @endif
</div>
@endsection
