@extends('cims_pmpro::layouts.system_settings')

@section('title', 'View Language')
@section('page_heading', 'VIEW LANGUAGE')

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ $language->name }}</h1>
        <span class="sl-page-subtitle">Language details</span>
        <div style="margin-left:auto; display:flex; gap:8px;">
            <a href="{{ route('system-settings.languages.edit', $language->id) }}" class="neon-btn neon-btn-blue"><i class="fas fa-pen"></i> Edit</a>
            <a href="{{ route('system-settings.languages.index') }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back</a>
        </div>
    </div>
</div>

<div style="display:grid; grid-template-columns:1fr 1fr; grid-template-rows:auto auto; gap:20px;" class="sl-animate d2">

    @if($language->lang_image)
    <div class="sl-card" style="grid-row:1 / 3;">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-image"></i> Language Image</div>
        </div>
        <div style="padding:20px; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:14px; height:calc(100% - 50px);">
            <div style="background:var(--bg-raised); border:1px solid var(--border-subtle); border-radius:var(--radius-md); padding:16px; display:inline-flex; align-items:center; justify-content:center; flex:1; width:100%; max-height:320px;">
                <img src="/{{ $language->lang_image }}" alt="{{ $language->name }}" style="max-width:100%; max-height:280px; object-fit:contain; border-radius:4px;">
            </div>
            @if($language->caption)
            <div style="color:var(--text-muted); font-size:13px; font-style:italic; text-align:center; line-height:1.6;">{{ $language->caption }}</div>
            @endif
        </div>
    </div>
    @endif

    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-language"></i> Language Information</div>
            @if($language->is_official) <span class="sl-tag sl-tag-purple">Official</span> @endif
            @if($language->is_active) <span class="sl-tag sl-tag-green">Active</span>
            @else <span class="sl-tag sl-tag-red">Inactive</span> @endif
        </div>
        @if($language->country)
        <div class="sl-result-row">
            <span class="sl-result-label">Country</span>
            <span class="sl-result-value"><a href="{{ route('pmpro.countries.show', $language->country_id) }}" style="color:var(--accent-cyan); text-decoration:none;">{{ $language->country->name }}</a></span>
        </div>
        @endif
        <div class="sl-result-row">
            <span class="sl-result-label">Name</span>
            <span class="sl-result-value" style="font-weight:600;">{{ $language->name }}</span>
        </div>
        @if($language->native_name)
        <div class="sl-result-row">
            <span class="sl-result-label">Native Name</span>
            <span class="sl-result-value">{{ $language->native_name }}</span>
        </div>
        @endif
        <div class="sl-result-row">
            <span class="sl-result-label">Code</span>
            <span class="sl-result-value"><span class="sl-tag sl-tag-cyan">{{ $language->code }}</span></span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Official Language</span>
            <span class="sl-result-value">@if($language->is_official) <span style="color:var(--accent-green);">Yes</span> @else No @endif</span>
        </div>
    </div>

    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-cog"></i> Status & Audit</div>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Active</span>
            <span class="sl-result-value">@if($language->is_active) <span class="sl-status-dot pass"></span> Yes @else <span class="sl-status-dot fail"></span> No @endif</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Deleted</span>
            <span class="sl-result-value">@if($language->is_deleted) <span style="color:var(--accent-red);">Yes</span> @else No @endif</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Created</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-size:13px;">{{ $language->created_at ? $language->created_at->format('j M Y H:i') : '-' }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Last Updated</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-size:13px;">{{ $language->updated_at ? $language->updated_at->format('j M Y H:i') : '-' }}</span>
        </div>
    </div>

</div>

@if($language->description)
<div class="sl-card sl-animate d3" style="margin-top:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-align-left"></i> Description</div>
    </div>
    <div style="padding:20px; color:var(--text-secondary); font-size:14px; line-height:1.8;">
        {!! nl2br(e($language->description)) !!}
    </div>
</div>
@endif
@endsection
