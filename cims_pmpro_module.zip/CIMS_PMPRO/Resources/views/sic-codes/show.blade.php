@extends('cims_pmpro::layouts.system_settings')

@section('title', 'View SIC Code')
@section('page_heading', 'VIEW SIC CODE')

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ $sicCode->description }}</h1>
        <span class="sl-page-subtitle">SARS SIC Code {{ $sicCode->sic_code }}</span>
        <div style="margin-left:auto; display:flex; gap:8px;">
            <a href="{{ route('system-settings.sic-codes.edit', $sicCode->id) }}" class="neon-btn neon-btn-blue"><i class="fas fa-pen"></i> Edit</a>
            <a href="{{ route('system-settings.sic-codes.index') }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back</a>
        </div>
    </div>
</div>

<div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;" class="sl-animate d2">

    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-file-invoice"></i> SIC Code Information</div>
            @if($sicCode->is_active) <span class="sl-tag sl-tag-green">Active</span>
            @else <span class="sl-tag sl-tag-red">Inactive</span> @endif
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">SIC Code</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-weight:700; color:var(--accent-cyan); font-size:20px;">{{ $sicCode->sic_code }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Description</span>
            <span class="sl-result-value" style="font-weight:600;">{{ $sicCode->description }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Section</span>
            <span class="sl-result-value"><span class="sl-tag sl-tag-blue">{{ $sicCode->section_code }} - {{ $sicCode->section_name }}</span></span>
        </div>
    </div>

    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-calculator"></i> ITR14 Source Codes</div>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Profit Code</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-weight:700; color:var(--accent-green); font-size:20px;">{{ $sicCode->profit_code ?? '-' }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Loss Code</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-weight:700; color:var(--accent-red); font-size:20px;">{{ $sicCode->loss_code ?? '-' }}</span>
        </div>
        <div style="padding:12px 20px; font-size:12px; color:var(--text-muted); border-top:1px solid var(--border-subtle);">
            <i class="fas fa-info-circle" style="margin-right:4px;"></i> SARS ITR14 tax return source codes. Even = Profit, Odd = Loss.
        </div>
    </div>

</div>

<div style="display:grid; grid-template-columns:1fr; gap:20px; margin-top:20px;" class="sl-animate d3">

    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-cog"></i> Status & Audit</div>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Active</span>
            <span class="sl-result-value">@if($sicCode->is_active) <span class="sl-status-dot pass"></span> Yes @else <span class="sl-status-dot fail"></span> No @endif</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Section Code</span>
            <span class="sl-result-value"><span class="sl-tag sl-tag-cyan" style="font-family:var(--font-mono);">{{ $sicCode->section_code }}</span></span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Created</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-size:13px;">{{ $sicCode->created_at ? $sicCode->created_at->format('j M Y H:i') : '-' }}</span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Last Updated</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); font-size:13px;">{{ $sicCode->updated_at ? $sicCode->updated_at->format('j M Y H:i') : '-' }}</span>
        </div>
    </div>

</div>

@if($linkedIndustries->count() > 0)
<div class="sl-card sl-animate d3" style="margin-top:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-industry"></i> Linked Industries</div>
        <span class="sl-tag sl-tag-green">{{ $linkedIndustries->count() }} {{ $linkedIndustries->count() === 1 ? 'industry' : 'industries' }}</span>
    </div>
    <div class="sl-table-wrap">
        <table class="sl-table">
            <thead><tr><th>Industry</th><th>Code</th><th class="center">Status</th><th class="center">View</th></tr></thead>
            <tbody>
                @foreach($linkedIndustries as $ind)
                <tr>
                    <td style="font-weight:600;">{{ $ind->name }}</td>
                    <td><span class="sl-tag sl-tag-amber" style="font-family:var(--font-mono);">{{ $ind->code ?? '-' }}</span></td>
                    <td class="center">@if($ind->is_active) <span class="sl-status-dot pass"></span> @else <span class="sl-status-dot fail"></span> @endif</td>
                    <td class="center"><a href="{{ route('system-settings.industries.show', $ind->id) }}" style="color:var(--accent-cyan);"><i class="fas fa-external-link-alt"></i></a></td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endif
@endsection
