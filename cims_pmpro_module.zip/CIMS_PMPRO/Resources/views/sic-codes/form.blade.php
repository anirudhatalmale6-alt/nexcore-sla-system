@extends('cims_pmpro::layouts.system_settings')

@section('title', isset($sicCode) ? 'Edit SIC Code' : 'New SIC Code')
@section('page_heading', isset($sicCode) ? 'EDIT SIC CODE' : 'NEW SIC CODE')

@push('styles')
<style>
.sl-form-section { background:var(--bg-surface); border:1px solid var(--border-subtle); border-radius:var(--radius-lg); padding:24px; margin-bottom:20px; box-shadow:var(--shadow-card); }
.sl-form-section-title { font-size:15px; font-weight:700; letter-spacing:2px; text-transform:uppercase; color:var(--accent-green); margin-bottom:20px; padding-bottom:10px; border-bottom:1px solid var(--border-subtle); display:flex; align-items:center; gap:10px; }
.sl-form-section-title i { font-size:16px; }
.sl-form-grid { display:grid; gap:16px; }
.sl-form-grid.cols-2 { grid-template-columns:1fr 1fr; }
.sl-field label .required { color:var(--accent-red); margin-left:2px; }
.sl-field select { background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:9px 12px; color:var(--text-primary); font-size:15px; font-family:var(--font-mono); width:100%; outline:none; appearance:none; -webkit-appearance:none; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%235a6478' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 12px center; padding-right:32px; }
.sl-field select:focus { border-color:var(--accent-green); box-shadow:0 0 0 2px rgba(34,197,94,0.15); }
.sl-field input { width:100%; }
.code-hint { font-size:12px; color:var(--text-muted); margin-top:6px; }
.code-hint i { margin-right:4px; }
@media (max-width:768px) { .sl-form-grid.cols-2 { grid-template-columns:1fr; } }
</style>
@endpush

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ isset($sicCode) ? 'Edit SIC Code '.$sicCode->sic_code : 'Create New SIC Code' }}</h1>
        <span class="sl-page-subtitle">{{ isset($sicCode) ? 'Update SIC code details' : 'Add a new SARS SIC code to the system' }}</span>
        <div style="margin-left:auto;">
            <a href="{{ route('system-settings.sic-codes.index') }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back to List</a>
        </div>
    </div>
</div>

<form method="POST" action="{{ isset($sicCode) ? route('system-settings.sic-codes.update', $sicCode->id) : route('system-settings.sic-codes.store') }}" class="sl-animate d2">
    @csrf
    @if(isset($sicCode)) @method('PUT') @endif

    @if($errors->any())
    <div class="sl-verdict reject sl-mb-md" style="padding:14px 20px;">
        <div class="sl-verdict-icon" style="width:32px;height:32px;font-size:16px;"><i class="fas fa-exclamation-triangle"></i></div>
        <div>@foreach($errors->all() as $error)<div class="sl-verdict-text" style="font-size:14px;">{{ $error }}</div>@endforeach</div>
    </div>
    @endif

    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-file-invoice"></i> SIC Code Details</div>
        <div class="sl-form-grid cols-2" style="margin-bottom:16px;">
            <div class="sl-field">
                <label>SIC Code <span class="required">*</span></label>
                <input type="text" name="sic_code" value="{{ old('sic_code', $sicCode->sic_code ?? '') }}" placeholder="e.g. 16210" maxlength="10" required style="font-family:var(--font-mono); font-weight:700; color:var(--accent-cyan); font-size:18px;">
                <div class="code-hint"><i class="fas fa-info-circle"></i> 5-digit SARS Standard Industry Classification code</div>
            </div>
            <div class="sl-field">&nbsp;</div>
        </div>
        <div class="sl-field">
            <label>Description <span class="required">*</span></label>
            <input type="text" name="description" value="{{ old('description', $sicCode->description ?? '') }}" placeholder="e.g. Manufacture of veneer sheets and wood-based panels" required>
        </div>
    </div>

    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-calculator"></i> ITR14 Source Codes</div>
        <div class="sl-form-grid cols-2">
            <div class="sl-field">
                <label>Profit Code</label>
                <input type="text" name="profit_code" value="{{ old('profit_code', $sicCode->profit_code ?? '') }}" placeholder="e.g. 0302" maxlength="10" style="font-family:var(--font-mono); font-weight:700; color:var(--accent-green); font-size:18px;">
                <div class="code-hint"><i class="fas fa-info-circle"></i> Even number - SARS ITR14 profit source code</div>
            </div>
            <div class="sl-field">
                <label>Loss Code</label>
                <input type="text" name="loss_code" value="{{ old('loss_code', $sicCode->loss_code ?? '') }}" placeholder="e.g. 0303" maxlength="10" style="font-family:var(--font-mono); font-weight:700; color:var(--accent-red); font-size:18px;">
                <div class="code-hint"><i class="fas fa-info-circle"></i> Odd number - SARS ITR14 loss source code</div>
            </div>
        </div>
    </div>

    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-layer-group"></i> Section / Division</div>
        <div class="sl-form-grid cols-2">
            <div class="sl-field">
                <label>Section Code <span class="required">*</span></label>
                <input type="text" name="section_code" value="{{ old('section_code', $sicCode->section_code ?? '') }}" placeholder="e.g. 10-33" maxlength="10" required list="sectionCodesList">
                <datalist id="sectionCodesList">
                    @foreach($sections as $sec)
                        <option value="{{ $sec->section_code }}">{{ $sec->section_name }}</option>
                    @endforeach
                </datalist>
                <div class="code-hint"><i class="fas fa-info-circle"></i> Division range e.g. 01-03, 10-33, 64-66</div>
            </div>
            <div class="sl-field">
                <label>Section Name <span class="required">*</span></label>
                <input type="text" name="section_name" value="{{ old('section_name', $sicCode->section_name ?? '') }}" placeholder="e.g. Manufacturing" required list="sectionNamesList">
                <datalist id="sectionNamesList">
                    @foreach($sections as $sec)
                        <option value="{{ $sec->section_name }}">{{ $sec->section_code }}</option>
                    @endforeach
                </datalist>
            </div>
        </div>
    </div>

    @if(isset($sicCode))
    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-cog"></i> Status</div>
        <div class="sl-form-grid cols-2">
            <div class="sl-field">
                <label>Active</label>
                <select name="is_active">
                    <option value="1" {{ old('is_active', $sicCode->is_active) ? 'selected' : '' }}>Active</option>
                    <option value="0" {{ old('is_active', $sicCode->is_active) ? '' : 'selected' }}>Inactive</option>
                </select>
            </div>
        </div>
    </div>
    @endif

    <div style="display:flex; gap:12px; justify-content:flex-end;">
        <a href="{{ route('system-settings.sic-codes.index') }}" class="neon-btn neon-btn-red"><i class="fas fa-times"></i> Cancel</a>
        <button type="submit" class="neon-btn neon-btn-green neon-pulse"><i class="fas fa-check"></i> {{ isset($sicCode) ? 'Update' : 'Save' }}</button>
    </div>
</form>
@endsection
