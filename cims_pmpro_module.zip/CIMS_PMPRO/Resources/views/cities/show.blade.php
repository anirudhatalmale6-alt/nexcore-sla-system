@extends('cims_pmpro::layouts.pmpro')

@section('title', $city->name)
@section('page_heading', 'MAIN PLACE — ' . strtoupper($city->name))

@section('content')
<div class="sl-animate d1">
    <div style="margin-bottom:12px; font-size:13px; color:var(--text-muted);">
        <a href="{{ route('pmpro.countries.index') }}" style="color:var(--accent-cyan); text-decoration:none;">Countries</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        <a href="{{ route('pmpro.countries.show', 129) }}" style="color:var(--accent-cyan); text-decoration:none;">South Africa</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        @if($city->province)
        <a href="{{ route('pmpro.provinces.show', $city->province->id) }}" style="color:var(--accent-cyan); text-decoration:none;">{{ $city->province->name }}</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        @endif
        @if($city->metro)
        <a href="{{ route('pmpro.metros.show', $city->metro->id) }}" style="color:var(--accent-cyan); text-decoration:none;">{{ $city->metro->name }}</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        @elseif($city->localMunicipality)
        <a href="{{ route('pmpro.districts.show', $city->localMunicipality->district->id) }}" style="color:var(--accent-cyan); text-decoration:none;">{{ $city->localMunicipality->district->name }}</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        <a href="{{ route('pmpro.local-municipalities.show', $city->localMunicipality->id) }}" style="color:var(--accent-cyan); text-decoration:none;">{{ $city->localMunicipality->name }}</a>
        <i class="fas fa-chevron-right" style="font-size:10px; margin:0 6px;"></i>
        @endif
        <span style="color:var(--text-primary);">{{ $city->name }}</span>
    </div>
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ $city->name }}</h1>
        <span class="sl-page-subtitle">Main place — suburbs, postal codes & wards</span>
        <div style="margin-left:auto; display:flex; gap:8px;">
            @if($city->metro)
            <a href="{{ route('pmpro.metros.show', $city->metro->id) }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back to {{ $city->metro->name }}</a>
            @elseif($city->localMunicipality)
            <a href="{{ route('pmpro.local-municipalities.show', $city->localMunicipality->id) }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back to {{ $city->localMunicipality->name }}</a>
            @endif
        </div>
    </div>
</div>

<div class="sl-stats-grid sl-animate d2">
    <div class="sl-stat-card green">
        <div class="sl-stat-label">Main Place</div>
        <div class="sl-stat-value" style="color:var(--accent-green); font-size:22px;">{{ $city->name }}</div>
        <div class="sl-stat-meta">{{ $city->province->name ?? '' }}</div>
    </div>
    <div class="sl-stat-card blue">
        <div class="sl-stat-label">Suburbs</div>
        <div class="sl-stat-value" style="color:var(--accent-blue);">{{ $suburbs->count() }}</div>
        <div class="sl-stat-meta">With postal codes</div>
    </div>
    <div class="sl-stat-card cyan">
        <div class="sl-stat-label">Wards</div>
        <div class="sl-stat-value" style="color:var(--accent-cyan);">{{ $wards->count() }}</div>
        <div class="sl-stat-meta">Electoral wards</div>
    </div>
</div>

<div class="sl-card sl-animate d3" style="margin-top:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-home"></i> Suburbs, Postal Codes & Wards</div>
        <div style="font-size:13px; color:var(--text-muted);">{{ $suburbs->count() }} suburbs &bull; {{ $wards->count() }} wards</div>
    </div>
    <div class="sl-table-wrap">
        <table class="sl-table">
            <thead><tr><th>#</th><th>Suburb</th><th>Postal Code</th><th>Ward</th><th class="center">Status</th></tr></thead>
            <tbody>
                @php $wardList = $wards->values(); @endphp
                @forelse($suburbs as $idx => $sub)
                <tr>
                    <td style="color:var(--text-muted);">{{ $idx + 1 }}</td>
                    <td style="font-weight:600;">{{ $sub->name }}</td>
                    <td><span style="font-family:monospace; font-weight:600; color:var(--accent-green);">{{ $sub->postal_code ?? '-' }}</span></td>
                    <td>
                        @if(isset($wardList[$idx]))
                        <a href="{{ route('pmpro.wards.show', $wardList[$idx]->id) }}" style="text-decoration:none;"><span class="sl-tag sl-tag-cyan">Ward {{ $wardList[$idx]->ward_number }}</span></a>
                        @else
                        <span style="color:var(--text-muted);">—</span>
                        @endif
                    </td>
                    <td class="center">@if($sub->is_active) <span class="sl-status-dot pass"></span> @else <span class="sl-status-dot fail"></span> @endif</td>
                </tr>
                @empty
                <tr><td colspan="5" style="text-align:center; padding:40px; color:var(--text-muted);"><i class="fas fa-home" style="font-size:32px; opacity:0.3; margin-bottom:12px; display:block;"></i>No suburbs found for this main place.</td></tr>
                @endforelse
                @if($wards->count() > $suburbs->count())
                @for($i = $suburbs->count(); $i < $wards->count(); $i++)
                <tr>
                    <td style="color:var(--text-muted);">{{ $i + 1 }}</td>
                    <td style="color:var(--text-muted);">—</td>
                    <td style="color:var(--text-muted);">—</td>
                    <td><a href="{{ route('pmpro.wards.show', $wardList[$i]->id) }}" style="text-decoration:none;"><span class="sl-tag sl-tag-cyan">Ward {{ $wardList[$i]->ward_number }}</span></a></td>
                    <td class="center">@if($wardList[$i]->is_active) <span class="sl-status-dot pass"></span> @else <span class="sl-status-dot fail"></span> @endif</td>
                </tr>
                @endfor
                @endif
            </tbody>
        </table>
    </div>
</div>
@endsection
