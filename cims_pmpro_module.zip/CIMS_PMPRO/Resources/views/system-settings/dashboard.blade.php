@extends('cims_pmpro::layouts.system_settings')

@section('title', 'Dashboard')
@section('page_heading', 'DASHBOARD')

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">System Settings</h1>
        <span class="sl-page-subtitle">NexCore platform configuration</span>
    </div>
</div>

<div class="sl-stats-grid sl-animate d2">
    <div class="sl-stat-card green">
        <div class="sl-stat-label">Languages</div>
        <div class="sl-stat-value" style="color:var(--accent-green);">{{ number_format($stats['languages'] ?? 0) }}</div>
        <div class="sl-stat-meta">Total registered</div>
    </div>
    <div class="sl-stat-card blue">
        <div class="sl-stat-label">Active Languages</div>
        <div class="sl-stat-value" style="color:var(--accent-blue);">{{ number_format($stats['active_languages'] ?? 0) }}</div>
        <div class="sl-stat-meta">Currently enabled</div>
    </div>
    <div class="sl-stat-card purple">
        <div class="sl-stat-label">Official Languages</div>
        <div class="sl-stat-value" style="color:var(--accent-purple);">{{ number_format($stats['official_languages'] ?? 0) }}</div>
        <div class="sl-stat-meta">SA official</div>
    </div>
</div>

<div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;" class="sl-animate d3">
    <a href="{{ route('system-settings.languages.index') }}" class="sl-card" style="text-decoration:none; transition:all 0.3s; border:1px solid var(--border-subtle);" onmouseover="this.style.borderColor='var(--accent-green)'; this.style.boxShadow='0 0 20px rgba(34,197,94,0.1)'" onmouseout="this.style.borderColor='var(--border-subtle)'; this.style.boxShadow='none'">
        <div style="padding:30px; display:flex; align-items:center; gap:20px;">
            <div style="width:56px; height:56px; border-radius:12px; background:rgba(34,197,94,0.1); display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                <i class="fas fa-language" style="font-size:24px; color:var(--accent-green);"></i>
            </div>
            <div>
                <div style="font-size:16px; font-weight:700; color:var(--text-primary); margin-bottom:4px;">Languages</div>
                <div style="font-size:13px; color:var(--text-muted);">Manage system languages, descriptions, images, and captions</div>
            </div>
            <i class="fas fa-chevron-right" style="margin-left:auto; color:var(--text-muted); font-size:14px;"></i>
        </div>
    </a>

    <div class="sl-card" style="border:1px dashed var(--border-subtle); opacity:0.5;">
        <div style="padding:30px; display:flex; align-items:center; gap:20px;">
            <div style="width:56px; height:56px; border-radius:12px; background:rgba(148,163,184,0.1); display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                <i class="fas fa-cogs" style="font-size:24px; color:var(--text-muted);"></i>
            </div>
            <div>
                <div style="font-size:16px; font-weight:700; color:var(--text-muted); margin-bottom:4px;">More Settings</div>
                <div style="font-size:13px; color:var(--text-muted);">Additional system settings coming soon</div>
            </div>
        </div>
    </div>
</div>
@endsection
