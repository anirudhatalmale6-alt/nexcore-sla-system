@extends('cims_pmpro::layouts.pmpro')

@section('title', isset($country) ? 'Edit Country' : 'New Country')
@section('page_heading', isset($country) ? 'EDIT COUNTRY' : 'NEW COUNTRY')

@push('styles')
<style>
.sl-form-section { background:var(--bg-surface); border:1px solid var(--border-subtle); border-radius:var(--radius-lg); padding:24px; margin-bottom:20px; box-shadow:var(--shadow-card); }
.sl-form-section-title { font-size:15px; font-weight:700; letter-spacing:2px; text-transform:uppercase; color:var(--accent-green); margin-bottom:20px; padding-bottom:10px; border-bottom:1px solid var(--border-subtle); display:flex; align-items:center; gap:10px; }
.sl-form-section-title i { font-size:16px; }
.sl-form-grid { display:grid; gap:16px; }
.sl-form-grid.cols-2 { grid-template-columns:1fr 1fr; }
.sl-form-grid.cols-3 { grid-template-columns:1fr 1fr 1fr; }
.sl-form-grid.cols-4 { grid-template-columns:1fr 1fr 1fr 1fr; }
.sl-field label .required { color:var(--accent-red); margin-left:2px; }
.sl-field select { background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:9px 12px; color:var(--text-primary); font-size:15px; font-family:var(--font-mono); width:100%; outline:none; appearance:none; -webkit-appearance:none; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%235a6478' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 12px center; padding-right:32px; }
.sl-field select:focus { border-color:var(--accent-green); box-shadow:0 0 0 2px rgba(34,197,94,0.15); }
.sl-field input { width:100%; }
.sl-field textarea { width:100%; background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:12px; color:var(--text-primary); font-size:14px; font-family:var(--font-body); line-height:1.6; resize:vertical; outline:none; }
.sl-field textarea:focus { border-color:var(--accent-green); box-shadow:0 0 0 2px rgba(34,197,94,0.15); }
.sl-img-upload { display:flex; flex-direction:column; align-items:center; gap:12px; }
.sl-img-preview { width:100%; max-width:200px; height:140px; border:2px dashed var(--border-default); border-radius:var(--radius-md); display:flex; align-items:center; justify-content:center; overflow:hidden; background:var(--bg-raised); position:relative; }
.sl-img-preview img { max-width:100%; max-height:100%; object-fit:contain; }
.sl-img-preview .sl-img-placeholder { color:var(--text-muted); font-size:13px; text-align:center; padding:10px; }
.sl-img-preview .sl-img-placeholder i { font-size:28px; display:block; margin-bottom:6px; opacity:0.4; }
input[type="file"] { width:100%; font-size:13px; color:var(--text-secondary); }
input[type="file"]::file-selector-button { background:var(--accent-green); color:#fff; border:none; padding:6px 14px; border-radius:var(--radius-sm); font-size:12px; font-weight:600; cursor:pointer; margin-right:10px; }
@media (max-width:768px) { .sl-form-grid.cols-2, .sl-form-grid.cols-3, .sl-form-grid.cols-4 { grid-template-columns:1fr; } }
</style>
@endpush

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">{{ isset($country) ? 'Edit '.$country->name : 'Create New Country' }}</h1>
        <span class="sl-page-subtitle">{{ isset($country) ? 'Update country details' : 'Add a new country to the system' }}</span>
        <div style="margin-left:auto;">
            <a href="{{ route('pmpro.countries.index') }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back to List</a>
        </div>
    </div>
</div>

<form method="POST" action="{{ isset($country) ? route('pmpro.countries.update', $country->id) : route('pmpro.countries.store') }}" enctype="multipart/form-data" class="sl-animate d2">
    @csrf
    @if(isset($country)) @method('PUT') @endif

    @if($errors->any())
    <div class="sl-verdict reject sl-mb-md" style="padding:14px 20px;">
        <div class="sl-verdict-icon" style="width:32px;height:32px;font-size:16px;"><i class="fas fa-exclamation-triangle"></i></div>
        <div>@foreach($errors->all() as $error)<div class="sl-verdict-text" style="font-size:14px;">{{ $error }}</div>@endforeach</div>
    </div>
    @endif

    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-images"></i> Country Images</div>
        <div class="sl-form-grid cols-3">
            <div class="sl-field">
                <label><i class="fas fa-flag" style="color:var(--accent-green);"></i> Country Flag</label>
                <div class="sl-img-upload">
                    <div class="sl-img-preview" id="flag_preview">
                        @if(isset($country) && $country->flag_image)
                            <img src="/{{ $country->flag_image }}" alt="Flag">
                        @else
                            <div class="sl-img-placeholder"><i class="fas fa-flag"></i>No flag uploaded</div>
                        @endif
                    </div>
                    <input type="file" name="flag_image" accept="image/*" onchange="previewImage(this, 'flag_preview')">
                </div>
            </div>
            <div class="sl-field">
                <label><i class="fas fa-shield-alt" style="color:var(--accent-amber);"></i> Coat of Arms</label>
                <div class="sl-img-upload">
                    <div class="sl-img-preview" id="coat_preview">
                        @if(isset($country) && $country->coat_of_arms_image)
                            <img src="/{{ $country->coat_of_arms_image }}" alt="Coat of Arms">
                        @else
                            <div class="sl-img-placeholder"><i class="fas fa-shield-alt"></i>No coat of arms uploaded</div>
                        @endif
                    </div>
                    <input type="file" name="coat_of_arms_image" accept="image/*" onchange="previewImage(this, 'coat_preview')">
                </div>
            </div>
            <div class="sl-field">
                <label><i class="fas fa-map" style="color:var(--accent-cyan);"></i> Country Map</label>
                <div class="sl-img-upload">
                    <div class="sl-img-preview" id="map_preview">
                        @if(isset($country) && $country->map_image)
                            <img src="/{{ $country->map_image }}" alt="Map">
                        @else
                            <div class="sl-img-placeholder"><i class="fas fa-map"></i>No map uploaded</div>
                        @endif
                    </div>
                    <input type="file" name="map_image" accept="image/*" onchange="previewImage(this, 'map_preview')">
                </div>
            </div>
        </div>
    </div>

    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-globe"></i> Country Identity</div>
        <div class="sl-form-grid cols-3">
            <div class="sl-field">
                <label>Country Name <span class="required">*</span></label>
                <input type="text" name="name" value="{{ old('name', $country->name ?? '') }}" placeholder="e.g. South Africa" required>
            </div>
            <div class="sl-field">
                <label>Official Name</label>
                <input type="text" name="official_name" value="{{ old('official_name', $country->official_name ?? '') }}" placeholder="e.g. Republic of South Africa">
            </div>
            <div class="sl-field">
                <label>Flag Emoji</label>
                <input type="text" name="flag_emoji" value="{{ old('flag_emoji', $country->flag_emoji ?? '') }}" placeholder="e.g. &#127487;&#127462;">
            </div>
        </div>
        <div class="sl-form-grid cols-3" style="margin-top:16px;">
            <div class="sl-field">
                <label>ISO Code 2 <span class="required">*</span></label>
                <input type="text" name="iso_code_2" value="{{ old('iso_code_2', $country->iso_code_2 ?? '') }}" placeholder="e.g. ZA" maxlength="2" required style="text-transform:uppercase;">
            </div>
            <div class="sl-field">
                <label>ISO Code 3 <span class="required">*</span></label>
                <input type="text" name="iso_code_3" value="{{ old('iso_code_3', $country->iso_code_3 ?? '') }}" placeholder="e.g. ZAF" maxlength="3" required style="text-transform:uppercase;">
            </div>
            <div class="sl-field">
                <label>Numeric Code</label>
                <input type="text" name="numeric_code" value="{{ old('numeric_code', $country->numeric_code ?? '') }}" placeholder="e.g. 710" maxlength="3">
            </div>
        </div>
    </div>

    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-align-left"></i> Description</div>
        <div class="sl-field">
            <label>Country Description</label>
            <textarea name="description" rows="6" placeholder="Enter a detailed description of this country...">{{ old('description', $country->description ?? '') }}</textarea>
        </div>
    </div>

    @if(isset($country) && $country->countryLanguages->count())
    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-language"></i> Languages ({{ $country->countryLanguages->count() }})</div>
        <div style="display:flex; flex-wrap:wrap; gap:8px; margin-bottom:12px;">
            @foreach($country->countryLanguages->sortBy('name') as $lang)
            <span class="sl-tag {{ $lang->is_official ? 'sl-tag-green' : 'sl-tag-cyan' }}" style="padding:6px 14px; font-size:13px;">
                {{ $lang->name }}@if($lang->is_official) <i class="fas fa-star" style="font-size:9px; margin-left:4px; opacity:0.7;"></i>@endif
            </span>
            @endforeach
        </div>
        <div style="font-size:12px; color:var(--text-muted);">
            <i class="fas fa-info-circle"></i> Languages are managed in <a href="{{ route('system-settings.languages.index', ['country_id' => $country->id]) }}" style="color:var(--accent-cyan);">System Settings</a>. They are automatically linked to this country.
        </div>
    </div>
    @endif

    @if(isset($country) && $country->ethnicGroups->count())
    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-users"></i> Ethnic Groups ({{ $country->ethnicGroups->count() }})</div>
        <div style="display:flex; flex-wrap:wrap; gap:8px; margin-bottom:12px;">
            @foreach($country->ethnicGroups->sortByDesc('percentage') as $eg)
            <span class="sl-tag sl-tag-amber" style="padding:6px 14px; font-size:13px; font-family:var(--font-mono);">
                {{ $eg->name }} <span style="opacity:0.7;">{{ number_format($eg->percentage, 1) }}%</span>
            </span>
            @endforeach
        </div>
        <div style="font-size:12px; color:var(--text-muted);">
            <i class="fas fa-info-circle"></i> Ethnic groups are managed in <a href="{{ route('system-settings.ethnic-groups.index', ['country_id' => $country->id]) }}" style="color:var(--accent-cyan);">System Settings</a>. They are automatically linked to this country.
        </div>
    </div>
    @endif

    @if(isset($country) && $country->religions->count())
    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-pray"></i> Religions ({{ $country->religions->count() }})</div>
        <div style="display:flex; flex-wrap:wrap; gap:8px; margin-bottom:12px;">
            @foreach($country->religions->sortByDesc('percentage') as $rel)
            <span class="sl-tag sl-tag-purple" style="padding:6px 14px; font-size:13px; font-family:var(--font-mono);">
                {{ $rel->name }} <span style="opacity:0.7;">{{ number_format($rel->percentage, 1) }}%</span>
            </span>
            @endforeach
        </div>
        <div style="font-size:12px; color:var(--text-muted);">
            <i class="fas fa-info-circle"></i> Religions are managed in <a href="{{ route('system-settings.religions.index', ['country_id' => $country->id]) }}" style="color:var(--accent-cyan);">System Settings</a>. They are automatically linked to this country.
        </div>
    </div>
    @endif

    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-map-marked-alt"></i> Geography</div>
        <div class="sl-form-grid cols-3">
            <div class="sl-field">
                <label>Continent <span class="required">*</span></label>
                <select name="continent" required>
                    <option value="">Select Continent...</option>
                    @foreach(['Africa','Antarctica','Asia','Europe','North America','Oceania','South America'] as $cont)
                        <option value="{{ $cont }}" {{ old('continent', $country->continent ?? '') == $cont ? 'selected' : '' }}>{{ $cont }}</option>
                    @endforeach
                </select>
            </div>
            <div class="sl-field">
                <label>Region</label>
                <input type="text" name="region" value="{{ old('region', $country->region ?? '') }}" placeholder="e.g. Southern Africa">
            </div>
            <div class="sl-field">
                <label>Capital</label>
                <input type="text" name="capital" value="{{ old('capital', $country->capital ?? '') }}" placeholder="e.g. Pretoria">
            </div>
        </div>
    </div>

    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-coins"></i> Currency & Communication</div>
        <div class="sl-form-grid cols-4">
            <div class="sl-field">
                <label>Currency Code</label>
                <input type="text" name="currency_code" value="{{ old('currency_code', $country->currency_code ?? '') }}" placeholder="e.g. ZAR" maxlength="3" style="text-transform:uppercase;">
            </div>
            <div class="sl-field">
                <label>Currency Name</label>
                <input type="text" name="currency_name" value="{{ old('currency_name', $country->currency_name ?? '') }}" placeholder="e.g. South African Rand">
            </div>
            <div class="sl-field">
                <label>Currency Symbol</label>
                <input type="text" name="currency_symbol" value="{{ old('currency_symbol', $country->currency_symbol ?? '') }}" placeholder="e.g. R">
            </div>
            <div class="sl-field">
                <label>Calling Code</label>
                <input type="text" name="calling_code" value="{{ old('calling_code', $country->calling_code ?? '') }}" placeholder="e.g. +27">
            </div>
        </div>
        <div style="margin-top:16px;">
            <div class="sl-field">
                <label>Timezone</label>
                <input type="text" name="timezone" value="{{ old('timezone', $country->timezone ?? '') }}" placeholder="e.g. Africa/Johannesburg">
            </div>
        </div>
    </div>

    @if(isset($country))
    <div class="sl-form-section">
        <div class="sl-form-section-title"><i class="fas fa-cog"></i> Status</div>
        <div class="sl-form-grid cols-2">
            <div class="sl-field">
                <label>Status</label>
                <select name="is_active">
                    <option value="1" {{ old('is_active', $country->is_active) ? 'selected' : '' }}>Active</option>
                    <option value="0" {{ old('is_active', $country->is_active) ? '' : 'selected' }}>Inactive</option>
                </select>
            </div>
        </div>
    </div>
    @endif

    <div style="display:flex; gap:12px; justify-content:flex-end;">
        <a href="{{ route('pmpro.countries.index') }}" class="neon-btn neon-btn-red"><i class="fas fa-times"></i> Cancel</a>
        <button type="submit" class="neon-btn neon-btn-green neon-pulse"><i class="fas fa-check"></i> {{ isset($country) ? 'Update Country' : 'Save Country' }}</button>
    </div>
</form>

@push('scripts')
<script>
function previewImage(input, previewId) {
    var preview = document.getElementById(previewId);
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            preview.innerHTML = '<img src="' + e.target.result + '" alt="Preview">';
        };
        reader.readAsDataURL(input.files[0]);
    }
}
</script>
@endpush
@endsection
