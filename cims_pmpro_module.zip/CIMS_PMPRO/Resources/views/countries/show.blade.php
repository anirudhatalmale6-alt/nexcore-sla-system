@extends('cims_pmpro::layouts.pmpro')

@section('title', 'View Country')
@section('page_heading', 'VIEW COUNTRY')

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">@if($country->flag_image)<img src="/{{ $country->flag_image }}" alt="" style="width:32px; height:24px; border-radius:3px; vertical-align:middle; margin-right:8px; border:1px solid rgba(255,255,255,0.15); object-fit:cover;">@endif{{ $country->name }}</h1>
        <span class="sl-page-subtitle">Country details</span>
        <div style="margin-left:auto; display:flex; gap:8px;">
            <a href="{{ route('pmpro.countries.edit', $country->id) }}" class="neon-btn neon-btn-blue"><i class="fas fa-pen"></i> Edit</a>
            <a href="{{ route('pmpro.countries.index') }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back</a>
        </div>
    </div>
</div>

@if($country->flag_image || $country->coat_of_arms_image || $country->map_image)
<div class="sl-card sl-animate d2" style="margin-bottom:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-images"></i> Country Images</div>
    </div>
    <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:20px; padding:20px;">
        @if($country->flag_image)
        <div style="text-align:center;">
            <div style="font-size:12px; font-weight:700; letter-spacing:1px; text-transform:uppercase; color:var(--accent-green); margin-bottom:10px;"><i class="fas fa-flag"></i> Country Flag</div>
            <div style="background:var(--bg-raised); border:1px solid var(--border-subtle); border-radius:var(--radius-md); padding:16px; display:flex; align-items:center; justify-content:center; min-height:160px;">
                <img src="/{{ $country->flag_image }}" alt="{{ $country->name }} Flag" style="max-width:100%; max-height:160px; object-fit:contain; border-radius:4px;">
            </div>
        </div>
        @endif
        @if($country->coat_of_arms_image)
        <div style="text-align:center;">
            <div style="font-size:12px; font-weight:700; letter-spacing:1px; text-transform:uppercase; color:var(--accent-amber); margin-bottom:10px;"><i class="fas fa-shield-alt"></i> Coat of Arms</div>
            <div style="background:var(--bg-raised); border:1px solid var(--border-subtle); border-radius:var(--radius-md); padding:16px; display:flex; align-items:center; justify-content:center; min-height:160px;">
                <img src="/{{ $country->coat_of_arms_image }}" alt="{{ $country->name }} Coat of Arms" style="max-width:100%; max-height:160px; object-fit:contain;">
            </div>
        </div>
        @endif
        @if($country->map_image)
        <div style="text-align:center;">
            <div style="font-size:12px; font-weight:700; letter-spacing:1px; text-transform:uppercase; color:var(--accent-cyan); margin-bottom:10px;"><i class="fas fa-map"></i> Country Map</div>
            <div style="background:var(--bg-raised); border:1px solid var(--border-subtle); border-radius:var(--radius-md); padding:16px; display:flex; align-items:center; justify-content:center; min-height:160px;">
                <img src="/{{ $country->map_image }}" alt="{{ $country->name }} Map" style="max-width:100%; max-height:160px; object-fit:contain;">
            </div>
        </div>
        @endif
    </div>
</div>
@endif

@if($country->description)
<div class="sl-card sl-animate d3" style="margin-bottom:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-align-left"></i> Description</div>
    </div>
    <div style="padding:20px; color:var(--text-secondary); font-size:14px; line-height:1.8;">
        {!! nl2br(e($country->description)) !!}
    </div>
</div>
@endif

@if($country->countryLanguages->count())
<div class="sl-card sl-animate d3" style="margin-bottom:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-language"></i> Languages ({{ $country->countryLanguages->count() }})</div>
        <a href="{{ route('system-settings.languages.index', ['country_id' => $country->id]) }}" style="font-size:12px; color:var(--accent-cyan); text-decoration:none;">Manage in System Settings <i class="fas fa-external-link-alt"></i></a>
    </div>
    <div style="padding:16px 20px; display:flex; flex-wrap:wrap; gap:8px;">
        @foreach($country->countryLanguages->sortBy('name') as $lang)
        <a href="{{ route('system-settings.languages.show', $lang->id) }}" style="text-decoration:none;">
            <span class="sl-tag {{ $lang->is_official ? 'sl-tag-green' : 'sl-tag-cyan' }}" style="padding:6px 14px; font-size:13px; cursor:pointer; transition:all 0.2s;" onmouseover="this.style.transform='translateY(-1px)'; this.style.boxShadow='0 2px 8px rgba(0,0,0,0.2)'" onmouseout="this.style.transform='none'; this.style.boxShadow='none'">
                {{ $lang->name }}@if($lang->is_official) <i class="fas fa-star" style="font-size:9px; margin-left:4px; opacity:0.7;"></i>@endif
            </span>
        </a>
        @endforeach
    </div>
    <div style="padding:0 20px 14px; font-size:11px; color:var(--text-muted);">
        <i class="fas fa-star" style="font-size:9px; color:var(--accent-green);"></i> = Official language
    </div>
</div>
@endif

@if($country->ethnicGroups->count())
<div class="sl-card sl-animate d3" style="margin-bottom:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-users"></i> Ethnic Groups ({{ $country->ethnicGroups->count() }})</div>
        <a href="{{ route('system-settings.ethnic-groups.index', ['country_id' => $country->id]) }}" style="font-size:12px; color:var(--accent-cyan); text-decoration:none;">Manage in System Settings <i class="fas fa-external-link-alt"></i></a>
    </div>
    <div style="padding:16px 20px; display:flex; flex-wrap:wrap; gap:8px;">
        @foreach($country->ethnicGroups->sortByDesc('percentage') as $eg)
        <a href="{{ route('system-settings.ethnic-groups.show', $eg->id) }}" style="text-decoration:none;">
            <span class="sl-tag sl-tag-amber" style="padding:6px 14px; font-size:13px; cursor:pointer; transition:all 0.2s; font-family:var(--font-mono);" onmouseover="this.style.transform='translateY(-1px)'; this.style.boxShadow='0 2px 8px rgba(0,0,0,0.2)'" onmouseout="this.style.transform='none'; this.style.boxShadow='none'">
                {{ $eg->name }} <span style="opacity:0.7;">{{ number_format($eg->percentage, 1) }}%</span>
            </span>
        </a>
        @endforeach
    </div>
    <div style="padding:0 20px 14px; font-size:11px; color:var(--text-muted);">
        <i class="fas fa-chart-pie" style="font-size:9px; color:var(--accent-amber);"></i> Population percentage (2022 census)
    </div>
</div>
@endif

@if($country->religions->count())
<div class="sl-card sl-animate d3" style="margin-bottom:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-pray"></i> Religions ({{ $country->religions->count() }})</div>
        <a href="{{ route('system-settings.religions.index', ['country_id' => $country->id]) }}" style="font-size:12px; color:var(--accent-cyan); text-decoration:none;">Manage in System Settings <i class="fas fa-external-link-alt"></i></a>
    </div>
    <div style="padding:16px 20px; display:flex; flex-wrap:wrap; gap:8px;">
        @foreach($country->religions->sortByDesc('percentage') as $rel)
        <a href="{{ route('system-settings.religions.show', $rel->id) }}" style="text-decoration:none;">
            <span class="sl-tag sl-tag-purple" style="padding:6px 14px; font-size:13px; cursor:pointer; transition:all 0.2s; font-family:var(--font-mono);" onmouseover="this.style.transform='translateY(-1px)'; this.style.boxShadow='0 2px 8px rgba(0,0,0,0.2)'" onmouseout="this.style.transform='none'; this.style.boxShadow='none'">
                {{ $rel->name }} <span style="opacity:0.7;">{{ number_format($rel->percentage, 1) }}%</span>
            </span>
        </a>
        @endforeach
    </div>
    <div style="padding:0 20px 14px; font-size:11px; color:var(--text-muted);">
        <i class="fas fa-chart-pie" style="font-size:9px; color:var(--accent-purple);"></i> Population percentage (2022 census)
    </div>
</div>
@endif

<div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;" class="sl-animate d4">
    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-globe"></i> Identity</div>
            @if($country->is_active) <span class="sl-tag sl-tag-green">Active</span>
            @else <span class="sl-tag sl-tag-red">Inactive</span> @endif
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Name</span>
            <span class="sl-result-value" style="font-weight:600;">{{ $country->name }}</span>
        </div>
        @if($country->official_name)
        <div class="sl-result-row">
            <span class="sl-result-label">Official Name</span>
            <span class="sl-result-value">{{ $country->official_name }}</span>
        </div>
        @endif
        <div class="sl-result-row">
            <span class="sl-result-label">ISO Code 2</span>
            <span class="sl-result-value"><span class="sl-tag sl-tag-green">{{ $country->iso_code_2 }}</span></span>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">ISO Code 3</span>
            <span class="sl-result-value"><span class="sl-tag sl-tag-cyan">{{ $country->iso_code_3 }}</span></span>
        </div>
        @if($country->numeric_code)
        <div class="sl-result-row">
            <span class="sl-result-label">Numeric Code</span>
            <span class="sl-result-value" style="font-family:var(--font-mono);">{{ $country->numeric_code }}</span>
        </div>
        @endif
        @if($country->flag_image)
        <div class="sl-result-row">
            <span class="sl-result-label">Flag</span>
            <span class="sl-result-value"><img src="/{{ $country->flag_image }}" alt="{{ $country->name }} flag" style="width:48px; height:36px; border-radius:4px; vertical-align:middle; border:1px solid rgba(255,255,255,0.15); object-fit:cover;"></span>
        </div>
        @endif
    </div>

    <div class="sl-card">
        <div class="sl-card-header">
            <div class="sl-card-title"><i class="fas fa-map-marked-alt"></i> Geography & Currency</div>
        </div>
        <div class="sl-result-row">
            <span class="sl-result-label">Continent</span>
            <span class="sl-result-value"><span class="sl-tag sl-tag-blue">{{ $country->continent ?? '-' }}</span></span>
        </div>
        @if($country->region)
        <div class="sl-result-row">
            <span class="sl-result-label">Region</span>
            <span class="sl-result-value">{{ $country->region }}</span>
        </div>
        @endif
        @if($country->capital)
        <div class="sl-result-row">
            <span class="sl-result-label">Capital</span>
            <span class="sl-result-value" style="font-weight:600;">{{ $country->capital }}</span>
        </div>
        @endif
        @if($country->currency_code)
        <div class="sl-result-row">
            <span class="sl-result-label">Currency</span>
            <span class="sl-result-value"><span class="sl-tag sl-tag-amber">{{ $country->currency_code }}</span> {{ $country->currency_name ?? '' }} <span style="color:var(--accent-cyan);">{{ $country->currency_symbol ?? '' }}</span></span>
        </div>
        @endif
        @if($country->calling_code)
        <div class="sl-result-row">
            <span class="sl-result-label">Calling Code</span>
            <span class="sl-result-value" style="font-family:var(--font-mono); color:var(--accent-green);">{{ $country->calling_code }}</span>
        </div>
        @endif
        @if($country->timezone)
        <div class="sl-result-row">
            <span class="sl-result-label">Timezone</span>
            <span class="sl-result-value" style="font-family:var(--font-mono);">{{ $country->timezone }}</span>
        </div>
        @endif
    </div>
</div>

@if($provinces->count())
<div class="sl-card sl-animate d5" style="margin-top:20px;">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-globe-africa"></i> Provinces ({{ $provinces->count() }})</div>
        <span class="sl-tag sl-tag-green">Drill Down</span>
    </div>
    <div class="sl-table-wrap">
        <table class="sl-table">
            <thead>
                <tr>
                    <th>Province</th>
                    <th>Code</th>
                    <th class="center">Districts</th>
                    <th class="center">Metros</th>
                    <th class="center">Status</th>
                    <th class="center">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($provinces as $p)
                <tr style="cursor:pointer;" onclick="window.location='{{ route('pmpro.provinces.show', $p->id) }}'">
                    <td style="font-weight:600;">{{ $p->name }}</td>
                    <td><span class="sl-tag sl-tag-green">{{ $p->code }}</span></td>
                    <td class="center"><span class="sl-tag sl-tag-blue">{{ $p->districts_count }}</span></td>
                    <td class="center"><span class="sl-tag sl-tag-purple">{{ $p->metros_count }}</span></td>
                    <td class="center">
                        @if($p->is_active) <span class="sl-status-dot pass"></span>
                        @else <span class="sl-status-dot fail"></span> @endif
                    </td>
                    <td class="center">
                        <a href="{{ route('pmpro.provinces.show', $p->id) }}" class="neon-btn neon-btn-cyan" style="padding:6px 14px; font-size:11px;">
                            <i class="fas fa-arrow-right"></i> Drill Down
                        </a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endif
@endsection
