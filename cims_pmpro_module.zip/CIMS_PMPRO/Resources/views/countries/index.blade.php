@extends('cims_pmpro::layouts.pmpro')

@section('title', 'Countries')
@section('page_heading', 'COUNTRIES')

@section('content')
<div class="sl-animate d1">
    <div class="sl-page-header">
        <h1 class="sl-page-title">Country Registry</h1>
        <span class="sl-page-subtitle">World countries with currency, timezone and regional data</span>
        <div style="margin-left:auto;">
            <a href="{{ route('pmpro.countries.create') }}" class="neon-btn neon-btn-green neon-pulse"><i class="fas fa-plus"></i> New Country</a>
        </div>
    </div>
</div>

<div class="sl-stats-grid sl-animate d2">
    <div class="sl-stat-card green">
        <div class="sl-stat-label">Total</div>
        <div class="sl-stat-value" style="color:var(--accent-green);">{{ number_format($stats['total'] ?? 0) }}</div>
        <div class="sl-stat-meta">All countries</div>
    </div>
    <div class="sl-stat-card blue">
        <div class="sl-stat-label">Active</div>
        <div class="sl-stat-value" style="color:var(--accent-blue);">{{ number_format($stats['active'] ?? 0) }}</div>
        <div class="sl-stat-meta">Currently active</div>
    </div>
    <div class="sl-stat-card amber">
        <div class="sl-stat-label">Inactive</div>
        <div class="sl-stat-value" style="color:var(--accent-amber);">{{ number_format($stats['inactive'] ?? 0) }}</div>
        <div class="sl-stat-meta">Disabled</div>
    </div>
</div>

<div class="sl-card sl-animate d3 sl-mb-md">
    <form method="GET" action="{{ route('pmpro.countries.index') }}">
        <div style="display:flex; gap:12px; align-items:end; flex-wrap:wrap;">
            <div class="sl-field" style="flex:1; min-width:200px;">
                <label>Search</label>
                <input type="text" name="search" value="{{ request('search') }}" placeholder="Country, ISO code, capital, currency..." style="width:100%;">
            </div>
            <div class="sl-field" style="min-width:180px;">
                <label>Continent</label>
                <select name="continent" style="width:100%; background:var(--bg-raised); border:1px solid var(--border-default); border-radius:var(--radius-sm); padding:9px 12px; color:var(--text-primary); font-size:15px; font-family:var(--font-mono);">
                    <option value="">All Continents</option>
                    @foreach($continents as $cont)
                        <option value="{{ $cont }}" {{ request('continent') == $cont ? 'selected' : '' }}>{{ $cont }}</option>
                    @endforeach
                </select>
            </div>
            <div style="display:flex; gap:8px;">
                <button type="submit" class="neon-btn neon-btn-cyan" style="padding:9px 18px;"><i class="fas fa-search"></i> Filter</button>
                <a href="{{ route('pmpro.countries.index') }}" class="neon-btn neon-btn-ghost" style="padding:9px 18px;"><i class="fas fa-times"></i> Clear</a>
            </div>
        </div>
    </form>
</div>

<div class="sl-card sl-animate d4">
    <div class="sl-card-header">
        <div class="sl-card-title"><i class="fas fa-globe"></i> Countries</div>
        <div style="font-size:13px; color:var(--text-muted);">Showing {{ $countries->firstItem() ?? 0 }}-{{ $countries->lastItem() ?? 0 }} of {{ $countries->total() }}</div>
    </div>
    <div class="sl-table-wrap">
        <table class="sl-table">
            <thead><tr><th>#</th><th>Flag</th><th>Country</th><th>ISO 2</th><th>ISO 3</th><th>Capital</th><th>Currency</th><th>Calling</th><th>Continent</th><th class="center">Status</th><th class="center">Actions</th></tr></thead>
            <tbody>
                @forelse($countries as $country)
                <tr>
                    <td class="mono">{{ $country->id }}</td>
                    <td>@if($country->flag_image)<img src="/{{ $country->flag_image }}" alt="{{ $country->name }}" style="width:28px; height:21px; border-radius:3px; vertical-align:middle; border:1px solid rgba(255,255,255,0.15); object-fit:cover;">@else -@endif</td>
                    <td style="font-weight:600;"><a href="{{ route('pmpro.countries.show', $country->id) }}" style="color:var(--text-primary); text-decoration:none;" onmouseover="this.style.color='var(--accent-cyan)'" onmouseout="this.style.color='var(--text-primary)'">{{ $country->name }}</a></td>
                    <td><span class="sl-tag sl-tag-green">{{ $country->iso_code_2 }}</span></td>
                    <td><span class="sl-tag sl-tag-cyan">{{ $country->iso_code_3 }}</span></td>
                    <td>{{ $country->capital ?? '-' }}</td>
                    <td class="mono">{{ $country->currency_code ?? '-' }} <span style="color:var(--text-muted);">{{ $country->currency_symbol ?? '' }}</span></td>
                    <td class="mono">{{ $country->calling_code ?? '-' }}</td>
                    <td><span class="sl-tag sl-tag-blue">{{ $country->continent ?? '-' }}</span></td>
                    <td class="center">@if($country->is_active) <span class="sl-status-dot pass"></span> @else <span class="sl-status-dot fail"></span> @endif</td>
                    <td class="center">
                        <div style="display:flex; gap:6px; justify-content:center;">
                            <a href="{{ route('pmpro.countries.edit', $country->id) }}" style="color:var(--accent-blue); font-size:15px;" title="Edit"><i class="fas fa-pen"></i></a>
                            <a href="{{ route('pmpro.countries.show', $country->id) }}" style="color:var(--accent-green); font-size:15px;" title="View"><i class="fas fa-eye"></i></a>
                            <form method="POST" action="{{ route('pmpro.countries.toggle', $country->id) }}" style="display:inline;">@csrf
                                <button type="submit" style="background:none; border:none; color:var(--accent-amber); cursor:pointer; font-size:15px;" title="Toggle"><i class="fas fa-power-off"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="11" style="text-align:center; padding:40px; color:var(--text-muted);"><i class="fas fa-globe" style="font-size:32px; opacity:0.3; margin-bottom:12px; display:block;"></i>No countries found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($countries->hasPages())
    <div style="display:flex; justify-content:center; padding:16px 0 0; gap:4px;">
        @if($countries->onFirstPage()) <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Prev</span>
        @else <a href="{{ $countries->previousPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Prev</a> @endif
        @foreach($countries->getUrlRange(max(1, $countries->currentPage()-2), min($countries->lastPage(), $countries->currentPage()+2)) as $page => $url)
            @if($page == $countries->currentPage()) <span class="sl-btn sl-btn-primary" style="padding:6px 12px; font-size:13px;">{{ $page }}</span>
            @else <a href="{{ $url }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">{{ $page }}</a> @endif
        @endforeach
        @if($countries->hasMorePages()) <a href="{{ $countries->nextPageUrl() }}" class="sl-btn sl-btn-ghost" style="padding:6px 12px; font-size:13px;">Next</a>
        @else <span class="sl-btn sl-btn-ghost" style="opacity:0.4; padding:6px 12px; font-size:13px;">Next</span> @endif
    </div>
    @endif
</div>
@endsection
