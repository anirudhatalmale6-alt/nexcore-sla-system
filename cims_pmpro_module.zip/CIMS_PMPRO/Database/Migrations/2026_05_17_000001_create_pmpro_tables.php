<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('pmpro_provinces', function (Blueprint $table) {
            $table->id();
            $table->string('name', 100);
            $table->string('code', 5);
            $table->boolean('is_active')->default(true);
        });

        Schema::create('pmpro_districts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('province_id')->constrained('pmpro_provinces');
            $table->string('name', 200);
            $table->string('code', 10)->nullable();
            $table->boolean('is_active')->default(true);
        });

        Schema::create('pmpro_metropolitan_municipalities', function (Blueprint $table) {
            $table->id();
            $table->foreignId('province_id')->constrained('pmpro_provinces');
            $table->string('name', 200);
            $table->string('code', 10)->nullable();
            $table->boolean('is_active')->default(true);
        });

        Schema::create('pmpro_local_municipalities', function (Blueprint $table) {
            $table->id();
            $table->foreignId('district_id')->constrained('pmpro_districts');
            $table->string('name', 200);
            $table->string('code', 10)->nullable();
            $table->boolean('is_active')->default(true);
        });

        Schema::create('pmpro_wards', function (Blueprint $table) {
            $table->id();
            $table->foreignId('local_municipality_id')->nullable()->constrained('pmpro_local_municipalities');
            $table->foreignId('metro_id')->nullable()->constrained('pmpro_metropolitan_municipalities');
            $table->integer('ward_number');
            $table->string('code', 20)->nullable();
            $table->boolean('is_active')->default(true);
        });

        Schema::create('pmpro_cities', function (Blueprint $table) {
            $table->id();
            $table->foreignId('province_id')->constrained('pmpro_provinces');
            $table->unsignedBigInteger('municipality_id')->nullable();
            $table->unsignedBigInteger('metro_id')->nullable();
            $table->string('name', 200);
            $table->boolean('is_active')->default(true);
        });

        Schema::create('pmpro_suburbs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('city_id')->constrained('pmpro_cities');
            $table->unsignedBigInteger('municipality_id')->nullable();
            $table->string('name', 200);
            $table->string('postal_code', 10)->nullable();
            $table->boolean('is_active')->default(true);
            $table->index('postal_code');
            $table->index('name');
        });

        Schema::create('pmpro_address_main', function (Blueprint $table) {
            $table->id();
            $table->string('unit_number', 20)->nullable();
            $table->string('complex_name', 200)->nullable();
            $table->string('street_number', 20);
            $table->string('street_name', 255);
            $table->foreignId('suburb_id')->nullable()->constrained('pmpro_suburbs');
            $table->string('city', 200);
            $table->string('postal_code', 10);
            $table->foreignId('province_id')->constrained('pmpro_provinces');
            $table->unsignedBigInteger('municipality_id')->nullable();
            $table->unsignedBigInteger('ward_id')->nullable();
            $table->string('country', 5)->default('ZA');
            $table->decimal('latitude', 10, 8)->nullable();
            $table->decimal('longitude', 11, 8)->nullable();
            $table->text('google_formatted_address')->nullable();
            $table->enum('address_category', ['Residential', 'Commercial', 'Industrial', 'Agricultural', 'Mixed Use'])->default('Residential');
            $table->boolean('is_active')->default(true);
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->index(['city', 'postal_code']);
            $table->index('province_id');
        });

        Schema::create('pmpro_address_secondary', function (Blueprint $table) {
            $table->id();
            $table->foreignId('address_id')->constrained('pmpro_address_main')->onDelete('cascade');
            $table->string('floor_level', 20)->nullable();
            $table->string('building_name', 200)->nullable();
            $table->string('estate_name', 200)->nullable();
            $table->string('section_number', 50)->nullable();
            $table->string('farm_name', 200)->nullable();
            $table->string('farm_number', 50)->nullable();
            $table->string('stand_number', 50)->nullable();
            $table->string('erf_number', 50)->nullable();
            $table->string('sg_code', 50)->nullable();
            $table->string('municipal_account_number', 100)->nullable();
            $table->string('plus_code', 50)->nullable();
            $table->string('what3words', 100)->nullable();
            $table->string('google_place_id', 300)->nullable();
            $table->text('map_url')->nullable();
            $table->enum('address_source', ['Manual', 'Google', 'Imported', 'SARS'])->default('Manual');
            $table->boolean('is_verified')->default(false);
            $table->date('verified_date')->nullable();
            $table->timestamps();
        });

        Schema::create('pmpro_address_types', function (Blueprint $table) {
            $table->id();
            $table->string('name', 100);
            $table->string('description', 255)->nullable();
            $table->boolean('is_active')->default(true);
        });

        Schema::create('pmpro_address_links', function (Blueprint $table) {
            $table->id();
            $table->foreignId('address_id')->constrained('pmpro_address_main')->onDelete('cascade');
            $table->string('linkable_type', 100);
            $table->unsignedBigInteger('linkable_id');
            $table->foreignId('address_type_id')->constrained('pmpro_address_types');
            $table->boolean('is_primary')->default(false);
            $table->timestamps();
            $table->index(['linkable_type', 'linkable_id']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('pmpro_address_links');
        Schema::dropIfExists('pmpro_address_types');
        Schema::dropIfExists('pmpro_address_secondary');
        Schema::dropIfExists('pmpro_address_main');
        Schema::dropIfExists('pmpro_suburbs');
        Schema::dropIfExists('pmpro_cities');
        Schema::dropIfExists('pmpro_wards');
        Schema::dropIfExists('pmpro_local_municipalities');
        Schema::dropIfExists('pmpro_metropolitan_municipalities');
        Schema::dropIfExists('pmpro_districts');
        Schema::dropIfExists('pmpro_provinces');
    }
};
