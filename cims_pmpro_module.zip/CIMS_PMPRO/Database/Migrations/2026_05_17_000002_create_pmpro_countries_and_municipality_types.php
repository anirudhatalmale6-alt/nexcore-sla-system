<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('pmpro_municipality_types', function (Blueprint $table) {
            $table->id();
            $table->string('name', 100);
            $table->string('code', 5);
            $table->string('description', 500)->nullable();
            $table->boolean('is_active')->default(true);
        });

        Schema::create('pmpro_countries', function (Blueprint $table) {
            $table->id();
            $table->string('name', 200);
            $table->string('official_name', 300)->nullable();
            $table->string('iso_code_2', 2)->unique();
            $table->string('iso_code_3', 3)->unique();
            $table->string('numeric_code', 3)->nullable();
            $table->string('continent', 50)->nullable();
            $table->string('region', 100)->nullable();
            $table->string('capital', 200)->nullable();
            $table->string('currency_code', 5)->nullable();
            $table->string('currency_name', 100)->nullable();
            $table->string('currency_symbol', 10)->nullable();
            $table->string('calling_code', 10)->nullable();
            $table->string('timezone', 50)->nullable();
            $table->string('languages', 255)->nullable();
            $table->string('flag_emoji', 10)->nullable();
            $table->boolean('is_active')->default(true);
            $table->index('continent');
            $table->index('is_active');
        });
    }

    public function down()
    {
        Schema::dropIfExists('pmpro_countries');
        Schema::dropIfExists('pmpro_municipality_types');
    }
};
