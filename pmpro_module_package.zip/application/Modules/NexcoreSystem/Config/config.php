<?php

return [
    'name' => 'NexcoreSystem',
];
