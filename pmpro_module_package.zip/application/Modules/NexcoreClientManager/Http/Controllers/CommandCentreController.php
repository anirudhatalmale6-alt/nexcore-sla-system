<?php

namespace Modules\NexcoreClientManager\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Modules\NexcoreClientManager\Models\NexcoreClient;
use Modules\NexcoreClientManager\Models\NexcoreClientTask;
use Modules\NexcoreClientManager\Models\NexcoreTaskActivityLog;
use App\Models\User;

class CommandCentreController extends Controller
{
    /**
     * Display the Command Centre dashboard with live data.
     */
    public function index()
    {
        $today = Carbon::today();
        $endOfWeek = Carbon::now()->endOfWeek();
        $startOfMonth = Carbon::now()->startOfMonth();

        // All tasks across all clients
        $allTasks = NexcoreClientTask::with(['client', 'steps'])->get();

        // Stats
        $totalTasks = $allTasks->count();
        $activeTasks = $allTasks->filter(fn($t) => !in_array($t->task_status, ['completed', 'cancelled']));
        $overdueTasks = $activeTasks->filter(fn($t) => $t->due_date && $t->due_date->lt($today));
        $dueThisWeek = $activeTasks->filter(fn($t) => $t->due_date && $t->due_date->gte($today) && $t->due_date->lte($endOfWeek));
        $inProgress = $allTasks->where('task_status', 'in_progress');
        $completedThisMonth = $allTasks->filter(fn($t) => $t->task_status === 'completed' && $t->completed_date && $t->completed_date->gte($startOfMonth));
        $urgentTasks = $activeTasks->where('is_urgent', true);
        $pendingTasks = $allTasks->where('task_status', 'pending');
        $reviewTasks = $allTasks->where('task_status', 'review');
        $onHoldTasks = $allTasks->where('task_status', 'on_hold');

        // Status breakdown for chart
        $statusBreakdown = [
            'pending' => $pendingTasks->count(),
            'in_progress' => $inProgress->count(),
            'review' => $reviewTasks->count(),
            'completed' => $allTasks->where('task_status', 'completed')->count(),
            'on_hold' => $onHoldTasks->count(),
            'cancelled' => $allTasks->where('task_status', 'cancelled')->count(),
        ];

        // Priority breakdown for chart
        $priorityBreakdown = [
            'urgent' => $allTasks->where('priority', 'urgent')->count(),
            'high' => $allTasks->where('priority', 'high')->count(),
            'medium' => $allTasks->where('priority', 'medium')->count(),
            'low' => $allTasks->where('priority', 'low')->count(),
        ];

        // Category breakdown
        $categoryBreakdown = $allTasks->groupBy('category')->map->count()->toArray();

        // Tasks by client
        $tasksByClient = $allTasks->groupBy(function($t) {
            return $t->client ? $t->client->company_name : 'Unknown';
        })->map(function($tasks, $clientName) {
            return [
                'name' => $clientName,
                'total' => $tasks->count(),
                'active' => $tasks->filter(fn($t) => !in_array($t->task_status, ['completed', 'cancelled']))->count(),
                'completed' => $tasks->where('task_status', 'completed')->count(),
                'client_id' => $tasks->first()->client_id,
            ];
        })->values()->sortByDesc('active')->take(10);

        // Recent activity (last 20)
        $recentActivity = NexcoreTaskActivityLog::with(['task', 'user'])
            ->orderByDesc('created_at')
            ->take(20)
            ->get();

        // Upcoming deadlines (next 7 days)
        $upcomingDeadlines = NexcoreClientTask::with('client')
            ->whereNotIn('task_status', ['completed', 'cancelled'])
            ->whereNotNull('due_date')
            ->where('due_date', '>=', $today)
            ->where('due_date', '<=', $today->copy()->addDays(7))
            ->orderBy('due_date')
            ->take(10)
            ->get();

        // Overdue tasks list
        $overdueList = NexcoreClientTask::with('client')
            ->whereNotIn('task_status', ['completed', 'cancelled'])
            ->whereNotNull('due_date')
            ->where('due_date', '<', $today)
            ->orderBy('due_date')
            ->take(10)
            ->get();

        // Team workload (tasks per assigned_to)
        $teamWorkload = $activeTasks->filter(fn($t) => $t->assigned_to)
            ->groupBy('assigned_to')
            ->map(function($tasks, $name) {
                return [
                    'name' => $name,
                    'count' => $tasks->count(),
                    'overdue' => $tasks->filter(fn($t) => $t->due_date && $t->due_date->lt(Carbon::today()))->count(),
                ];
            })->values()->sortByDesc('count');

        // All clients for navigation (for task list links)
        $clients = NexcoreClient::where('is_active', true)->orderBy('company_name')->get(['id', 'company_name', 'client_code']);

        return response(view('nexcore_client_manager::command-centre', compact(
            'totalTasks', 'activeTasks', 'overdueTasks', 'dueThisWeek',
            'inProgress', 'completedThisMonth', 'urgentTasks', 'pendingTasks',
            'statusBreakdown', 'priorityBreakdown', 'categoryBreakdown',
            'tasksByClient', 'recentActivity', 'upcomingDeadlines',
            'overdueList', 'teamWorkload', 'clients', 'allTasks'
        )))
        ->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        ->header('Pragma', 'no-cache')
        ->header('Expires', 'Sat, 01 Jan 2000 00:00:00 GMT');
    }
}
