<?php

namespace Modules\NexcoreClientManager\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Modules\NexcoreClientManager\Models\NexcoreClient;
use Modules\NexcoreClientManager\Models\NexcoreClientTask;
use Modules\NexcoreClientManager\Models\NexcoreTaskActivityLog;
use Modules\NexcoreClientManager\Models\NexcoreTaskAttachment;
use Modules\NexcoreClientManager\Models\NexcoreTaskComment;
use Modules\NexcoreClientManager\Models\NexcoreTaskNote;
use Modules\NexcoreClientManager\Models\NexcoreTaskReminder;
use Modules\NexcoreClientManager\Models\NexcoreTaskStep;

class TaskController extends Controller
{
    /* ================================================================== */
    /*  Protected Arrays (passed to views)                                 */
    /* ================================================================== */

    protected array $priorities = [
        'low' => 'Low', 'medium' => 'Medium', 'high' => 'High', 'urgent' => 'Urgent',
    ];

    protected array $taskStatuses = [
        'pending'     => 'Pending',
        'in_progress' => 'In Progress',
        'review'      => 'In Review',
        'completed'   => 'Completed',
        'on_hold'     => 'On Hold',
        'cancelled'   => 'Cancelled',
    ];

    protected array $categories = [
        'sars'       => 'SARS',
        'cipc'       => 'CIPC',
        'coida'      => 'COIDA',
        'compliance' => 'Compliance',
        'birthdays'  => 'Birthdays',
        'events'     => 'Events',
        'general'    => 'General',
        'finance'    => 'Finance',
        'hr'         => 'Human Resources',
        'operations' => 'Operations',
        'it'         => 'IT & Systems',
        'legal'      => 'Legal',
        'marketing'  => 'Marketing',
    ];

    protected array $categoryIcons = [
        'sars'       => 'fa-file-invoice-dollar',
        'cipc'       => 'fa-clipboard-check',
        'coida'      => 'fa-hard-hat',
        'compliance' => 'fa-shield-alt',
        'birthdays'  => 'fa-birthday-cake',
        'events'     => 'fa-calendar-day',
        'general'    => 'fa-tasks',
        'finance'    => 'fa-coins',
        'hr'         => 'fa-users',
        'operations' => 'fa-cogs',
        'it'         => 'fa-laptop-code',
        'legal'      => 'fa-gavel',
        'marketing'  => 'fa-bullhorn',
    ];

    protected array $categoryColors = [
        'sars'       => '#ef4444',
        'cipc'       => '#8b5cf6',
        'coida'      => '#f59e0b',
        'compliance' => '#06b6d4',
        'birthdays'  => '#ec4899',
        'events'     => '#3b82f6',
        'general'    => '#94a3b8',
        'finance'    => '#10b981',
        'hr'         => '#f97316',
        'operations' => '#0891b2',
        'it'         => '#6366f1',
        'legal'      => '#a855f7',
        'marketing'  => '#14b8a6',
    ];

    /* ================================================================== */
    /*  Private Helpers                                                     */
    /* ================================================================== */

    /**
     * Return the common data every page view needs.
     */
    private function getViewData($client): array
    {
        $teamUsers = User::where('type', 'team')
            ->where('status', 'active')
            ->orderBy('first_name')
            ->get(['id', 'first_name', 'last_name']);

        return compact('client') + [
            'priorities'     => $this->priorities,
            'taskStatuses'   => $this->taskStatuses,
            'categories'     => $this->categories,
            'categoryIcons'  => $this->categoryIcons,
            'categoryColors' => $this->categoryColors,
            'teamUsers'      => $teamUsers,
        ];
    }

    /**
     * Write a row to the task activity log.
     */
    private function logActivity(
        $taskId,
        string $action,
        ?string $description = null,
        ?string $fieldName = null,
        ?string $oldValue = null,
        ?string $newValue = null
    ): void {
        NexcoreTaskActivityLog::create([
            'task_id'    => $taskId,
            'user_id'    => auth()->id(),
            'action'     => $action,
            'field_name' => $fieldName,
            'old_value'  => $oldValue,
            'new_value'  => $newValue,
            'description'=> $description,
        ]);
    }

    /**
     * Recalculate task progress_percent from its steps.
     */
    private function recalcProgress($task): NexcoreClientTask
    {
        $total = $task->steps()->count();

        if ($total > 0) {
            $completed = $task->steps()->where('is_completed', true)->count();
            $task->update(['progress_percent' => round(($completed / $total) * 100)]);
        }

        return $task->fresh();
    }

    /**
     * Resolve the client model (abort 404 if missing).
     */
    private function resolveClient($clientId): NexcoreClient
    {
        return NexcoreClient::findOrFail($clientId);
    }

    /**
     * Resolve a task scoped to the given client (abort 404 if missing).
     */
    private function resolveTask($clientId, $taskId): NexcoreClientTask
    {
        return NexcoreClientTask::where('client_id', $clientId)->findOrFail($taskId);
    }

    /**
     * Shared validation rules for store / update.
     */
    private function taskValidationRules(): array
    {
        return [
            'title'          => 'required|max:255',
            'description'    => 'nullable',
            'category'       => 'required|in:' . implode(',', array_keys($this->categories)),
            'priority'       => 'required|in:' . implode(',', array_keys($this->priorities)),
            'task_status'    => 'required|in:' . implode(',', array_keys($this->taskStatuses)),
            'assigned_to'    => 'nullable|max:255',
            'due_date'       => 'nullable|date',
            'start_date'     => 'nullable|date',
            'completed_date' => 'nullable|date',
            'estimated_hours'=> 'nullable|numeric|min:0',
            'notes'          => 'nullable',
            'color_label'    => 'nullable|max:20',
            'is_urgent'      => 'nullable|boolean',
            'parent_task_id' => 'nullable|integer',
        ];
    }

    /* ================================================================== */
    /*  PAGE ENDPOINTS                                                     */
    /* ================================================================== */

    /**
     * 1. Task list view.
     */
    public function index($clientId)
    {
        $client = $this->resolveClient($clientId);

        $tasks = NexcoreClientTask::where('client_id', $clientId)
            ->with(['steps', 'comments', 'attachments'])
            ->orderBy('created_at', 'desc')
            ->get();

        $now       = Carbon::now();
        $weekEnd   = Carbon::now()->endOfWeek();
        $total     = $tasks->count();
        $overdue   = $tasks->filter(fn ($t) => $t->due_date && $t->due_date->lt($now) && ! in_array($t->task_status, ['completed', 'cancelled']))->count();
        $dueWeek   = $tasks->filter(fn ($t) => $t->due_date && $t->due_date->between($now, $weekEnd) && ! in_array($t->task_status, ['completed', 'cancelled']))->count();
        $inProgress = $tasks->where('task_status', 'in_progress')->count();
        $completed  = $tasks->where('task_status', 'completed')->count();

        $stats = compact('total', 'overdue', 'dueWeek', 'inProgress', 'completed');

        return view('nexcore_client_manager::tasks.index', $this->getViewData($client) + compact('tasks', 'stats'));
    }

    /**
     * 2. Task detail view.
     */
    public function show($clientId, $taskId)
    {
        $client = $this->resolveClient($clientId);

        $task = NexcoreClientTask::where('client_id', $clientId)
            ->with([
                'steps'                => fn ($q) => $q->orderBy('sort_order'),
                'comments.user'        => fn ($q) => $q,
                'comments'             => fn ($q) => $q->orderBy('created_at', 'desc'),
                'attachments'          => fn ($q) => $q->orderBy('created_at', 'desc'),
                'notes.user'           => fn ($q) => $q,
                'notes'                => fn ($q) => $q->orderBy('is_pinned', 'desc')->orderBy('created_at', 'desc'),
                'activityLog.user'     => fn ($q) => $q,
                'activityLog'          => fn ($q) => $q->orderBy('created_at', 'desc'),
                'reminders',
                'subtasks',
            ])
            ->findOrFail($taskId);

        return view('nexcore_client_manager::tasks.show', $this->getViewData($client) + compact('task'));
    }

    /**
     * 3. Create form.
     */
    public function create($clientId)
    {
        $client = $this->resolveClient($clientId);

        return view('nexcore_client_manager::tasks.form', $this->getViewData($client));
    }

    /**
     * 4. Store a new task.
     */
    public function store(Request $request, $clientId)
    {
        $client   = $this->resolveClient($clientId);
        $validated = $request->validate($this->taskValidationRules());

        $task = NexcoreClientTask::create(array_merge($validated, [
            'client_id'  => $clientId,
            'is_active'  => true,
            'created_by' => auth()->id(),
            'updated_by' => auth()->id(),
        ]));

        $this->logActivity($task->id, 'created', "Task created: {$task->title}");

        return redirect()
            ->route('nexcore.clients.tasks.show', [$clientId, $task->id])
            ->with('success', 'Task created successfully.');
    }

    /**
     * 5. Edit form.
     */
    public function edit($clientId, $taskId)
    {
        $client = $this->resolveClient($clientId);
        $task   = $this->resolveTask($clientId, $taskId);

        return view('nexcore_client_manager::tasks.form', $this->getViewData($client) + compact('task'));
    }

    /**
     * 6. Update an existing task.
     */
    public function update(Request $request, $clientId, $taskId)
    {
        $client   = $this->resolveClient($clientId);
        $task     = $this->resolveTask($clientId, $taskId);
        $validated = $request->validate($this->taskValidationRules());

        // Track field changes for the activity log
        $trackable = [
            'title', 'description', 'category', 'priority', 'task_status',
            'assigned_to', 'due_date', 'start_date', 'completed_date',
            'estimated_hours', 'notes', 'color_label', 'is_urgent', 'parent_task_id',
        ];

        foreach ($trackable as $field) {
            $oldVal = (string) $task->{$field};
            $newVal = (string) ($validated[$field] ?? '');

            if ($oldVal !== $newVal) {
                $this->logActivity(
                    $task->id,
                    'updated',
                    "Changed {$field}",
                    $field,
                    $oldVal ?: null,
                    $newVal ?: null
                );
            }
        }

        // Auto-set completed_date when status changes to 'completed'
        if (($validated['task_status'] ?? null) === 'completed' && $task->task_status !== 'completed') {
            $validated['completed_date'] = Carbon::now()->toDateString();
        }

        // Auto-clear completed_date when status moves away from 'completed'
        if (($validated['task_status'] ?? null) !== 'completed' && $task->task_status === 'completed') {
            $validated['completed_date'] = null;
        }

        $validated['updated_by'] = auth()->id();

        $task->update($validated);

        return redirect()
            ->route('nexcore.clients.tasks.show', [$clientId, $task->id])
            ->with('success', 'Task updated successfully.');
    }

    /**
     * 7. Delete (soft-delete) a task.
     */
    public function destroy($clientId, $taskId)
    {
        $task = $this->resolveTask($clientId, $taskId);

        $this->logActivity($task->id, 'deleted', "Task deleted: {$task->title}");

        $task->delete(); // SoftDeletes

        return redirect()
            ->route('nexcore.clients.tasks.index', $clientId)
            ->with('success', 'Task deleted successfully.');
    }

    /**
     * 8. Kanban board view.
     */
    public function kanban($clientId)
    {
        $client = $this->resolveClient($clientId);

        $tasks = NexcoreClientTask::where('client_id', $clientId)
            ->with(['steps', 'comments', 'attachments'])
            ->orderBy('sort_order')
            ->orderBy('created_at', 'desc')
            ->get();

        $columns = [];
        foreach ($this->taskStatuses as $key => $label) {
            $columns[$key] = $tasks->where('task_status', $key)->values();
        }

        return view('nexcore_client_manager::tasks.kanban', $this->getViewData($client) + compact('columns'));
    }

    /**
     * 9. Kanban drag-drop update (AJAX).
     */
    public function kanbanUpdate(Request $request, $clientId, $taskId): JsonResponse
    {
        $request->validate([
            'task_status' => 'required|in:' . implode(',', array_keys($this->taskStatuses)),
        ]);

        $task      = $this->resolveTask($clientId, $taskId);
        $oldStatus = $task->task_status;
        $newStatus = $request->input('task_status');

        $updateData = ['task_status' => $newStatus, 'updated_by' => auth()->id()];

        // Auto-set completed_date when moved to 'completed'
        if ($newStatus === 'completed' && $oldStatus !== 'completed') {
            $updateData['completed_date'] = Carbon::now()->toDateString();
        }

        // Auto-clear completed_date when moved away from 'completed'
        if ($newStatus !== 'completed' && $oldStatus === 'completed') {
            $updateData['completed_date'] = null;
        }

        $task->update($updateData);

        $this->logActivity(
            $task->id,
            'status_changed',
            'Status changed via Kanban board',
            'task_status',
            $oldStatus,
            $newStatus
        );

        return response()->json([
            'success' => true,
            'message' => 'Task status updated to ' . ($this->taskStatuses[$newStatus] ?? $newStatus) . '.',
        ]);
    }

    /**
     * 10. Calendar view.
     */
    public function calendar($clientId)
    {
        $client = $this->resolveClient($clientId);

        $tasks = NexcoreClientTask::where('client_id', $clientId)
            ->whereNotNull('due_date')
            ->orderBy('due_date')
            ->get();

        return view('nexcore_client_manager::tasks.calendar', $this->getViewData($client) + compact('tasks'));
    }

    /**
     * 11. Printable job card.
     */
    public function jobcard($clientId, $taskId)
    {
        $client = $this->resolveClient($clientId);

        $task = NexcoreClientTask::where('client_id', $clientId)
            ->with([
                'steps'            => fn ($q) => $q->orderBy('sort_order'),
                'comments.user',
                'attachments',
                'notes.user',
                'activityLog.user' => fn ($q) => $q,
                'activityLog'      => fn ($q) => $q->orderBy('created_at', 'desc'),
                'reminders',
                'subtasks',
            ])
            ->findOrFail($taskId);

        return view('nexcore_client_manager::tasks.jobcard', $this->getViewData($client) + compact('task'));
    }

    /* ================================================================== */
    /*  STEPS (Checklist) - AJAX                                           */
    /* ================================================================== */

    /**
     * 12. Add a checklist step.
     */
    public function storeStep(Request $request, $clientId, $taskId): JsonResponse
    {
        $request->validate(['title' => 'required|max:255']);

        $task = $this->resolveTask($clientId, $taskId);

        $maxSort = $task->steps()->max('sort_order') ?? 0;

        $step = NexcoreTaskStep::create([
            'task_id'    => $task->id,
            'title'      => $request->input('title'),
            'sort_order' => $maxSort + 1,
        ]);

        $this->logActivity($task->id, 'step_added', "Step added: {$step->title}");

        $task = $this->recalcProgress($task);

        return response()->json([
            'success'  => true,
            'message'  => 'Step added.',
            'step'     => $step,
            'progress' => $task->progress_percent,
        ]);
    }

    /**
     * 13. Toggle step completion.
     */
    public function toggleStep(Request $request, $clientId, $taskId, $stepId): JsonResponse
    {
        $task = $this->resolveTask($clientId, $taskId);
        $step = NexcoreTaskStep::where('task_id', $task->id)->findOrFail($stepId);

        $wasCompleted = $step->is_completed;

        $step->update([
            'is_completed' => ! $wasCompleted,
            'completed_by' => $wasCompleted ? null : auth()->id(),
            'completed_at' => $wasCompleted ? null : Carbon::now(),
        ]);

        $action = $wasCompleted ? 'step_unchecked' : 'step_completed';
        $this->logActivity($task->id, $action, "Step {$action}: {$step->title}");

        $task = $this->recalcProgress($task);

        return response()->json([
            'success'  => true,
            'message'  => 'Step updated.',
            'step'     => $step->fresh(),
            'progress' => $task->progress_percent,
        ]);
    }

    /**
     * 14. Delete a step.
     */
    public function destroyStep($clientId, $taskId, $stepId): JsonResponse
    {
        $task = $this->resolveTask($clientId, $taskId);
        $step = NexcoreTaskStep::where('task_id', $task->id)->findOrFail($stepId);

        $this->logActivity($task->id, 'step_deleted', "Step deleted: {$step->title}");

        $step->delete();

        $task = $this->recalcProgress($task);

        return response()->json([
            'success'  => true,
            'message'  => 'Step removed.',
            'progress' => $task->progress_percent,
        ]);
    }

    /**
     * 15. Reorder steps via drag-drop.
     */
    public function reorderSteps(Request $request, $clientId, $taskId): JsonResponse
    {
        $request->validate([
            'order'   => 'required|array',
            'order.*' => 'required|integer',
        ]);

        $task = $this->resolveTask($clientId, $taskId);

        foreach ($request->input('order') as $position => $stepId) {
            NexcoreTaskStep::where('task_id', $task->id)
                ->where('id', $stepId)
                ->update(['sort_order' => $position]);
        }

        return response()->json([
            'success' => true,
            'message' => 'Steps reordered.',
        ]);
    }

    /* ================================================================== */
    /*  COMMENTS - AJAX                                                    */
    /* ================================================================== */

    /**
     * 16. Add a comment.
     */
    public function storeComment(Request $request, $clientId, $taskId): JsonResponse
    {
        $request->validate([
            'comment'     => 'required',
            'parent_id'   => 'nullable|integer',
            'is_internal' => 'nullable|boolean',
        ]);

        $task = $this->resolveTask($clientId, $taskId);

        $comment = NexcoreTaskComment::create([
            'task_id'     => $task->id,
            'user_id'     => auth()->id(),
            'comment'     => $request->input('comment'),
            'parent_id'   => $request->input('parent_id'),
            'is_internal' => $request->boolean('is_internal', false),
        ]);

        $this->logActivity($task->id, 'comment_added', 'Comment added');

        $user = auth()->user();

        return response()->json([
            'success' => true,
            'message' => 'Comment added.',
            'comment' => [
                'id'          => $comment->id,
                'comment'     => $comment->comment,
                'parent_id'   => $comment->parent_id,
                'is_internal' => $comment->is_internal,
                'created_at'  => $comment->created_at->toDateTimeString(),
                'user_name'   => $user ? trim($user->first_name . ' ' . $user->last_name) : 'System',
            ],
        ]);
    }

    /**
     * 17. Delete a comment (soft-delete).
     */
    public function destroyComment($clientId, $taskId, $commentId): JsonResponse
    {
        $task    = $this->resolveTask($clientId, $taskId);
        $comment = NexcoreTaskComment::where('task_id', $task->id)->findOrFail($commentId);

        $comment->delete(); // SoftDeletes

        return response()->json([
            'success' => true,
            'message' => 'Comment removed.',
        ]);
    }

    /* ================================================================== */
    /*  ATTACHMENTS - AJAX                                                 */
    /* ================================================================== */

    /**
     * 18. Upload an attachment.
     */
    public function storeAttachment(Request $request, $clientId, $taskId): JsonResponse
    {
        $request->validate([
            'file'        => 'required|file|max:20480',
            'description' => 'nullable|max:500',
        ]);

        $task = $this->resolveTask($clientId, $taskId);
        $file = $request->file('file');

        $originalName = $file->getClientOriginalName();
        $ext          = $file->getClientOriginalExtension();
        $fileName     = time() . '_' . Str::slug(pathinfo($originalName, PATHINFO_FILENAME)) . '.' . $ext;

        $destinationPath = public_path('uploads/tasks/' . $task->id);
        $file->move($destinationPath, $fileName);

        $attachment = NexcoreTaskAttachment::create([
            'task_id'     => $task->id,
            'uploaded_by' => auth()->id(),
            'file_name'   => $originalName,
            'file_path'   => 'uploads/tasks/' . $task->id . '/' . $fileName,
            'file_size'   => filesize($destinationPath . '/' . $fileName),
            'file_type'   => $file->getClientMimeType() ?? mime_content_type($destinationPath . '/' . $fileName),
            'description' => $request->input('description'),
        ]);

        $this->logActivity($task->id, 'attachment_added', "File uploaded: {$originalName}");

        return response()->json([
            'success'    => true,
            'message'    => 'File uploaded.',
            'attachment' => $attachment,
        ]);
    }

    /**
     * 19. Delete an attachment (file + record).
     */
    public function destroyAttachment($clientId, $taskId, $attachmentId): JsonResponse
    {
        $task       = $this->resolveTask($clientId, $taskId);
        $attachment = NexcoreTaskAttachment::where('task_id', $task->id)->findOrFail($attachmentId);

        // Remove file from disk
        $fullPath = public_path($attachment->file_path);
        if (file_exists($fullPath)) {
            @unlink($fullPath);
        }

        $this->logActivity($task->id, 'attachment_deleted', "File deleted: {$attachment->file_name}");

        $attachment->delete();

        return response()->json([
            'success' => true,
            'message' => 'Attachment removed.',
        ]);
    }

    /* ================================================================== */
    /*  NOTES - AJAX                                                       */
    /* ================================================================== */

    /**
     * 20. Add a note.
     */
    public function storeNote(Request $request, $clientId, $taskId): JsonResponse
    {
        $request->validate([
            'title'   => 'required|max:255',
            'content' => 'required',
        ]);

        $task = $this->resolveTask($clientId, $taskId);

        $note = NexcoreTaskNote::create([
            'task_id' => $task->id,
            'user_id' => auth()->id(),
            'title'   => $request->input('title'),
            'content' => $request->input('content'),
        ]);

        $this->logActivity($task->id, 'note_added', "Note added: {$note->title}");

        $user = auth()->user();

        return response()->json([
            'success' => true,
            'message' => 'Note added.',
            'note'    => [
                'id'         => $note->id,
                'title'      => $note->title,
                'content'    => $note->content,
                'is_pinned'  => $note->is_pinned,
                'created_at' => $note->created_at->toDateTimeString(),
                'user_name'  => $user ? trim($user->first_name . ' ' . $user->last_name) : 'System',
            ],
        ]);
    }

    /**
     * 21. Update a note.
     */
    public function updateNote(Request $request, $clientId, $taskId, $noteId): JsonResponse
    {
        $request->validate([
            'title'   => 'required|max:255',
            'content' => 'required',
        ]);

        $task = $this->resolveTask($clientId, $taskId);
        $note = NexcoreTaskNote::where('task_id', $task->id)->findOrFail($noteId);

        $note->update([
            'title'   => $request->input('title'),
            'content' => $request->input('content'),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Note updated.',
            'note'    => $note->fresh(),
        ]);
    }

    /**
     * 22. Delete a note (soft-delete).
     */
    public function destroyNote($clientId, $taskId, $noteId): JsonResponse
    {
        $task = $this->resolveTask($clientId, $taskId);
        $note = NexcoreTaskNote::where('task_id', $task->id)->findOrFail($noteId);

        $note->delete(); // SoftDeletes

        return response()->json([
            'success' => true,
            'message' => 'Note removed.',
        ]);
    }

    /**
     * 23. Toggle note pin.
     */
    public function toggleNotePin(Request $request, $clientId, $taskId, $noteId): JsonResponse
    {
        $task = $this->resolveTask($clientId, $taskId);
        $note = NexcoreTaskNote::where('task_id', $task->id)->findOrFail($noteId);

        $note->update(['is_pinned' => ! $note->is_pinned]);

        return response()->json([
            'success'   => true,
            'message'   => $note->is_pinned ? 'Note pinned.' : 'Note unpinned.',
            'is_pinned' => $note->fresh()->is_pinned,
        ]);
    }

    /* ================================================================== */
    /*  REMINDERS - AJAX                                                   */
    /* ================================================================== */

    /**
     * 24. Add a reminder.
     */
    public function storeReminder(Request $request, $clientId, $taskId): JsonResponse
    {
        $request->validate([
            'remind_at' => 'required|date',
            'message'   => 'nullable|max:500',
        ]);

        $task = $this->resolveTask($clientId, $taskId);

        $reminder = NexcoreTaskReminder::create([
            'task_id'   => $task->id,
            'user_id'   => auth()->id(),
            'remind_at' => $request->input('remind_at'),
            'message'   => $request->input('message'),
        ]);

        return response()->json([
            'success'  => true,
            'message'  => 'Reminder set.',
            'reminder' => $reminder,
        ]);
    }

    /**
     * 25. Delete a reminder.
     */
    public function destroyReminder($clientId, $taskId, $reminderId): JsonResponse
    {
        $task     = $this->resolveTask($clientId, $taskId);
        $reminder = NexcoreTaskReminder::where('task_id', $task->id)->findOrFail($reminderId);

        $reminder->delete();

        return response()->json([
            'success' => true,
            'message' => 'Reminder removed.',
        ]);
    }

    /* ================================================================== */
    /*  PROGRESS - AJAX                                                    */
    /* ================================================================== */

    /**
     * 26. Manual progress update.
     */
    public function updateProgress(Request $request, $clientId, $taskId): JsonResponse
    {
        $request->validate([
            'progress_percent' => 'required|integer|min:0|max:100',
        ]);

        $task = $this->resolveTask($clientId, $taskId);

        $oldProgress = $task->progress_percent;
        $newProgress = $request->input('progress_percent');

        $task->update([
            'progress_percent' => $newProgress,
            'updated_by'       => auth()->id(),
        ]);

        $this->logActivity(
            $task->id,
            'progress_updated',
            "Progress updated from {$oldProgress}% to {$newProgress}%",
            'progress_percent',
            (string) $oldProgress,
            (string) $newProgress
        );

        return response()->json([
            'success'  => true,
            'message'  => 'Progress updated.',
            'progress' => (int) $newProgress,
        ]);
    }
}
