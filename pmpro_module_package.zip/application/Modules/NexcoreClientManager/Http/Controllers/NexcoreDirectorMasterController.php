<?php

namespace Modules\NexcoreClientManager\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\NexcoreClientManager\Models\NexcoreClient;
use Modules\NexcoreClientManager\Models\NexcoreDirector;
use Modules\NexcoreClientManager\Models\NexcoreDirectorContact;
use Modules\NexcoreClientManager\Models\NexcoreDirectorBankAccount;
use Modules\NexcoreClientManager\Models\NexcoreAddress;
use Modules\NexcoreClientManager\Models\NexcoreDirectorAddress;
use Modules\NexcoreClientManager\Models\NexcoreDirectorCompany;
use Modules\NexcoreClientManager\Models\NexcoreDirectorAuditLog;

class NexcoreDirectorMasterController extends Controller
{
    public function index($clientId)
    {
        $client = NexcoreClient::with(['companyType', 'companyStatus', 'industry', 'sicCode', 'beeStatus'])->findOrFail($clientId);

        $linkedDirectorIds = NexcoreDirectorCompany::where('client_id', $clientId)
            ->whereNull('deleted_at')
            ->pluck('director_id');

        $directors = NexcoreDirector::with(['contact', 'bankAccounts', 'addresses.address', 'companies.client'])
            ->whereIn('id', $linkedDirectorIds)
            ->orderBy('surname')
            ->get();

        return view('nexcore_client_manager::director-master.index', compact('client', 'directors'));
    }

    public function search(Request $request)
    {
        $searchBy = $request->input('search_by', 'id_number');
        $searchVal = $request->input('search_value', '');

        if (!$searchVal) {
            return response()->json(['found' => false, 'message' => 'No search value provided.']);
        }

        $query = NexcoreDirector::with(['contact', 'bankAccounts', 'addresses.address', 'companies.client']);

        if ($searchBy === 'id_number') {
            $query->where('id_number', $searchVal);
        } else {
            $query->where('passport_number', $searchVal);
        }

        $director = $query->first();

        if ($director) {
            return response()->json([
                'found' => true,
                'director' => $this->formatDirectorForForm($director),
            ]);
        }

        return response()->json(['found' => false, 'message' => 'Director not found.']);
    }

    public function store(Request $request, $clientId)
    {
        $client = NexcoreClient::findOrFail($clientId);

        $request->validate([
            'first_name' => 'required|string|max:100',
            'surname' => 'required|string|max:100',
            'id_number' => 'nullable|string|max:20|unique:nexcore_directors,id_number',
        ]);

        try {
            \DB::beginTransaction();

            $director = NexcoreDirector::create([
                'personal_title' => $request->personal_title,
                'first_name' => strtoupper($request->first_name),
                'middle_name' => $request->middle_name ? strtoupper($request->middle_name) : null,
                'known_as' => $request->known_as,
                'initials' => $request->initials ? strtoupper($request->initials) : null,
                'surname' => strtoupper($request->surname),
                'date_of_birth' => $request->date_of_birth,
                'ethnic_group' => $request->ethnic_group,
                'gender' => $request->gender,
                'director_status' => $request->director_status ?? 'Active',
                'marital_status' => $request->marital_status,
                'partner_initials' => $request->partner_initials,
                'partner_id_number' => $request->partner_id_number,
                'marriage_date' => $request->marriage_date,
                'id_number' => $request->id_number,
                'passport_number' => $request->passport_number,
                'passport_expiry' => $request->passport_expiry,
                'tax_number' => $request->tax_number,
                'is_sa_citizen' => $request->boolean('is_sa_citizen', true),
                'country_of_origin' => $request->country_of_origin ?? 'South Africa',
                'is_active' => true,
                'created_by' => auth()->id(),
                'updated_by' => auth()->id(),
            ]);

            if ($request->hasFile('director_photo')) {
                $photo = $request->file('director_photo');
                $filename = 'director_' . $director->id . '_' . time() . '.' . $photo->getClientOriginalExtension();
                $photo->move(base_path('../uploads/persons/'), $filename);
                $director->update(['director_photo' => 'uploads/persons/' . $filename]);
            }

            NexcoreDirectorContact::create([
                'director_id' => $director->id,
                'mobile_number' => $request->mobile_number,
                'whatsapp_number' => $request->whatsapp_number,
                'email_address' => $request->email_address,
                'sars_login' => $request->sars_login,
                'sars_password' => $request->sars_password,
                'is_active' => true,
                'created_by' => auth()->id(),
                'updated_by' => auth()->id(),
            ]);

            $this->saveBankAccounts($director->id, $request);
            $this->saveAddressLinks($director->id, $request);

            NexcoreDirectorCompany::create([
                'director_id' => $director->id,
                'client_id' => $clientId,
                'title' => $request->employment_title,
                'occupation_level' => $request->occupation_level,
                'appointment_date' => $request->appointment_date ?? now(),
                'is_active' => true,
                'created_by' => auth()->id(),
                'updated_by' => auth()->id(),
            ]);

            $this->logAudit($director->id, 'created', 'nexcore_directors');

            \DB::commit();

            return response()->json(['success' => true, 'message' => 'Director added successfully.', 'director_id' => $director->id]);

        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json(['success' => false, 'message' => 'Error: ' . $e->getMessage()], 422);
        }
    }

    public function update(Request $request, $clientId, $directorId)
    {
        $client = NexcoreClient::findOrFail($clientId);
        $director = NexcoreDirector::findOrFail($directorId);

        $request->validate([
            'first_name' => 'required|string|max:100',
            'surname' => 'required|string|max:100',
            'id_number' => 'nullable|string|max:20|unique:nexcore_directors,id_number,' . $director->id,
        ]);

        try {
            \DB::beginTransaction();

            $oldValues = $director->toArray();

            $director->update([
                'personal_title' => $request->personal_title,
                'first_name' => strtoupper($request->first_name),
                'middle_name' => $request->middle_name ? strtoupper($request->middle_name) : null,
                'known_as' => $request->known_as,
                'initials' => $request->initials ? strtoupper($request->initials) : null,
                'surname' => strtoupper($request->surname),
                'date_of_birth' => $request->date_of_birth,
                'ethnic_group' => $request->ethnic_group,
                'gender' => $request->gender,
                'director_status' => $request->director_status,
                'marital_status' => $request->marital_status,
                'partner_initials' => $request->partner_initials,
                'partner_id_number' => $request->partner_id_number,
                'marriage_date' => $request->marriage_date,
                'id_number' => $request->id_number,
                'passport_number' => $request->passport_number,
                'passport_expiry' => $request->passport_expiry,
                'tax_number' => $request->tax_number,
                'is_sa_citizen' => $request->boolean('is_sa_citizen', true),
                'country_of_origin' => $request->country_of_origin ?? 'South Africa',
                'updated_by' => auth()->id(),
            ]);

            if ($request->hasFile('director_photo')) {
                if ($director->director_photo && file_exists(base_path('../' . $director->director_photo))) {
                    @unlink(base_path('../' . $director->director_photo));
                }
                $photo = $request->file('director_photo');
                $filename = 'director_' . $director->id . '_' . time() . '.' . $photo->getClientOriginalExtension();
                $photo->move(base_path('../uploads/persons/'), $filename);
                $director->update(['director_photo' => 'uploads/persons/' . $filename]);
            }

            $contact = NexcoreDirectorContact::firstOrNew(['director_id' => $director->id]);
            $contact->fill([
                'mobile_number' => $request->mobile_number,
                'whatsapp_number' => $request->whatsapp_number,
                'email_address' => $request->email_address,
                'sars_login' => $request->sars_login,
                'sars_password' => $request->sars_password,
                'is_active' => true,
                'updated_by' => auth()->id(),
            ]);
            if (!$contact->exists) {
                $contact->created_by = auth()->id();
            }
            $contact->save();

            $this->saveBankAccounts($director->id, $request);
            $this->saveAddressLinks($director->id, $request);

            $companyLink = NexcoreDirectorCompany::where('director_id', $director->id)
                ->where('client_id', $clientId)
                ->first();

            if ($companyLink) {
                $companyLink->update([
                    'title' => $request->employment_title,
                    'occupation_level' => $request->occupation_level,
                    'updated_by' => auth()->id(),
                ]);
            }

            $this->logChanges($director->id, $oldValues, $director->fresh()->toArray());

            \DB::commit();

            return response()->json(['success' => true, 'message' => 'Director updated successfully.']);

        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json(['success' => false, 'message' => 'Error: ' . $e->getMessage()], 422);
        }
    }

    public function linkToClient(Request $request, $clientId)
    {
        $client = NexcoreClient::findOrFail($clientId);
        $director = NexcoreDirector::findOrFail($request->director_id);

        $existing = NexcoreDirectorCompany::where('director_id', $director->id)
            ->where('client_id', $clientId)
            ->first();

        if ($existing) {
            if ($existing->trashed()) {
                $existing->restore();
                $existing->update(['is_active' => true, 'updated_by' => auth()->id()]);
            }
            return response()->json(['success' => true, 'message' => 'Director already linked to this company.']);
        }

        NexcoreDirectorCompany::create([
            'director_id' => $director->id,
            'client_id' => $clientId,
            'title' => $request->title,
            'occupation_level' => $request->occupation_level,
            'appointment_date' => $request->appointment_date ?? now(),
            'is_active' => true,
            'created_by' => auth()->id(),
            'updated_by' => auth()->id(),
        ]);

        $this->logAudit($director->id, 'linked', 'nexcore_director_companies', 'client_id', null, $clientId);

        return response()->json(['success' => true, 'message' => 'Director linked to company successfully.']);
    }

    public function unlinkFromClient($clientId, $directorId)
    {
        $link = NexcoreDirectorCompany::where('director_id', $directorId)
            ->where('client_id', $clientId)
            ->firstOrFail();

        $link->update(['is_active' => false, 'updated_by' => auth()->id()]);
        $link->delete();

        $this->logAudit($directorId, 'unlinked', 'nexcore_director_companies', 'client_id', $clientId, null);

        return response()->json(['success' => true, 'message' => 'Director unlinked from company.']);
    }

    public function getDirector($directorId)
    {
        $director = NexcoreDirector::with(['contact', 'bankAccounts', 'addresses.address', 'companies.client'])
            ->findOrFail($directorId);

        return response()->json(['director' => $this->formatDirectorForForm($director)]);
    }

    public function getAddresses()
    {
        $addresses = NexcoreAddress::where('is_active', true)
            ->whereNull('deleted_at')
            ->orderBy('city')
            ->get();

        return response()->json(['addresses' => $addresses]);
    }

    public function storeAddress(Request $request)
    {
        $request->validate([
            'address_1' => 'required|string|max:200',
            'city' => 'required|string|max:100',
            'postal_code' => 'required|string|max:15',
        ]);

        $address = NexcoreAddress::create([
            'address_1' => strtoupper($request->address_1),
            'address_2' => $request->address_2 ? strtoupper($request->address_2) : null,
            'city' => strtoupper($request->city),
            'province' => $request->province,
            'postal_code' => $request->postal_code,
            'country' => $request->country ?? 'South Africa',
            'is_active' => true,
            'created_by' => auth()->id(),
            'updated_by' => auth()->id(),
        ]);

        return response()->json(['success' => true, 'address' => $address]);
    }

    private function saveBankAccounts($directorId, Request $request)
    {
        $bankAccounts = $request->input('bank_accounts', []);
        if (!is_array($bankAccounts)) {
            $bankAccounts = json_decode($bankAccounts, true) ?? [];
        }

        NexcoreDirectorBankAccount::where('director_id', $directorId)->delete();

        foreach ($bankAccounts as $acc) {
            NexcoreDirectorBankAccount::create([
                'director_id' => $directorId,
                'bank_name' => $acc['bank_name'],
                'account_type' => $acc['account_type'],
                'account_holder' => $acc['account_holder'],
                'account_number' => $acc['account_number'],
                'is_primary' => !empty($acc['is_primary']),
                'is_active' => true,
                'created_by' => auth()->id(),
                'updated_by' => auth()->id(),
            ]);
        }
    }

    private function saveAddressLinks($directorId, Request $request)
    {
        $addressLinks = $request->input('address_links', []);
        if (!is_array($addressLinks)) {
            $addressLinks = json_decode($addressLinks, true) ?? [];
        }

        NexcoreDirectorAddress::where('director_id', $directorId)->delete();

        foreach ($addressLinks as $link) {
            NexcoreDirectorAddress::create([
                'director_id' => $directorId,
                'address_id' => $link['address_id'],
                'address_type' => $link['link_type'],
                'is_active' => true,
                'created_by' => auth()->id(),
                'updated_by' => auth()->id(),
            ]);
        }
    }

    private function formatDirectorForForm($director)
    {
        $contact = $director->contact;
        $companyLink = $director->companies->first();

        return [
            'id' => $director->id,
            'personal_title' => $director->personal_title,
            'first_name' => $director->first_name,
            'middle_name' => $director->middle_name,
            'known_as' => $director->known_as,
            'initials' => $director->initials,
            'surname' => $director->surname,
            'date_of_birth' => $director->date_of_birth ? $director->date_of_birth->format('Y-m-d') : null,
            'ethnic_group' => $director->ethnic_group,
            'gender' => $director->gender,
            'director_status' => $director->director_status,
            'marital_status' => $director->marital_status,
            'partner_initials' => $director->partner_initials,
            'partner_id_number' => $director->partner_id_number,
            'marriage_date' => $director->marriage_date ? $director->marriage_date->format('Y-m-d') : null,
            'id_number' => $director->id_number,
            'passport_number' => $director->passport_number,
            'passport_expiry' => $director->passport_expiry ? $director->passport_expiry->format('Y-m-d') : null,
            'tax_number' => $director->tax_number,
            'is_sa_citizen' => $director->is_sa_citizen,
            'country_of_origin' => $director->country_of_origin,
            'director_photo' => $director->director_photo ? '/' . $director->director_photo : null,
            'mobile_number' => $contact->mobile_number ?? null,
            'whatsapp_number' => $contact->whatsapp_number ?? null,
            'email_address' => $contact->email_address ?? null,
            'sars_login' => $contact->sars_login ?? null,
            'sars_password' => $contact->sars_password ?? null,
            'employment_title' => $companyLink->title ?? null,
            'occupation_level' => $companyLink->occupation_level ?? null,
            'bank_accounts' => $director->bankAccounts->map(function ($ba) {
                return [
                    'id' => $ba->id,
                    'bank_name' => $ba->bank_name,
                    'account_type' => $ba->account_type,
                    'account_holder' => $ba->account_holder,
                    'account_number' => $ba->account_number,
                    'is_primary' => $ba->is_primary,
                ];
            })->values()->toArray(),
            'linked_addresses' => $director->addresses->map(function ($da) {
                return [
                    'address_id' => $da->address_id,
                    'link_type' => $da->address_type,
                    'address' => $da->address ? $da->address->toArray() : null,
                ];
            })->values()->toArray(),
            'companies' => $director->companies->map(function ($dc) {
                return [
                    'id' => $dc->id,
                    'client_id' => $dc->client_id,
                    'company_name' => $dc->client->company_name ?? 'Unknown',
                    'title' => $dc->title,
                    'appointment_date' => $dc->appointment_date ? $dc->appointment_date->format('Y-m-d') : null,
                ];
            })->values()->toArray(),
        ];
    }

    private function logAudit($directorId, $action, $table = null, $field = null, $old = null, $new = null)
    {
        NexcoreDirectorAuditLog::create([
            'director_id' => $directorId,
            'action' => $action,
            'table_name' => $table,
            'field_name' => $field,
            'old_value' => $old,
            'new_value' => $new,
            'performed_by' => auth()->id(),
        ]);
    }

    private function logChanges($directorId, $oldValues, $newValues)
    {
        $tracked = ['personal_title', 'first_name', 'middle_name', 'known_as', 'initials', 'surname',
            'date_of_birth', 'ethnic_group', 'gender', 'director_status', 'marital_status',
            'id_number', 'passport_number', 'tax_number', 'is_sa_citizen', 'country_of_origin'];

        foreach ($tracked as $field) {
            $old = $oldValues[$field] ?? null;
            $new = $newValues[$field] ?? null;
            if ((string) $old !== (string) $new) {
                $this->logAudit($directorId, 'updated', 'nexcore_directors', $field, $old, $new);
            }
        }
    }
}
