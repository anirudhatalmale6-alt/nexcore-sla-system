<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class NexcoreDirectorBankAccount extends Model
{
    use SoftDeletes;

    protected $table = 'nexcore_director_bank_accounts';

    protected $fillable = [
        'director_id', 'bank_name', 'account_type', 'account_holder',
        'account_number', 'is_primary',
        'is_active', 'created_by', 'updated_by',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'is_primary' => 'boolean',
    ];

    public function director()
    {
        return $this->belongsTo(NexcoreDirector::class, 'director_id');
    }
}
