<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class NexcoreDirectorCompany extends Model
{
    use SoftDeletes;

    protected $table = 'nexcore_director_companies';

    protected $fillable = [
        'director_id', 'client_id', 'title', 'occupation_level',
        'appointment_date', 'resignation_date',
        'is_active', 'created_by', 'updated_by',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'appointment_date' => 'date',
        'resignation_date' => 'date',
    ];

    public function director()
    {
        return $this->belongsTo(NexcoreDirector::class, 'director_id');
    }

    public function client()
    {
        return $this->belongsTo(NexcoreClient::class, 'client_id');
    }
}
