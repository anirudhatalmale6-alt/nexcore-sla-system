<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class NexcoreDirectorContact extends Model
{
    use SoftDeletes;

    protected $table = 'nexcore_director_contacts';

    protected $fillable = [
        'director_id', 'mobile_number', 'whatsapp_number', 'email_address',
        'sars_login', 'sars_password',
        'is_active', 'created_by', 'updated_by',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function director()
    {
        return $this->belongsTo(NexcoreDirector::class, 'director_id');
    }
}
