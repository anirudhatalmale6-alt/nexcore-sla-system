<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class NexcoreDirectorAddress extends Model
{
    use SoftDeletes;

    protected $table = 'nexcore_director_addresses';

    protected $fillable = [
        'director_id', 'address_id', 'address_type',
        'is_active', 'created_by', 'updated_by',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function director()
    {
        return $this->belongsTo(NexcoreDirector::class, 'director_id');
    }

    public function address()
    {
        return $this->belongsTo(NexcoreAddress::class, 'address_id');
    }
}
