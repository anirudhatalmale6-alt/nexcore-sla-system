<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;

class NexcoreDirectorAuditLog extends Model
{
    public $timestamps = false;

    protected $table = 'nexcore_director_audit_log';

    protected $fillable = [
        'director_id', 'action', 'table_name', 'field_name',
        'old_value', 'new_value', 'performed_by',
    ];

    protected $casts = [
        'created_at' => 'datetime',
    ];

    public function director()
    {
        return $this->belongsTo(NexcoreDirector::class, 'director_id');
    }
}
