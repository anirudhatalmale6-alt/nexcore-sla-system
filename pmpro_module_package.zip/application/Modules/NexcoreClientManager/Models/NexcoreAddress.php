<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class NexcoreAddress extends Model
{
    use SoftDeletes;

    protected $table = 'nexcore_addresses';

    protected $fillable = [
        'address_1', 'address_2', 'city', 'province', 'postal_code', 'country',
        'is_active', 'created_by', 'updated_by',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function getFullAddressAttribute()
    {
        return collect([$this->address_1, $this->address_2, $this->city, $this->province, $this->postal_code, $this->country])
            ->filter()->implode(', ');
    }

    public function directorLinks()
    {
        return $this->hasMany(NexcoreDirectorAddress::class, 'address_id');
    }
}
