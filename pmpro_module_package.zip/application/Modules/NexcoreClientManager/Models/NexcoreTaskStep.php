<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;

class NexcoreTaskStep extends Model
{
    protected $table = 'nexcore_task_steps';

    protected $fillable = [
        'task_id',
        'title',
        'is_completed',
        'completed_by',
        'completed_at',
        'sort_order',
    ];

    protected $casts = [
        'is_completed' => 'boolean',
        'completed_at' => 'datetime',
    ];

    /* ------------------------------------------------------------------ */
    /*  Relationships                                                      */
    /* ------------------------------------------------------------------ */

    public function task()
    {
        return $this->belongsTo(NexcoreClientTask::class, 'task_id');
    }

    public function completedByUser()
    {
        return $this->belongsTo(\App\Models\User::class, 'completed_by');
    }
}
