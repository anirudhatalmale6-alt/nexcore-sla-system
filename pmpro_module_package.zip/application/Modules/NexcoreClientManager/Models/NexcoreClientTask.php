<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class NexcoreClientTask extends Model
{
    use SoftDeletes;

    protected $table = 'nexcore_client_tasks';

    protected $fillable = [
        'client_id',
        'title',
        'description',
        'category',
        'priority',
        'task_status',
        'assigned_to',
        'due_date',
        'completed_date',
        'notes',
        'is_active',
        'created_by',
        'updated_by',
        'start_date',
        'estimated_hours',
        'actual_hours',
        'progress_percent',
        'parent_task_id',
        'sort_order',
        'color_label',
        'is_urgent',
    ];

    protected $casts = [
        'is_active'        => 'boolean',
        'due_date'         => 'date',
        'completed_date'   => 'date',
        'start_date'       => 'date',
        'is_urgent'        => 'boolean',
        'progress_percent' => 'integer',
        'estimated_hours'  => 'decimal:2',
        'actual_hours'     => 'decimal:2',
    ];

    /* ------------------------------------------------------------------ */
    /*  Relationships                                                      */
    /* ------------------------------------------------------------------ */

    public function client()
    {
        return $this->belongsTo(NexcoreClient::class, 'client_id');
    }

    public function steps()
    {
        return $this->hasMany(NexcoreTaskStep::class, 'task_id')->orderBy('sort_order');
    }

    public function comments()
    {
        return $this->hasMany(NexcoreTaskComment::class, 'task_id');
    }

    public function attachments()
    {
        return $this->hasMany(NexcoreTaskAttachment::class, 'task_id');
    }

    public function notes()
    {
        return $this->hasMany(NexcoreTaskNote::class, 'task_id');
    }

    public function activityLog()
    {
        return $this->hasMany(NexcoreTaskActivityLog::class, 'task_id');
    }

    public function reminders()
    {
        return $this->hasMany(NexcoreTaskReminder::class, 'task_id');
    }

    public function parentTask()
    {
        return $this->belongsTo(self::class, 'parent_task_id');
    }

    public function subtasks()
    {
        return $this->hasMany(self::class, 'parent_task_id');
    }

    public function creator()
    {
        return $this->belongsTo(\App\Models\User::class, 'created_by');
    }

    public function assignedUser()
    {
        return $this->belongsTo(\App\Models\User::class, 'assigned_to');
    }

    /* ------------------------------------------------------------------ */
    /*  Helper Methods                                                     */
    /* ------------------------------------------------------------------ */

    public function completedStepsCount(): int
    {
        return $this->steps()->where('is_completed', true)->count();
    }

    public function totalStepsCount(): int
    {
        return $this->steps()->count();
    }

    public function calculatedProgress(): float
    {
        $totalSteps = $this->totalStepsCount();

        if ($totalSteps > 0) {
            return ($this->completedStepsCount() / $totalSteps) * 100;
        }

        return (float) ($this->progress_percent ?? 0);
    }
}
