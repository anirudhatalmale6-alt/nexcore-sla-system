<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class NexcoreDirectorDocument extends Model
{
    use SoftDeletes;

    protected $table = 'nexcore_director_documents';

    protected $fillable = [
        'director_id', 'document_type', 'file_name', 'file_path', 'description',
        'is_active', 'created_by', 'updated_by',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function director()
    {
        return $this->belongsTo(NexcoreDirector::class, 'director_id');
    }
}
