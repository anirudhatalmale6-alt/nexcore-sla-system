<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class NexcoreDirector extends Model
{
    use SoftDeletes;

    protected $table = 'nexcore_directors';

    protected $fillable = [
        'personal_title', 'first_name', 'middle_name', 'known_as', 'initials',
        'surname', 'date_of_birth', 'ethnic_group', 'gender', 'director_status',
        'marital_status', 'partner_initials', 'partner_id_number', 'marriage_date',
        'id_number', 'passport_number', 'passport_expiry', 'tax_number',
        'is_sa_citizen', 'country_of_origin', 'director_photo',
        'is_active', 'created_by', 'updated_by',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'is_sa_citizen' => 'boolean',
        'date_of_birth' => 'date',
        'passport_expiry' => 'date',
        'marriage_date' => 'date',
    ];

    public function getFullNameAttribute()
    {
        return trim(($this->personal_title ? $this->personal_title . ' ' : '') . $this->first_name . ' ' . $this->surname);
    }

    public function contact()
    {
        return $this->hasOne(NexcoreDirectorContact::class, 'director_id');
    }

    public function bankAccounts()
    {
        return $this->hasMany(NexcoreDirectorBankAccount::class, 'director_id');
    }

    public function addresses()
    {
        return $this->hasMany(NexcoreDirectorAddress::class, 'director_id');
    }

    public function companies()
    {
        return $this->hasMany(NexcoreDirectorCompany::class, 'director_id');
    }

    public function documents()
    {
        return $this->hasMany(NexcoreDirectorDocument::class, 'director_id');
    }

    public function auditLogs()
    {
        return $this->hasMany(NexcoreDirectorAuditLog::class, 'director_id');
    }

    public function primaryBankAccount()
    {
        return $this->hasOne(NexcoreDirectorBankAccount::class, 'director_id')->where('is_primary', true);
    }
}
