<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;

class NexcoreTaskReminder extends Model
{
    protected $table = 'nexcore_task_reminders';

    protected $fillable = [
        'task_id',
        'user_id',
        'remind_at',
        'reminder_type',
        'message',
        'is_sent',
        'is_recurring',
        'recurring_interval',
    ];

    protected $casts = [
        'remind_at'    => 'datetime',
        'is_sent'      => 'boolean',
        'is_recurring' => 'boolean',
    ];

    /* ------------------------------------------------------------------ */
    /*  Relationships                                                      */
    /* ------------------------------------------------------------------ */

    public function task()
    {
        return $this->belongsTo(NexcoreClientTask::class, 'task_id');
    }

    public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }
}
