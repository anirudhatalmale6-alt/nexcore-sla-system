@extends('nexcore_client_manager::layouts.nerve-centre')

@section('sidebar')
    @include('nexcore_client_manager::partials.nerve-centre-sidebar')
@endsection

@section('title', 'Director Master - ' . $client->company_name)
@section('topbar_module', 'Client Manager')
@section('topbar_page', 'Director Master')

@push('styles')
<link href="https://cdn.jsdelivr.net/npm/flatpickr/dist/themes/dark.css" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════════════════
   DIRECTOR MASTER PAGE
   ═══════════════════════════════════════════════════════════════════════ */

/* Page Header */
.dm-header { display:flex; align-items:center; gap:18px; margin-bottom:28px; padding-bottom:22px; border-bottom:1px solid rgba(255,255,255,0.06); }
.dm-header-icon { width:52px; height:52px; border-radius:14px; background:linear-gradient(135deg,rgba(139,92,246,0.2),rgba(6,182,212,0.1)); border:1px solid rgba(139,92,246,0.35); display:flex; align-items:center; justify-content:center; flex-shrink:0; box-shadow:0 8px 24px rgba(139,92,246,0.15); }
.dm-header-icon i { color:#a78bfa; font-size:22px; }
.dm-header-info { flex:1; }
.dm-header-title { font-size:28px; font-weight:900; color:#f1f5f9; letter-spacing:1px; margin:0; font-family:'Montserrat',sans-serif; }
.dm-header-sub { font-size:13px; color:rgba(255,255,255,0.4); font-weight:500; margin-top:4px; letter-spacing:0.4px; }
.dm-header-actions { display:flex; gap:10px; flex-shrink:0; }

/* Stats */
.dm-stats { display:grid; grid-template-columns:repeat(4,1fr); gap:14px; margin-bottom:28px; }
.dm-stat { background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:14px; padding:18px 20px; position:relative; overflow:hidden; transition:all 0.3s; }
.dm-stat:hover { border-color:rgba(255,255,255,0.15); background:rgba(255,255,255,0.06); transform:translateY(-2px); box-shadow:0 8px 24px rgba(0,0,0,0.2); }
.dm-stat::before { content:''; position:absolute; top:0; left:0; right:0; height:3px; border-radius:3px 3px 0 0; }
.dm-stat:nth-child(1)::before { background:linear-gradient(90deg,#8b5cf6,#a78bfa); }
.dm-stat:nth-child(2)::before { background:linear-gradient(90deg,#10b981,#34d399); }
.dm-stat:nth-child(3)::before { background:linear-gradient(90deg,#06b6d4,#22d3ee); }
.dm-stat:nth-child(4)::before { background:linear-gradient(90deg,#f59e0b,#fbbf24); }
.dm-stat-label { font-size:10px; font-weight:800; letter-spacing:1px; text-transform:uppercase; color:rgba(255,255,255,0.4); margin-bottom:8px; }
.dm-stat-value { font-size:28px; font-weight:900; color:#f1f5f9; font-family:'Montserrat',sans-serif; line-height:1; }
.dm-stat-meta { font-size:11px; color:rgba(255,255,255,0.3); margin-top:6px; font-weight:500; }

/* Action Bar */
.dm-action-bar { display:flex; align-items:center; gap:12px; margin-bottom:22px; padding:16px 20px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.06); border-radius:14px; }
.dm-search-wrap { position:relative; flex:1; max-width:400px; }
.dm-search-wrap i { position:absolute; left:14px; top:50%; transform:translateY(-50%); color:rgba(255,255,255,0.3); font-size:13px; }
.dm-search-input { width:100%; height:42px; background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.1); border-radius:10px; padding:0 14px 0 40px; color:#e2e8f0; font-size:13px; font-weight:600; font-family:'Montserrat',sans-serif; outline:none; transition:all 0.3s; }
.dm-search-input:focus { border-color:rgba(139,92,246,0.5); box-shadow:0 0 0 3px rgba(139,92,246,0.1); background:rgba(255,255,255,0.08); }
.dm-search-input::placeholder { color:rgba(255,255,255,0.25); }
.dm-btn { height:42px; padding:0 22px; border:none; border-radius:10px; font-size:12px; font-weight:800; font-family:'Montserrat',sans-serif; cursor:pointer; transition:all 0.3s cubic-bezier(0.4,0,0.2,1); letter-spacing:0.5px; text-transform:uppercase; display:inline-flex; align-items:center; gap:8px; white-space:nowrap; }
.dm-btn-primary { background:linear-gradient(135deg,#8b5cf6,#7c3aed); color:#fff; box-shadow:0 4px 16px rgba(139,92,246,0.3); }
.dm-btn-primary:hover { box-shadow:0 8px 28px rgba(139,92,246,0.4); transform:translateY(-2px); }
.dm-btn-accent { background:linear-gradient(135deg,#06b6d4,#0891b2); color:#fff; box-shadow:0 4px 16px rgba(6,182,212,0.3); }
.dm-btn-accent:hover { box-shadow:0 8px 28px rgba(6,182,212,0.4); transform:translateY(-2px); }
.dm-btn-outline { background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.12); color:rgba(255,255,255,0.6); box-shadow:none; }
.dm-btn-outline:hover { background:rgba(255,255,255,0.08); border-color:rgba(255,255,255,0.2); color:#fff; }
.dm-action-spacer { flex:1; }

/* Director Cards */
.dm-card-list { display:flex; flex-direction:column; gap:12px; }
.dm-card { display:flex; align-items:center; gap:20px; padding:20px 24px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:14px; cursor:pointer; transition:all 0.35s cubic-bezier(0.4,0,0.2,1); position:relative; overflow:hidden; }
.dm-card::before { content:''; position:absolute; left:0; top:0; bottom:0; width:4px; border-radius:4px 0 0 4px; transition:opacity 0.3s; }
.dm-card:nth-child(4n+1)::before { background:linear-gradient(180deg,#8b5cf6,#a78bfa); }
.dm-card:nth-child(4n+2)::before { background:linear-gradient(180deg,#06b6d4,#22d3ee); }
.dm-card:nth-child(4n+3)::before { background:linear-gradient(180deg,#10b981,#34d399); }
.dm-card:nth-child(4n+4)::before { background:linear-gradient(180deg,#f59e0b,#fbbf24); }
.dm-card:hover { background:rgba(255,255,255,0.07); border-color:rgba(255,255,255,0.15); transform:translateY(-2px); box-shadow:0 12px 36px rgba(0,0,0,0.25); }
.dm-card:hover::after { content:''; position:absolute; inset:0; border-radius:14px; pointer-events:none; box-shadow:inset 0 0 0 1px rgba(139,92,246,0.15); }

/* Photo */
.dm-photo { width:68px; height:68px; min-width:68px; border-radius:14px; overflow:hidden; border:2px solid rgba(255,255,255,0.1); flex-shrink:0; position:relative; }
.dm-photo img { width:100%; height:100%; object-fit:cover; }
.dm-photo-initials { width:100%; height:100%; display:flex; align-items:center; justify-content:center; font-size:22px; font-weight:900; color:#fff; letter-spacing:2px; font-family:'Montserrat',sans-serif; }
.dm-card:nth-child(4n+1) .dm-photo-initials { background:linear-gradient(135deg,#7c3aed,#8b5cf6); }
.dm-card:nth-child(4n+2) .dm-photo-initials { background:linear-gradient(135deg,#0891b2,#06b6d4); }
.dm-card:nth-child(4n+3) .dm-photo-initials { background:linear-gradient(135deg,#059669,#10b981); }
.dm-card:nth-child(4n+4) .dm-photo-initials { background:linear-gradient(135deg,#d97706,#f59e0b); }

/* Info */
.dm-info { flex:1; min-width:0; }
.dm-info-row1 { display:flex; align-items:center; gap:10px; flex-wrap:wrap; margin-bottom:6px; }
.dm-name { font-size:16px; font-weight:800; color:#f1f5f9; font-family:'Montserrat',sans-serif; letter-spacing:0.3px; }
.dm-badge { font-size:9px; font-weight:800; text-transform:uppercase; letter-spacing:0.8px; padding:3px 10px; border-radius:6px; white-space:nowrap; }
.dm-badge-active { background:rgba(16,185,129,0.2); border:1px solid rgba(16,185,129,0.35); color:#34d399; }
.dm-badge-inactive { background:rgba(239,68,68,0.2); border:1px solid rgba(239,68,68,0.35); color:#f87171; }
.dm-badge-resigned { background:rgba(245,158,11,0.2); border:1px solid rgba(245,158,11,0.35); color:#fbbf24; }
.dm-badge-title { background:rgba(139,92,246,0.15); border:1px solid rgba(139,92,246,0.3); color:#a78bfa; }
.dm-info-row2 { display:flex; align-items:center; gap:18px; flex-wrap:wrap; }
.dm-detail { display:flex; align-items:center; gap:6px; font-size:12px; color:rgba(255,255,255,0.45); font-weight:500; }
.dm-detail i { font-size:11px; opacity:0.6; width:14px; text-align:center; }
.dm-detail-value { color:rgba(255,255,255,0.65); font-weight:600; }

/* Card Actions */
.dm-card-actions { display:flex; gap:8px; flex-shrink:0; }
.dm-card-btn { width:36px; height:36px; border-radius:10px; border:1px solid rgba(255,255,255,0.1); background:rgba(255,255,255,0.04); color:rgba(255,255,255,0.4); font-size:13px; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:all 0.25s; }
.dm-card-btn:hover { transform:translateY(-2px); }
.dm-card-btn-view:hover { background:rgba(139,92,246,0.15); border-color:rgba(139,92,246,0.4); color:#a78bfa; }
.dm-card-btn-unlink:hover { background:rgba(239,68,68,0.15); border-color:rgba(239,68,68,0.4); color:#f87171; }

/* Empty State */
.dm-empty { text-align:center; padding:60px 20px; color:rgba(255,255,255,0.3); }
.dm-empty i { font-size:48px; margin-bottom:16px; display:block; opacity:0.3; }
.dm-empty-title { font-size:16px; font-weight:700; color:rgba(255,255,255,0.5); margin-bottom:8px; }
.dm-empty-sub { font-size:13px; color:rgba(255,255,255,0.3); font-weight:500; }

/* Companies list on card */
.dm-companies { display:flex; gap:6px; flex-wrap:wrap; margin-top:4px; }
.dm-company-tag { font-size:9px; font-weight:700; letter-spacing:0.5px; padding:2px 8px; border-radius:4px; background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.08); color:rgba(255,255,255,0.4); }

/* ═══════════════════════════════════════════════════════════════════════
   CENTERED MODAL
   ═══════════════════════════════════════════════════════════════════════ */
.nx-modal-overlay { position:fixed; inset:0; background:rgba(4,8,18,0.78); backdrop-filter:blur(10px); -webkit-backdrop-filter:blur(10px); z-index:9000; display:none; align-items:flex-start; justify-content:center; padding:30px 20px; overflow-y:auto; }
.nx-modal-overlay.nx-modal-open { display:flex; }
@@keyframes nxModalIn { 0% { opacity:0; transform:translateY(24px) scale(0.97); } 100% { opacity:1; transform:translateY(0) scale(1); } }
.nx-modal { width:100%; max-width:740px; background:#fff; border-radius:20px; box-shadow:0 25px 80px rgba(0,0,0,0.45), 0 0 0 1px rgba(255,255,255,0.1), 0 0 120px rgba(6,182,212,0.06); animation:nxModalIn 0.45s cubic-bezier(0.16,1,0.3,1) forwards; position:relative; overflow:hidden; }
.nx-modal::before { content:''; position:absolute; top:0; left:0; right:0; height:5px; background:linear-gradient(90deg,#06b6d4,#3b82f6,#8b5cf6,#10b981,#f59e0b); z-index:1; }

.nx-modal-header { display:flex; align-items:center; gap:16px; padding:22px 30px 20px; background:linear-gradient(135deg,#f0f9ff,#faf5ff,#ecfdf5); border-bottom:1px solid #e2e8f0; }
.nx-modal-header-icon { width:48px; height:48px; border-radius:14px; background:linear-gradient(135deg,#8b5cf6,#7c3aed); display:flex; align-items:center; justify-content:center; flex-shrink:0; box-shadow:0 6px 20px rgba(139,92,246,0.3), inset 0 1px 0 rgba(255,255,255,0.2); }
.nx-modal-header-icon i { color:#fff; font-size:19px; }
.nx-modal-header h3 { font-size:20px; font-weight:800; color:#0f172a; letter-spacing:0.2px; margin:0; flex:1; font-family:'Montserrat',sans-serif; }
.nx-modal-header-sub { font-size:12px; color:#64748b; font-weight:500; margin-top:2px; }
.nx-modal-close { width:36px; height:36px; border-radius:10px; border:1px solid #e2e8f0; background:#fff; color:#94a3b8; font-size:15px; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:all 0.25s cubic-bezier(0.4,0,0.2,1); }
.nx-modal-close:hover { background:#fef2f2; border-color:#fca5a5; color:#ef4444; transform:rotate(90deg) scale(1.1); }

.nx-modal-body { padding:0; display:flex; flex-direction:column; gap:0; background:#fafbfc; max-height:65vh; overflow-y:auto; }
.nx-modal-body::-webkit-scrollbar { width:6px; }
.nx-modal-body::-webkit-scrollbar-track { background:#f1f5f9; }
.nx-modal-body::-webkit-scrollbar-thumb { background:#cbd5e1; border-radius:3px; }
.nx-modal-body::-webkit-scrollbar-thumb:hover { background:#94a3b8; }

.nx-modal-footer { display:flex; align-items:center; justify-content:space-between; padding:18px 30px; border-top:1px solid #e2e8f0; background:linear-gradient(135deg,#f8fafc,#f0f9ff); border-radius:0 0 20px 20px; }
.nx-modal-footer-note { font-size:11px; color:#94a3b8; display:flex; align-items:center; gap:4px; font-weight:500; }

/* ═══════════════════════════════════════════════════════════════════════
   NX FORM CLASSES (White/Light Theme - Inside Drawer)
   ═══════════════════════════════════════════════════════════════════════ */
.nx-form-section { padding:22px 30px; border-bottom:1px solid #f1f5f9; position:relative; transition:background 0.3s; display:flex; flex-direction:column; gap:14px; }
.nx-form-section:last-child { border-bottom:none; }
.nx-form-section:hover { background:rgba(255,255,255,0.8); }
.nx-form-section-header { display:flex; align-items:center; gap:10px; margin-bottom:4px; }
.nx-form-section-icon { width:32px; height:32px; border-radius:9px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
.nx-form-section-icon i { font-size:14px; }
.nx-form-section-title { font-size:13px; font-weight:800; letter-spacing:0.8px; text-transform:uppercase; }
.nx-form-section-line { flex:1; height:1px; margin-left:8px; }

/* Section Colour Variants */
.nx-section-cyan { background:linear-gradient(135deg,#f0fdfa,#f0f9ff); border-left:4px solid #06b6d4; }
.nx-section-cyan .nx-form-section-icon { background:linear-gradient(135deg,#e0f7fa,#cffafe); }
.nx-section-cyan .nx-form-section-icon i { color:#0891b2; }
.nx-section-cyan .nx-form-section-title { color:#0891b2; }
.nx-section-cyan .nx-form-section-line { background:linear-gradient(90deg,#06b6d4 0%,#e0f7fa 50%,transparent); }
.nx-section-cyan .nx-form-input:focus, .nx-section-cyan .nx-form-select:focus { border-color:#06b6d4; box-shadow:0 0 0 3px rgba(6,182,212,0.1), 0 2px 8px rgba(6,182,212,0.06); }

.nx-section-blue { background:linear-gradient(135deg,#eff6ff,#f0f9ff); border-left:4px solid #3b82f6; }
.nx-section-blue .nx-form-section-icon { background:linear-gradient(135deg,#dbeafe,#e0f2fe); }
.nx-section-blue .nx-form-section-icon i { color:#2563eb; }
.nx-section-blue .nx-form-section-title { color:#2563eb; }
.nx-section-blue .nx-form-section-line { background:linear-gradient(90deg,#3b82f6 0%,#dbeafe 50%,transparent); }
.nx-section-blue .nx-form-input:focus, .nx-section-blue .nx-form-select:focus { border-color:#3b82f6; box-shadow:0 0 0 3px rgba(59,130,246,0.1), 0 2px 8px rgba(59,130,246,0.06); }

.nx-section-green { background:linear-gradient(135deg,#ecfdf5,#f0fdf4); border-left:4px solid #10b981; }
.nx-section-green .nx-form-section-icon { background:linear-gradient(135deg,#d1fae5,#dcfce7); }
.nx-section-green .nx-form-section-icon i { color:#059669; }
.nx-section-green .nx-form-section-title { color:#059669; }
.nx-section-green .nx-form-section-line { background:linear-gradient(90deg,#10b981 0%,#d1fae5 50%,transparent); }
.nx-section-green .nx-form-input:focus, .nx-section-green .nx-form-select:focus { border-color:#10b981; box-shadow:0 0 0 3px rgba(16,185,129,0.1), 0 2px 8px rgba(16,185,129,0.06); }

.nx-section-amber { background:linear-gradient(135deg,#fffbeb,#fefce8); border-left:4px solid #f59e0b; }
.nx-section-amber .nx-form-section-icon { background:linear-gradient(135deg,#fef3c7,#fef9c3); }
.nx-section-amber .nx-form-section-icon i { color:#d97706; }
.nx-section-amber .nx-form-section-title { color:#d97706; }
.nx-section-amber .nx-form-section-line { background:linear-gradient(90deg,#f59e0b 0%,#fef3c7 50%,transparent); }
.nx-section-amber .nx-form-input:focus, .nx-section-amber .nx-form-select:focus { border-color:#f59e0b; box-shadow:0 0 0 3px rgba(245,158,11,0.1), 0 2px 8px rgba(245,158,11,0.06); }

.nx-section-purple { background:linear-gradient(135deg,#faf5ff,#f5f3ff); border-left:4px solid #8b5cf6; }
.nx-section-purple .nx-form-section-icon { background:linear-gradient(135deg,#ede9fe,#e9d5ff); }
.nx-section-purple .nx-form-section-icon i { color:#7c3aed; }
.nx-section-purple .nx-form-section-title { color:#7c3aed; }
.nx-section-purple .nx-form-section-line { background:linear-gradient(90deg,#8b5cf6 0%,#ede9fe 50%,transparent); }
.nx-section-purple .nx-form-input:focus, .nx-section-purple .nx-form-select:focus { border-color:#8b5cf6; box-shadow:0 0 0 3px rgba(139,92,246,0.1), 0 2px 8px rgba(139,92,246,0.06); }

/* Form Controls */
.nx-form-group { display:flex; flex-direction:column; gap:5px; }
.nx-form-label { font-size:11px; font-weight:700; letter-spacing:0.5px; text-transform:uppercase; color:#475569; display:flex; align-items:center; gap:5px; transition:color 0.2s; }
.nx-form-req { color:#ef4444; font-size:13px; line-height:1; }
.nx-form-input { width:100%; height:44px; background:#fff; border:1.5px solid #e2e8f0; border-radius:10px; outline:none; color:#0f172a; font-size:14px; font-weight:600; padding:0 14px; font-family:'Montserrat',sans-serif; transition:all 0.25s cubic-bezier(0.4,0,0.2,1); }
.nx-form-input:hover { border-color:#cbd5e1; box-shadow:0 2px 6px rgba(0,0,0,0.04); }
.nx-form-input:focus { border-color:#06b6d4; box-shadow:0 0 0 3px rgba(6,182,212,0.1), 0 2px 8px rgba(6,182,212,0.06); background:#fff; }
.nx-form-input::placeholder { color:#a1a1aa; font-weight:400; font-size:13px; }
.nx-form-input:disabled { opacity:0.55; cursor:not-allowed; background:#f1f5f9; border-color:#e2e8f0; }
.nx-form-select { width:100%; height:44px; background:#fff; border:1.5px solid #e2e8f0; border-radius:10px; outline:none; color:#0f172a; font-size:13px; font-weight:600; padding:0 14px; padding-right:36px; font-family:'Montserrat',sans-serif; transition:all 0.3s cubic-bezier(0.4,0,0.2,1); cursor:pointer; appearance:none; -webkit-appearance:none; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%2364748b' stroke-width='2.5'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 14px center; text-overflow:ellipsis; letter-spacing:0.2px; }
.nx-form-select:hover { border-color:#cbd5e1; box-shadow:0 2px 6px rgba(0,0,0,0.04); }
.nx-form-select:focus { border-color:#06b6d4; box-shadow:0 0 0 3px rgba(6,182,212,0.1), 0 2px 8px rgba(6,182,212,0.06); }
.nx-form-select option { background:#fff; color:#0f172a; padding:10px 14px; font-size:13px; font-weight:600; font-family:'Montserrat',sans-serif; }
.nx-form-row { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
.nx-form-row-3 { display:grid; grid-template-columns:1fr 1fr 1fr; gap:14px; }
.nx-form-row-4 { display:grid; grid-template-columns:1fr 1fr 1fr 1fr; gap:14px; }
.nx-form-check { display:inline-flex; align-items:center; gap:8px; cursor:pointer; font-size:13px; font-weight:600; color:#475569; padding:6px 12px; border-radius:8px; transition:all 0.2s; }
.nx-form-check:hover { background:rgba(6,182,212,0.06); color:#0f172a; }
.nx-form-check input[type="checkbox"] { width:18px; height:18px; accent-color:#06b6d4; cursor:pointer; }

/* Photo Frame */
.nx-photo-layout { display:grid; grid-template-columns:180px 1fr; gap:24px; align-items:stretch; }
.nx-photo-frame { display:flex; flex-direction:column; }
.nx-photo-border { flex:1; border-radius:16px; padding:4px; background:linear-gradient(135deg,#06b6d4,#3b82f6,#10b981,#f59e0b); box-shadow:0 8px 32px rgba(6,182,212,0.2), 0 2px 8px rgba(0,0,0,0.08); min-height:0; }
.nx-photo-inner { width:100%; height:100%; border-radius:12px; background:#f8fafc; overflow:hidden; display:flex; align-items:center; justify-content:center; position:relative; }
.nx-photo-inner img { width:100%; height:100%; object-fit:cover; }
.nx-photo-initials { font-size:52px; font-weight:900; font-family:'Montserrat',sans-serif; color:#fff; letter-spacing:3px; background:linear-gradient(135deg,#0891b2,#2563eb); width:100%; height:100%; display:flex; align-items:center; justify-content:center; user-select:none; }
.nx-photo-upload { margin-top:10px; padding:10px 0; background:linear-gradient(135deg,#f0f9ff,#ecfdf5); border:1.5px dashed #cbd5e1; border-radius:10px; color:#0891b2; font-size:11px; font-weight:700; font-family:'Montserrat',sans-serif; cursor:pointer; text-align:center; transition:all 0.3s; letter-spacing:0.4px; text-transform:uppercase; display:flex; align-items:center; justify-content:center; gap:6px; flex-shrink:0; }
.nx-photo-upload:hover { border-color:#06b6d4; background:linear-gradient(135deg,#e0f7fa,#d1fae5); color:#0e7490; }
.nx-photo-hint { text-align:center; font-size:9px; color:#94a3b8; font-weight:500; margin-top:4px; letter-spacing:0.3px; font-family:'Montserrat',sans-serif; }
.nx-photo-fields { display:flex; flex-direction:column; gap:14px; }

/* Bank List */
.nx-bank-list { display:flex; flex-direction:column; gap:12px; }
.nx-bank-empty { text-align:center; padding:20px; color:#94a3b8; font-size:12px; font-weight:600; font-family:'Montserrat',sans-serif; font-style:italic; }
.nx-bank-card { display:flex; align-items:center; gap:16px; padding:16px 20px; background:#fff; border:1.5px solid #e2e8f0; border-radius:10px; transition:all 0.3s; }
.nx-bank-card:hover { border-color:#cbd5e1; box-shadow:0 2px 8px rgba(0,0,0,0.05); transform:translateY(-1px); }
.nx-bank-card.nx-bank-primary { border-color:#10b981; background:linear-gradient(135deg,#f0fdf4,#ecfdf5); }
.nx-bank-icon { width:38px; height:38px; border-radius:10px; background:linear-gradient(135deg,#3b82f6,#2563eb); display:flex; align-items:center; justify-content:center; flex-shrink:0; }
.nx-bank-icon i { color:#fff; font-size:15px; }
.nx-bank-info { flex:1; min-width:0; }
.nx-bank-name { font-size:13px; font-weight:800; color:#0f172a; font-family:'Montserrat',sans-serif; display:flex; align-items:center; gap:8px; }
.nx-bank-badge { font-size:9px; font-weight:800; text-transform:uppercase; letter-spacing:0.8px; padding:3px 8px; border-radius:6px; }
.nx-bank-badge-primary { background:linear-gradient(135deg,#d1fae5,#a7f3d0); color:#065f46; }
.nx-bank-badge-type { background:linear-gradient(135deg,#dbeafe,#bfdbfe); color:#1e40af; }
.nx-bank-detail { font-size:11px; color:#64748b; font-weight:600; font-family:'Montserrat',sans-serif; margin-top:2px; }
.nx-bank-actions { display:flex; gap:6px; flex-shrink:0; }
.nx-bank-action { width:32px; height:32px; border-radius:8px; border:1px solid #e2e8f0; background:#fff; color:#94a3b8; font-size:12px; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:all 0.25s; }
.nx-bank-action:hover { transform:translateY(-1px); }
.nx-bank-action-star:hover { background:#fef9c3; border-color:#f59e0b; color:#f59e0b; }
.nx-bank-action-edit:hover { background:#eff6ff; border-color:#3b82f6; color:#3b82f6; }
.nx-bank-action-del:hover { background:#fef2f2; border-color:#ef4444; color:#ef4444; }
.nx-bank-add-btn { padding:10px 24px; background:linear-gradient(135deg,#3b82f6,#2563eb); border:none; border-radius:10px; color:#fff; font-size:12px; font-weight:800; font-family:'Montserrat',sans-serif; cursor:pointer; transition:all 0.3s cubic-bezier(0.4,0,0.2,1); letter-spacing:0.5px; text-transform:uppercase; display:inline-flex; align-items:center; gap:8px; box-shadow:0 4px 14px rgba(59,130,246,0.25); }
.nx-bank-add-btn:hover { box-shadow:0 8px 24px rgba(59,130,246,0.35); transform:translateY(-2px); }

/* Address List */
.nx-addr-list { display:flex; flex-direction:column; gap:12px; }
.nx-addr-empty { text-align:center; padding:20px; color:#94a3b8; font-size:12px; font-weight:600; font-family:'Montserrat',sans-serif; font-style:italic; }
.nx-addr-card { display:flex; align-items:center; gap:16px; padding:16px 20px; background:#fff; border:1.5px solid #e2e8f0; border-radius:10px; transition:all 0.3s; }
.nx-addr-card:hover { border-color:#cbd5e1; box-shadow:0 2px 8px rgba(0,0,0,0.05); transform:translateY(-1px); }
.nx-addr-icon { width:38px; height:38px; border-radius:10px; background:linear-gradient(135deg,#f59e0b,#d97706); display:flex; align-items:center; justify-content:center; flex-shrink:0; }
.nx-addr-icon i { color:#fff; font-size:15px; }
.nx-addr-info { flex:1; min-width:0; }
.nx-addr-type { font-size:13px; font-weight:800; color:#0f172a; font-family:'Montserrat',sans-serif; display:flex; align-items:center; gap:8px; }
.nx-addr-badge { font-size:9px; font-weight:800; text-transform:uppercase; letter-spacing:0.8px; padding:3px 8px; border-radius:6px; background:linear-gradient(135deg,#fef3c7,#fde68a); color:#92400e; }
.nx-addr-detail { font-size:11px; color:#64748b; font-weight:600; font-family:'Montserrat',sans-serif; margin-top:2px; }
.nx-addr-actions { display:flex; gap:6px; flex-shrink:0; }
.nx-addr-action { width:32px; height:32px; border-radius:8px; border:1px solid #e2e8f0; background:#fff; color:#94a3b8; font-size:12px; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:all 0.25s; }
.nx-addr-action:hover { transform:translateY(-1px); }
.nx-addr-action-del:hover { background:#fef2f2; border-color:#ef4444; color:#ef4444; }
.nx-addr-add-btn { padding:10px 24px; background:linear-gradient(135deg,#f59e0b,#d97706); border:none; border-radius:10px; color:#fff; font-size:12px; font-weight:800; font-family:'Montserrat',sans-serif; cursor:pointer; transition:all 0.3s cubic-bezier(0.4,0,0.2,1); letter-spacing:0.5px; text-transform:uppercase; display:inline-flex; align-items:center; gap:8px; box-shadow:0 4px 14px rgba(245,158,11,0.25); }
.nx-addr-add-btn:hover { box-shadow:0 8px 24px rgba(245,158,11,0.35); transform:translateY(-2px); }
.nx-addr-search-list { max-height:220px; overflow-y:auto; border:1.5px solid #e2e8f0; border-radius:10px; background:#fff; }
.nx-addr-search-item { padding:12px 16px; border-bottom:1px solid #f1f5f9; cursor:pointer; transition:background 0.2s; font-family:'Montserrat',sans-serif; font-size:12px; font-weight:600; color:#334155; }
.nx-addr-search-item:last-child { border-bottom:none; }
.nx-addr-search-item:hover { background:#f0fdf4; }
.nx-addr-search-item .nx-addr-search-type { font-size:9px; font-weight:800; text-transform:uppercase; letter-spacing:0.6px; color:#f59e0b; margin-right:8px; }
.nx-addr-search-input { width:100%; padding:10px 14px 10px 38px; border:1.5px solid #e2e8f0; border-radius:10px; font-family:'Montserrat',sans-serif; font-size:12px; font-weight:600; color:#0f172a; background:#fff; outline:none; transition:border-color 0.3s; }
.nx-addr-search-input:focus { border-color:#f59e0b; }
.nx-addr-search-wrap { position:relative; margin-bottom:10px; }
.nx-addr-search-wrap i { position:absolute; left:14px; top:50%; transform:translateY(-50%); color:#94a3b8; font-size:13px; }

/* Search Section (Pink) */
.nx-search-section { padding:22px 30px; background:linear-gradient(135deg,#eb2376,#d91e6b,#c4185a); border-bottom:2px solid rgba(235,35,118,0.3); position:relative; overflow:hidden; }
.nx-search-section::before { content:''; position:absolute; inset:0; background:radial-gradient(ellipse at 20% 50%, rgba(255,255,255,0.1) 0%, transparent 60%); pointer-events:none; }
.nx-search-header { display:flex; align-items:center; gap:10px; margin-bottom:14px; position:relative; }
.nx-search-icon { width:32px; height:32px; border-radius:9px; background:rgba(255,255,255,0.2); backdrop-filter:blur(4px); display:flex; align-items:center; justify-content:center; flex-shrink:0; box-shadow:0 4px 12px rgba(0,0,0,0.15); border:1px solid rgba(255,255,255,0.25); }
.nx-search-icon i { color:#fff; font-size:14px; }
.nx-search-title { font-size:13px; font-weight:800; letter-spacing:0.8px; text-transform:uppercase; color:#fff; }
.nx-search-subtitle { font-size:11px; color:rgba(255,255,255,0.7); font-weight:500; margin-left:auto; }
.nx-search-row { display:grid; grid-template-columns:200px 1fr auto auto; gap:10px; align-items:end; position:relative; }
.nx-search-select { width:100%; height:44px; background:#fff; border:1.5px solid #e2e8f0; border-radius:10px; outline:none; color:#0f172a; font-size:14px; font-weight:700; padding:0 14px; padding-right:36px; font-family:'Montserrat',sans-serif; cursor:pointer; appearance:none; -webkit-appearance:none; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23eb2376' stroke-width='2.5'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 14px center; transition:all 0.3s; box-shadow:0 2px 8px rgba(0,0,0,0.08); }
.nx-search-select:focus { border-color:#eb2376; box-shadow:0 0 0 3px rgba(235,35,118,0.15); }
.nx-search-input { width:100%; height:44px; background:#fff; border:1.5px solid #e2e8f0; border-radius:10px; outline:none; color:#0f172a; font-size:14px; font-weight:700; padding:0 14px; font-family:'Montserrat',sans-serif; transition:all 0.3s; box-shadow:0 2px 8px rgba(0,0,0,0.08); }
.nx-search-input:focus { border-color:#eb2376; box-shadow:0 0 0 3px rgba(235,35,118,0.15); }
.nx-search-input::placeholder { color:#94a3b8; font-weight:500; font-size:13px; }
.nx-search-btn { height:44px; padding:0 28px; background:linear-gradient(135deg,#fff,#f8fafc); border:2px solid #fff; border-radius:10px; color:#eb2376; font-size:14px; font-weight:800; font-family:'Montserrat',sans-serif; cursor:pointer; transition:all 0.3s; letter-spacing:0.6px; text-transform:uppercase; box-shadow:0 4px 16px rgba(0,0,0,0.12); display:flex; align-items:center; gap:8px; white-space:nowrap; }
.nx-search-btn:hover { box-shadow:0 8px 28px rgba(235,35,118,0.25); transform:translateY(-2px); }
.nx-search-clear { height:44px; padding:0 20px; background:linear-gradient(135deg,#fff,#f8fafc); border:2px solid rgba(255,255,255,0.9); border-radius:10px; color:#64748b; font-size:12px; font-weight:800; font-family:'Montserrat',sans-serif; cursor:pointer; transition:all 0.3s; display:flex; align-items:center; gap:7px; white-space:nowrap; box-shadow:0 4px 16px rgba(0,0,0,0.12); letter-spacing:0.5px; text-transform:uppercase; }
.nx-search-clear:hover { color:#ef4444; box-shadow:0 8px 28px rgba(239,68,68,0.2); transform:translateY(-2px); }
.nx-search-result { display:none; margin:0; padding:14px 30px; font-size:13px; font-weight:700; font-family:'Montserrat',sans-serif; border-bottom:1px solid #f1f5f9; }
.nx-search-result.nx-result-found { display:flex; align-items:center; gap:10px; background:linear-gradient(135deg,#ecfdf5,#d1fae5); color:#065f46; border-left:4px solid #10b981; }
.nx-search-result.nx-result-notfound { display:flex; align-items:center; gap:10px; background:linear-gradient(135deg,#eff6ff,#dbeafe); color:#1e40af; border-left:4px solid #3b82f6; }
.nx-search-result i { font-size:16px; }

/* Save/Cancel Buttons */
.nx-modal-save { padding:12px 36px; background:linear-gradient(135deg,#06b6d4,#3b82f6); border:none; border-radius:10px; color:#fff; font-size:14px; font-weight:800; font-family:'Montserrat',sans-serif; cursor:pointer; transition:all 0.3s cubic-bezier(0.4,0,0.2,1); letter-spacing:0.5px; box-shadow:0 4px 16px rgba(6,182,212,0.3); position:relative; overflow:hidden; }
.nx-modal-save:hover { box-shadow:0 8px 28px rgba(6,182,212,0.4); transform:translateY(-2px); }
.nx-modal-save:disabled { opacity:0.4; cursor:not-allowed; transform:none; box-shadow:none; }
.nx-modal-cancel { padding:12px 24px; background:linear-gradient(135deg,#ef4444,#dc2626); border:none; border-radius:10px; color:#fff; font-size:13px; font-weight:700; font-family:'Montserrat',sans-serif; cursor:pointer; transition:all 0.3s; box-shadow:0 4px 14px rgba(239,68,68,0.25); letter-spacing:0.3px; }
.nx-modal-cancel:hover { background:linear-gradient(135deg,#dc2626,#b91c1c); box-shadow:0 8px 24px rgba(239,68,68,0.35); transform:translateY(-1px); }

/* Animations */
@@keyframes dmFadeIn { 0% { opacity:0; transform:translateY(12px); } 100% { opacity:1; transform:translateY(0); } }
@@keyframes dmPulse { 0%,100% { box-shadow:0 0 8px rgba(139,92,246,0.2); } 50% { box-shadow:0 0 20px rgba(139,92,246,0.4); } }
.dm-animate { animation:dmFadeIn 0.4s cubic-bezier(0.4,0,0.2,1) forwards; opacity:0; }
.dm-animate:nth-child(1) { animation-delay:0.05s; }
.dm-animate:nth-child(2) { animation-delay:0.1s; }
.dm-animate:nth-child(3) { animation-delay:0.15s; }
.dm-animate:nth-child(4) { animation-delay:0.2s; }
.dm-pulse { animation:dmPulse 2.5s ease-in-out infinite; }

/* Responsive */
@@media (max-width:900px) {
    .dm-stats { grid-template-columns:1fr 1fr; }
    .dm-action-bar { flex-wrap:wrap; }
    .dm-search-wrap { max-width:100%; }
    .dm-card { flex-wrap:wrap; gap:12px; }
    .dm-info-row2 { gap:10px; }
    .nx-modal { margin:10px; border-radius:14px; }
}
@@media (max-width:640px) {
    .dm-stats { grid-template-columns:1fr; }
    .nx-form-row, .nx-form-row-3, .nx-form-row-4 { grid-template-columns:1fr; }
    .nx-form-section { padding:16px 18px; }
    .nx-modal-header, .nx-modal-footer { padding-left:18px; padding-right:18px; }
    .nx-photo-layout { grid-template-columns:1fr; }
    .nx-photo-frame { align-items:center; }
    .nx-photo-border { width:160px; height:200px; flex:none; }
    .nx-search-row { grid-template-columns:1fr; }
    .nx-form-row-4 { grid-template-columns:1fr 1fr; }
}
</style>
@endpush

@section('content')

{{-- Page Header --}}
<div class="dm-header dm-animate">
    <div class="dm-header-icon dm-pulse">
        <i class="fas fa-user-tie"></i>
    </div>
    <div class="dm-header-info">
        <h1 class="dm-header-title">Director Master</h1>
        <div class="dm-header-sub">{{ $client->company_name }} &mdash; Independent Director Registry</div>
    </div>
</div>

{{-- Stats --}}
<div class="dm-stats dm-animate">
    <div class="dm-stat">
        <div class="dm-stat-label">Total Directors</div>
        <div class="dm-stat-value">{{ $directors->count() }}</div>
        <div class="dm-stat-meta">Linked to this company</div>
    </div>
    <div class="dm-stat">
        <div class="dm-stat-label">Active</div>
        <div class="dm-stat-value">{{ $directors->where('director_status', 'Active')->count() }}</div>
        <div class="dm-stat-meta">Currently active directors</div>
    </div>
    <div class="dm-stat">
        <div class="dm-stat-label">With ID Number</div>
        <div class="dm-stat-value">{{ $directors->whereNotNull('id_number')->count() }}</div>
        <div class="dm-stat-meta">SA citizens identified</div>
    </div>
    <div class="dm-stat">
        <div class="dm-stat-label">Bank Accounts</div>
        <div class="dm-stat-value">{{ $directors->sum(function($d) { return $d->bankAccounts->count(); }) }}</div>
        <div class="dm-stat-meta">Total banking records</div>
    </div>
</div>

{{-- Action Bar --}}
<div class="dm-action-bar dm-animate">
    <div class="dm-search-wrap">
        <i class="fas fa-search"></i>
        <input type="text" class="dm-search-input" id="dm-filter" placeholder="Filter directors..." oninput="dmFilterCards()">
    </div>
    <div class="dm-action-spacer"></div>
    <button class="dm-btn dm-btn-accent" onclick="dmOpenModal('search')">
        <i class="fas fa-search-plus"></i> Search & Link
    </button>
    <button class="dm-btn dm-btn-primary" onclick="dmOpenModal('add')">
        <i class="fas fa-user-plus"></i> Add Director
    </button>
</div>

{{-- Director Cards --}}
<div class="dm-card-list dm-animate" id="dm-card-list">
    @forelse($directors as $dir)
        <div class="dm-card" data-director-id="{{ $dir->id }}" data-name="{{ strtolower($dir->first_name . ' ' . $dir->surname) }}" ondblclick="dmOpenModal('edit', {{ $dir->id }})">
            <div class="dm-photo">
                @if($dir->director_photo)
                    <img src="/{{ $dir->director_photo }}" alt="{{ $dir->first_name }}">
                @else
                    <div class="dm-photo-initials">{{ substr($dir->first_name,0,1) . substr($dir->surname,0,1) }}</div>
                @endif
            </div>
            <div class="dm-info">
                <div class="dm-info-row1">
                    <span class="dm-name">{{ ($dir->personal_title ? $dir->personal_title . ' ' : '') . $dir->first_name . ' ' . $dir->surname }}</span>
                    @php
                        $statusClass = 'dm-badge-active';
                        if($dir->director_status === 'Inactive') $statusClass = 'dm-badge-inactive';
                        elseif($dir->director_status === 'Resigned') $statusClass = 'dm-badge-resigned';
                    @endphp
                    <span class="dm-badge {{ $statusClass }}">{{ $dir->director_status ?? 'Active' }}</span>
                    @php $companyLink = $dir->companies->where('client_id', $client->id)->first(); @endphp
                    @if($companyLink && $companyLink->title)
                        <span class="dm-badge dm-badge-title">{{ $companyLink->title }}</span>
                    @endif
                </div>
                <div class="dm-info-row2">
                    @if($dir->id_number)
                        <span class="dm-detail"><i class="fas fa-id-card"></i> <span class="dm-detail-value">{{ $dir->id_number }}</span></span>
                    @endif
                    @if($dir->contact && $dir->contact->email_address)
                        <span class="dm-detail"><i class="fas fa-envelope"></i> <span class="dm-detail-value">{{ $dir->contact->email_address }}</span></span>
                    @endif
                    @if($dir->contact && $dir->contact->mobile_number)
                        <span class="dm-detail"><i class="fas fa-mobile-alt"></i> <span class="dm-detail-value">{{ $dir->contact->mobile_number }}</span></span>
                    @endif
                    @if($dir->bankAccounts->count())
                        <span class="dm-detail"><i class="fas fa-university"></i> <span class="dm-detail-value">{{ $dir->bankAccounts->count() }} account{{ $dir->bankAccounts->count() > 1 ? 's' : '' }}</span></span>
                    @endif
                </div>
                @if($dir->companies->count() > 1)
                    <div class="dm-companies">
                        @foreach($dir->companies as $comp)
                            <span class="dm-company-tag">{{ $comp->client->company_name ?? 'Unknown' }}</span>
                        @endforeach
                    </div>
                @endif
            </div>
            <div class="dm-card-actions">
                <button class="dm-card-btn dm-card-btn-view" title="View / Edit" onclick="event.stopPropagation(); dmOpenModal('edit', {{ $dir->id }})"><i class="fas fa-pen"></i></button>
                <button class="dm-card-btn dm-card-btn-unlink" title="Unlink from company" onclick="event.stopPropagation(); dmUnlinkDirector({{ $dir->id }}, '{{ addslashes($dir->first_name . ' ' . $dir->surname) }}')"><i class="fas fa-unlink"></i></button>
            </div>
        </div>
    @empty
        <div class="dm-empty">
            <i class="fas fa-user-tie"></i>
            <div class="dm-empty-title">No Directors Linked</div>
            <div class="dm-empty-sub">Use "Search & Link" to find an existing director or "Add Director" to create a new one.</div>
        </div>
    @endforelse
</div>

{{-- ═══════════════════════════════════════════════════════════════════════
     RIGHT DRAWER
     ═══════════════════════════════════════════════════════════════════════ --}}
<div class="nx-modal-overlay" id="dm-modal-overlay" onclick="if(event.target===this)dmCloseModal()">
<div class="nx-modal" id="dm-modal">
    <div class="nx-modal-header">
        <div class="nx-modal-header-icon"><i class="fas fa-user-tie"></i></div>
        <div>
            <h3 id="dm-modal-title">Add Director</h3>
            <div class="nx-modal-header-sub" id="dm-modal-sub">Complete all sections below</div>
        </div>
        <button class="nx-modal-close" onclick="dmCloseModal()"><i class="fas fa-times"></i></button>
    </div>

    <div class="nx-modal-body" id="dm-modal-body">

        {{-- Search Section (Pink) --}}
        <div class="nx-search-section" id="dm-search-section">
            <div class="nx-search-header">
                <div class="nx-search-icon"><i class="fas fa-search"></i></div>
                <span class="nx-search-title">Director Lookup</span>
                <span class="nx-search-subtitle">Search by ID or Passport</span>
            </div>
            <div class="nx-search-row">
                <select id="dm-search-by" class="nx-search-select">
                    <option value="id_number">ID Number</option>
                    <option value="passport_number">Passport Number</option>
                </select>
                <input type="text" id="dm-search-value" class="nx-search-input" placeholder="Enter ID or Passport number...">
                <button class="nx-search-btn" onclick="dmSearchDirector()"><i class="fas fa-search"></i> Search</button>
                <button class="nx-search-clear" onclick="dmClearSearch()"><i class="fas fa-eraser"></i> Clear</button>
            </div>
        </div>

        <div id="dm-search-result" class="nx-search-result"></div>

        {{-- SECTION 1: Personal Details (Cyan) --}}
        <div class="nx-form-section nx-section-cyan" data-nx-form-section>
            <div class="nx-form-section-header">
                <div class="nx-form-section-icon"><i class="fas fa-user"></i></div>
                <span class="nx-form-section-title">Personal Details</span>
                <div class="nx-form-section-line"></div>
            </div>
            <div class="nx-photo-layout">
                <div class="nx-photo-frame">
                    <div class="nx-photo-border">
                        <div class="nx-photo-inner">
                            <div class="nx-photo-initials" id="dm-photo-initials">?</div>
                        </div>
                    </div>
                    <button type="button" class="nx-photo-upload" onclick="document.getElementById('dm-photo-file').click()">
                        <i class="fas fa-camera"></i> Upload Photo
                    </button>
                    <input type="file" id="dm-photo-file" accept="image/*" style="display:none" onchange="dmPreviewPhoto(this)">
                    <div class="nx-photo-hint">Recommended: 300 x 400px portrait</div>
                </div>
                <div class="nx-photo-fields">
                    <div class="nx-form-row">
                        <div class="nx-form-group">
                            <label class="nx-form-label">Title</label>
                            <select id="dm-personal-title" class="nx-form-select">
                                <option value="">N/A</option>
                                <option value="Mr">Mr</option>
                                <option value="Mrs">Mrs</option>
                                <option value="Miss">Miss</option>
                                <option value="Ms">Ms</option>
                                <option value="Dr">Dr</option>
                                <option value="Prof">Prof</option>
                                <option value="Rev">Rev</option>
                                <option value="Adv">Adv</option>
                            </select>
                        </div>
                        <div class="nx-form-group">
                            <label class="nx-form-label">Initials</label>
                            <input type="text" id="dm-initials" class="nx-form-input" placeholder="e.g. KM">
                        </div>
                    </div>
                    <div class="nx-form-group">
                        <label class="nx-form-label"><span class="nx-form-req">*</span> Surname</label>
                        <input type="text" id="dm-surname" class="nx-form-input" placeholder="Surname">
                    </div>
                    <div class="nx-form-group">
                        <label class="nx-form-label"><span class="nx-form-req">*</span> First Name</label>
                        <input type="text" id="dm-first-name" class="nx-form-input" placeholder="First Name">
                    </div>
                    <div class="nx-form-row">
                        <div class="nx-form-group">
                            <label class="nx-form-label">Middle Name</label>
                            <input type="text" id="dm-middle-name" class="nx-form-input" placeholder="Optional">
                        </div>
                        <div class="nx-form-group">
                            <label class="nx-form-label">Known As</label>
                            <input type="text" id="dm-known-as" class="nx-form-input" placeholder="e.g. Nickname">
                        </div>
                    </div>
                </div>
            </div>
            <div class="nx-form-row" style="margin-top:4px;">
                <div class="nx-form-group">
                    <label class="nx-form-label">Date of Birth</label>
                    <input type="text" id="dm-dob" class="nx-form-input dm-date-input" placeholder="Select date">
                </div>
                <div class="nx-form-group"></div>
            </div>
            <div class="nx-form-row-3">
                <div class="nx-form-group">
                    <label class="nx-form-label">Ethnic Group</label>
                    <select id="dm-ethnic-group" class="nx-form-select">
                        <option value="">N/A</option>
                        <option value="African">African</option>
                        <option value="Asian">Asian</option>
                        <option value="Coloured">Coloured</option>
                        <option value="Indian">Indian</option>
                        <option value="White">White</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="nx-form-group">
                    <label class="nx-form-label">Gender</label>
                    <select id="dm-gender" class="nx-form-select">
                        <option value="">N/A</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Non-Binary">Non-Binary</option>
                        <option value="Prefer Not To Say">Prefer Not To Say</option>
                    </select>
                </div>
                <div class="nx-form-group">
                    <label class="nx-form-label">Status</label>
                    <select id="dm-director-status" class="nx-form-select">
                        <option value="">N/A</option>
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                        <option value="Resigned">Resigned</option>
                        <option value="Deceased">Deceased</option>
                        <option value="Suspended">Suspended</option>
                    </select>
                </div>
            </div>
            <div class="nx-form-row-4">
                <div class="nx-form-group">
                    <label class="nx-form-label">Marital Status</label>
                    <select id="dm-marital-status" class="nx-form-select">
                        <option value="">N/A</option>
                        <option value="Single">Single</option>
                        <option value="Married">Married</option>
                        <option value="Divorced">Divorced</option>
                        <option value="Widowed">Widowed</option>
                        <option value="Separated">Separated</option>
                        <option value="Civil Union">Civil Union</option>
                    </select>
                </div>
                <div class="nx-form-group">
                    <label class="nx-form-label">Partner Initials</label>
                    <input type="text" id="dm-partner-initials" class="nx-form-input" placeholder="e.g. SM">
                </div>
                <div class="nx-form-group">
                    <label class="nx-form-label">Partner ID Number</label>
                    <input type="text" id="dm-partner-id" class="nx-form-input" placeholder="Partner Identity Number">
                </div>
                <div class="nx-form-group">
                    <label class="nx-form-label">Date of Marriage</label>
                    <input type="text" id="dm-marriage-date" class="nx-form-input dm-date-input" placeholder="Select date">
                </div>
            </div>
        </div>

        {{-- SECTION 2: Identification & Tax (Blue) --}}
        <div class="nx-form-section nx-section-blue" data-nx-form-section>
            <div class="nx-form-section-header">
                <div class="nx-form-section-icon"><i class="fas fa-id-card"></i></div>
                <span class="nx-form-section-title">Identification & Tax</span>
                <div class="nx-form-section-line"></div>
            </div>
            <label class="nx-form-check">
                <input type="checkbox" id="dm-citizen" checked onchange="dmToggleCitizen()"> SA Citizen
            </label>
            <div id="dm-citizen-fields">
                <div class="nx-form-row">
                    <div class="nx-form-group">
                        <label class="nx-form-label"><span class="nx-form-req">*</span> Identity Number</label>
                        <input type="text" id="dm-id-number" class="nx-form-input" placeholder="YYMMDD1234567">
                    </div>
                    <div class="nx-form-group">
                        <label class="nx-form-label">Personal Tax Reference Number</label>
                        <input type="text" id="dm-tax-number" class="nx-form-input" placeholder="0123456789">
                    </div>
                </div>
            </div>
            <div id="dm-foreign-fields" style="display:none;">
                <div class="nx-form-row-3">
                    <div class="nx-form-group">
                        <label class="nx-form-label"><span class="nx-form-req">*</span> Passport Number</label>
                        <input type="text" id="dm-passport-number" class="nx-form-input" placeholder="Passport Number">
                    </div>
                    <div class="nx-form-group">
                        <label class="nx-form-label">Expiry Date</label>
                        <input type="text" id="dm-passport-expiry" class="nx-form-input dm-date-input" placeholder="Select date">
                    </div>
                    <div class="nx-form-group">
                        <label class="nx-form-label">Country of Origin</label>
                        <select id="dm-country-origin" class="nx-form-select">
                            <option value="">N/A</option>
                            <option value="Angola">Angola</option>
                            <option value="Botswana">Botswana</option>
                            <option value="DRC">DRC</option>
                            <option value="Eswatini">Eswatini</option>
                            <option value="Ethiopia">Ethiopia</option>
                            <option value="Ghana">Ghana</option>
                            <option value="India">India</option>
                            <option value="Kenya">Kenya</option>
                            <option value="Lesotho">Lesotho</option>
                            <option value="Malawi">Malawi</option>
                            <option value="Mozambique">Mozambique</option>
                            <option value="Namibia">Namibia</option>
                            <option value="Nigeria">Nigeria</option>
                            <option value="Pakistan">Pakistan</option>
                            <option value="Tanzania">Tanzania</option>
                            <option value="Uganda">Uganda</option>
                            <option value="United Kingdom">United Kingdom</option>
                            <option value="Zambia">Zambia</option>
                            <option value="Zimbabwe">Zimbabwe</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        {{-- SECTION 3: SARS / Contact Information (Purple) --}}
        <div class="nx-form-section nx-section-purple" data-nx-form-section>
            <div class="nx-form-section-header">
                <div class="nx-form-section-icon"><i class="fas fa-headset"></i></div>
                <span class="nx-form-section-title">SARS / Contact Information</span>
                <div class="nx-form-section-line"></div>
            </div>
            <div class="nx-form-row" style="grid-template-columns:1fr 1fr 2fr;">
                <div class="nx-form-group">
                    <label class="nx-form-label">Mobile Number</label>
                    <input type="text" id="dm-mobile" class="nx-form-input" placeholder="Mobile number">
                </div>
                <div class="nx-form-group">
                    <label class="nx-form-label">WhatsApp Number</label>
                    <input type="text" id="dm-whatsapp" class="nx-form-input" placeholder="WhatsApp number">
                </div>
                <div class="nx-form-group">
                    <label class="nx-form-label">Email Address</label>
                    <input type="email" id="dm-email" class="nx-form-input" placeholder="Email address">
                </div>
            </div>
            <div class="nx-form-row">
                <div class="nx-form-group">
                    <label class="nx-form-label">SARS eFiling Login</label>
                    <input type="text" id="dm-sars-login" class="nx-form-input" placeholder="SARS eFiling username">
                </div>
                <div class="nx-form-group">
                    <label class="nx-form-label">SARS eFiling Password</label>
                    <div style="position:relative;">
                        <input type="password" id="dm-sars-password" class="nx-form-input" placeholder="SARS eFiling password" style="padding-right:42px;">
                        <button type="button" onclick="dmToggleSarsPass()" id="dm-sars-eye" style="position:absolute; right:8px; top:50%; transform:translateY(-50%); background:none; border:none; color:#94a3b8; cursor:pointer; padding:4px 6px; font-size:14px; transition:color 0.2s;" title="Show/Hide password"><i class="fas fa-eye"></i></button>
                    </div>
                </div>
            </div>
        </div>

        {{-- SECTION 4: Employment (Green) --}}
        <div class="nx-form-section nx-section-green" data-nx-form-section>
            <div class="nx-form-section-header">
                <div class="nx-form-section-icon"><i class="fas fa-briefcase"></i></div>
                <span class="nx-form-section-title">Employment</span>
                <div class="nx-form-section-line"></div>
            </div>
            <div class="nx-form-row">
                <div class="nx-form-group">
                    <label class="nx-form-label">Title</label>
                    <select id="dm-title" class="nx-form-select">
                        <option value="">N/A</option>
                        <option value="Director">Director</option>
                        <option value="Managing Director">Managing Director</option>
                        <option value="Chief Executive Officer">Chief Executive Officer</option>
                        <option value="Chief Financial Officer">Chief Financial Officer</option>
                        <option value="Chief Operating Officer">Chief Operating Officer</option>
                        <option value="Chief Technology Officer">Chief Technology Officer</option>
                        <option value="Chairperson">Chairperson</option>
                        <option value="Non-Executive Director">Non-Executive Director</option>
                        <option value="Company Secretary">Company Secretary</option>
                        <option value="Finance Manager">Finance Manager</option>
                        <option value="Operations Manager">Operations Manager</option>
                        <option value="General Manager">General Manager</option>
                        <option value="Partner">Partner</option>
                        <option value="Member">Member</option>
                        <option value="Trustee">Trustee</option>
                        <option value="Sole Proprietor">Sole Proprietor</option>
                    </select>
                </div>
                <div class="nx-form-group">
                    <label class="nx-form-label">Occupation Level</label>
                    <select id="dm-occupation-level" class="nx-form-select">
                        <option value="">N/A</option>
                        <option value="Top Management / Executive">Top Management / Executive</option>
                        <option value="Senior Management">Senior Management</option>
                        <option value="Mid-Management / Professional">Mid-Management / Professional</option>
                        <option value="Junior Management / Skilled">Junior Management / Skilled</option>
                        <option value="Semi-Skilled">Semi-Skilled</option>
                        <option value="Unskilled">Unskilled</option>
                    </select>
                </div>
            </div>
        </div>

        {{-- SECTION 5: Banking Details (Blue) --}}
        <div class="nx-form-section nx-section-blue" data-nx-form-section>
            <div class="nx-form-section-header" style="align-items:center;">
                <div class="nx-form-section-icon"><i class="fas fa-university"></i></div>
                <span class="nx-form-section-title">Banking Details</span>
                <div class="nx-form-section-line"></div>
                <button type="button" class="nx-bank-add-btn" id="dm-bank-toggle-btn" onclick="dmToggleBankForm()" style="margin-left:12px; white-space:nowrap; flex-shrink:0;">
                    <i class="fas fa-plus-circle"></i> Add Account
                </button>
            </div>
            <div id="dm-bank-form" style="display:none; padding-top:8px; padding-bottom:6px;">
                <div class="nx-form-row" style="margin-bottom:12px;">
                    <div class="nx-form-group">
                        <label class="nx-form-label">Bank Name</label>
                        <select id="dm-bank-name" class="nx-form-select">
                            <option value="">Select Bank</option>
                            <option value="ABSA Bank">ABSA Bank</option>
                            <option value="African Bank">African Bank</option>
                            <option value="Bidvest Bank">Bidvest Bank</option>
                            <option value="Capitec Bank">Capitec Bank</option>
                            <option value="Discovery Bank">Discovery Bank</option>
                            <option value="First National Bank">First National Bank</option>
                            <option value="Grindrod Bank">Grindrod Bank</option>
                            <option value="Investec Bank">Investec Bank</option>
                            <option value="Mercantile Bank">Mercantile Bank</option>
                            <option value="Nedbank">Nedbank</option>
                            <option value="Old Mutual">Old Mutual</option>
                            <option value="Rand Merchant Bank">Rand Merchant Bank</option>
                            <option value="Sasfin Bank">Sasfin Bank</option>
                            <option value="Standard Bank">Standard Bank</option>
                            <option value="TymeBank">TymeBank</option>
                        </select>
                    </div>
                    <div class="nx-form-group">
                        <label class="nx-form-label">Account Holder Name</label>
                        <input type="text" id="dm-bank-holder" class="nx-form-input" placeholder="Full name on account">
                    </div>
                </div>
                <div class="nx-form-row" style="grid-template-columns:1fr 1fr auto;">
                    <div class="nx-form-group">
                        <label class="nx-form-label">Account Number</label>
                        <input type="text" id="dm-bank-accno" class="nx-form-input" placeholder="Account number">
                    </div>
                    <div class="nx-form-group">
                        <label class="nx-form-label">Account Type</label>
                        <select id="dm-bank-type" class="nx-form-select">
                            <option value="">Select Type</option>
                            <option value="Cheque Account">Cheque Account</option>
                            <option value="Savings Account">Savings Account</option>
                            <option value="Current Account">Current Account</option>
                            <option value="Transmission Account">Transmission Account</option>
                            <option value="Bond Account">Bond Account</option>
                            <option value="Credit Card">Credit Card</option>
                        </select>
                    </div>
                    <div class="nx-form-group" style="display:flex; align-items:flex-end; gap:8px; padding-bottom:1px;">
                        <button type="button" class="nx-bank-add-btn" onclick="dmAddBankAccount()" style="height:42px;">
                            <i class="fas fa-plus-circle"></i> <span id="dm-bank-btn-text">Add</span>
                        </button>
                        <button type="button" id="dm-bank-cancel-btn" class="nx-bank-add-btn" onclick="dmCancelBankEdit()" style="display:none; height:42px; background:linear-gradient(135deg,#64748b,#475569); box-shadow:0 4px 14px rgba(100,116,139,0.25);">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                    </div>
                </div>
            </div>
            <div id="dm-bank-list" class="nx-bank-list" style="margin-top:16px;">
                <div class="nx-bank-empty" id="dm-bank-empty">
                    <i class="fas fa-piggy-bank" style="font-size:22px; margin-bottom:6px; display:block; opacity:0.4;"></i>
                    No bank accounts added yet
                </div>
            </div>
        </div>

        {{-- SECTION 6: Addresses (Amber) --}}
        <div class="nx-form-section nx-section-amber" data-nx-form-section>
            <div class="nx-form-section-header" style="align-items:center;">
                <div class="nx-form-section-icon"><i class="fas fa-map-marker-alt"></i></div>
                <span class="nx-form-section-title">Addresses</span>
                <div class="nx-form-section-line"></div>
                <button type="button" class="nx-addr-add-btn" id="dm-addr-toggle-btn" onclick="dmToggleAddrPanel()" style="margin-left:12px; white-space:nowrap; flex-shrink:0;">
                    <i class="fas fa-link"></i> Link Address
                </button>
            </div>
            <div id="dm-addr-panel" style="display:none; padding-top:8px; padding-bottom:6px;">
                <div id="dm-addr-search-view">
                    <div style="display:grid; grid-template-columns:1fr 3fr; gap:14px; align-items:end; margin-bottom:12px;">
                        <div class="nx-form-group">
                            <label class="nx-form-label">Address Type</label>
                            <select id="dm-addr-link-type" class="nx-form-select">
                                <option value="">Select Type</option>
                                <option value="Residential">Residential</option>
                                <option value="Postal">Postal</option>
                                <option value="Business">Business</option>
                                <option value="Registered">Registered</option>
                                <option value="Domicilium">Domicilium</option>
                            </select>
                        </div>
                        <div class="nx-addr-search-wrap" style="margin-bottom:0;">
                            <i class="fas fa-search"></i>
                            <input type="text" id="dm-addr-search" class="nx-addr-search-input" placeholder="Search addresses by street, city..." oninput="dmFilterAddresses()">
                        </div>
                    </div>
                    <div id="dm-addr-search-list" class="nx-addr-search-list"></div>
                    <div style="margin-top:12px; text-align:center;">
                        <button type="button" class="nx-addr-add-btn" onclick="dmShowNewAddrForm()" style="padding:8px 20px; font-size:11px;">
                            <i class="fas fa-plus-circle"></i> Add New Address
                        </button>
                    </div>
                </div>
                <div id="dm-addr-new-form" style="display:none;">
                    <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:12px;">
                        <span style="font-size:12px; font-weight:800; color:#0f172a; font-family:'Montserrat',sans-serif; text-transform:uppercase; letter-spacing:0.5px;">New Address</span>
                        <button type="button" onclick="dmBackToAddrSearch()" style="background:none; border:none; color:#64748b; font-size:12px; font-weight:700; cursor:pointer; font-family:'Montserrat',sans-serif;"><i class="fas fa-arrow-left"></i> Back to Search</button>
                    </div>
                    <div class="nx-form-group" style="margin-bottom:12px;">
                        <label class="nx-form-label">Country</label>
                        <select id="dm-addr-country" class="nx-form-select">
                            <option value="South Africa" selected>South Africa</option>
                        </select>
                    </div>
                    <div class="nx-form-group" style="margin-bottom:12px;">
                        <label class="nx-form-label"><span class="nx-form-req">*</span> Street Address</label>
                        <input type="text" id="dm-addr-line1" class="nx-form-input" placeholder="Street Address Line 1">
                    </div>
                    <div class="nx-form-group" style="margin-bottom:12px;">
                        <input type="text" id="dm-addr-line2" class="nx-form-input" placeholder="Street Address Line 2 (optional)">
                    </div>
                    <div class="nx-form-row-3" style="margin-bottom:12px;">
                        <div class="nx-form-group">
                            <label class="nx-form-label"><span class="nx-form-req">*</span> City / Town</label>
                            <input type="text" id="dm-addr-city" class="nx-form-input" placeholder="City / Town">
                        </div>
                        <div class="nx-form-group">
                            <label class="nx-form-label">Province</label>
                            <select id="dm-addr-province" class="nx-form-select">
                                <option value="">Select Province</option>
                                <option value="EASTERN CAPE">Eastern Cape</option>
                                <option value="FREE STATE">Free State</option>
                                <option value="GAUTENG">Gauteng</option>
                                <option value="KWA-ZULU NATAL">KwaZulu-Natal</option>
                                <option value="LIMPOPO">Limpopo</option>
                                <option value="MPUMALANGA">Mpumalanga</option>
                                <option value="NORTH WEST">North West</option>
                                <option value="NORTHERN CAPE">Northern Cape</option>
                                <option value="WESTERN CAPE">Western Cape</option>
                            </select>
                        </div>
                        <div class="nx-form-group">
                            <label class="nx-form-label"><span class="nx-form-req">*</span> Postal Code</label>
                            <input type="text" id="dm-addr-postal" class="nx-form-input" placeholder="Postal Code">
                        </div>
                    </div>
                    <div style="display:flex; gap:8px;">
                        <button type="button" class="nx-addr-add-btn" onclick="dmSaveNewAddress()" style="height:42px;">
                            <i class="fas fa-save"></i> Save & Link
                        </button>
                        <button type="button" class="nx-addr-add-btn" onclick="dmBackToAddrSearch()" style="height:42px; background:linear-gradient(135deg,#64748b,#475569); box-shadow:0 4px 14px rgba(100,116,139,0.25);">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                    </div>
                </div>
            </div>
            <div id="dm-addr-list" class="nx-addr-list" style="margin-top:16px;">
                <div class="nx-addr-empty" id="dm-addr-empty">
                    <i class="fas fa-map-signs" style="font-size:22px; margin-bottom:6px; display:block; opacity:0.4;"></i>
                    No addresses linked yet
                </div>
            </div>
        </div>

    </div>

    {{-- Modal Footer --}}
    <div class="nx-modal-footer">
        <div class="nx-modal-footer-note"><span class="nx-form-req">*</span> Indicates a required field</div>
        <div style="display:flex; gap:10px;">
            <button class="nx-modal-cancel" onclick="dmCloseModal()">Cancel</button>
            <button id="dm-save-btn" class="nx-modal-save" onclick="dmSaveDirector()">Save Changes</button>
        </div>
    </div>
</div>
</div>

@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
var DM_CLIENT_ID = {{ $client->id }};
var DM_BASE = '/nexcore/clients/' + DM_CLIENT_ID + '/director-master';
var DM_CSRF = document.querySelector('meta[name="csrf-token"]').content;
var dmCurrentMode = null;
var dmCurrentDirectorId = null;
var dmBankAccounts = [];
var dmBankEditIdx = -1;
var dmLinkedAddresses = [];
var dmSystemAddresses = [];
var dmIsExistingDirector = false;

function dmFilterCards() {
    var q = document.getElementById('dm-filter').value.toLowerCase();
    document.querySelectorAll('.dm-card').forEach(function(card) {
        var name = card.getAttribute('data-name') || '';
        card.style.display = name.indexOf(q) !== -1 ? '' : 'none';
    });
}

function dmOpenModal(mode, directorId) {
    dmCurrentMode = mode;
    dmCurrentDirectorId = directorId || null;
    dmIsExistingDirector = false;
    dmClearForm();

    var title = document.getElementById('dm-modal-title');
    var sub = document.getElementById('dm-modal-sub');
    var searchSection = document.getElementById('dm-search-section');

    if (mode === 'add') {
        title.textContent = 'Add New Director';
        sub.textContent = 'Create a new director record';
        searchSection.style.display = 'block';
    } else if (mode === 'search') {
        title.textContent = 'Search & Link Director';
        sub.textContent = 'Find an existing director to link to this company';
        searchSection.style.display = 'block';
    } else if (mode === 'edit') {
        title.textContent = 'Edit Director';
        sub.textContent = 'Update director information';
        searchSection.style.display = 'none';
        dmLoadDirector(directorId);
    }

    document.getElementById('dm-modal-overlay').classList.add('nx-modal-open');
    document.body.style.overflow = 'hidden';
    dmInitDatePickers();
}

function dmCloseModal() {
    document.getElementById('dm-modal-overlay').classList.remove('nx-modal-open');
    document.body.style.overflow = '';
    dmCurrentMode = null;
    dmCurrentDirectorId = null;
}

function dmInitDatePickers() {
    document.querySelectorAll('.dm-date-input').forEach(function(el) {
        if (!el._flatpickr) {
            flatpickr(el, { dateFormat: 'j M Y', allowInput: true });
        }
    });
}

function dmClearForm() {
    var ids = ['dm-personal-title','dm-initials','dm-surname','dm-first-name','dm-middle-name','dm-known-as','dm-dob',
        'dm-ethnic-group','dm-gender','dm-director-status','dm-marital-status','dm-partner-initials','dm-partner-id','dm-marriage-date',
        'dm-citizen','dm-id-number','dm-tax-number','dm-passport-number','dm-passport-expiry','dm-country-origin',
        'dm-mobile','dm-whatsapp','dm-email','dm-sars-login','dm-sars-password',
        'dm-title','dm-occupation-level','dm-search-value'];
    ids.forEach(function(id) {
        var el = document.getElementById(id);
        if (!el) return;
        if (el.type === 'checkbox') { el.checked = true; }
        else if (el._flatpickr) { el._flatpickr.clear(); }
        else { el.value = ''; }
    });

    document.getElementById('dm-citizen').checked = true;
    dmToggleCitizen();
    document.getElementById('dm-photo-initials').textContent = '?';
    document.getElementById('dm-photo-initials').style.display = '';
    var photoInner = document.querySelector('.nx-photo-inner img');
    if (photoInner) photoInner.remove();

    dmBankAccounts = [];
    dmBankEditIdx = -1;
    dmLinkedAddresses = [];
    dmRenderBankList();
    dmRenderAddrList();

    document.getElementById('dm-bank-form').style.display = 'none';
    document.getElementById('dm-addr-panel').style.display = 'none';
    document.getElementById('dm-search-result').className = 'nx-search-result';
    document.getElementById('dm-search-result').style.display = 'none';

    var addrBtn = document.getElementById('dm-addr-toggle-btn');
    if (addrBtn) { addrBtn.innerHTML = '<i class="fas fa-link"></i> Link Address'; addrBtn.style.background = 'linear-gradient(135deg,#f59e0b,#d97706)'; addrBtn.style.boxShadow = '0 4px 14px rgba(245,158,11,0.25)'; }
}

function dmPopulateForm(d) {
    dmIsExistingDirector = true;
    dmCurrentDirectorId = d.id;

    function setVal(id, val) { var el = document.getElementById(id); if (el) { if (el._flatpickr && val) { el._flatpickr.setDate(val, true); } else { el.value = val || ''; } } }
    function setSel(id, val) { var el = document.getElementById(id); if (el) el.value = val || ''; }

    setSel('dm-personal-title', d.personal_title);
    setVal('dm-initials', d.initials);
    setVal('dm-surname', d.surname);
    setVal('dm-first-name', d.first_name);
    setVal('dm-middle-name', d.middle_name);
    setVal('dm-known-as', d.known_as);
    setVal('dm-dob', d.date_of_birth);
    setSel('dm-ethnic-group', d.ethnic_group);
    setSel('dm-gender', d.gender);
    setSel('dm-director-status', d.director_status);
    setSel('dm-marital-status', d.marital_status);
    setVal('dm-partner-initials', d.partner_initials);
    setVal('dm-partner-id', d.partner_id_number);
    setVal('dm-marriage-date', d.marriage_date);

    var isCitizen = d.is_sa_citizen !== false && d.is_sa_citizen !== 0;
    document.getElementById('dm-citizen').checked = isCitizen;
    dmToggleCitizen();
    setVal('dm-id-number', d.id_number);
    setVal('dm-tax-number', d.tax_number);
    setVal('dm-passport-number', d.passport_number);
    setVal('dm-passport-expiry', d.passport_expiry);
    setSel('dm-country-origin', d.country_of_origin);

    setVal('dm-mobile', d.mobile_number);
    setVal('dm-whatsapp', d.whatsapp_number);
    setVal('dm-email', d.email_address);
    setVal('dm-sars-login', d.sars_login);
    setVal('dm-sars-password', d.sars_password);

    setSel('dm-title', d.employment_title);
    setSel('dm-occupation-level', d.occupation_level);

    var initials = (d.first_name ? d.first_name.charAt(0) : '') + (d.surname ? d.surname.charAt(0) : '');
    document.getElementById('dm-photo-initials').textContent = initials || '?';

    if (d.director_photo) {
        var inner = document.querySelector('.nx-photo-inner');
        var existing = inner.querySelector('img');
        if (existing) existing.remove();
        var img = document.createElement('img');
        img.src = d.director_photo;
        img.style.cssText = 'width:100%;height:100%;object-fit:cover;';
        inner.insertBefore(img, inner.firstChild);
        document.getElementById('dm-photo-initials').style.display = 'none';
    }

    dmBankAccounts = d.bank_accounts || [];
    dmRenderBankList();

    dmLinkedAddresses = d.linked_addresses || [];
    dmRenderAddrList();
}

function dmLoadDirector(directorId) {
    fetch(DM_BASE + '/' + directorId, {
        headers: { 'Accept': 'application/json', 'X-CSRF-TOKEN': DM_CSRF }
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        if (data.director) {
            dmPopulateForm(data.director);
            dmLoadAddresses();
        }
    })
    .catch(function(e) { alert('Error loading director: ' + e.message); });
}

function dmLoadAddresses() {
    fetch(DM_BASE + '/addresses', {
        headers: { 'Accept': 'application/json', 'X-CSRF-TOKEN': DM_CSRF }
    })
    .then(function(r) { return r.json(); })
    .then(function(data) { dmSystemAddresses = data.addresses || []; })
    .catch(function(e) { console.error('Error loading addresses:', e); });
}

function dmSearchDirector() {
    var searchBy = document.getElementById('dm-search-by').value;
    var searchVal = document.getElementById('dm-search-value').value.trim();
    if (!searchVal) { alert('Please enter an ID or Passport number.'); return; }

    fetch(DM_BASE + '/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-TOKEN': DM_CSRF },
        body: JSON.stringify({ search_by: searchBy, search_value: searchVal })
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        var resultEl = document.getElementById('dm-search-result');
        if (data.found) {
            resultEl.className = 'nx-search-result nx-result-found';
            resultEl.style.display = 'flex';
            resultEl.innerHTML = '<i class="fas fa-check-circle"></i> Director found: <strong>' + data.director.first_name + ' ' + data.director.surname + '</strong> — Form populated below. Review and save to link.';
            dmPopulateForm(data.director);
            dmLoadAddresses();
        } else {
            resultEl.className = 'nx-search-result nx-result-notfound';
            resultEl.style.display = 'flex';
            resultEl.innerHTML = '<i class="fas fa-info-circle"></i> ' + (data.message || 'Director not found.') + ' You can create a new record below.';
            dmIsExistingDirector = false;
        }
    })
    .catch(function(e) { alert('Search error: ' + e.message); });
}

function dmClearSearch() {
    document.getElementById('dm-search-value').value = '';
    document.getElementById('dm-search-result').style.display = 'none';
    document.getElementById('dm-search-result').className = 'nx-search-result';
    dmClearForm();
}

function dmSaveDirector() {
    var firstName = document.getElementById('dm-first-name').value.trim();
    var surname = document.getElementById('dm-surname').value.trim();
    if (!firstName || !surname) { alert('First Name and Surname are required.'); return; }

    var formData = new FormData();
    formData.append('personal_title', document.getElementById('dm-personal-title').value);
    formData.append('initials', document.getElementById('dm-initials').value.trim());
    formData.append('first_name', firstName);
    formData.append('middle_name', document.getElementById('dm-middle-name').value.trim());
    formData.append('known_as', document.getElementById('dm-known-as').value.trim());
    formData.append('surname', surname);

    var dobEl = document.getElementById('dm-dob');
    if (dobEl._flatpickr && dobEl._flatpickr.selectedDates.length) {
        formData.append('date_of_birth', dobEl._flatpickr.formatDate(dobEl._flatpickr.selectedDates[0], 'Y-m-d'));
    }
    formData.append('ethnic_group', document.getElementById('dm-ethnic-group').value);
    formData.append('gender', document.getElementById('dm-gender').value);
    formData.append('director_status', document.getElementById('dm-director-status').value || 'Active');
    formData.append('marital_status', document.getElementById('dm-marital-status').value);
    formData.append('partner_initials', document.getElementById('dm-partner-initials').value.trim());
    formData.append('partner_id_number', document.getElementById('dm-partner-id').value.trim());

    var marriageEl = document.getElementById('dm-marriage-date');
    if (marriageEl._flatpickr && marriageEl._flatpickr.selectedDates.length) {
        formData.append('marriage_date', marriageEl._flatpickr.formatDate(marriageEl._flatpickr.selectedDates[0], 'Y-m-d'));
    }

    var isCitizen = document.getElementById('dm-citizen').checked;
    formData.append('is_sa_citizen', isCitizen ? '1' : '0');
    formData.append('id_number', document.getElementById('dm-id-number').value.trim());
    formData.append('tax_number', document.getElementById('dm-tax-number').value.trim());
    formData.append('passport_number', document.getElementById('dm-passport-number').value.trim());

    var passExpEl = document.getElementById('dm-passport-expiry');
    if (passExpEl._flatpickr && passExpEl._flatpickr.selectedDates.length) {
        formData.append('passport_expiry', passExpEl._flatpickr.formatDate(passExpEl._flatpickr.selectedDates[0], 'Y-m-d'));
    }
    formData.append('country_of_origin', document.getElementById('dm-country-origin').value || 'South Africa');

    formData.append('mobile_number', document.getElementById('dm-mobile').value.trim());
    formData.append('whatsapp_number', document.getElementById('dm-whatsapp').value.trim());
    formData.append('email_address', document.getElementById('dm-email').value.trim());
    formData.append('sars_login', document.getElementById('dm-sars-login').value.trim());
    formData.append('sars_password', document.getElementById('dm-sars-password').value.trim());

    formData.append('employment_title', document.getElementById('dm-title').value);
    formData.append('occupation_level', document.getElementById('dm-occupation-level').value);

    formData.append('bank_accounts', JSON.stringify(dmBankAccounts));
    formData.append('address_links', JSON.stringify(dmLinkedAddresses));

    var photoFile = document.getElementById('dm-photo-file').files[0];
    if (photoFile) { formData.append('director_photo', photoFile); }

    var url, method;
    if (dmIsExistingDirector && dmCurrentDirectorId) {
        if (dmCurrentMode === 'search' || dmCurrentMode === 'add') {
            url = DM_BASE + '/link';
            var linkData = {
                director_id: dmCurrentDirectorId,
                title: document.getElementById('dm-title').value,
                occupation_level: document.getElementById('dm-occupation-level').value
            };
            fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-TOKEN': DM_CSRF },
                body: JSON.stringify(linkData)
            })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.success) { dmCloseModal(); location.reload(); }
                else { alert(data.message || 'Error linking director.'); }
            })
            .catch(function(e) { alert('Error: ' + e.message); });
            return;
        }
        url = DM_BASE + '/' + dmCurrentDirectorId;
        formData.append('_method', 'PUT');
    } else {
        url = DM_BASE;
    }

    fetch(url, {
        method: 'POST',
        headers: { 'Accept': 'application/json', 'X-CSRF-TOKEN': DM_CSRF },
        body: formData
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        if (data.success) { dmCloseModal(); location.reload(); }
        else { alert(data.message || 'Error saving director.'); }
    })
    .catch(function(e) { alert('Error: ' + e.message); });
}

function dmUnlinkDirector(directorId, name) {
    if (!confirm('Unlink ' + name + ' from this company? The director record will remain in the system.')) return;
    fetch(DM_BASE + '/' + directorId + '/unlink', {
        method: 'DELETE',
        headers: { 'Accept': 'application/json', 'X-CSRF-TOKEN': DM_CSRF }
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        if (data.success) { location.reload(); }
        else { alert(data.message || 'Error unlinking director.'); }
    })
    .catch(function(e) { alert('Error: ' + e.message); });
}

/* ── Toggle helpers ── */
function dmToggleCitizen() {
    var isCitizen = document.getElementById('dm-citizen').checked;
    document.getElementById('dm-citizen-fields').style.display = isCitizen ? '' : 'none';
    document.getElementById('dm-foreign-fields').style.display = isCitizen ? 'none' : '';
}

function dmToggleSarsPass() {
    var inp = document.getElementById('dm-sars-password');
    var icon = document.querySelector('#dm-sars-eye i');
    if (inp.type === 'password') { inp.type = 'text'; icon.className = 'fas fa-eye-slash'; }
    else { inp.type = 'password'; icon.className = 'fas fa-eye'; }
}

function dmPreviewPhoto(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            var inner = document.querySelector('.nx-photo-inner');
            var existing = inner.querySelector('img');
            if (existing) existing.remove();
            var img = document.createElement('img');
            img.src = e.target.result;
            img.style.cssText = 'width:100%;height:100%;object-fit:cover;';
            inner.insertBefore(img, inner.firstChild);
            document.getElementById('dm-photo-initials').style.display = 'none';
        };
        reader.readAsDataURL(input.files[0]);
    }
}

/* ── Banking ── */
function dmToggleBankForm() {
    var form = document.getElementById('dm-bank-form');
    var btn = document.getElementById('dm-bank-toggle-btn');
    if (form.style.display === 'none') {
        form.style.display = '';
        btn.innerHTML = '<i class="fas fa-times-circle"></i> Close';
        btn.style.background = 'linear-gradient(135deg,#64748b,#475569)';
        btn.style.boxShadow = '0 4px 14px rgba(100,116,139,0.25)';
    } else {
        form.style.display = 'none';
        btn.innerHTML = '<i class="fas fa-plus-circle"></i> Add Account';
        btn.style.background = 'linear-gradient(135deg,#3b82f6,#2563eb)';
        btn.style.boxShadow = '0 4px 14px rgba(59,130,246,0.25)';
        dmClearBankForm();
    }
}

function dmClearBankForm() {
    document.getElementById('dm-bank-name').value = '';
    document.getElementById('dm-bank-holder').value = '';
    document.getElementById('dm-bank-accno').value = '';
    document.getElementById('dm-bank-type').value = '';
    document.getElementById('dm-bank-btn-text').textContent = 'Add';
    document.getElementById('dm-bank-cancel-btn').style.display = 'none';
    dmBankEditIdx = -1;
}

function dmAddBankAccount() {
    var bankName = document.getElementById('dm-bank-name').value;
    var holder = document.getElementById('dm-bank-holder').value.trim();
    var accNo = document.getElementById('dm-bank-accno').value.trim();
    var accType = document.getElementById('dm-bank-type').value;
    if (!bankName || !accNo) { alert('Bank Name and Account Number are required.'); return; }

    var obj = { bank_name: bankName, account_holder: holder, account_number: accNo, account_type: accType, is_primary: false };
    if (dmBankEditIdx >= 0) {
        obj.is_primary = dmBankAccounts[dmBankEditIdx].is_primary;
        dmBankAccounts[dmBankEditIdx] = obj;
    } else {
        if (dmBankAccounts.length === 0) obj.is_primary = true;
        dmBankAccounts.push(obj);
    }
    dmClearBankForm();
    dmRenderBankList();
}

function dmEditBankAccount(idx) {
    var acc = dmBankAccounts[idx];
    document.getElementById('dm-bank-name').value = acc.bank_name;
    document.getElementById('dm-bank-holder').value = acc.account_holder || '';
    document.getElementById('dm-bank-accno').value = acc.account_number;
    document.getElementById('dm-bank-type').value = acc.account_type || '';
    document.getElementById('dm-bank-btn-text').textContent = 'Update';
    document.getElementById('dm-bank-cancel-btn').style.display = '';
    dmBankEditIdx = idx;
    document.getElementById('dm-bank-form').style.display = '';
}

function dmCancelBankEdit() { dmClearBankForm(); }

function dmDeleteBankAccount(idx) {
    if (!confirm('Remove this bank account?')) return;
    var wasPrimary = dmBankAccounts[idx].is_primary;
    dmBankAccounts.splice(idx, 1);
    if (wasPrimary && dmBankAccounts.length) dmBankAccounts[0].is_primary = true;
    dmRenderBankList();
}

function dmSetPrimaryBank(idx) {
    dmBankAccounts.forEach(function(a, i) { a.is_primary = (i === idx); });
    dmRenderBankList();
}

function dmRenderBankList() {
    var list = document.getElementById('dm-bank-list');
    var empty = document.getElementById('dm-bank-empty');
    list.innerHTML = '';
    if (!dmBankAccounts.length) { list.appendChild(empty); empty.style.display = ''; return; }
    empty.style.display = 'none';

    dmBankAccounts.forEach(function(acc, idx) {
        var card = document.createElement('div');
        card.className = 'nx-bank-card' + (acc.is_primary ? ' nx-bank-primary' : '');
        card.innerHTML =
            '<div class="nx-bank-icon"><i class="fas fa-university"></i></div>' +
            '<div class="nx-bank-info">' +
                '<div class="nx-bank-name">' + acc.bank_name +
                    (acc.is_primary ? ' <span class="nx-bank-badge nx-bank-badge-primary">PRIMARY</span>' : '') +
                    (acc.account_type ? ' <span class="nx-bank-badge nx-bank-badge-type">' + acc.account_type + '</span>' : '') +
                '</div>' +
                '<div class="nx-bank-detail">' + (acc.account_holder || '---') + ' &bull; Acc: ' + acc.account_number + '</div>' +
            '</div>' +
            '<div class="nx-bank-actions">' +
                '<button class="nx-bank-action nx-bank-action-star" title="Set Primary" onclick="dmSetPrimaryBank(' + idx + ')"><i class="fas fa-star"></i></button>' +
                '<button class="nx-bank-action nx-bank-action-edit" title="Edit" onclick="dmEditBankAccount(' + idx + ')"><i class="fas fa-pen"></i></button>' +
                '<button class="nx-bank-action nx-bank-action-del" title="Delete" onclick="dmDeleteBankAccount(' + idx + ')"><i class="fas fa-trash"></i></button>' +
            '</div>';
        list.appendChild(card);
    });
}

/* ── Addresses ── */
function dmToggleAddrPanel() {
    var panel = document.getElementById('dm-addr-panel');
    var btn = document.getElementById('dm-addr-toggle-btn');
    if (panel.style.display === 'none') {
        panel.style.display = '';
        btn.innerHTML = '<i class="fas fa-times"></i> Close';
        btn.style.background = 'linear-gradient(135deg,#64748b,#475569)';
        btn.style.boxShadow = '0 4px 14px rgba(100,116,139,0.25)';
        if (!dmSystemAddresses.length) dmLoadAddresses();
        dmFilterAddresses();
    } else {
        panel.style.display = 'none';
        btn.innerHTML = '<i class="fas fa-link"></i> Link Address';
        btn.style.background = 'linear-gradient(135deg,#f59e0b,#d97706)';
        btn.style.boxShadow = '0 4px 14px rgba(245,158,11,0.25)';
    }
}

function dmGetLinkedIds() {
    return dmLinkedAddresses.map(function(l) { return l.address_id; });
}

function dmFilterAddresses() {
    var query = (document.getElementById('dm-addr-search').value || '').toLowerCase();
    var list = document.getElementById('dm-addr-search-list');
    var linkedIds = dmGetLinkedIds();
    var available = dmSystemAddresses.filter(function(a) { return linkedIds.indexOf(a.id) === -1; });

    if (query) {
        available = available.filter(function(a) {
            var full = (a.address_1 + ' ' + (a.address_2 || '') + ' ' + a.city + ' ' + (a.province || '') + ' ' + a.postal_code).toLowerCase();
            return full.indexOf(query) !== -1;
        });
    }

    if (!available.length) {
        list.innerHTML = '<div style="padding:16px; text-align:center; color:#94a3b8; font-size:12px; font-weight:600; font-family:Montserrat,sans-serif; font-style:italic;">' +
            (dmSystemAddresses.length ? 'No matching addresses found' : 'Loading addresses...') + '</div>';
        return;
    }

    list.innerHTML = '';
    available.forEach(function(a) {
        var addrLine = [a.address_1, a.address_2, a.city, a.province, a.postal_code].filter(Boolean).join(', ');
        var item = document.createElement('div');
        item.className = 'nx-addr-search-item';
        item.innerHTML = addrLine;
        item.ondblclick = function() { dmLinkAddress(a.id); };
        list.appendChild(item);
    });
}

function dmLinkAddress(addrId) {
    var linkType = document.getElementById('dm-addr-link-type').value;
    if (!linkType) { alert('Please select an Address Type before linking.'); return; }
    dmLinkedAddresses.push({ address_id: addrId, link_type: linkType });
    dmRenderAddrList();
    dmFilterAddresses();
}

function dmUnlinkAddress(addrId) {
    if (!confirm('Unlink this address from the director?')) return;
    dmLinkedAddresses = dmLinkedAddresses.filter(function(l) { return l.address_id !== addrId; });
    dmRenderAddrList();
    dmFilterAddresses();
}

function dmRenderAddrList() {
    var list = document.getElementById('dm-addr-list');
    var empty = document.getElementById('dm-addr-empty');
    list.innerHTML = '';
    if (!dmLinkedAddresses.length) { list.appendChild(empty); empty.style.display = ''; return; }
    empty.style.display = 'none';

    dmLinkedAddresses.forEach(function(link) {
        var a = dmSystemAddresses.find(function(sa) { return sa.id === link.address_id; });
        if (!a && link.address) a = link.address;
        if (!a) return;
        var addrLine = [a.address_1, a.address_2, a.city, a.province, a.postal_code, a.country].filter(Boolean).join(', ');
        var card = document.createElement('div');
        card.className = 'nx-addr-card';
        card.innerHTML =
            '<div class="nx-addr-icon"><i class="fas fa-map-marker-alt"></i></div>' +
            '<div class="nx-addr-info">' +
                '<div class="nx-addr-type">' + (link.link_type || 'Address') + ' <span class="nx-addr-badge">' + (link.link_type || 'ADDRESS') + '</span></div>' +
                '<div class="nx-addr-detail">' + addrLine + '</div>' +
            '</div>' +
            '<div class="nx-addr-actions">' +
                '<button class="nx-addr-action nx-addr-action-del" title="Unlink" onclick="dmUnlinkAddress(' + a.id + ')"><i class="fas fa-unlink"></i></button>' +
            '</div>';
        list.appendChild(card);
    });
}

function dmShowNewAddrForm() {
    var linkType = document.getElementById('dm-addr-link-type').value;
    if (!linkType) { alert('Please select an Address Type first.'); return; }
    document.getElementById('dm-addr-search-view').style.display = 'none';
    document.getElementById('dm-addr-new-form').style.display = '';
}

function dmBackToAddrSearch() {
    document.getElementById('dm-addr-new-form').style.display = 'none';
    document.getElementById('dm-addr-search-view').style.display = '';
    dmClearAddrForm();
}

function dmClearAddrForm() {
    ['dm-addr-line1','dm-addr-line2','dm-addr-city','dm-addr-province','dm-addr-postal'].forEach(function(id) {
        var el = document.getElementById(id); if (el) el.value = '';
    });
    document.getElementById('dm-addr-country').value = 'South Africa';
}

function dmSaveNewAddress() {
    var linkType = document.getElementById('dm-addr-link-type').value;
    var line1 = document.getElementById('dm-addr-line1').value.trim();
    var city = document.getElementById('dm-addr-city').value.trim();
    var postal = document.getElementById('dm-addr-postal').value.trim();
    if (!line1 || !city || !postal) { alert('Please fill in Street Address, City, and Postal Code.'); return; }

    var addrData = {
        address_1: line1.toUpperCase(),
        address_2: (document.getElementById('dm-addr-line2').value.trim()).toUpperCase(),
        city: city.toUpperCase(),
        province: document.getElementById('dm-addr-province').value,
        postal_code: postal,
        country: document.getElementById('dm-addr-country').value
    };

    fetch(DM_BASE + '/addresses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-TOKEN': DM_CSRF },
        body: JSON.stringify(addrData)
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        if (data.success && data.address) {
            dmSystemAddresses.push(data.address);
            dmLinkedAddresses.push({ address_id: data.address.id, link_type: linkType });
            dmRenderAddrList();
            dmBackToAddrSearch();
            dmFilterAddresses();
        } else {
            alert('Error saving address.');
        }
    })
    .catch(function(e) { alert('Error: ' + e.message); });
}

document.addEventListener('DOMContentLoaded', function() {
    dmInitDatePickers();
});
</script>
@endpush
