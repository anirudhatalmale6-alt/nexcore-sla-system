@php
function ccTimeAgo($date) {
    if (!$date) return '';
    $diff = now()->diffInMinutes($date);
    if ($diff < 1) return 'Just now';
    if ($diff < 60) return $diff . 'm ago';
    $hours = floor($diff / 60);
    if ($hours < 24) return $hours . 'h ago';
    $days = floor($hours / 24);
    if ($days < 7) return $days . 'd ago';
    return $date->format('j M Y');
}

$actionIcons = [
    'created' => ['icon' => 'fa-plus-circle', 'color' => '#22c55e'],
    'status_changed' => ['icon' => 'fa-exchange-alt', 'color' => '#3b82f6'],
    'comment_added' => ['icon' => 'fa-comment', 'color' => '#06b6d4'],
    'attachment_added' => ['icon' => 'fa-paperclip', 'color' => '#f59e0b'],
    'step_completed' => ['icon' => 'fa-check-circle', 'color' => '#8b5cf6'],
    'deleted' => ['icon' => 'fa-trash', 'color' => '#ef4444'],
    'updated' => ['icon' => 'fa-pen', 'color' => '#3b82f6'],
    'assigned' => ['icon' => 'fa-user-plus', 'color' => '#06b6d4'],
];

$statusColors = [
    'pending' => '#94a3b8',
    'in_progress' => '#3b82f6',
    'review' => '#f59e0b',
    'completed' => '#22c55e',
    'on_hold' => '#8b5cf6',
    'cancelled' => '#ef4444',
];

$statusLabels = [
    'pending' => 'Pending',
    'in_progress' => 'In Progress',
    'review' => 'In Review',
    'completed' => 'Completed',
    'on_hold' => 'On Hold',
    'cancelled' => 'Cancelled',
];

$priorityColors = [
    'urgent' => '#ef4444',
    'high' => '#f97316',
    'medium' => '#f59e0b',
    'low' => '#22c55e',
];

$priorityLabels = [
    'urgent' => 'Urgent',
    'high' => 'High',
    'medium' => 'Medium',
    'low' => 'Low',
];
@endphp
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>NexCore | Command Centre</title>
<link rel="shortcut icon" type="image/png" href="/public/smartdash/images/favicon.png">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
:root{
    --cc-bg:#080a12;
    --cc-sidebar-bg:#0a0e1a;
    --cc-surface:rgba(12,16,26,0.9);
    --cc-surface-solid:#0c101a;
    --cc-surface2:#131a2b;
    --cc-border:rgba(255,255,255,0.06);
    --cc-border2:rgba(255,255,255,0.12);
    --cc-text:#f1f5f9;
    --cc-dim:#b0bec5;
    --cc-muted:#6b7a8d;
    --cc-accent1:#06b6d4;
    --cc-accent2:#8b5cf6;
    --cc-green:#22c55e;
    --cc-red:#ef4444;
    --cc-blue:#3b82f6;
    --cc-amber:#f59e0b;
    --cc-cyan:#06b6d4;
    --cc-purple:#8b5cf6;
    --sidebar-w:260px;
}
html{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}
body{font-family:'Montserrat',sans-serif;background:var(--cc-bg);color:var(--cc-text);height:100vh;overflow:hidden;display:flex;position:relative}

/* ====== BACKGROUND EFFECTS ====== */
body::before{
    content:'';position:fixed;top:-50%;left:-50%;width:200%;height:200%;
    background:radial-gradient(ellipse at 20% 50%, rgba(6,182,212,0.03) 0%, transparent 50%),
               radial-gradient(ellipse at 80% 20%, rgba(139,92,246,0.03) 0%, transparent 50%),
               radial-gradient(ellipse at 50% 80%, rgba(59,130,246,0.02) 0%, transparent 50%);
    pointer-events:none;z-index:0;
}

/* ====== SIDEBAR ====== */
.cc-sb{
    width:var(--sidebar-w);height:100vh;background:var(--cc-sidebar-bg);
    border-right:1px solid var(--cc-border);display:flex;flex-direction:column;
    flex-shrink:0;overflow:hidden;position:relative;z-index:10;
    backdrop-filter:blur(20px);
    transition:width 0.3s cubic-bezier(0.4,0,0.2,1);
}
.cc-sb.collapsed{width:68px}
.cc-sb.collapsed .cc-sb-brand span,
.cc-sb.collapsed .cc-sb-item span,
.cc-sb.collapsed .cc-sb-badge,
.cc-sb.collapsed .cc-sb-footer-info,
.cc-sb.collapsed .cc-sb-section-label,
.cc-sb.collapsed .cc-sb-client-code{display:none}
.cc-sb.collapsed .cc-sb-item{justify-content:center;padding:12px 0}
.cc-sb.collapsed .cc-sb-item i{margin:0}

.cc-sb-logo{
    padding:20px 20px 18px;display:flex;align-items:center;gap:14px;
    border-bottom:1px solid var(--cc-border);position:relative;
}
.cc-sb-hex{
    width:40px;height:40px;
    background:linear-gradient(135deg,var(--cc-cyan),var(--cc-purple));
    clip-path:polygon(50% 0%,100% 25%,100% 75%,50% 100%,0% 75%,0% 25%);
    display:flex;align-items:center;justify-content:center;flex-shrink:0;
    box-shadow:0 0 20px rgba(6,182,212,0.3);
}
.cc-sb-hex i{color:#fff;font-size:15px}
.cc-sb-brand{display:flex;flex-direction:column}
.cc-sb-brand span:first-child{font-size:15px;font-weight:800;letter-spacing:2px;color:#fff;text-transform:uppercase}
.cc-sb-brand span:last-child{font-size:9px;font-weight:600;letter-spacing:1px;color:var(--cc-muted);text-transform:uppercase;margin-top:2px}

.cc-sb-toggle-btn{
    position:absolute;right:-13px;top:50%;transform:translateY(-50%);
    width:26px;height:26px;border-radius:50%;background:var(--cc-surface-solid);
    border:1px solid var(--cc-border2);display:flex;align-items:center;justify-content:center;
    cursor:pointer;z-index:20;color:var(--cc-dim);font-size:10px;transition:all 0.2s;
}
.cc-sb-toggle-btn:hover{background:var(--cc-cyan);color:#fff;border-color:var(--cc-cyan)}

.cc-sb-nav{flex:1;overflow-y:auto;padding:8px 0}
.cc-sb-nav::-webkit-scrollbar{width:3px}
.cc-sb-nav::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.06);border-radius:2px}

.cc-sb-section-label{
    font-size:9px;font-weight:700;letter-spacing:1.5px;color:var(--cc-muted);
    text-transform:uppercase;padding:16px 20px 6px;
}

.cc-sb-item{
    display:flex;align-items:center;gap:12px;padding:10px 20px;
    font-size:13px;font-weight:500;color:var(--cc-dim);cursor:pointer;
    transition:all 0.2s;position:relative;text-decoration:none;
}
.cc-sb-item:hover{color:var(--cc-text);background:rgba(255,255,255,0.03)}
.cc-sb-item.active{color:#fff;background:linear-gradient(90deg,rgba(6,182,212,0.1),transparent)}
.cc-sb-item.active::before{
    content:'';position:absolute;left:0;top:4px;bottom:4px;width:3px;
    background:linear-gradient(180deg,var(--cc-cyan),var(--cc-purple));border-radius:0 3px 3px 0;
}
.cc-sb-item i{width:20px;text-align:center;font-size:14px;flex-shrink:0}
.cc-sb-item.active i{color:var(--cc-cyan)}
.cc-sb-item span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1}
.cc-sb-badge{
    margin-left:auto;background:var(--cc-red);color:#fff;font-size:9px;font-weight:700;
    padding:2px 7px;border-radius:10px;min-width:18px;text-align:center;flex-shrink:0;
}
.cc-sb-client-code{
    font-size:9px;color:var(--cc-muted);margin-left:auto;font-weight:600;
    letter-spacing:0.5px;flex-shrink:0;
}

.cc-sb-footer{
    padding:14px 18px;border-top:1px solid var(--cc-border);
    background:rgba(0,0,0,0.2);
}
.cc-sb-footer-info{display:flex;align-items:center;gap:10px}
.cc-sb-footer-av{
    width:32px;height:32px;border-radius:50%;
    background:linear-gradient(135deg,var(--cc-cyan),var(--cc-purple));
    display:flex;align-items:center;justify-content:center;
    font-size:11px;font-weight:700;color:#fff;flex-shrink:0;
}
.cc-sb-footer-text{display:flex;flex-direction:column}
.cc-sb-footer-text span:first-child{font-size:12px;font-weight:600;color:#fff}
.cc-sb-footer-text span:last-child{font-size:9px;color:var(--cc-muted);letter-spacing:0.5px}

/* ====== MAIN ====== */
.cc-main{flex:1;display:flex;flex-direction:column;overflow:hidden;position:relative;z-index:1}

/* ====== TOPBAR ====== */
.cc-top{
    height:62px;background:rgba(10,14,26,0.95);backdrop-filter:blur(20px);
    border-bottom:1px solid var(--cc-border);display:flex;align-items:center;
    padding:0 28px;gap:20px;flex-shrink:0;
}
.cc-top-title{display:flex;flex-direction:column}
.cc-top-title h1{
    font-size:18px;font-weight:800;color:#fff;line-height:1.2;letter-spacing:0.5px;
    background:linear-gradient(135deg,#fff,var(--cc-cyan));
    -webkit-background-clip:text;-webkit-text-fill-color:transparent;
    background-clip:text;
}
.cc-top-subtitle{
    font-size:10px;color:var(--cc-muted);letter-spacing:1px;font-weight:500;
    text-transform:uppercase;
}
.cc-top-subtitle .cc-pulse-dot{
    display:inline-block;width:6px;height:6px;border-radius:50%;
    background:var(--cc-green);margin-right:6px;
    animation:ccPulse 2s ease-in-out infinite;
}
.cc-top-spacer{flex:1}
.cc-top-clock{
    display:flex;flex-direction:column;align-items:flex-end;
}
.cc-top-time{font-size:20px;font-weight:700;color:#fff;letter-spacing:1px;font-variant-numeric:tabular-nums}
.cc-top-date{font-size:10px;color:var(--cc-muted);letter-spacing:0.5px;font-weight:500}

/* ====== CONTENT ====== */
.cc-content{
    flex:1;overflow-y:auto;padding:20px 24px;display:flex;flex-direction:column;gap:18px;
}
.cc-content::-webkit-scrollbar{width:6px}
.cc-content::-webkit-scrollbar-track{background:transparent}
.cc-content::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.06);border-radius:3px}
.cc-content::-webkit-scrollbar-thumb:hover{background:rgba(255,255,255,0.1)}

/* ====== STAT CARDS ====== */
.cc-stats{display:grid;grid-template-columns:repeat(6,1fr);gap:14px}
.cc-stat{
    background:var(--cc-surface);backdrop-filter:blur(20px);
    border:1px solid var(--cc-border);border-radius:14px;
    padding:18px 20px;display:flex;align-items:center;gap:16px;
    position:relative;overflow:hidden;transition:all 0.3s ease;
}
.cc-stat::before{
    content:'';position:absolute;top:0;left:0;right:0;height:2px;
    border-radius:14px 14px 0 0;opacity:0.8;
}
.cc-stat::after{
    content:'';position:absolute;inset:0;border-radius:14px;
    opacity:0;transition:opacity 0.3s;pointer-events:none;
}
.cc-stat:hover{transform:translateY(-2px);border-color:var(--cc-border2)}
.cc-stat:hover::after{opacity:1}

.cc-stat-icon{
    width:48px;height:48px;border-radius:14px;display:flex;
    align-items:center;justify-content:center;font-size:20px;flex-shrink:0;
    position:relative;
}
.cc-stat-info{flex:1;min-width:0}
.cc-stat-label{font-size:10px;font-weight:600;letter-spacing:1px;color:var(--cc-muted);text-transform:uppercase;margin-bottom:4px}
.cc-stat-val{font-size:30px;font-weight:800;color:#fff;line-height:1;letter-spacing:1px}

.cc-stat.gray::before{background:linear-gradient(90deg,#94a3b8,#64748b)}
.cc-stat.gray .cc-stat-icon{background:rgba(148,163,184,0.12);color:#94a3b8}
.cc-stat.gray::after{background:radial-gradient(circle at 30% 50%,rgba(148,163,184,0.04),transparent 70%)}

.cc-stat.blue::before{background:linear-gradient(90deg,#3b82f6,#06b6d4)}
.cc-stat.blue .cc-stat-icon{background:rgba(59,130,246,0.12);color:#3b82f6}
.cc-stat.blue::after{background:radial-gradient(circle at 30% 50%,rgba(59,130,246,0.04),transparent 70%)}

.cc-stat.red::before{background:linear-gradient(90deg,#ef4444,#f97316)}
.cc-stat.red .cc-stat-icon{background:rgba(239,68,68,0.12);color:#ef4444}
.cc-stat.red::after{background:radial-gradient(circle at 30% 50%,rgba(239,68,68,0.04),transparent 70%)}

.cc-stat.amber::before{background:linear-gradient(90deg,#f59e0b,#eab308)}
.cc-stat.amber .cc-stat-icon{background:rgba(245,158,11,0.12);color:#f59e0b}
.cc-stat.amber::after{background:radial-gradient(circle at 30% 50%,rgba(245,158,11,0.04),transparent 70%)}

.cc-stat.green::before{background:linear-gradient(90deg,#22c55e,#10b981)}
.cc-stat.green .cc-stat-icon{background:rgba(34,197,94,0.12);color:#22c55e}
.cc-stat.green::after{background:radial-gradient(circle at 30% 50%,rgba(34,197,94,0.04),transparent 70%)}

.cc-stat.flame::before{background:linear-gradient(90deg,#ef4444,#dc2626)}
.cc-stat.flame .cc-stat-icon{background:rgba(239,68,68,0.15);color:#ef4444}
.cc-stat.flame::after{background:radial-gradient(circle at 30% 50%,rgba(239,68,68,0.04),transparent 70%)}

.cc-pulse-icon{animation:ccPulse 2s ease-in-out infinite}

/* ====== PANEL (shared) ====== */
.cc-panel{
    background:var(--cc-surface);backdrop-filter:blur(20px);
    border:1px solid var(--cc-border);border-radius:14px;overflow:hidden;
}
.cc-panel-head{
    display:flex;align-items:center;justify-content:space-between;
    padding:14px 18px;border-bottom:1px solid var(--cc-border);
}
.cc-panel-title{
    font-size:12px;font-weight:700;letter-spacing:1px;text-transform:uppercase;
    color:var(--cc-text);display:flex;align-items:center;gap:8px;
}
.cc-panel-title i{font-size:14px}
.cc-panel-body{padding:16px 18px}

/* ====== MID ROW ====== */
.cc-mid{display:grid;grid-template-columns:1fr 1fr;gap:18px}

/* Donut Chart */
.cc-donut-wrap{display:flex;align-items:center;justify-content:center;gap:30px;padding:20px 0}
.cc-donut-canvas{flex-shrink:0}
.cc-donut-legend{display:flex;flex-direction:column;gap:8px}
.cc-legend-item{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--cc-dim)}
.cc-legend-dot{width:10px;height:10px;border-radius:3px;flex-shrink:0}
.cc-legend-count{margin-left:auto;font-weight:700;color:var(--cc-text);min-width:28px;text-align:right}

/* Priority Bars */
.cc-pri-bars{display:flex;flex-direction:column;gap:14px;padding:6px 0}
.cc-pri-row{display:flex;align-items:center;gap:12px}
.cc-pri-label{font-size:12px;font-weight:600;color:var(--cc-dim);width:60px;text-align:right}
.cc-pri-bar-track{flex:1;height:28px;background:rgba(255,255,255,0.04);border-radius:8px;overflow:hidden;position:relative}
.cc-pri-bar-fill{height:100%;border-radius:8px;display:flex;align-items:center;padding:0 10px;font-size:11px;font-weight:700;color:#fff;
    transition:width 1s cubic-bezier(0.4,0,0.2,1);min-width:0;
}
.cc-pri-count{font-size:13px;font-weight:700;color:var(--cc-text);min-width:28px;text-align:right}

/* ====== OVERDUE + UPCOMING ====== */
.cc-split{display:grid;grid-template-columns:1fr 1fr;gap:18px}

.cc-task-list{display:flex;flex-direction:column;gap:0}
.cc-task-row{
    display:flex;align-items:center;gap:12px;padding:10px 0;
    border-bottom:1px solid var(--cc-border);transition:background 0.15s;
}
.cc-task-row:last-child{border-bottom:none}
.cc-task-row:hover{background:rgba(255,255,255,0.02);margin:0 -18px;padding:10px 18px}
.cc-task-title-col{flex:1;min-width:0}
.cc-task-title-link{
    font-size:13px;font-weight:600;color:#fff;text-decoration:none;
    display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
    transition:color 0.2s;
}
.cc-task-title-link:hover{color:var(--cc-cyan)}
.cc-task-client{font-size:11px;color:var(--cc-muted);margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cc-task-meta{display:flex;align-items:center;gap:10px;flex-shrink:0}
.cc-task-badge{
    font-size:10px;font-weight:700;padding:3px 9px;border-radius:6px;
    white-space:nowrap;letter-spacing:0.3px;
}
.cc-task-assigned{font-size:11px;color:var(--cc-dim);white-space:nowrap;max-width:100px;overflow:hidden;text-overflow:ellipsis}
.cc-empty-state{
    display:flex;flex-direction:column;align-items:center;justify-content:center;
    padding:30px 20px;color:var(--cc-muted);gap:8px;
}
.cc-empty-state i{font-size:28px}
.cc-empty-state span{font-size:13px;font-weight:500}

/* ====== BOTTOM ROW ====== */
.cc-bottom{display:grid;grid-template-columns:2fr 1.5fr 1.5fr;gap:18px}

/* Activity Feed */
.cc-activity-scroll{max-height:320px;overflow-y:auto}
.cc-activity-scroll::-webkit-scrollbar{width:3px}
.cc-activity-scroll::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.06);border-radius:2px}

.cc-activity-item{
    display:flex;align-items:flex-start;gap:10px;padding:8px 0;
    border-bottom:1px solid rgba(255,255,255,0.03);
}
.cc-activity-item:last-child{border-bottom:none}
.cc-activity-icon{
    width:30px;height:30px;border-radius:8px;display:flex;
    align-items:center;justify-content:center;font-size:12px;flex-shrink:0;
}
.cc-activity-body{flex:1;min-width:0}
.cc-activity-text{font-size:12px;color:var(--cc-dim);line-height:1.4}
.cc-activity-text strong{color:var(--cc-text);font-weight:600}
.cc-activity-time{font-size:10px;color:var(--cc-muted);margin-top:2px}

/* Team Workload */
.cc-team-list{display:flex;flex-direction:column;gap:10px}
.cc-team-row{display:flex;align-items:center;gap:10px}
.cc-team-name{font-size:12px;font-weight:600;color:var(--cc-dim);width:80px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cc-team-bar-track{flex:1;height:22px;background:rgba(255,255,255,0.04);border-radius:6px;overflow:hidden}
.cc-team-bar-fill{
    height:100%;border-radius:6px;display:flex;align-items:center;padding:0 8px;
    font-size:10px;font-weight:700;color:#fff;
    background:linear-gradient(90deg,var(--cc-cyan),var(--cc-purple));
    transition:width 1s cubic-bezier(0.4,0,0.2,1);
}
.cc-team-overdue{font-size:10px;font-weight:700;color:var(--cc-red);min-width:20px;text-align:right;flex-shrink:0}

/* Tasks by Client */
.cc-client-list{display:flex;flex-direction:column;gap:0}
.cc-client-row{
    display:flex;align-items:center;gap:10px;padding:8px 0;
    border-bottom:1px solid rgba(255,255,255,0.03);text-decoration:none;
    transition:background 0.15s;cursor:pointer;
}
.cc-client-row:last-child{border-bottom:none}
.cc-client-row:hover{background:rgba(255,255,255,0.02);margin:0 -18px;padding:8px 18px}
.cc-client-name{font-size:12px;font-weight:600;color:var(--cc-dim);flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cc-client-counts{font-size:11px;color:var(--cc-muted);white-space:nowrap}
.cc-client-counts strong{color:var(--cc-text);font-weight:700}
.cc-client-mini-bar{width:60px;height:6px;background:rgba(255,255,255,0.05);border-radius:3px;overflow:hidden;flex-shrink:0}
.cc-client-mini-fill{height:100%;border-radius:3px;background:linear-gradient(90deg,var(--cc-cyan),var(--cc-green))}

/* ====== RESPONSIVE ====== */
@@media(max-width:1400px){
    .cc-stats{grid-template-columns:repeat(3,1fr)}
    .cc-bottom{grid-template-columns:1fr 1fr}
}
@@media(max-width:1100px){
    .cc-mid{grid-template-columns:1fr}
    .cc-split{grid-template-columns:1fr}
    .cc-bottom{grid-template-columns:1fr}
}
@@media(max-width:900px){
    .cc-stats{grid-template-columns:repeat(2,1fr)}
    .cc-sb{width:68px}
    .cc-sb .cc-sb-brand span,
    .cc-sb .cc-sb-item span,
    .cc-sb .cc-sb-badge,
    .cc-sb .cc-sb-footer-info,
    .cc-sb .cc-sb-section-label,
    .cc-sb .cc-sb-client-code{display:none}
    .cc-sb .cc-sb-item{justify-content:center;padding:12px 0}
    .cc-sb .cc-sb-toggle-btn{display:none}
}
@@media(max-width:640px){
    .cc-stats{grid-template-columns:1fr}
    .cc-content{padding:12px}
    .cc-top{padding:0 14px}
}

/* ====== ANIMATIONS ====== */
@@keyframes ccPulse{
    0%,100%{opacity:1}
    50%{opacity:0.4}
}
@@keyframes ccFadeIn{
    from{opacity:0;transform:translateY(12px)}
    to{opacity:1;transform:translateY(0)}
}
@@keyframes ccSlideRight{
    from{opacity:0;transform:translateX(-16px)}
    to{opacity:1;transform:translateX(0)}
}
@@keyframes ccGlow{
    0%,100%{box-shadow:0 0 8px rgba(6,182,212,0.15)}
    50%{box-shadow:0 0 20px rgba(6,182,212,0.3)}
}

.cc-animate{animation:ccFadeIn 0.5s ease-out both}
.cc-animate-1{animation-delay:0.05s}
.cc-animate-2{animation-delay:0.1s}
.cc-animate-3{animation-delay:0.15s}
.cc-animate-4{animation-delay:0.2s}
.cc-animate-5{animation-delay:0.25s}
.cc-animate-6{animation-delay:0.3s}
.cc-animate-7{animation-delay:0.35s}
.cc-animate-8{animation-delay:0.4s}

.cc-sb-animate{animation:ccSlideRight 0.4s ease-out both}

/* ====== SCROLLBAR GLOBAL ====== */
::-webkit-scrollbar{width:6px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.06);border-radius:3px}
</style>
</head>
<body>

{{-- ============================================================ --}}
{{-- SIDEBAR --}}
{{-- ============================================================ --}}
<aside class="cc-sb" id="ccSidebar">
    <div class="cc-sb-logo">
        <div class="cc-sb-hex"><i class="fas fa-hexagon-check"></i></div>
        <div class="cc-sb-brand">
            <span>NEXCORE</span>
            <span>Command Centre</span>
        </div>
        <div class="cc-sb-toggle-btn" id="ccSbToggle" title="Toggle sidebar">
            <i class="fas fa-chevron-left"></i>
        </div>
    </div>

    <nav class="cc-sb-nav">
        <div class="cc-sb-section-label">Navigation</div>

        <a href="{{ route('nexcore.command-centre') }}" class="cc-sb-item active cc-sb-animate" style="animation-delay:0.05s">
            <i class="fas fa-border-all"></i>
            <span>Command Centre</span>
        </a>
        <a href="{{ route('nexcore.clients.index') }}" class="cc-sb-item cc-sb-animate" style="animation-delay:0.08s">
            <i class="fas fa-users"></i>
            <span>All Clients</span>
            <span class="cc-sb-badge">{{ $clients->count() }}</span>
        </a>

        @if($clients->count() > 0)
            <div class="cc-sb-section-label" style="margin-top:6px">Clients</div>
            @foreach($clients as $idx => $client)
                <a href="{{ route('nexcore.clients.show.tasks', $client->id) }}"
                   class="cc-sb-item cc-sb-animate"
                   style="animation-delay:{{ 0.1 + ($idx * 0.02) }}s"
                   title="{{ $client->company_name }}">
                    <i class="fas fa-briefcase"></i>
                    <span>{{ \Illuminate\Support\Str::limit($client->company_name, 22) }}</span>
                    @if($client->client_code)
                        <span class="cc-sb-client-code">{{ $client->client_code }}</span>
                    @endif
                </a>
            @endforeach
        @endif
    </nav>

    <div class="cc-sb-footer">
        <div class="cc-sb-footer-info">
            <div class="cc-sb-footer-av">
                {{ strtoupper(substr(auth()->user()->name ?? 'A', 0, 1)) }}{{ strtoupper(substr(explode(' ', auth()->user()->name ?? 'Admin')[1] ?? '', 0, 1)) }}
            </div>
            <div class="cc-sb-footer-text">
                <span>{{ auth()->user()->name ?? 'Admin' }}</span>
                <span>{{ now()->format('j M Y') }}</span>
            </div>
        </div>
    </div>
</aside>

{{-- ============================================================ --}}
{{-- MAIN --}}
{{-- ============================================================ --}}
<div class="cc-main">

    {{-- TOPBAR --}}
    <header class="cc-top">
        <div class="cc-top-title">
            <h1>NexCore Command Centre</h1>
            <div class="cc-top-subtitle">
                <span class="cc-pulse-dot"></span>
                LIVE OPERATIONS DASHBOARD
            </div>
        </div>
        <div class="cc-top-spacer"></div>
        <div class="cc-top-clock">
            <div class="cc-top-time" id="ccClock">--:--</div>
            <div class="cc-top-date" id="ccDate">--</div>
        </div>
    </header>

    {{-- CONTENT --}}
    <div class="cc-content">

        {{-- ============================================================ --}}
        {{-- STAT CARDS ROW --}}
        {{-- ============================================================ --}}
        <div class="cc-stats">
            {{-- Total Tasks --}}
            <div class="cc-stat gray cc-animate cc-animate-1">
                <div class="cc-stat-icon"><i class="fas fa-layer-group"></i></div>
                <div class="cc-stat-info">
                    <div class="cc-stat-label">Total Tasks</div>
                    <div class="cc-stat-val">{{ $totalTasks }}</div>
                </div>
            </div>
            {{-- Active Tasks --}}
            <div class="cc-stat blue cc-animate cc-animate-2">
                <div class="cc-stat-icon"><i class="fas fa-bolt"></i></div>
                <div class="cc-stat-info">
                    <div class="cc-stat-label">Active Tasks</div>
                    <div class="cc-stat-val">{{ $activeTasks->count() }}</div>
                </div>
            </div>
            {{-- Overdue --}}
            <div class="cc-stat red cc-animate cc-animate-3">
                <div class="cc-stat-icon @if($overdueTasks->count() > 0) cc-pulse-icon @endif"><i class="fas fa-exclamation-triangle"></i></div>
                <div class="cc-stat-info">
                    <div class="cc-stat-label">Overdue</div>
                    <div class="cc-stat-val">{{ $overdueTasks->count() }}</div>
                </div>
            </div>
            {{-- Due This Week --}}
            <div class="cc-stat amber cc-animate cc-animate-4">
                <div class="cc-stat-icon"><i class="fas fa-clock"></i></div>
                <div class="cc-stat-info">
                    <div class="cc-stat-label">Due This Week</div>
                    <div class="cc-stat-val">{{ $dueThisWeek->count() }}</div>
                </div>
            </div>
            {{-- Completed This Month --}}
            <div class="cc-stat green cc-animate cc-animate-5">
                <div class="cc-stat-icon"><i class="fas fa-check-circle"></i></div>
                <div class="cc-stat-info">
                    <div class="cc-stat-label">Completed (Month)</div>
                    <div class="cc-stat-val">{{ $completedThisMonth->count() }}</div>
                </div>
            </div>
            {{-- Urgent --}}
            <div class="cc-stat flame cc-animate cc-animate-6">
                <div class="cc-stat-icon @if($urgentTasks->count() > 0) cc-pulse-icon @endif"><i class="fas fa-fire"></i></div>
                <div class="cc-stat-info">
                    <div class="cc-stat-label">Urgent</div>
                    <div class="cc-stat-val">{{ $urgentTasks->count() }}</div>
                </div>
            </div>
        </div>

        {{-- ============================================================ --}}
        {{-- MID ROW: STATUS DONUT + PRIORITY BARS --}}
        {{-- ============================================================ --}}
        <div class="cc-mid">
            {{-- Status Distribution Donut --}}
            <div class="cc-panel cc-animate cc-animate-7">
                <div class="cc-panel-head">
                    <div class="cc-panel-title">
                        <i class="fas fa-chart-pie" style="color:var(--cc-cyan)"></i>
                        Status Distribution
                    </div>
                </div>
                <div class="cc-panel-body">
                    <div class="cc-donut-wrap">
                        <canvas id="ccDonutCanvas" class="cc-donut-canvas" width="180" height="180"></canvas>
                        <div class="cc-donut-legend">
                            @foreach($statusBreakdown as $status => $count)
                                <div class="cc-legend-item">
                                    <span class="cc-legend-dot" style="background:{{ $statusColors[$status] ?? '#94a3b8' }}"></span>
                                    {{ $statusLabels[$status] ?? ucfirst(str_replace('_', ' ', $status)) }}
                                    <span class="cc-legend-count">{{ $count }}</span>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>

            {{-- Priority Breakdown --}}
            <div class="cc-panel cc-animate cc-animate-8">
                <div class="cc-panel-head">
                    <div class="cc-panel-title">
                        <i class="fas fa-signal" style="color:var(--cc-amber)"></i>
                        Priority Breakdown
                    </div>
                </div>
                <div class="cc-panel-body">
                    <div class="cc-pri-bars">
                        @php
                            $maxPri = max(1, max($priorityBreakdown));
                        @endphp
                        @foreach($priorityBreakdown as $level => $count)
                            <div class="cc-pri-row">
                                <div class="cc-pri-label">{{ $priorityLabels[$level] ?? ucfirst($level) }}</div>
                                <div class="cc-pri-bar-track">
                                    <div class="cc-pri-bar-fill" style="width:{{ $maxPri > 0 ? round(($count / $maxPri) * 100) : 0 }}%;background:{{ $priorityColors[$level] ?? '#94a3b8' }}" data-target="{{ $maxPri > 0 ? round(($count / $maxPri) * 100) : 0 }}">
                                        @if($count > 0){{ $count }}@endif
                                    </div>
                                </div>
                                <div class="cc-pri-count">{{ $count }}</div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>

        {{-- ============================================================ --}}
        {{-- OVERDUE + UPCOMING ROW --}}
        {{-- ============================================================ --}}
        <div class="cc-split">
            {{-- Overdue Tasks --}}
            <div class="cc-panel cc-animate" style="animation-delay:0.45s">
                <div class="cc-panel-head">
                    <div class="cc-panel-title">
                        <i class="fas fa-exclamation-circle" style="color:var(--cc-red)"></i>
                        Overdue Tasks
                        @if($overdueList->count() > 0)
                            <span class="cc-sb-badge" style="font-size:9px">{{ $overdueList->count() }}</span>
                        @endif
                    </div>
                </div>
                <div class="cc-panel-body">
                    @if($overdueList->count() > 0)
                        <div class="cc-task-list">
                            @foreach($overdueList as $task)
                                @php
                                    $daysOverdue = $task->due_date ? now()->diffInDays($task->due_date) : 0;
                                @endphp
                                <div class="cc-task-row">
                                    <div class="cc-task-title-col">
                                        <a href="{{ route('nexcore.clients.show.tasks.show', [$task->client_id, $task->id]) }}" class="cc-task-title-link">
                                            {{ $task->title }}
                                        </a>
                                        <div class="cc-task-client">{{ $task->client->company_name ?? 'Unknown' }}</div>
                                    </div>
                                    <div class="cc-task-meta">
                                        <span class="cc-task-badge" style="background:rgba(239,68,68,0.15);color:#ef4444">
                                            {{ $daysOverdue }}d overdue
                                        </span>
                                        @if($task->assigned_to)
                                            <span class="cc-task-assigned"><i class="fas fa-user" style="margin-right:4px;font-size:9px"></i>{{ $task->assigned_to }}</span>
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @else
                        <div class="cc-empty-state">
                            <i class="fas fa-check-circle" style="color:var(--cc-green)"></i>
                            <span>No overdue tasks</span>
                        </div>
                    @endif
                </div>
            </div>

            {{-- Upcoming Deadlines --}}
            <div class="cc-panel cc-animate" style="animation-delay:0.5s">
                <div class="cc-panel-head">
                    <div class="cc-panel-title">
                        <i class="fas fa-calendar-check" style="color:var(--cc-amber)"></i>
                        Upcoming Deadlines
                    </div>
                </div>
                <div class="cc-panel-body">
                    @if($upcomingDeadlines->count() > 0)
                        <div class="cc-task-list">
                            @foreach($upcomingDeadlines as $task)
                                @php
                                    $daysUntil = now()->startOfDay()->diffInDays($task->due_date, false);
                                    if ($daysUntil <= 1) {
                                        $urgencyColor = '#ef4444';
                                        $urgencyBg = 'rgba(239,68,68,0.15)';
                                    } elseif ($daysUntil <= 3) {
                                        $urgencyColor = '#f59e0b';
                                        $urgencyBg = 'rgba(245,158,11,0.12)';
                                    } else {
                                        $urgencyColor = '#22c55e';
                                        $urgencyBg = 'rgba(34,197,94,0.12)';
                                    }
                                @endphp
                                <div class="cc-task-row">
                                    <div class="cc-task-title-col">
                                        <a href="{{ route('nexcore.clients.show.tasks.show', [$task->client_id, $task->id]) }}" class="cc-task-title-link">
                                            {{ $task->title }}
                                        </a>
                                        <div class="cc-task-client">{{ $task->client->company_name ?? 'Unknown' }}</div>
                                    </div>
                                    <div class="cc-task-meta">
                                        <span class="cc-task-badge" style="background:{{ $urgencyBg }};color:{{ $urgencyColor }}">
                                            @if($daysUntil == 0)
                                                Today
                                            @elseif($daysUntil == 1)
                                                Tomorrow
                                            @else
                                                {{ $daysUntil }}d left
                                            @endif
                                        </span>
                                        <span style="font-size:11px;color:var(--cc-muted)">{{ $task->due_date->format('j M') }}</span>
                                        @if($task->assigned_to)
                                            <span class="cc-task-assigned"><i class="fas fa-user" style="margin-right:4px;font-size:9px"></i>{{ $task->assigned_to }}</span>
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @else
                        <div class="cc-empty-state">
                            <i class="fas fa-calendar-check" style="color:var(--cc-cyan)"></i>
                            <span>No upcoming deadlines this week</span>
                        </div>
                    @endif
                </div>
            </div>
        </div>

        {{-- ============================================================ --}}
        {{-- BOTTOM ROW: ACTIVITY + TEAM + CLIENTS --}}
        {{-- ============================================================ --}}
        <div class="cc-bottom">
            {{-- Recent Activity Feed --}}
            <div class="cc-panel cc-animate" style="animation-delay:0.55s">
                <div class="cc-panel-head">
                    <div class="cc-panel-title">
                        <i class="fas fa-stream" style="color:var(--cc-cyan)"></i>
                        Recent Activity
                    </div>
                </div>
                <div class="cc-panel-body" style="padding:10px 18px">
                    <div class="cc-activity-scroll">
                        @forelse($recentActivity as $activity)
                            @php
                                $actionKey = $activity->action ?? 'updated';
                                $ai = $actionIcons[$actionKey] ?? ['icon' => 'fa-info-circle', 'color' => '#94a3b8'];
                            @endphp
                            <div class="cc-activity-item">
                                <div class="cc-activity-icon" style="background:{{ $ai['color'] }}15;color:{{ $ai['color'] }}">
                                    <i class="fas {{ $ai['icon'] }}"></i>
                                </div>
                                <div class="cc-activity-body">
                                    <div class="cc-activity-text">
                                        <strong>{{ $activity->user->name ?? 'System' }}</strong>
                                        {{ str_replace('_', ' ', $activity->action ?? 'updated') }}
                                        @if($activity->task)
                                            on <strong>{{ \Illuminate\Support\Str::limit($activity->task->title, 30) }}</strong>
                                        @endif
                                        @if($activity->description)
                                            &mdash; {{ \Illuminate\Support\Str::limit($activity->description, 40) }}
                                        @endif
                                    </div>
                                    <div class="cc-activity-time">{{ ccTimeAgo($activity->created_at) }}</div>
                                </div>
                            </div>
                        @empty
                            <div class="cc-empty-state">
                                <i class="fas fa-history" style="color:var(--cc-muted)"></i>
                                <span>No recent activity</span>
                            </div>
                        @endforelse
                    </div>
                </div>
            </div>

            {{-- Team Workload --}}
            <div class="cc-panel cc-animate" style="animation-delay:0.6s">
                <div class="cc-panel-head">
                    <div class="cc-panel-title">
                        <i class="fas fa-user-friends" style="color:var(--cc-purple)"></i>
                        Team Workload
                    </div>
                </div>
                <div class="cc-panel-body">
                    @php
                        $maxTeam = $teamWorkload->max('count') ?: 1;
                    @endphp
                    @if($teamWorkload->count() > 0)
                        <div class="cc-team-list">
                            @foreach($teamWorkload as $member)
                                <div class="cc-team-row">
                                    <div class="cc-team-name" title="{{ $member['name'] }}">{{ $member['name'] }}</div>
                                    <div class="cc-team-bar-track">
                                        <div class="cc-team-bar-fill" style="width:{{ round(($member['count'] / $maxTeam) * 100) }}%" data-target="{{ round(($member['count'] / $maxTeam) * 100) }}">
                                            {{ $member['count'] }}
                                        </div>
                                    </div>
                                    @if($member['overdue'] > 0)
                                        <div class="cc-team-overdue" title="{{ $member['overdue'] }} overdue">
                                            <i class="fas fa-exclamation-triangle" style="font-size:9px;margin-right:2px"></i>{{ $member['overdue'] }}
                                        </div>
                                    @else
                                        <div class="cc-team-overdue" style="color:var(--cc-green)">
                                            <i class="fas fa-check" style="font-size:9px"></i>
                                        </div>
                                    @endif
                                </div>
                            @endforeach
                        </div>
                    @else
                        <div class="cc-empty-state">
                            <i class="fas fa-user-friends" style="color:var(--cc-muted)"></i>
                            <span>No team assignments</span>
                        </div>
                    @endif
                </div>
            </div>

            {{-- Tasks by Client --}}
            <div class="cc-panel cc-animate" style="animation-delay:0.65s">
                <div class="cc-panel-head">
                    <div class="cc-panel-title">
                        <i class="fas fa-building" style="color:var(--cc-green)"></i>
                        Tasks by Client
                    </div>
                </div>
                <div class="cc-panel-body" style="padding:10px 18px">
                    @if($tasksByClient->count() > 0)
                        <div class="cc-client-list">
                            @foreach($tasksByClient as $clientData)
                                @php
                                    $completedPct = $clientData['total'] > 0 ? round(($clientData['completed'] / $clientData['total']) * 100) : 0;
                                @endphp
                                <a href="{{ route('nexcore.clients.show.tasks', $clientData['client_id']) }}" class="cc-client-row">
                                    <div class="cc-client-name" title="{{ $clientData['name'] }}">{{ $clientData['name'] }}</div>
                                    <div class="cc-client-counts">
                                        <strong>{{ $clientData['active'] }}</strong> / {{ $clientData['total'] }}
                                    </div>
                                    <div class="cc-client-mini-bar">
                                        <div class="cc-client-mini-fill" style="width:{{ $completedPct }}%"></div>
                                    </div>
                                </a>
                            @endforeach
                        </div>
                    @else
                        <div class="cc-empty-state">
                            <i class="fas fa-building" style="color:var(--cc-muted)"></i>
                            <span>No client tasks</span>
                        </div>
                    @endif
                </div>
            </div>
        </div>

    </div>{{-- end .cc-content --}}
</div>{{-- end .cc-main --}}

{{-- ============================================================ --}}
{{-- JAVASCRIPT --}}
{{-- ============================================================ --}}
<script>
(function(){
    'use strict';

    /* ── Clock ── */
    function updateClock() {
        var now = new Date();
        var h = now.getHours(), m = now.getMinutes();
        var ampm = h >= 12 ? 'PM' : 'AM';
        var h12 = h % 12 || 12;
        var timeStr = String(h12).padStart(2, '0') + ':' + String(m).padStart(2, '0') + ' ' + ampm;
        var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
        var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
        var dateStr = days[now.getDay()] + ', ' + now.getDate() + ' ' + months[now.getMonth()] + ' ' + now.getFullYear();
        var clockEl = document.getElementById('ccClock');
        var dateEl = document.getElementById('ccDate');
        if (clockEl) clockEl.textContent = timeStr;
        if (dateEl) dateEl.textContent = dateStr;
    }
    updateClock();
    setInterval(updateClock, 30000);

    /* ── Sidebar Toggle ── */
    var sbToggle = document.getElementById('ccSbToggle');
    var sidebar = document.getElementById('ccSidebar');
    if (sbToggle && sidebar) {
        sbToggle.addEventListener('click', function() {
            sidebar.classList.toggle('collapsed');
            var icon = sbToggle.querySelector('i');
            if (sidebar.classList.contains('collapsed')) {
                icon.className = 'fas fa-chevron-right';
            } else {
                icon.className = 'fas fa-chevron-left';
            }
        });
    }

    /* ── Donut Chart (Canvas) ── */
    var canvas = document.getElementById('ccDonutCanvas');
    if (canvas) {
        var ctx = canvas.getContext('2d');
        var dpr = window.devicePixelRatio || 1;
        var size = 180;
        canvas.width = size * dpr;
        canvas.height = size * dpr;
        canvas.style.width = size + 'px';
        canvas.style.height = size + 'px';
        ctx.scale(dpr, dpr);

        var data = @json($statusBreakdown);
        var colors = {
            'pending': '#94a3b8',
            'in_progress': '#3b82f6',
            'review': '#f59e0b',
            'completed': '#22c55e',
            'on_hold': '#8b5cf6',
            'cancelled': '#ef4444'
        };

        var total = 0;
        for (var k in data) total += data[k];

        var cx = size / 2, cy = size / 2;
        var outerR = 80, innerR = 52;
        var startAngle = -Math.PI / 2;

        if (total === 0) {
            // Empty state ring
            ctx.beginPath();
            ctx.arc(cx, cy, (outerR + innerR) / 2, 0, Math.PI * 2);
            ctx.lineWidth = outerR - innerR;
            ctx.strokeStyle = 'rgba(255,255,255,0.06)';
            ctx.stroke();
        } else {
            var gap = 0.03;
            var entries = [];
            for (var key in data) {
                if (data[key] > 0) entries.push({ key: key, val: data[key] });
            }

            for (var i = 0; i < entries.length; i++) {
                var slice = entries[i];
                var sliceAngle = (slice.val / total) * (Math.PI * 2);
                var actualStart = startAngle + (entries.length > 1 ? gap / 2 : 0);
                var actualEnd = startAngle + sliceAngle - (entries.length > 1 ? gap / 2 : 0);

                ctx.beginPath();
                ctx.arc(cx, cy, outerR, actualStart, actualEnd);
                ctx.arc(cx, cy, innerR, actualEnd, actualStart, true);
                ctx.closePath();
                ctx.fillStyle = colors[slice.key] || '#94a3b8';
                ctx.fill();

                startAngle += sliceAngle;
            }
        }

        // Center text
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 28px Montserrat, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(total, cx, cy - 6);
        ctx.fillStyle = '#6b7a8d';
        ctx.font = '500 10px Montserrat, sans-serif';
        ctx.fillText('TOTAL', cx, cy + 14);
    }

    /* ── Animate bars on scroll ── */
    function animateBars() {
        document.querySelectorAll('.cc-pri-bar-fill, .cc-team-bar-fill').forEach(function(el) {
            var target = el.getAttribute('data-target');
            if (target) {
                el.style.width = '0%';
                setTimeout(function() {
                    el.style.width = target + '%';
                }, 200);
            }
        });
    }
    setTimeout(animateBars, 600);

})();
</script>
</body>
</html>
