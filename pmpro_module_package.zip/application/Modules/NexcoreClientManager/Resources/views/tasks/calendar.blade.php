@extends('nexcore_client_manager::layouts.nerve-centre')

@section('sidebar')
    @include('nexcore_client_manager::partials.nerve-centre-sidebar')
@endsection

@section('title', 'Task Calendar - ' . $client->company_name)
@section('topbar_module', 'Task Manager')
@section('topbar_page', 'Calendar View')

@section('content')

{{-- Page Header --}}
<div class="tc-hero sl-animate d1">
    <div class="tc-hero-left">
        <div class="tc-hero-icon">
            <i class="fas fa-calendar-alt"></i>
            <div class="tc-hero-pulse"></div>
        </div>
        <div>
            <h1 class="tc-hero-title">Task Calendar</h1>
            <p class="tc-hero-sub">{{ $client->company_name }} <span class="tc-hero-dot"></span> {{ $tasks->count() }} {{ $tasks->count() === 1 ? 'task' : 'tasks' }} scheduled</p>
        </div>
    </div>
    <div class="tc-hero-right">
        <div class="tc-view-toggle">
            <a href="{{ route('nexcore.clients.show.tasks', $client->id) }}" class="tc-toggle-btn" title="List View">
                <i class="fas fa-list-ul"></i>
            </a>
            <a href="{{ route('nexcore.clients.show.tasks.kanban', $client->id) }}" class="tc-toggle-btn" title="Kanban Board">
                <i class="fas fa-columns"></i>
            </a>
            <a href="#" class="tc-toggle-btn tc-toggle-active" title="Calendar View">
                <i class="fas fa-calendar-alt"></i>
            </a>
        </div>
        <a href="{{ route('nexcore.clients.show.tasks.create', $client->id) }}" class="tc-btn-add">
            <i class="fas fa-plus"></i> New Task
        </a>
    </div>
</div>

{{-- Calendar Layout --}}
<div class="tc-layout sl-animate d2">
    {{-- Main Calendar --}}
    <div class="tc-calendar-wrap">
        <div class="tc-calendar-card">
            {{-- Month Navigation --}}
            <div class="tc-month-nav">
                <button class="tc-nav-arrow" id="tcPrevMonth" onclick="tcPrevMonth()" title="Previous Month">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <div class="tc-month-label" id="tcMonthLabel"></div>
                <button class="tc-nav-arrow" id="tcNextMonth" onclick="tcNextMonth()" title="Next Month">
                    <i class="fas fa-chevron-right"></i>
                </button>
                <button class="tc-today-btn" onclick="tcGoToday()" title="Go to Today">
                    <i class="fas fa-crosshairs"></i> Today
                </button>
            </div>

            {{-- Day Headers --}}
            <div class="tc-day-headers">
                <div class="tc-day-header">Mon</div>
                <div class="tc-day-header">Tue</div>
                <div class="tc-day-header">Wed</div>
                <div class="tc-day-header">Thu</div>
                <div class="tc-day-header">Fri</div>
                <div class="tc-day-header tc-day-weekend">Sat</div>
                <div class="tc-day-header tc-day-weekend">Sun</div>
            </div>

            {{-- Calendar Grid --}}
            <div class="tc-grid" id="tcGrid"></div>
        </div>
    </div>

    {{-- Upcoming Sidebar --}}
    <div class="tc-upcoming-wrap sl-animate d3">
        <div class="tc-upcoming-card">
            <div class="tc-upcoming-header">
                <div class="tc-upcoming-icon"><i class="fas fa-clock"></i></div>
                <div>
                    <h3 class="tc-upcoming-title">Upcoming Tasks</h3>
                    <p class="tc-upcoming-sub">Next 10 due</p>
                </div>
            </div>
            <div class="tc-upcoming-list" id="tcUpcomingList">
                @php
                    $now = \Carbon\Carbon::today();
                    $upcoming = $tasks->filter(function($t) use ($now) {
                        return $t->due_date && $t->due_date->gte($now) && !in_array($t->task_status, ['completed', 'cancelled']);
                    })->sortBy('due_date')->take(10);
                @endphp

                @forelse($upcoming as $ut)
                    @php
                        $uCat = $ut->category ?: 'general';
                        $uColor = $categoryColors[$uCat] ?? '#94a3b8';
                        $uIcon = $categoryIcons[$uCat] ?? 'fa-tasks';
                        $diff = $now->diffInDays($ut->due_date, false);
                        if ($diff === 0) { $uDue = 'Today'; }
                        elseif ($diff === 1) { $uDue = 'Tomorrow'; }
                        elseif ($diff <= 7) { $uDue = $diff . ' days'; }
                        else { $uDue = $ut->due_date->format('j M'); }
                    @endphp
                    <a href="{{ route('nexcore.clients.show.tasks.show', [$client->id, $ut->id]) }}" class="tc-upcoming-item" style="--item-color:{{ $uColor }};">
                        <div class="tc-upcoming-dot" style="background:{{ $uColor }};"></div>
                        <div class="tc-upcoming-info">
                            <div class="tc-upcoming-name">{{ \Illuminate\Support\Str::limit($ut->title, 36) }}</div>
                            <div class="tc-upcoming-meta">
                                <span class="tc-upcoming-cat"><i class="fas {{ $uIcon }}"></i> {{ $categories[$uCat] ?? 'General' }}</span>
                                @if($ut->priority === 'urgent' || $ut->is_urgent)
                                    <span class="tc-upcoming-urgent"><i class="fas fa-bolt"></i> Urgent</span>
                                @endif
                            </div>
                        </div>
                        <div class="tc-upcoming-due {{ $diff <= 1 ? 'tc-upcoming-due-soon' : '' }}">{{ $uDue }}</div>
                    </a>
                @empty
                    <div class="tc-upcoming-empty">
                        <i class="fas fa-check-circle"></i>
                        <p>No upcoming tasks</p>
                    </div>
                @endforelse
            </div>
        </div>

        {{-- Legend --}}
        <div class="tc-legend-card sl-animate d4">
            <div class="tc-legend-title"><i class="fas fa-palette"></i> Categories</div>
            <div class="tc-legend-items">
                @foreach($categories as $ck => $cl)
                    <div class="tc-legend-item">
                        <span class="tc-legend-dot" style="background:{{ $categoryColors[$ck] }};"></span>
                        <span class="tc-legend-label">{{ $cl }}</span>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
</div>

@endsection

@push('styles')
<style>
/* ═══ TASK CALENDAR ═══ */

/* ── Hero ── */
.tc-hero {
    display:flex; align-items:center; justify-content:space-between; gap:16px;
    padding:20px 24px; margin-bottom:20px;
    background:linear-gradient(135deg, rgba(59,130,246,0.06), rgba(139,92,246,0.04), rgba(16,185,129,0.03));
    border:1px solid rgba(255,255,255,0.06);
    border-radius:16px;
    position:relative; overflow:hidden;
}
.tc-hero::before {
    content:''; position:absolute; top:-50%; right:-20%; width:300px; height:300px;
    background:radial-gradient(circle, rgba(59,130,246,0.08), transparent 70%);
    pointer-events:none;
}
.tc-hero-left { display:flex; align-items:center; gap:16px; position:relative; z-index:1; }
.tc-hero-icon {
    width:52px; height:52px; border-radius:14px;
    background:linear-gradient(135deg, rgba(59,130,246,0.2), rgba(139,92,246,0.15));
    border:1px solid rgba(59,130,246,0.3);
    display:flex; align-items:center; justify-content:center;
    font-size:20px; color:#3b82f6; position:relative;
}
.tc-hero-pulse {
    position:absolute; inset:-4px; border-radius:18px;
    border:2px solid rgba(59,130,246,0.3);
    animation:tcPulse 2.5s ease-in-out infinite;
}
.tc-hero-title { margin:0; font-size:22px; font-weight:800; color:#fff; letter-spacing:0.5px; font-family:'Montserrat',sans-serif; }
.tc-hero-sub { margin:4px 0 0; font-size:13px; color:rgba(255,255,255,0.45); font-weight:500; }
.tc-hero-dot { display:inline-block; width:4px; height:4px; border-radius:50%; background:rgba(255,255,255,0.25); vertical-align:middle; margin:0 6px; }
.tc-hero-right { display:flex; align-items:center; gap:12px; position:relative; z-index:1; }

/* ── View Toggle ── */
.tc-view-toggle {
    display:flex; border-radius:10px; overflow:hidden;
    border:1px solid rgba(255,255,255,0.08);
    background:rgba(255,255,255,0.02);
}
.tc-toggle-btn {
    display:flex; align-items:center; justify-content:center;
    width:38px; height:36px; font-size:14px;
    color:rgba(255,255,255,0.4); text-decoration:none;
    border-right:1px solid rgba(255,255,255,0.06);
    transition:all 0.25s ease; cursor:pointer;
}
.tc-toggle-btn:last-child { border-right:none; }
.tc-toggle-btn:hover { color:rgba(255,255,255,0.7); background:rgba(255,255,255,0.04); }
.tc-toggle-active {
    color:#3b82f6 !important;
    background:rgba(59,130,246,0.12) !important;
    box-shadow:inset 0 -2px 0 #3b82f6;
}

/* ── Add Button ── */
.tc-btn-add {
    display:inline-flex; align-items:center; gap:8px;
    padding:11px 22px; border-radius:10px;
    background:linear-gradient(135deg, #059669, #10b981);
    color:#fff; font-size:13px; font-weight:700;
    text-decoration:none; border:none; cursor:pointer;
    box-shadow:0 0 20px rgba(16,185,129,0.25), inset 0 1px 0 rgba(255,255,255,0.1);
    transition:all 0.3s ease; letter-spacing:0.3px;
}
.tc-btn-add:hover {
    transform:translateY(-1px);
    box-shadow:0 0 30px rgba(16,185,129,0.4), inset 0 1px 0 rgba(255,255,255,0.15);
}

/* ── Layout ── */
.tc-layout {
    display:grid;
    grid-template-columns:1fr 300px;
    gap:20px;
    align-items:start;
}

/* ── Calendar Card ── */
.tc-calendar-card {
    background:rgba(17,21,32,0.8);
    border:1px solid rgba(255,255,255,0.06);
    border-radius:16px;
    padding:24px;
    backdrop-filter:blur(12px);
}

/* ── Month Nav ── */
.tc-month-nav {
    display:flex; align-items:center; gap:12px; margin-bottom:20px;
}
.tc-nav-arrow {
    width:36px; height:36px; border-radius:10px;
    background:rgba(255,255,255,0.04);
    border:1px solid rgba(255,255,255,0.08);
    color:rgba(255,255,255,0.6); font-size:13px;
    display:flex; align-items:center; justify-content:center;
    cursor:pointer; transition:all 0.25s ease;
}
.tc-nav-arrow:hover { background:rgba(255,255,255,0.08); color:#fff; border-color:rgba(255,255,255,0.15); }
.tc-month-label {
    font-size:20px; font-weight:800; color:#fff;
    font-family:'Montserrat',sans-serif; letter-spacing:0.5px;
    flex:1; text-align:center;
}
.tc-today-btn {
    display:inline-flex; align-items:center; gap:6px;
    padding:8px 16px; border-radius:8px;
    background:rgba(59,130,246,0.1);
    border:1px solid rgba(59,130,246,0.25);
    color:#3b82f6; font-size:12px; font-weight:700;
    cursor:pointer; transition:all 0.25s ease;
    font-family:'Poppins',sans-serif;
}
.tc-today-btn:hover { background:rgba(59,130,246,0.18); border-color:rgba(59,130,246,0.4); }

/* ── Day Headers ── */
.tc-day-headers {
    display:grid; grid-template-columns:repeat(7, 1fr); gap:1px;
    margin-bottom:2px;
}
.tc-day-header {
    text-align:center; padding:10px 0;
    font-size:11px; font-weight:700; text-transform:uppercase;
    letter-spacing:1px; color:rgba(255,255,255,0.35);
    font-family:'Montserrat',sans-serif;
}
.tc-day-weekend { color:rgba(255,255,255,0.2); }

/* ── Calendar Grid ── */
.tc-grid {
    display:grid; grid-template-columns:repeat(7, 1fr);
    gap:1px; background:rgba(255,255,255,0.03); border-radius:12px;
    overflow:hidden;
}
.tc-cell {
    min-height:100px; padding:8px;
    background:rgba(10,14,26,0.6);
    border:1px solid rgba(255,255,255,0.04);
    transition:all 0.2s ease;
    position:relative;
}
.tc-cell:hover { background:rgba(255,255,255,0.03); }
.tc-cell-other {
    opacity:0.3;
}
.tc-cell-today {
    border-color:rgba(6,182,212,0.5) !important;
    box-shadow:inset 0 0 20px rgba(6,182,212,0.06);
    background:rgba(6,182,212,0.04);
}
.tc-cell-overdue {
    background:rgba(239,68,68,0.03);
}
.tc-cell-num {
    font-size:13px; font-weight:700; color:rgba(255,255,255,0.5);
    font-family:'Montserrat',sans-serif; margin-bottom:6px;
    display:flex; align-items:center; justify-content:space-between;
}
.tc-cell-today .tc-cell-num {
    color:#06b6d4;
}
.tc-cell-today .tc-cell-num::after {
    content:'TODAY'; font-size:8px; font-weight:800;
    letter-spacing:1px; color:#06b6d4; opacity:0.7;
}
.tc-cell-tasks { display:flex; flex-direction:column; gap:3px; }

/* ── Task Pills ── */
.tc-pill {
    display:flex; align-items:center; gap:5px;
    padding:3px 8px; border-radius:5px;
    font-size:10px; font-weight:600;
    color:#fff; text-decoration:none;
    overflow:hidden; white-space:nowrap; text-overflow:ellipsis;
    transition:all 0.2s ease; cursor:pointer;
    position:relative;
    font-family:'Poppins',sans-serif;
}
.tc-pill:hover {
    transform:translateX(2px);
    box-shadow:0 2px 8px rgba(0,0,0,0.3);
}
.tc-pill-urgent::before {
    content:''; position:absolute; left:0; top:0; bottom:0; width:2px;
    background:#ef4444;
}
.tc-pill-title { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }

/* ── Tooltip ── */
.tc-tooltip {
    position:fixed; z-index:9999;
    padding:10px 14px; border-radius:10px;
    background:rgba(17,21,32,0.96);
    border:1px solid rgba(255,255,255,0.12);
    box-shadow:0 8px 32px rgba(0,0,0,0.5);
    backdrop-filter:blur(16px);
    pointer-events:none;
    opacity:0; transition:opacity 0.15s ease;
    max-width:260px;
}
.tc-tooltip.tc-tooltip-visible { opacity:1; }
.tc-tooltip-title { font-size:13px; font-weight:700; color:#fff; margin-bottom:4px; }
.tc-tooltip-meta { font-size:11px; color:rgba(255,255,255,0.5); display:flex; gap:8px; align-items:center; }
.tc-tooltip-badge {
    display:inline-flex; align-items:center; gap:4px;
    padding:2px 8px; border-radius:4px;
    font-size:10px; font-weight:600;
}
.tc-more-pill {
    font-size:9px; font-weight:700; color:rgba(255,255,255,0.4);
    text-align:center; padding:2px 0; cursor:default;
    font-family:'Montserrat',sans-serif; letter-spacing:0.5px;
}

/* ── Upcoming Sidebar ── */
.tc-upcoming-card {
    background:rgba(17,21,32,0.8);
    border:1px solid rgba(255,255,255,0.06);
    border-radius:16px;
    padding:20px;
    backdrop-filter:blur(12px);
}
.tc-upcoming-header { display:flex; align-items:center; gap:12px; margin-bottom:16px; }
.tc-upcoming-icon {
    width:40px; height:40px; border-radius:10px;
    background:linear-gradient(135deg, rgba(245,158,11,0.2), rgba(245,158,11,0.08));
    border:1px solid rgba(245,158,11,0.3);
    display:flex; align-items:center; justify-content:center;
    font-size:16px; color:#f59e0b;
}
.tc-upcoming-title { margin:0; font-size:15px; font-weight:700; color:#fff; font-family:'Montserrat',sans-serif; }
.tc-upcoming-sub { margin:2px 0 0; font-size:11px; color:rgba(255,255,255,0.35); }
.tc-upcoming-list { display:flex; flex-direction:column; gap:4px; }

.tc-upcoming-item {
    display:flex; align-items:center; gap:10px;
    padding:10px 12px; border-radius:10px;
    background:rgba(255,255,255,0.02);
    border:1px solid rgba(255,255,255,0.04);
    text-decoration:none; color:#fff;
    transition:all 0.25s ease;
}
.tc-upcoming-item:hover {
    background:rgba(255,255,255,0.05);
    border-color:rgba(255,255,255,0.1);
    transform:translateX(3px);
}
.tc-upcoming-dot {
    width:8px; height:8px; border-radius:50%; flex-shrink:0;
    box-shadow:0 0 8px color-mix(in srgb, var(--item-color) 50%, transparent);
}
.tc-upcoming-info { flex:1; min-width:0; }
.tc-upcoming-name { font-size:12px; font-weight:600; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.tc-upcoming-meta { display:flex; gap:8px; margin-top:3px; }
.tc-upcoming-cat { font-size:10px; color:rgba(255,255,255,0.35); display:flex; align-items:center; gap:4px; }
.tc-upcoming-cat i { font-size:9px; }
.tc-upcoming-urgent { font-size:10px; color:#ef4444; font-weight:700; display:flex; align-items:center; gap:3px; }
.tc-upcoming-urgent i { font-size:9px; }
.tc-upcoming-due {
    font-size:11px; font-weight:700; color:rgba(255,255,255,0.4);
    font-family:'Montserrat',sans-serif; white-space:nowrap;
}
.tc-upcoming-due-soon { color:#f59e0b; }

.tc-upcoming-empty {
    text-align:center; padding:24px 12px;
    color:rgba(255,255,255,0.2);
}
.tc-upcoming-empty i { font-size:28px; margin-bottom:8px; display:block; }
.tc-upcoming-empty p { margin:0; font-size:12px; }

/* ── Legend ── */
.tc-legend-card {
    background:rgba(17,21,32,0.8);
    border:1px solid rgba(255,255,255,0.06);
    border-radius:16px;
    padding:16px 20px; margin-top:12px;
    backdrop-filter:blur(12px);
}
.tc-legend-title {
    font-size:12px; font-weight:700; color:rgba(255,255,255,0.4);
    text-transform:uppercase; letter-spacing:0.8px;
    margin-bottom:12px; display:flex; align-items:center; gap:8px;
    font-family:'Montserrat',sans-serif;
}
.tc-legend-title i { font-size:11px; color:rgba(255,255,255,0.25); }
.tc-legend-items { display:flex; flex-wrap:wrap; gap:6px; }
.tc-legend-item { display:flex; align-items:center; gap:6px; font-size:11px; color:rgba(255,255,255,0.45); width:calc(50% - 3px); }
.tc-legend-dot { width:8px; height:8px; border-radius:3px; flex-shrink:0; }
.tc-legend-label { font-weight:500; }

/* ── Animations ── */
@@keyframes tcPulse {
    0%, 100% { opacity:0.5; transform:scale(1); }
    50% { opacity:0; transform:scale(1.15); }
}

/* ── Responsive ── */
@@media (max-width: 1100px) {
    .tc-layout { grid-template-columns:1fr; }
    .tc-upcoming-wrap { order:-1; }
}
@@media (max-width: 768px) {
    .tc-hero { flex-direction:column; align-items:flex-start; gap:12px; }
    .tc-hero-right { flex-wrap:wrap; }
    .tc-cell { min-height:70px; padding:4px; }
    .tc-cell-num { font-size:11px; }
    .tc-pill { font-size:9px; padding:2px 5px; }
    .tc-cell-today .tc-cell-num::after { display:none; }
    .tc-legend-item { width:100%; }
}
</style>
@endpush

@push('scripts')
<script>
(function() {
    var clientId = @json($client->id);
    @php
    $calTasksJson = $tasks->map(function($t) use ($categoryColors) {
        return [
            'id' => $t->id,
            'title' => $t->title,
            'due_date' => $t->due_date ? $t->due_date->format('Y-m-d') : null,
            'status' => $t->task_status,
            'priority' => $t->priority,
            'category' => $t->category,
            'color' => $categoryColors[$t->category] ?? '#94a3b8',
            'is_urgent' => $t->is_urgent,
        ];
    })->values();
    @endphp
    var calendarTasks = @json($calTasksJson);

    var taskStatuses = @json($taskStatuses);
    var todayStr = new Date().toISOString().split('T')[0];
    var currentYear, currentMonth;

    // Tooltip element
    var tooltip = document.createElement('div');
    tooltip.className = 'tc-tooltip';
    tooltip.innerHTML = '<div class="tc-tooltip-title"></div><div class="tc-tooltip-meta"></div>';
    document.body.appendChild(tooltip);

    function init() {
        var now = new Date();
        currentYear = now.getFullYear();
        currentMonth = now.getMonth();
        renderCalendar(currentYear, currentMonth);
    }

    function renderCalendar(year, month) {
        var grid = document.getElementById('tcGrid');
        var label = document.getElementById('tcMonthLabel');
        var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
        label.textContent = months[month] + ' ' + year;

        // First day of the month (0=Sun, adjust to Mon=0)
        var firstDay = new Date(year, month, 1).getDay();
        firstDay = firstDay === 0 ? 6 : firstDay - 1; // Mon=0
        var daysInMonth = new Date(year, month + 1, 0).getDate();
        var daysInPrev = new Date(year, month, 0).getDate();

        // Build index of tasks by date
        var tasksByDate = {};
        for (var i = 0; i < calendarTasks.length; i++) {
            var t = calendarTasks[i];
            if (!t.due_date) continue;
            if (!tasksByDate[t.due_date]) tasksByDate[t.due_date] = [];
            tasksByDate[t.due_date].push(t);
        }

        var html = '';
        var totalCells = Math.ceil((firstDay + daysInMonth) / 7) * 7;

        for (var c = 0; c < totalCells; c++) {
            var dayNum, dateStr, isOther = false;

            if (c < firstDay) {
                // Previous month
                dayNum = daysInPrev - firstDay + c + 1;
                var pm = month === 0 ? 11 : month - 1;
                var py = month === 0 ? year - 1 : year;
                dateStr = py + '-' + pad(pm + 1) + '-' + pad(dayNum);
                isOther = true;
            } else if (c >= firstDay + daysInMonth) {
                // Next month
                dayNum = c - firstDay - daysInMonth + 1;
                var nm = month === 11 ? 0 : month + 1;
                var ny = month === 11 ? year + 1 : year;
                dateStr = ny + '-' + pad(nm + 1) + '-' + pad(dayNum);
                isOther = true;
            } else {
                dayNum = c - firstDay + 1;
                dateStr = year + '-' + pad(month + 1) + '-' + pad(dayNum);
            }

            var isToday = (dateStr === todayStr);
            var dateTasks = tasksByDate[dateStr] || [];
            var hasOverdue = false;
            for (var j = 0; j < dateTasks.length; j++) {
                if (dateStr < todayStr && dateTasks[j].status !== 'completed' && dateTasks[j].status !== 'cancelled') {
                    hasOverdue = true;
                    break;
                }
            }

            var classes = 'tc-cell';
            if (isOther) classes += ' tc-cell-other';
            if (isToday) classes += ' tc-cell-today';
            if (hasOverdue && !isOther) classes += ' tc-cell-overdue';

            html += '<div class="' + classes + '">';
            html += '<div class="tc-cell-num">' + dayNum + '</div>';
            html += '<div class="tc-cell-tasks">';

            var maxShow = 3;
            for (var k = 0; k < Math.min(dateTasks.length, maxShow); k++) {
                var task = dateTasks[k];
                var pillClass = 'tc-pill' + (task.is_urgent ? ' tc-pill-urgent' : '');
                var bgAlpha = '33'; // 20% opacity
                html += '<a href="/nexcore/' + clientId + '/tasks/' + task.id + '" ';
                html += 'class="' + pillClass + '" ';
                html += 'style="background:' + task.color + bgAlpha + '; color:' + task.color + ';" ';
                html += 'data-task-id="' + task.id + '" ';
                html += 'data-task-title="' + escHtml(task.title) + '" ';
                html += 'data-task-status="' + (taskStatuses[task.status] || task.status) + '" ';
                html += 'data-task-priority="' + task.priority + '" ';
                html += 'data-task-color="' + task.color + '" ';
                html += 'onmouseenter="tcShowTooltip(event, this)" onmouseleave="tcHideTooltip()">';
                html += '<span class="tc-pill-title">' + escHtml(task.title) + '</span>';
                html += '</a>';
            }
            if (dateTasks.length > maxShow) {
                html += '<div class="tc-more-pill">+' + (dateTasks.length - maxShow) + ' more</div>';
            }
            html += '</div></div>';
        }

        grid.innerHTML = html;
    }

    function pad(n) { return n < 10 ? '0' + n : '' + n; }

    function escHtml(str) {
        var d = document.createElement('div');
        d.textContent = str;
        return d.innerHTML;
    }

    // Navigation
    window.tcPrevMonth = function() {
        currentMonth--;
        if (currentMonth < 0) { currentMonth = 11; currentYear--; }
        renderCalendar(currentYear, currentMonth);
    };

    window.tcNextMonth = function() {
        currentMonth++;
        if (currentMonth > 11) { currentMonth = 0; currentYear++; }
        renderCalendar(currentYear, currentMonth);
    };

    window.tcGoToday = function() {
        var now = new Date();
        currentYear = now.getFullYear();
        currentMonth = now.getMonth();
        renderCalendar(currentYear, currentMonth);
    };

    // Tooltip
    window.tcShowTooltip = function(e, el) {
        var title = el.getAttribute('data-task-title');
        var status = el.getAttribute('data-task-status');
        var priority = el.getAttribute('data-task-priority');
        var color = el.getAttribute('data-task-color');

        tooltip.querySelector('.tc-tooltip-title').textContent = title;

        var priorityColors = { low:'#94a3b8', medium:'#3b82f6', high:'#f59e0b', urgent:'#ef4444' };
        var pColor = priorityColors[priority] || '#94a3b8';

        tooltip.querySelector('.tc-tooltip-meta').innerHTML =
            '<span class="tc-tooltip-badge" style="background:' + color + '22; color:' + color + ';">' + status + '</span>' +
            '<span class="tc-tooltip-badge" style="background:' + pColor + '22; color:' + pColor + ';">' + priority.charAt(0).toUpperCase() + priority.slice(1) + '</span>';

        var rect = el.getBoundingClientRect();
        tooltip.style.left = (rect.left + rect.width / 2) + 'px';
        tooltip.style.top = (rect.top - 8) + 'px';
        tooltip.style.transform = 'translate(-50%, -100%)';
        tooltip.classList.add('tc-tooltip-visible');
    };

    window.tcHideTooltip = function() {
        tooltip.classList.remove('tc-tooltip-visible');
    };

    init();
})();
</script>
@endpush
