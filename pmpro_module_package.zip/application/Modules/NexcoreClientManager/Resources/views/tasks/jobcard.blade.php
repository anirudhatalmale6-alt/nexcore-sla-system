<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Card - {{ $task->title }}</title>
    <style>
        /* ═══ JOB CARD - PRINT OPTIMISED ═══ */

        @@page {
            size: A4;
            margin: 15mm;
        }

        @@media print {
            .jc-no-print { display: none !important; }
            body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif;
            color: #1a1a1a;
            background: #fff;
            font-size: 12px;
            line-height: 1.5;
        }

        /* ── Print Button ── */
        .jc-toolbar {
            position: fixed; top: 0; left: 0; right: 0; z-index: 100;
            padding: 12px 24px;
            background: #1e293b;
            display: flex; align-items: center; justify-content: space-between;
            box-shadow: 0 2px 12px rgba(0,0,0,0.3);
        }
        .jc-toolbar-title {
            font-size: 14px; font-weight: 600; color: #94a3b8;
        }
        .jc-toolbar-actions { display: flex; gap: 10px; }
        .jc-print-btn {
            display: inline-flex; align-items: center; gap: 8px;
            padding: 10px 24px; border-radius: 8px;
            background: linear-gradient(135deg, #059669, #10b981);
            color: #fff; font-size: 13px; font-weight: 700;
            border: none; cursor: pointer;
            box-shadow: 0 2px 10px rgba(16,185,129,0.3);
            transition: all 0.2s ease;
            font-family: inherit;
        }
        .jc-print-btn:hover { transform: translateY(-1px); box-shadow: 0 4px 16px rgba(16,185,129,0.4); }
        .jc-back-btn {
            display: inline-flex; align-items: center; gap: 8px;
            padding: 10px 20px; border-radius: 8px;
            background: rgba(255,255,255,0.08);
            color: #94a3b8; font-size: 13px; font-weight: 600;
            border: 1px solid rgba(255,255,255,0.12);
            cursor: pointer; text-decoration: none;
            transition: all 0.2s ease;
            font-family: inherit;
        }
        .jc-back-btn:hover { background: rgba(255,255,255,0.14); color: #fff; }

        .jc-page {
            max-width: 210mm;
            margin: 70px auto 40px;
            padding: 0 20px;
        }

        @@media print {
            .jc-page { margin: 0 auto; padding: 0; }
        }

        /* ── Header ── */
        .jc-header {
            display: flex; justify-content: space-between; align-items: flex-start;
            padding-bottom: 16px;
            border-bottom: 3px solid #1a1a1a;
            margin-bottom: 20px;
        }
        .jc-header-left { flex: 1; }
        .jc-logo-area {
            font-size: 10px; font-weight: 700; text-transform: uppercase;
            letter-spacing: 2px; color: #64748b;
            margin-bottom: 6px;
        }
        .jc-company-name {
            font-size: 18px; font-weight: 800; color: #0f172a;
            line-height: 1.2;
        }
        .jc-header-right { text-align: right; }
        .jc-jc-title {
            font-size: 28px; font-weight: 900; color: #0f172a;
            letter-spacing: 2px; line-height: 1;
            margin-bottom: 8px;
        }
        .jc-ref-table { margin-left: auto; }
        .jc-ref-table td {
            font-size: 11px; padding: 2px 0;
        }
        .jc-ref-label {
            font-weight: 700; color: #64748b;
            text-transform: uppercase; letter-spacing: 0.5px;
            padding-right: 12px;
            text-align: right;
        }
        .jc-ref-value {
            font-weight: 600; color: #1a1a1a;
            font-family: 'Consolas', 'Courier New', monospace;
        }

        /* ── Section ── */
        .jc-section {
            margin-bottom: 20px;
        }
        .jc-section-title {
            font-size: 11px; font-weight: 800; text-transform: uppercase;
            letter-spacing: 1.5px; color: #fff;
            background: #1e293b; padding: 6px 14px;
            border-radius: 4px; margin-bottom: 10px;
        }

        /* ── Details Table ── */
        .jc-details-table {
            width: 100%; border-collapse: collapse;
        }
        .jc-details-table td {
            padding: 8px 12px; border: 1px solid #e2e8f0;
            font-size: 12px; vertical-align: top;
        }
        .jc-detail-label {
            width: 140px; font-weight: 700; color: #475569;
            background: #f8fafc; text-transform: uppercase;
            font-size: 10px; letter-spacing: 0.5px;
        }
        .jc-detail-value { color: #1a1a1a; font-weight: 500; }

        .jc-priority-badge {
            display: inline-block; padding: 2px 10px;
            border-radius: 4px; font-size: 10px;
            font-weight: 800; text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .jc-priority-low { background: #f1f5f9; color: #64748b; }
        .jc-priority-medium { background: #dbeafe; color: #1d4ed8; }
        .jc-priority-high { background: #fef3c7; color: #b45309; }
        .jc-priority-urgent { background: #fee2e2; color: #dc2626; border: 1px solid #fca5a5; }

        .jc-status-badge {
            display: inline-block; padding: 2px 10px;
            border-radius: 4px; font-size: 10px;
            font-weight: 700; text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .jc-status-pending { background: #fef3c7; color: #b45309; }
        .jc-status-in_progress { background: #dbeafe; color: #1d4ed8; }
        .jc-status-review { background: #e0e7ff; color: #4338ca; }
        .jc-status-completed { background: #d1fae5; color: #047857; }
        .jc-status-on_hold { background: #f1f5f9; color: #475569; }
        .jc-status-cancelled { background: #fee2e2; color: #dc2626; }

        /* ── Description ── */
        .jc-desc-box {
            padding: 14px 16px;
            background: #f8fafc; border: 1px solid #e2e8f0;
            border-radius: 6px; min-height: 60px;
            font-size: 12px; color: #334155; line-height: 1.7;
            white-space: pre-wrap;
        }
        .jc-desc-empty {
            color: #94a3b8; font-style: italic;
        }

        /* ── Checklist Table ── */
        .jc-checklist-table {
            width: 100%; border-collapse: collapse;
        }
        .jc-checklist-table th {
            background: #f1f5f9; font-size: 10px;
            font-weight: 700; text-transform: uppercase;
            letter-spacing: 0.8px; color: #475569;
            padding: 8px 12px; border: 1px solid #e2e8f0;
            text-align: left;
        }
        .jc-checklist-table td {
            padding: 8px 12px; border: 1px solid #e2e8f0;
            font-size: 12px; vertical-align: middle;
        }
        .jc-check-col {
            width: 40px; text-align: center;
        }
        .jc-checkbox {
            width: 16px; height: 16px;
            border: 2px solid #cbd5e1; border-radius: 3px;
            display: inline-block; vertical-align: middle;
        }
        .jc-checkbox-done {
            background: #d1fae5; border-color: #10b981;
            position: relative;
        }
        .jc-checkbox-done::after {
            content: '\2713'; position: absolute;
            top: -2px; left: 2px;
            font-size: 12px; font-weight: 900; color: #047857;
        }
        .jc-step-num {
            width: 30px; text-align: center;
            font-weight: 700; color: #94a3b8;
            font-family: 'Consolas', 'Courier New', monospace;
        }
        .jc-step-title { font-weight: 500; color: #1a1a1a; }
        .jc-step-done .jc-step-title { color: #64748b; text-decoration: line-through; }
        .jc-step-status {
            width: 80px; text-align: center;
            font-size: 10px; font-weight: 700;
            text-transform: uppercase; letter-spacing: 0.3px;
        }
        .jc-step-status-open { color: #94a3b8; }
        .jc-step-status-done { color: #10b981; }

        .jc-empty-row td {
            text-align: center; color: #94a3b8;
            font-style: italic; padding: 20px;
        }

        /* ── Notes ── */
        .jc-notes-box {
            padding: 14px 16px;
            background: #fffbeb; border: 1px solid #fde68a;
            border-radius: 6px; min-height: 50px;
            font-size: 12px; color: #92400e; line-height: 1.7;
            white-space: pre-wrap;
        }

        /* ── Sign-off ── */
        .jc-signoff {
            border: 1px solid #e2e8f0; border-radius: 6px;
            overflow: hidden;
        }
        .jc-signoff-title {
            font-size: 11px; font-weight: 800; text-transform: uppercase;
            letter-spacing: 1.5px; color: #fff;
            background: #475569; padding: 6px 14px;
        }
        .jc-signoff-body { padding: 20px; }
        .jc-sig-row {
            display: flex; gap: 40px; margin-bottom: 28px;
        }
        .jc-sig-row:last-of-type { margin-bottom: 20px; }
        .jc-sig-block { flex: 1; }
        .jc-sig-label {
            font-size: 10px; font-weight: 700; text-transform: uppercase;
            letter-spacing: 0.5px; color: #64748b;
            margin-bottom: 24px;
        }
        .jc-sig-line {
            border-bottom: 1px solid #1a1a1a;
            min-width: 100%;
        }
        .jc-completion-label {
            font-size: 10px; font-weight: 700; text-transform: uppercase;
            letter-spacing: 0.5px; color: #64748b;
            margin-bottom: 8px;
        }
        .jc-completion-lines {
            border: 1px solid #e2e8f0; border-radius: 4px;
            min-height: 80px; padding: 10px;
            background: #fafafa;
        }
        .jc-completion-line {
            border-bottom: 1px dotted #cbd5e1;
            height: 24px;
        }
        .jc-completion-line:last-child { border-bottom: none; }

        /* ── Footer ── */
        .jc-footer {
            margin-top: 24px; padding-top: 12px;
            border-top: 1px solid #e2e8f0;
            display: flex; justify-content: space-between;
            font-size: 9px; color: #94a3b8;
        }
        .jc-footer-left { font-weight: 600; }
        .jc-footer-right { text-align: right; }

        /* ── Urgent Stamp ── */
        .jc-urgent-stamp {
            position: absolute; top: 50px; right: 30px;
            transform: rotate(12deg);
            border: 3px solid #dc2626; color: #dc2626;
            font-size: 18px; font-weight: 900;
            padding: 4px 16px; letter-spacing: 3px;
            text-transform: uppercase; opacity: 0.35;
            border-radius: 6px;
        }

        @@media print {
            .jc-urgent-stamp { opacity: 0.25; }
        }
    </style>
</head>
<body>

{{-- Print Toolbar --}}
<div class="jc-toolbar jc-no-print">
    <div class="jc-toolbar-title">Job Card Preview</div>
    <div class="jc-toolbar-actions">
        <a href="{{ route('nexcore.clients.show.tasks.show', [$client->id, $task->id]) }}" class="jc-back-btn">
            &#8592; Back to Task
        </a>
        <button class="jc-print-btn" onclick="window.print()">
            &#128438; Print Job Card
        </button>
    </div>
</div>

<div class="jc-page" style="position:relative;">

    {{-- Urgent Stamp --}}
    @if($task->is_urgent || $task->priority === 'urgent')
        <div class="jc-urgent-stamp">URGENT</div>
    @endif

    {{-- 1. HEADER --}}
    <div class="jc-header">
        <div class="jc-header-left">
            <div class="jc-logo-area">NexCore Enterprise Platform</div>
            <div class="jc-company-name">{{ $client->company_name }}</div>
        </div>
        <div class="jc-header-right">
            <div class="jc-jc-title">JOB CARD</div>
            <table class="jc-ref-table">
                <tr>
                    <td class="jc-ref-label">Job Card No:</td>
                    <td class="jc-ref-value">JC-{{ str_pad($task->id, 5, '0', STR_PAD_LEFT) }}</td>
                </tr>
                <tr>
                    <td class="jc-ref-label">Date Printed:</td>
                    <td class="jc-ref-value">{{ \Carbon\Carbon::now()->format('j M Y') }}</td>
                </tr>
            </table>
        </div>
    </div>

    {{-- 2. TASK DETAILS --}}
    <div class="jc-section">
        <div class="jc-section-title">Task Details</div>
        <table class="jc-details-table">
            <tr>
                <td class="jc-detail-label">Title</td>
                <td class="jc-detail-value" colspan="3" style="font-weight:700; font-size:14px;">{{ $task->title }}</td>
            </tr>
            <tr>
                <td class="jc-detail-label">Category</td>
                <td class="jc-detail-value">
                    @php $cat = $task->category ?: 'general'; @endphp
                    {{ $categories[$cat] ?? ucfirst($cat) }}
                </td>
                <td class="jc-detail-label">Priority</td>
                <td class="jc-detail-value">
                    <span class="jc-priority-badge jc-priority-{{ $task->priority }}">{{ ucfirst($task->priority) }}</span>
                </td>
            </tr>
            <tr>
                <td class="jc-detail-label">Status</td>
                <td class="jc-detail-value">
                    @php $statusLabel = ['pending'=>'Pending','in_progress'=>'In Progress','review'=>'In Review','completed'=>'Completed','on_hold'=>'On Hold','cancelled'=>'Cancelled'][$task->task_status] ?? ucfirst($task->task_status); @endphp
                    <span class="jc-status-badge jc-status-{{ $task->task_status }}">{{ $statusLabel }}</span>
                </td>
                <td class="jc-detail-label">Assigned To</td>
                <td class="jc-detail-value">{{ $task->assigned_to ?: '---' }}</td>
            </tr>
            <tr>
                <td class="jc-detail-label">Created Date</td>
                <td class="jc-detail-value">{{ $task->created_at ? $task->created_at->format('j M Y') : '---' }}</td>
                <td class="jc-detail-label">Due Date</td>
                <td class="jc-detail-value" style="{{ $task->due_date && $task->due_date->lt(\Carbon\Carbon::today()) && !in_array($task->task_status, ['completed','cancelled']) ? 'color:#dc2626; font-weight:700;' : '' }}">
                    {{ $task->due_date ? $task->due_date->format('j M Y') : '---' }}
                    @if($task->due_date && $task->due_date->lt(\Carbon\Carbon::today()) && !in_array($task->task_status, ['completed','cancelled']))
                        (OVERDUE)
                    @endif
                </td>
            </tr>
            <tr>
                <td class="jc-detail-label">Start Date</td>
                <td class="jc-detail-value">{{ $task->start_date ? $task->start_date->format('j M Y') : '---' }}</td>
                <td class="jc-detail-label">Estimated Hours</td>
                <td class="jc-detail-value">{{ $task->estimated_hours ? number_format($task->estimated_hours, 1) . ' hrs' : '---' }}</td>
            </tr>
        </table>
    </div>

    {{-- 3. DESCRIPTION --}}
    <div class="jc-section">
        <div class="jc-section-title">Description</div>
        <div class="jc-desc-box">
            @if($task->description)
                {{ $task->description }}
            @else
                <span class="jc-desc-empty">No description provided.</span>
            @endif
        </div>
    </div>

    {{-- 4. CHECKLIST --}}
    <div class="jc-section">
        <div class="jc-section-title">Checklist / Steps</div>
        <table class="jc-checklist-table">
            <thead>
                <tr>
                    <th class="jc-check-col">Done</th>
                    <th class="jc-step-num">#</th>
                    <th>Step Description</th>
                    <th class="jc-step-status">Status</th>
                </tr>
            </thead>
            <tbody>
                @forelse($task->steps as $idx => $step)
                    <tr class="{{ $step->is_completed ? 'jc-step-done' : '' }}">
                        <td class="jc-check-col">
                            <span class="jc-checkbox {{ $step->is_completed ? 'jc-checkbox-done' : '' }}"></span>
                        </td>
                        <td class="jc-step-num">{{ $idx + 1 }}</td>
                        <td class="jc-step-title">{{ $step->title }}</td>
                        <td class="jc-step-status {{ $step->is_completed ? 'jc-step-status-done' : 'jc-step-status-open' }}">
                            {{ $step->is_completed ? 'Done' : 'Open' }}
                        </td>
                    </tr>
                @empty
                    <tr class="jc-empty-row">
                        <td colspan="4">No checklist steps defined. Use this space for manual task breakdown.</td>
                    </tr>
                    {{-- Blank rows for manual writing --}}
                    @for($i = 0; $i < 6; $i++)
                    <tr>
                        <td class="jc-check-col"><span class="jc-checkbox"></span></td>
                        <td class="jc-step-num" style="color:#cbd5e1;">{{ $i + 1 }}</td>
                        <td style="min-height:20px;">&nbsp;</td>
                        <td class="jc-step-status">&nbsp;</td>
                    </tr>
                    @endfor
                @endforelse
            </tbody>
        </table>
    </div>

    {{-- 5. NOTES --}}
    @if($task->notes)
    <div class="jc-section">
        <div class="jc-section-title">Internal Notes</div>
        <div class="jc-notes-box">{{ $task->notes }}</div>
    </div>
    @endif

    {{-- 6. SIGN-OFF --}}
    <div class="jc-section">
        <div class="jc-signoff">
            <div class="jc-signoff-title">Sign-Off</div>
            <div class="jc-signoff-body">
                <div class="jc-sig-row">
                    <div class="jc-sig-block">
                        <div class="jc-sig-label">Assigned To:</div>
                        <div class="jc-sig-line"></div>
                    </div>
                    <div class="jc-sig-block" style="max-width:160px;">
                        <div class="jc-sig-label">Date:</div>
                        <div class="jc-sig-line"></div>
                    </div>
                </div>
                <div class="jc-sig-row">
                    <div class="jc-sig-block">
                        <div class="jc-sig-label">Approved By:</div>
                        <div class="jc-sig-line"></div>
                    </div>
                    <div class="jc-sig-block" style="max-width:160px;">
                        <div class="jc-sig-label">Date:</div>
                        <div class="jc-sig-line"></div>
                    </div>
                </div>
                <div class="jc-completion-label">Completion Notes:</div>
                <div class="jc-completion-lines">
                    <div class="jc-completion-line"></div>
                    <div class="jc-completion-line"></div>
                    <div class="jc-completion-line"></div>
                </div>
            </div>
        </div>
    </div>

    {{-- 7. FOOTER --}}
    <div class="jc-footer">
        <div class="jc-footer-left">NexCore Enterprise Platform</div>
        <div class="jc-footer-right">
            This document was generated on {{ \Carbon\Carbon::now()->format('j M Y \a\t H:i') }} and is for internal use only.
        </div>
    </div>

</div>

<script>
    // Auto-trigger print dialog after a short delay
    window.addEventListener('load', function() {
        setTimeout(function() {
            window.print();
        }, 800);
    });
</script>

</body>
</html>
