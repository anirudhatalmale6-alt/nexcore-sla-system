@extends('nexcore_client_manager::layouts.nerve-centre')

@section('sidebar')
    @include('nexcore_client_manager::partials.nerve-centre-sidebar')
@endsection

@section('title', $task->title . ' - ' . $client->company_name)
@section('topbar_module', 'Task Manager')
@section('topbar_page', 'Task Detail')

@section('content')

@php
    $today = \Carbon\Carbon::today();
    $cat = $task->category ?: 'general';
    $catColor = $categoryColors[$cat] ?? '#94a3b8';
    $catIcon = $categoryIcons[$cat] ?? 'fa-tasks';
    $catLabel = $categories[$cat] ?? 'General';
    $statusLabel = $taskStatuses[$task->task_status] ?? ucfirst($task->task_status);
    $priorityLabel = $priorities[$task->priority] ?? ucfirst($task->priority);

    $totalSteps = $task->steps->count();
    $completedSteps = $task->steps->where('is_completed', true)->count();
    $progressPercent = $totalSteps > 0 ? round(($completedSteps / $totalSteps) * 100) : (int)($task->progress_percent ?? 0);

    $isOverdue = $task->due_date && $task->due_date->lt($today) && !in_array($task->task_status, ['completed', 'cancelled']);

    $pinnedNotes = $task->notes->where('is_pinned', true);
    $unpinnedNotes = $task->notes->where('is_pinned', false);
    $allNotes = $pinnedNotes->merge($unpinnedNotes);
@endphp

{{-- ═══════════════════════════════════════════════════ --}}
{{-- 1. HEADER BAR                                      --}}
{{-- ═══════════════════════════════════════════════════ --}}
<div class="td-header sl-animate d1">
    <div class="td-header-left">
        <a href="{{ route('nexcore.clients.show.tasks', $client->id) }}" class="td-back-btn" title="Back to Tasks">
            <i class="fas fa-arrow-left"></i>
        </a>
        <div class="td-header-cat-badge" style="--cat-color:{{ $catColor }};">
            <i class="fas {{ $catIcon }}"></i>
        </div>
        <div class="td-header-title-group">
            <div class="td-header-cat-label" style="color:{{ $catColor }};">{{ $catLabel }}</div>
            <h1 class="td-header-title">
                {{ $task->title }}
                @if($task->is_urgent)
                    <span class="td-urgent-flame" title="Urgent"><i class="fas fa-fire"></i></span>
                @endif
            </h1>
            <div class="td-header-badges">
                <span class="td-badge td-badge-priority td-priority-{{ $task->priority }}">
                    <span class="td-priority-dot"></span> {{ $priorityLabel }}
                </span>
                <span class="td-badge td-badge-status td-status-{{ $task->task_status }}">
                    @switch($task->task_status)
                        @case('pending') <i class="fas fa-clock"></i> @break
                        @case('in_progress') <i class="fas fa-spinner"></i> @break
                        @case('completed') <i class="fas fa-check-circle"></i> @break
                        @case('cancelled') <i class="fas fa-ban"></i> @break
                        @default <i class="fas fa-circle"></i>
                    @endswitch
                    {{ $statusLabel }}
                </span>
            </div>
        </div>
    </div>
    <div class="td-header-right">
        <a href="{{ route('nexcore.clients.show.tasks.edit', [$client->id, $task->id]) }}" class="neon-btn neon-btn-cyan">
            <i class="fas fa-pen"></i> Edit
        </a>
        <a href="{{ route('nexcore.clients.show.tasks.jobcard', [$client->id, $task->id]) }}" class="neon-btn neon-btn-amber" target="_blank">
            <i class="fas fa-print"></i> Print Job Card
        </a>
        <form method="POST" action="{{ route('nexcore.clients.show.tasks.destroy', [$client->id, $task->id]) }}" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this task? This action cannot be undone.');">
            @csrf @method('DELETE')
            <button type="submit" class="neon-btn neon-btn-red"><i class="fas fa-trash-alt"></i> Delete</button>
        </form>
    </div>
</div>

{{-- ═══════════════════════════════════════════════════ --}}
{{-- 2. TOP INFO STRIP                                  --}}
{{-- ═══════════════════════════════════════════════════ --}}
<div class="td-info-strip sl-animate d2">
    <div class="td-info-item">
        <div class="td-info-label"><i class="fas fa-building"></i> Client</div>
        <div class="td-info-value">{{ $client->company_name }}</div>
    </div>
    <div class="td-info-divider"></div>
    <div class="td-info-item">
        <div class="td-info-label"><i class="fas fa-user"></i> Assigned To</div>
        <div class="td-info-value">{{ $task->assigned_to ?: 'Unassigned' }}</div>
    </div>
    <div class="td-info-divider"></div>
    <div class="td-info-item">
        <div class="td-info-label"><i class="fas fa-calendar-alt"></i> Due Date</div>
        <div class="td-info-value {{ $isOverdue ? 'td-info-overdue' : '' }}">
            {{ $task->due_date ? $task->due_date->format('j M Y') : 'No due date' }}
            @if($isOverdue)
                <span class="td-overdue-tag">OVERDUE</span>
            @endif
        </div>
    </div>
    <div class="td-info-divider"></div>
    <div class="td-info-item">
        <div class="td-info-label"><i class="fas fa-play"></i> Start Date</div>
        <div class="td-info-value">{{ $task->start_date ? $task->start_date->format('j M Y') : '-' }}</div>
    </div>
    <div class="td-info-divider"></div>
    <div class="td-info-item">
        <div class="td-info-label"><i class="fas fa-plus-circle"></i> Created</div>
        <div class="td-info-value">{{ $task->created_at->format('j M Y') }}</div>
    </div>
    <div class="td-info-divider"></div>
    <div class="td-info-item">
        <div class="td-info-label"><i class="fas fa-hourglass-half"></i> Est. Hours</div>
        <div class="td-info-value">{{ $task->estimated_hours ? number_format($task->estimated_hours, 1) : '-' }}</div>
    </div>
</div>

{{-- ═══════════════════════════════════════════════════ --}}
{{-- 3. PROGRESS BAR SECTION                            --}}
{{-- ═══════════════════════════════════════════════════ --}}
<div class="td-progress-card sl-animate d2">
    <div class="td-progress-header">
        <div class="td-progress-left">
            <span class="td-progress-label">Progress</span>
            <span class="td-progress-pct" id="tdProgressPct">{{ $progressPercent }}%</span>
        </div>
        <div class="td-progress-right">
            <span class="td-progress-steps" id="tdProgressStepsText">{{ $completedSteps }} of {{ $totalSteps }} steps completed</span>
        </div>
    </div>
    <div class="td-progress-track">
        <div class="td-progress-fill" id="tdProgressFill" style="width:{{ $progressPercent }}%;"></div>
        <div class="td-progress-glow" id="tdProgressGlow" style="left:{{ $progressPercent }}%;"></div>
    </div>
    <div class="td-progress-slider-row">
        <span class="td-progress-slider-label">Manual Override</span>
        <input type="range" class="td-progress-range" id="tdProgressRange" min="0" max="100" value="{{ $progressPercent }}" oninput="tdUpdateProgressPreview(this.value)" onchange="tdSaveProgress(this.value)">
        <span class="td-progress-range-val" id="tdProgressRangeVal">{{ $progressPercent }}%</span>
    </div>
</div>

{{-- ═══════════════════════════════════════════════════ --}}
{{-- 4. DESCRIPTION CARD                                --}}
{{-- ═══════════════════════════════════════════════════ --}}
@if($task->description || $task->notes)
<div class="td-desc-card sl-animate d3">
    @if($task->description)
    <div class="td-desc-section">
        <div class="td-desc-header"><i class="fas fa-align-left"></i> Description</div>
        <div class="td-desc-body">{!! nl2br(e($task->description)) !!}</div>
    </div>
    @endif
    @if($task->notes)
    <div class="td-desc-section td-desc-notes-section">
        <div class="td-desc-header"><i class="fas fa-lock"></i> Internal Notes</div>
        <div class="td-desc-body td-desc-notes">{!! nl2br(e($task->notes)) !!}</div>
    </div>
    @endif
</div>
@endif

{{-- ═══════════════════════════════════════════════════ --}}
{{-- 5. TABBED CONTENT AREA                             --}}
{{-- ═══════════════════════════════════════════════════ --}}
<div class="td-tabs-wrapper sl-animate d4">
    {{-- Tab Buttons --}}
    <div class="td-tab-bar">
        <button class="td-tab-btn active" data-tab="checklist" onclick="tdSwitchTab('checklist', this)">
            <i class="fas fa-check-square"></i> <span>Checklist</span>
            <span class="td-tab-count" id="tdChecklistCount">{{ $totalSteps }}</span>
        </button>
        <button class="td-tab-btn" data-tab="comments" onclick="tdSwitchTab('comments', this)">
            <i class="fas fa-comments"></i> <span>Comments</span>
            <span class="td-tab-count">{{ $task->comments->count() }}</span>
        </button>
        <button class="td-tab-btn" data-tab="attachments" onclick="tdSwitchTab('attachments', this)">
            <i class="fas fa-paperclip"></i> <span>Attachments</span>
            <span class="td-tab-count">{{ $task->attachments->count() }}</span>
        </button>
        <button class="td-tab-btn" data-tab="notes" onclick="tdSwitchTab('notes', this)">
            <i class="fas fa-sticky-note"></i> <span>Notes</span>
            <span class="td-tab-count">{{ $task->notes->count() }}</span>
        </button>
        <button class="td-tab-btn" data-tab="activity" onclick="tdSwitchTab('activity', this)">
            <i class="fas fa-history"></i> <span>Activity</span>
        </button>
    </div>

    {{-- ──────────── TAB 1: CHECKLIST ──────────── --}}
    <div class="td-tab-panel active" id="tdPanel-checklist">
        <div class="td-panel-header">
            <h3 class="td-panel-title"><i class="fas fa-check-square"></i> Checklist Steps</h3>
        </div>

        {{-- Add Step Form --}}
        <div class="td-add-form" id="tdAddStepForm">
            <input type="text" class="td-add-input" id="tdNewStepTitle" placeholder="Add a new step..." maxlength="255" onkeydown="if(event.key==='Enter'){event.preventDefault();tdAddStep();}">
            <button class="neon-btn neon-btn-green td-add-btn" onclick="tdAddStep()">
                <i class="fas fa-plus"></i> Add Step
            </button>
        </div>

        {{-- Step List --}}
        <div class="td-step-list" id="tdStepList">
            @forelse($task->steps as $step)
            <div class="td-step-row {{ $step->is_completed ? 'td-step-done' : '' }}" data-step-id="{{ $step->id }}" data-sort="{{ $step->sort_order }}">
                <div class="td-step-drag" title="Drag to reorder">
                    <i class="fas fa-grip-vertical"></i>
                </div>
                <label class="td-step-check">
                    <input type="checkbox" {{ $step->is_completed ? 'checked' : '' }} onchange="tdToggleStep({{ $step->id }}, this)">
                    <span class="td-step-checkmark">
                        <i class="fas fa-check"></i>
                    </span>
                </label>
                <div class="td-step-content">
                    <span class="td-step-title">{{ $step->title }}</span>
                    @if($step->is_completed && $step->completedByUser)
                        <span class="td-step-meta">
                            Completed by {{ $step->completedByUser->first_name }} {{ $step->completedByUser->last_name }}
                            @if($step->completed_at) &middot; {{ $step->completed_at->diffForHumans() }}@endif
                        </span>
                    @endif
                </div>
                <button class="td-step-delete" onclick="tdDeleteStep({{ $step->id }}, this)" title="Remove step">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            @empty
            <div class="td-empty-state" id="tdStepEmpty">
                <i class="fas fa-list-check"></i>
                <p>No checklist steps yet. Add your first step above.</p>
            </div>
            @endforelse
        </div>
    </div>

    {{-- ──────────── TAB 2: COMMENTS ──────────── --}}
    <div class="td-tab-panel" id="tdPanel-comments">
        <div class="td-panel-header">
            <h3 class="td-panel-title"><i class="fas fa-comments"></i> Comments</h3>
        </div>

        {{-- Comment Form --}}
        <div class="td-add-form td-comment-form">
            <textarea class="td-add-textarea" id="tdNewComment" placeholder="Write a comment..." rows="3"></textarea>
            <div class="td-comment-form-footer">
                <label class="td-internal-check">
                    <input type="checkbox" id="tdCommentInternal">
                    <span class="td-internal-checkmark"></span>
                    <span>Internal only</span>
                </label>
                <button class="neon-btn neon-btn-blue td-add-btn" onclick="tdAddComment()">
                    <i class="fas fa-paper-plane"></i> Post Comment
                </button>
            </div>
        </div>

        {{-- Comment List --}}
        <div class="td-comment-list" id="tdCommentList">
            @forelse($task->comments->sortByDesc('created_at') as $comment)
            <div class="td-comment-item" data-comment-id="{{ $comment->id }}">
                <div class="td-comment-avatar" style="--avatar-hue:{{ ($comment->user_id ?? 0) * 47 % 360 }};">
                    {{ $comment->user ? strtoupper(substr($comment->user->first_name, 0, 1) . substr($comment->user->last_name, 0, 1)) : '??' }}
                </div>
                <div class="td-comment-body">
                    <div class="td-comment-header">
                        <span class="td-comment-author">{{ $comment->user ? $comment->user->first_name . ' ' . $comment->user->last_name : 'Unknown' }}</span>
                        <span class="td-comment-time">{{ $comment->created_at->diffForHumans() }}</span>
                        @if($comment->is_internal)
                            <span class="td-internal-badge"><i class="fas fa-lock"></i> Internal</span>
                        @endif
                    </div>
                    <div class="td-comment-text">{!! nl2br(e($comment->comment)) !!}</div>
                    @if($comment->user_id == auth()->id())
                    <button class="td-comment-delete" onclick="tdDeleteComment({{ $comment->id }}, this)" title="Delete comment">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                    @endif
                </div>
            </div>
            @empty
            <div class="td-empty-state" id="tdCommentEmpty">
                <i class="fas fa-comments"></i>
                <p>No comments yet.</p>
            </div>
            @endforelse
        </div>
    </div>

    {{-- ──────────── TAB 3: ATTACHMENTS ──────────── --}}
    <div class="td-tab-panel" id="tdPanel-attachments">
        <div class="td-panel-header">
            <h3 class="td-panel-title"><i class="fas fa-paperclip"></i> Attachments</h3>
        </div>

        {{-- Upload Form --}}
        <div class="td-add-form td-upload-form">
            <div class="td-dropzone" id="tdDropzone" onclick="document.getElementById('tdFileInput').click();" ondragover="event.preventDefault();this.classList.add('td-dropzone-hover');" ondragleave="this.classList.remove('td-dropzone-hover');" ondrop="event.preventDefault();this.classList.remove('td-dropzone-hover');tdHandleDrop(event);">
                <i class="fas fa-cloud-upload-alt"></i>
                <p>Drop files here or click to browse</p>
                <span class="td-dropzone-hint">Max 10MB per file</span>
                <input type="file" id="tdFileInput" style="display:none;" onchange="tdFileSelected(this);" multiple>
            </div>
            <div class="td-upload-row" id="tdUploadRow" style="display:none;">
                <span class="td-upload-filename" id="tdUploadFilename"></span>
                <input type="text" class="td-add-input td-upload-desc" id="tdFileDesc" placeholder="Optional description...">
                <button class="neon-btn neon-btn-purple td-add-btn" onclick="tdUploadAttachment()">
                    <i class="fas fa-upload"></i> Upload
                </button>
            </div>
        </div>

        {{-- Attachment Grid --}}
        <div class="td-attachment-grid" id="tdAttachmentGrid">
            @forelse($task->attachments->sortByDesc('created_at') as $att)
            @php
                $ext = strtolower(pathinfo($att->file_name, PATHINFO_EXTENSION));
                $iconClass = 'fa-file'; $iconColor = '#94a3b8';
                if (in_array($ext, ['pdf'])) { $iconClass = 'fa-file-pdf'; $iconColor = '#ef4444'; }
                elseif (in_array($ext, ['doc','docx'])) { $iconClass = 'fa-file-word'; $iconColor = '#3b82f6'; }
                elseif (in_array($ext, ['xls','xlsx','csv'])) { $iconClass = 'fa-file-excel'; $iconColor = '#22c55e'; }
                elseif (in_array($ext, ['jpg','jpeg','png','gif','svg','webp'])) { $iconClass = 'fa-file-image'; $iconColor = '#8b5cf6'; }
                elseif (in_array($ext, ['zip','rar','7z','tar','gz'])) { $iconClass = 'fa-file-archive'; $iconColor = '#f59e0b'; }

                $sizeBytes = $att->file_size ?? 0;
                if ($sizeBytes >= 1048576) $sizeStr = number_format($sizeBytes / 1048576, 1) . ' MB';
                elseif ($sizeBytes >= 1024) $sizeStr = number_format($sizeBytes / 1024, 0) . ' KB';
                else $sizeStr = $sizeBytes . ' B';
            @endphp
            <div class="td-att-card" data-att-id="{{ $att->id }}">
                <div class="td-att-icon" style="--att-color:{{ $iconColor }};">
                    <i class="fas {{ $iconClass }}"></i>
                </div>
                <div class="td-att-info">
                    <div class="td-att-name" title="{{ $att->file_name }}">{{ \Illuminate\Support\Str::limit($att->file_name, 30) }}</div>
                    <div class="td-att-meta">{{ $sizeStr }} &middot; {{ $att->created_at->format('j M Y') }}</div>
                    @if($att->uploader)
                        <div class="td-att-uploader">by {{ $att->uploader->first_name }} {{ $att->uploader->last_name }}</div>
                    @endif
                    @if($att->description)
                        <div class="td-att-desc">{{ $att->description }}</div>
                    @endif
                </div>
                <div class="td-att-actions">
                    <a href="{{ asset($att->file_path) }}" class="td-att-action-btn td-att-download" download title="Download">
                        <i class="fas fa-download"></i>
                    </a>
                    <button class="td-att-action-btn td-att-delete" onclick="tdDeleteAttachment({{ $att->id }}, this)" title="Delete">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </div>
            </div>
            @empty
            <div class="td-empty-state td-empty-full" id="tdAttachmentEmpty">
                <i class="fas fa-paperclip"></i>
                <p>No attachments yet.</p>
            </div>
            @endforelse
        </div>
    </div>

    {{-- ──────────── TAB 4: NOTES ──────────── --}}
    <div class="td-tab-panel" id="tdPanel-notes">
        <div class="td-panel-header">
            <h3 class="td-panel-title"><i class="fas fa-sticky-note"></i> Notes</h3>
        </div>

        {{-- Add Note Form --}}
        <div class="td-add-form td-note-form">
            <input type="text" class="td-add-input" id="tdNoteTitle" placeholder="Note title..." maxlength="255">
            <textarea class="td-add-textarea" id="tdNoteContent" placeholder="Note content..." rows="3"></textarea>
            <div style="display:flex;justify-content:flex-end;">
                <button class="neon-btn neon-btn-amber td-add-btn" onclick="tdAddNote()">
                    <i class="fas fa-plus"></i> Add Note
                </button>
            </div>
        </div>

        {{-- Note List --}}
        <div class="td-note-list" id="tdNoteList">
            @forelse($allNotes as $note)
            <div class="td-note-card {{ $note->is_pinned ? 'td-note-pinned' : '' }}" data-note-id="{{ $note->id }}">
                <div class="td-note-pin-wrap">
                    <button class="td-note-pin {{ $note->is_pinned ? 'active' : '' }}" onclick="tdTogglePin({{ $note->id }}, this)" title="{{ $note->is_pinned ? 'Unpin' : 'Pin' }}">
                        <i class="fas fa-thumbtack"></i>
                    </button>
                </div>
                <div class="td-note-body">
                    <div class="td-note-title">{{ $note->title }}</div>
                    <div class="td-note-content">{!! nl2br(e($note->content)) !!}</div>
                    <div class="td-note-footer">
                        <span class="td-note-meta">
                            {{ $note->user ? $note->user->first_name . ' ' . $note->user->last_name : 'Unknown' }}
                            &middot; {{ $note->created_at->diffForHumans() }}
                        </span>
                        <div class="td-note-actions">
                            <button class="td-note-action-btn" onclick="tdEditNote({{ $note->id }}, this)" title="Edit">
                                <i class="fas fa-pen"></i>
                            </button>
                            <button class="td-note-action-btn td-note-del" onclick="tdDeleteNote({{ $note->id }}, this)" title="Delete">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            @empty
            <div class="td-empty-state" id="tdNoteEmpty">
                <i class="fas fa-sticky-note"></i>
                <p>No notes yet.</p>
            </div>
            @endforelse
        </div>
    </div>

    {{-- ──────────── TAB 5: ACTIVITY ──────────── --}}
    <div class="td-tab-panel" id="tdPanel-activity">
        <div class="td-panel-header">
            <h3 class="td-panel-title"><i class="fas fa-history"></i> Activity Timeline</h3>
        </div>

        <div class="td-timeline" id="tdTimeline">
            @forelse($task->activityLog->sortByDesc('created_at') as $log)
            @php
                $logIcon = 'fa-circle'; $logColor = '#94a3b8';
                $a = $log->action ?? '';
                if (str_contains($a, 'created')) { $logIcon = 'fa-plus-circle'; $logColor = '#22c55e'; }
                elseif (str_contains($a, 'status')) { $logIcon = 'fa-exchange-alt'; $logColor = '#3b82f6'; }
                elseif (str_contains($a, 'comment')) { $logIcon = 'fa-comment'; $logColor = '#06b6d4'; }
                elseif (str_contains($a, 'attachment') || str_contains($a, 'upload')) { $logIcon = 'fa-paperclip'; $logColor = '#f59e0b'; }
                elseif (str_contains($a, 'step') || str_contains($a, 'check')) { $logIcon = 'fa-check-square'; $logColor = '#8b5cf6'; }
                elseif (str_contains($a, 'delete') || str_contains($a, 'remove')) { $logIcon = 'fa-trash'; $logColor = '#ef4444'; }
                elseif (str_contains($a, 'update') || str_contains($a, 'edit')) { $logIcon = 'fa-pen'; $logColor = '#06b6d4'; }
                elseif (str_contains($a, 'assign')) { $logIcon = 'fa-user-check'; $logColor = '#8b5cf6'; }
                elseif (str_contains($a, 'note')) { $logIcon = 'fa-sticky-note'; $logColor = '#f59e0b'; }
                elseif (str_contains($a, 'reminder')) { $logIcon = 'fa-bell'; $logColor = '#f59e0b'; }
            @endphp
            <div class="td-tl-item">
                <div class="td-tl-dot" style="--tl-color:{{ $logColor }};">
                    <i class="fas {{ $logIcon }}"></i>
                </div>
                <div class="td-tl-body">
                    <div class="td-tl-text">{{ $log->description ?? ucfirst(str_replace('_', ' ', $log->action)) }}</div>
                    <div class="td-tl-meta">
                        {{ $log->user ? $log->user->first_name . ' ' . $log->user->last_name : 'System' }}
                        &middot; {{ $log->created_at->diffForHumans() }}
                    </div>
                </div>
            </div>
            @empty
            <div class="td-empty-state">
                <i class="fas fa-history"></i>
                <p>No activity recorded yet.</p>
            </div>
            @endforelse
        </div>
    </div>
</div>

{{-- ═══════════════════════════════════════════════════ --}}
{{-- 6. REMINDERS SECTION                               --}}
{{-- ═══════════════════════════════════════════════════ --}}
<div class="td-reminders-card sl-animate d5">
    <div class="td-reminders-header">
        <i class="fas fa-bell"></i> <span>Reminders</span>
        <span class="td-tab-count">{{ $task->reminders->count() }}</span>
    </div>

    <div class="td-reminder-form">
        <div class="td-reminder-form-row">
            <input type="datetime-local" class="td-add-input td-reminder-datetime" id="tdReminderAt">
            <input type="text" class="td-add-input" id="tdReminderMsg" placeholder="Reminder message..." maxlength="500">
        </div>
        <button class="neon-btn neon-btn-amber td-add-btn" onclick="tdAddReminder()" style="align-self:flex-end;">
            <i class="fas fa-bell"></i> Set Reminder
        </button>
    </div>

    <div class="td-reminder-list" id="tdReminderList">
        @forelse($task->reminders->sortBy('remind_at') as $rem)
        <div class="td-reminder-item {{ $rem->is_sent ? 'td-reminder-sent' : '' }}" data-reminder-id="{{ $rem->id }}">
            <div class="td-reminder-icon">
                <i class="fas {{ $rem->is_sent ? 'fa-check-circle' : 'fa-clock' }}"></i>
            </div>
            <div class="td-reminder-body">
                <div class="td-reminder-time">{{ $rem->remind_at->format('j M Y, H:i') }}</div>
                @if($rem->message)
                    <div class="td-reminder-msg">{{ $rem->message }}</div>
                @endif
                @if($rem->is_sent)
                    <span class="td-reminder-sent-badge">Sent</span>
                @endif
            </div>
            <button class="td-reminder-delete" onclick="tdDeleteReminder({{ $rem->id }}, this)" title="Remove">
                <i class="fas fa-times"></i>
            </button>
        </div>
        @empty
        <div class="td-empty-state td-empty-sm" id="tdReminderEmpty">
            <i class="fas fa-bell-slash"></i>
            <p>No reminders set.</p>
        </div>
        @endforelse
    </div>
</div>

{{-- ═══════════════════════════════════════════════════ --}}
{{-- 7. SUB-TASKS SECTION                               --}}
{{-- ═══════════════════════════════════════════════════ --}}
@if($task->subtasks->count() > 0)
<div class="td-subtasks-card sl-animate d5">
    <div class="td-subtasks-header">
        <i class="fas fa-project-diagram"></i> <span>Sub-Tasks</span>
        <span class="td-tab-count">{{ $task->subtasks->count() }}</span>
    </div>

    <div class="td-subtask-list">
        @foreach($task->subtasks as $sub)
        @php
            $subProg = $sub->progress_percent ?? 0;
            $subStatusLabel = $taskStatuses[$sub->task_status] ?? ucfirst($sub->task_status);
        @endphp
        <a href="{{ route('nexcore.clients.show.tasks.show', [$client->id, $sub->id]) }}" class="td-subtask-row">
            <div class="td-subtask-title">{{ $sub->title }}</div>
            <span class="td-badge td-badge-status td-status-{{ $sub->task_status }}" style="font-size:10px;padding:2px 8px;">{{ $subStatusLabel }}</span>
            <div class="td-subtask-progress">
                <div class="td-subtask-bar">
                    <div class="td-subtask-fill" style="width:{{ $subProg }}%;"></div>
                </div>
                <span class="td-subtask-pct">{{ $subProg }}%</span>
            </div>
            <i class="fas fa-chevron-right td-subtask-arrow"></i>
        </a>
        @endforeach
    </div>
</div>
@endif

{{-- Note Edit Modal --}}
<div class="td-modal-overlay" id="tdNoteModal" style="display:none;">
    <div class="td-modal">
        <div class="td-modal-header">
            <h3><i class="fas fa-pen"></i> Edit Note</h3>
            <button class="td-modal-close" onclick="tdCloseNoteModal()"><i class="fas fa-times"></i></button>
        </div>
        <div class="td-modal-body">
            <input type="hidden" id="tdEditNoteId">
            <div class="td-add-form" style="padding:0;background:transparent;border:none;">
                <input type="text" class="td-add-input" id="tdEditNoteTitle" placeholder="Note title...">
                <textarea class="td-add-textarea" id="tdEditNoteContent" placeholder="Note content..." rows="4"></textarea>
            </div>
        </div>
        <div class="td-modal-footer">
            <button class="neon-btn neon-btn-ghost" onclick="tdCloseNoteModal()">Cancel</button>
            <button class="neon-btn neon-btn-green" onclick="tdSaveEditedNote()"><i class="fas fa-save"></i> Save</button>
        </div>
    </div>
</div>

@endsection

@push('styles')
<style>
/* ═══════════════════════════════════════════════════════════ */
/* TASK DETAIL (td-) — NexCore Enterprise Dark Theme          */
/* ═══════════════════════════════════════════════════════════ */

/* ── 1. HEADER BAR ── */
.td-header {
    display:flex; align-items:flex-start; justify-content:space-between; gap:16px;
    padding:20px 24px; margin-bottom:16px;
    background:linear-gradient(135deg, rgba(17,21,32,0.9), rgba(17,21,32,0.6));
    border:1px solid rgba(255,255,255,0.06);
    border-radius:16px;
    backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px);
    position:relative; overflow:hidden;
}
.td-header::before {
    content:''; position:absolute; top:0; left:0; right:0; height:1px;
    background:linear-gradient(90deg, transparent, rgba(59,130,246,0.3), rgba(139,92,246,0.2), transparent);
}
.td-header-left { display:flex; align-items:flex-start; gap:14px; flex:1; min-width:0; }
.td-back-btn {
    width:38px; height:38px; min-width:38px; border-radius:10px;
    background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08);
    display:flex; align-items:center; justify-content:center;
    color:rgba(255,255,255,0.5); font-size:14px; text-decoration:none;
    transition:all 0.25s ease; margin-top:2px;
}
.td-back-btn:hover { background:rgba(255,255,255,0.08); color:#fff; transform:translateX(-2px); }
.td-header-cat-badge {
    width:42px; height:42px; min-width:42px; border-radius:12px;
    background:color-mix(in srgb, var(--cat-color) 12%, transparent);
    border:1px solid color-mix(in srgb, var(--cat-color) 30%, transparent);
    display:flex; align-items:center; justify-content:center;
    color:var(--cat-color); font-size:16px; margin-top:2px;
}
.td-header-title-group { flex:1; min-width:0; }
.td-header-cat-label { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:0.8px; margin-bottom:4px; }
.td-header-title {
    margin:0; font-size:22px; font-weight:800; color:#fff; line-height:1.3;
    font-family:'Montserrat',sans-serif; letter-spacing:0.3px;
    display:flex; align-items:center; gap:10px; flex-wrap:wrap;
}
.td-urgent-flame {
    display:inline-flex; align-items:center; justify-content:center;
    width:28px; height:28px; border-radius:8px;
    background:rgba(239,68,68,0.15); color:#ef4444; font-size:14px;
    animation:tdFlameGlow 1.5s ease-in-out infinite;
}
.td-header-badges { display:flex; gap:8px; margin-top:8px; flex-wrap:wrap; }
.td-header-right { display:flex; gap:8px; align-items:flex-start; flex-shrink:0; flex-wrap:wrap; }

/* ── Badges (shared) ── */
.td-badge {
    display:inline-flex; align-items:center; gap:5px;
    padding:4px 12px; border-radius:6px;
    font-size:11px; font-weight:600; font-family:'Poppins',sans-serif;
}
.td-badge i { font-size:10px; }
.td-priority-dot { width:6px; height:6px; border-radius:50%; }
.td-badge-priority { border:1px solid rgba(255,255,255,0.08); }
.td-priority-low { color:rgba(255,255,255,0.4); background:rgba(255,255,255,0.03); }
.td-priority-low .td-priority-dot { background:#94a3b8; }
.td-priority-medium { color:#3b82f6; background:rgba(59,130,246,0.08); border-color:rgba(59,130,246,0.2); }
.td-priority-medium .td-priority-dot { background:#3b82f6; }
.td-priority-high { color:#f59e0b; background:rgba(245,158,11,0.08); border-color:rgba(245,158,11,0.2); }
.td-priority-high .td-priority-dot { background:#f59e0b; }
.td-priority-urgent { color:#ef4444; background:rgba(239,68,68,0.08); border-color:rgba(239,68,68,0.2); }
.td-priority-urgent .td-priority-dot { background:#ef4444; animation:tdDotPulse 1.2s ease-in-out infinite; }
.td-badge-status { border:1px solid rgba(255,255,255,0.08); }
.td-status-pending { color:#f59e0b; background:rgba(245,158,11,0.08); border-color:rgba(245,158,11,0.2); }
.td-status-in_progress { color:#3b82f6; background:rgba(59,130,246,0.08); border-color:rgba(59,130,246,0.2); }
.td-status-completed { color:#22c55e; background:rgba(34,197,94,0.08); border-color:rgba(34,197,94,0.2); }
.td-status-cancelled { color:#ef4444; background:rgba(239,68,68,0.08); border-color:rgba(239,68,68,0.2); }

/* ── 2. INFO STRIP ── */
.td-info-strip {
    display:flex; align-items:center; gap:0; flex-wrap:wrap;
    padding:14px 20px; margin-bottom:16px;
    background:rgba(17,21,32,0.8); backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px);
    border:1px solid rgba(255,255,255,0.06); border-radius:14px;
}
.td-info-item { flex:1; min-width:120px; padding:4px 16px; }
.td-info-label { font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:0.8px; color:rgba(255,255,255,0.3); margin-bottom:4px; display:flex; align-items:center; gap:5px; }
.td-info-label i { font-size:9px; opacity:0.6; }
.td-info-value { font-size:13px; font-weight:600; color:#fff; }
.td-info-overdue { color:#ef4444; }
.td-overdue-tag {
    display:inline-block; font-size:9px; font-weight:800; color:#fff;
    background:#ef4444; padding:1px 6px; border-radius:4px; margin-left:6px;
    letter-spacing:0.5px; animation:tdDotPulse 1.5s ease-in-out infinite;
}
.td-info-divider { width:1px; height:32px; background:rgba(255,255,255,0.06); flex-shrink:0; }

/* ── 3. PROGRESS BAR ── */
.td-progress-card {
    padding:20px 24px; margin-bottom:16px;
    background:rgba(17,21,32,0.8); backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px);
    border:1px solid rgba(255,255,255,0.06); border-radius:14px;
}
.td-progress-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:12px; }
.td-progress-left { display:flex; align-items:center; gap:10px; }
.td-progress-label { font-size:12px; font-weight:700; text-transform:uppercase; letter-spacing:0.5px; color:rgba(255,255,255,0.4); }
.td-progress-pct { font-size:24px; font-weight:800; color:#22c55e; font-family:'Montserrat',sans-serif; }
.td-progress-right {}
.td-progress-steps { font-size:12px; color:rgba(255,255,255,0.35); font-weight:500; }
.td-progress-track {
    position:relative; height:10px; border-radius:10px;
    background:rgba(255,255,255,0.04); overflow:visible; margin-bottom:14px;
}
.td-progress-fill {
    height:100%; border-radius:10px;
    background:linear-gradient(90deg, #22c55e, #06b6d4);
    transition:width 0.6s cubic-bezier(0.4, 0, 0.2, 1);
    position:relative; overflow:hidden;
}
.td-progress-fill::after {
    content:''; position:absolute; inset:0;
    background:linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent);
    animation:tdShimmer 2s ease-in-out infinite;
}
.td-progress-glow {
    position:absolute; top:50%; width:20px; height:20px;
    transform:translate(-50%, -50%);
    background:radial-gradient(circle, rgba(34,197,94,0.4), transparent 70%);
    border-radius:50%; pointer-events:none;
    transition:left 0.6s cubic-bezier(0.4, 0, 0.2, 1);
}
.td-progress-slider-row {
    display:flex; align-items:center; gap:12px;
    padding-top:4px; border-top:1px solid rgba(255,255,255,0.04);
}
.td-progress-slider-label { font-size:11px; color:rgba(255,255,255,0.25); font-weight:600; white-space:nowrap; }
.td-progress-range {
    flex:1; -webkit-appearance:none; appearance:none; height:4px;
    background:rgba(255,255,255,0.06); border-radius:4px; outline:none;
    cursor:pointer;
}
.td-progress-range::-webkit-slider-thumb {
    -webkit-appearance:none; width:16px; height:16px; border-radius:50%;
    background:linear-gradient(135deg, #22c55e, #06b6d4);
    border:2px solid rgba(255,255,255,0.2); cursor:pointer;
    box-shadow:0 0 10px rgba(34,197,94,0.3);
}
.td-progress-range::-moz-range-thumb {
    width:16px; height:16px; border-radius:50%;
    background:linear-gradient(135deg, #22c55e, #06b6d4);
    border:2px solid rgba(255,255,255,0.2); cursor:pointer;
}
.td-progress-range-val { font-size:12px; font-weight:700; color:rgba(255,255,255,0.5); min-width:36px; text-align:right; font-family:'Montserrat',sans-serif; }

/* ── 4. DESCRIPTION CARD ── */
.td-desc-card {
    padding:20px 24px; margin-bottom:16px;
    background:rgba(17,21,32,0.8); backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px);
    border:1px solid rgba(255,255,255,0.06); border-radius:14px;
}
.td-desc-section + .td-desc-section { margin-top:16px; padding-top:16px; border-top:1px solid rgba(255,255,255,0.04); }
.td-desc-header { font-size:12px; font-weight:700; text-transform:uppercase; letter-spacing:0.5px; color:rgba(255,255,255,0.35); margin-bottom:10px; display:flex; align-items:center; gap:8px; }
.td-desc-header i { font-size:11px; }
.td-desc-body { font-size:14px; line-height:1.7; color:var(--text-secondary, #d4dce8); }
.td-desc-notes { color:var(--text-muted, #a8b5c8); font-style:italic; opacity:0.8; }

/* ── 5. TABS ── */
.td-tabs-wrapper {
    background:rgba(17,21,32,0.8); backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px);
    border:1px solid rgba(255,255,255,0.06); border-radius:16px;
    overflow:hidden; margin-bottom:16px;
}
.td-tab-bar {
    display:flex; gap:0; border-bottom:1px solid rgba(255,255,255,0.06);
    overflow-x:auto; scrollbar-width:none;
}
.td-tab-bar::-webkit-scrollbar { display:none; }
.td-tab-btn {
    flex:1; min-width:0; padding:14px 12px;
    background:transparent; border:none; border-bottom:2px solid transparent;
    color:rgba(255,255,255,0.4); font-size:12px; font-weight:600;
    display:flex; align-items:center; justify-content:center; gap:7px;
    cursor:pointer; transition:all 0.25s ease; white-space:nowrap;
    font-family:'Poppins',sans-serif;
}
.td-tab-btn:hover { color:rgba(255,255,255,0.7); background:rgba(255,255,255,0.02); }
.td-tab-btn.active {
    color:#fff; border-bottom-color:#3b82f6;
    background:linear-gradient(180deg, rgba(59,130,246,0.06), transparent);
}
.td-tab-btn i { font-size:13px; }
.td-tab-count {
    font-size:10px; font-weight:700; font-family:'Montserrat',sans-serif;
    background:rgba(255,255,255,0.06); padding:2px 7px; border-radius:8px;
    min-width:18px; text-align:center;
}
.td-tab-btn.active .td-tab-count { background:rgba(59,130,246,0.2); color:#93c5fd; }
.td-tab-panel { display:none; padding:20px 24px; }
.td-tab-panel.active { display:block; }
.td-panel-header { margin-bottom:16px; }
.td-panel-title { margin:0; font-size:16px; font-weight:700; color:#fff; display:flex; align-items:center; gap:8px; }
.td-panel-title i { font-size:14px; color:rgba(255,255,255,0.4); }

/* ── Add Forms (shared) ── */
.td-add-form {
    padding:16px; border-radius:12px; margin-bottom:16px;
    background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.06);
    display:flex; flex-direction:column; gap:10px;
}
.td-add-input {
    flex:1; padding:10px 14px; border-radius:8px;
    background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08);
    color:#fff; font-size:13px; font-family:'Poppins',sans-serif;
    outline:none; transition:all 0.25s ease;
}
.td-add-input:focus { border-color:rgba(59,130,246,0.4); background:rgba(255,255,255,0.05); }
.td-add-input::placeholder { color:rgba(255,255,255,0.25); }
.td-add-textarea {
    width:100%; padding:10px 14px; border-radius:8px;
    background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08);
    color:#fff; font-size:13px; font-family:'Poppins',sans-serif;
    outline:none; resize:vertical; transition:all 0.25s ease;
}
.td-add-textarea:focus { border-color:rgba(59,130,246,0.4); background:rgba(255,255,255,0.05); }
.td-add-textarea::placeholder { color:rgba(255,255,255,0.25); }
.td-add-btn { flex-shrink:0; white-space:nowrap; }

#tdAddStepForm { flex-direction:row; align-items:center; }

/* ── Checklist Steps ── */
.td-step-list { display:flex; flex-direction:column; gap:4px; }
.td-step-row {
    display:flex; align-items:center; gap:12px;
    padding:10px 14px; border-radius:10px;
    background:rgba(255,255,255,0.015);
    border:1px solid rgba(255,255,255,0.04);
    transition:all 0.25s ease;
}
.td-step-row:hover { background:rgba(255,255,255,0.035); border-color:rgba(255,255,255,0.08); }
.td-step-drag { color:rgba(255,255,255,0.15); font-size:12px; cursor:grab; padding:2px 4px; }
.td-step-drag:active { cursor:grabbing; }
.td-step-check { position:relative; cursor:pointer; flex-shrink:0; }
.td-step-check input { display:none; }
.td-step-checkmark {
    width:22px; height:22px; border-radius:6px;
    background:rgba(255,255,255,0.04); border:1.5px solid rgba(255,255,255,0.15);
    display:flex; align-items:center; justify-content:center;
    color:transparent; font-size:11px; transition:all 0.3s ease;
}
.td-step-check input:checked + .td-step-checkmark {
    background:linear-gradient(135deg, #22c55e, #16a34a);
    border-color:#22c55e; color:#fff;
    box-shadow:0 0 12px rgba(34,197,94,0.3);
}
.td-step-content { flex:1; min-width:0; }
.td-step-title { font-size:13px; font-weight:600; color:#fff; transition:all 0.3s ease; }
.td-step-done .td-step-title { text-decoration:line-through; color:rgba(255,255,255,0.3); }
.td-step-meta { display:block; font-size:11px; color:rgba(255,255,255,0.25); margin-top:2px; }
.td-step-delete {
    width:26px; height:26px; border-radius:6px;
    background:transparent; border:none; color:rgba(255,255,255,0.15);
    display:flex; align-items:center; justify-content:center;
    font-size:11px; cursor:pointer; transition:all 0.2s ease;
    opacity:0;
}
.td-step-row:hover .td-step-delete { opacity:1; }
.td-step-delete:hover { background:rgba(239,68,68,0.15); color:#ef4444; }

/* ── Comments ── */
.td-comment-form { gap:12px; }
.td-comment-form-footer { display:flex; align-items:center; justify-content:space-between; gap:12px; }
.td-internal-check {
    display:flex; align-items:center; gap:8px;
    font-size:12px; color:rgba(255,255,255,0.4); cursor:pointer; font-weight:500;
}
.td-internal-check input { display:none; }
.td-internal-checkmark {
    width:16px; height:16px; border-radius:4px;
    background:rgba(255,255,255,0.04); border:1.5px solid rgba(255,255,255,0.15);
    display:inline-flex; align-items:center; justify-content:center; transition:all 0.2s ease;
}
.td-internal-check input:checked + .td-internal-checkmark {
    background:rgba(245,158,11,0.2); border-color:#f59e0b;
}
.td-internal-check input:checked + .td-internal-checkmark::after {
    content:'\f00c'; font-family:'Font Awesome 6 Free'; font-weight:900;
    font-size:8px; color:#f59e0b;
}
.td-comment-list { display:flex; flex-direction:column; gap:12px; }
.td-comment-item {
    display:flex; gap:12px; padding:14px 16px; border-radius:10px;
    background:rgba(255,255,255,0.015); border:1px solid rgba(255,255,255,0.04);
    transition:all 0.25s ease;
}
.td-comment-item:hover { background:rgba(255,255,255,0.03); }
.td-comment-avatar {
    width:36px; height:36px; min-width:36px; border-radius:10px;
    background:hsl(var(--avatar-hue), 50%, 20%);
    border:1px solid hsl(var(--avatar-hue), 50%, 30%);
    display:flex; align-items:center; justify-content:center;
    font-size:11px; font-weight:700; color:hsl(var(--avatar-hue), 70%, 70%);
    letter-spacing:0.5px;
}
.td-comment-body { flex:1; min-width:0; position:relative; }
.td-comment-header { display:flex; align-items:center; gap:8px; flex-wrap:wrap; margin-bottom:4px; }
.td-comment-author { font-size:13px; font-weight:700; color:#fff; }
.td-comment-time { font-size:11px; color:rgba(255,255,255,0.25); }
.td-internal-badge {
    display:inline-flex; align-items:center; gap:4px;
    font-size:10px; font-weight:700; color:#f59e0b;
    background:rgba(245,158,11,0.1); border:1px solid rgba(245,158,11,0.25);
    padding:1px 8px; border-radius:4px;
}
.td-comment-text { font-size:13px; line-height:1.6; color:var(--text-secondary, #d4dce8); }
.td-comment-delete {
    position:absolute; top:0; right:0;
    width:24px; height:24px; border-radius:6px;
    background:transparent; border:none; color:rgba(255,255,255,0.15);
    display:flex; align-items:center; justify-content:center;
    font-size:10px; cursor:pointer; transition:all 0.2s ease; opacity:0;
}
.td-comment-item:hover .td-comment-delete { opacity:1; }
.td-comment-delete:hover { background:rgba(239,68,68,0.15); color:#ef4444; }

/* ── Attachments ── */
.td-upload-form { gap:12px; }
.td-dropzone {
    padding:28px 20px; border-radius:12px; text-align:center;
    background:rgba(255,255,255,0.02);
    border:2px dashed rgba(255,255,255,0.1);
    cursor:pointer; transition:all 0.3s ease;
}
.td-dropzone:hover, .td-dropzone-hover {
    background:rgba(139,92,246,0.04) !important;
    border-color:rgba(139,92,246,0.3) !important;
}
.td-dropzone i { font-size:28px; color:rgba(255,255,255,0.15); margin-bottom:8px; display:block; }
.td-dropzone p { margin:0; font-size:13px; color:rgba(255,255,255,0.35); font-weight:500; }
.td-dropzone-hint { font-size:11px; color:rgba(255,255,255,0.2); margin-top:4px; display:block; }
.td-upload-row { display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
.td-upload-filename {
    font-size:12px; font-weight:600; color:#8b5cf6;
    background:rgba(139,92,246,0.1); padding:6px 12px; border-radius:6px;
    max-width:200px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;
}
.td-upload-desc { flex:1; min-width:150px; }
.td-attachment-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(280px, 1fr)); gap:10px; }
.td-att-card {
    display:flex; align-items:flex-start; gap:12px;
    padding:14px 16px; border-radius:10px;
    background:rgba(255,255,255,0.015); border:1px solid rgba(255,255,255,0.04);
    transition:all 0.25s ease;
}
.td-att-card:hover { background:rgba(255,255,255,0.03); border-color:rgba(255,255,255,0.08); }
.td-att-icon {
    width:40px; height:40px; min-width:40px; border-radius:10px;
    background:color-mix(in srgb, var(--att-color) 10%, transparent);
    border:1px solid color-mix(in srgb, var(--att-color) 25%, transparent);
    display:flex; align-items:center; justify-content:center;
    color:var(--att-color); font-size:16px;
}
.td-att-info { flex:1; min-width:0; }
.td-att-name { font-size:13px; font-weight:600; color:#fff; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.td-att-meta { font-size:11px; color:rgba(255,255,255,0.3); margin-top:2px; }
.td-att-uploader { font-size:11px; color:rgba(255,255,255,0.25); }
.td-att-desc { font-size:11px; color:rgba(255,255,255,0.35); margin-top:4px; font-style:italic; }
.td-att-actions { display:flex; gap:6px; flex-shrink:0; margin-top:4px; }
.td-att-action-btn {
    width:28px; height:28px; border-radius:6px;
    display:flex; align-items:center; justify-content:center;
    font-size:11px; border:none; cursor:pointer; transition:all 0.2s ease;
    text-decoration:none;
}
.td-att-download { background:rgba(59,130,246,0.1); color:#3b82f6; }
.td-att-download:hover { background:rgba(59,130,246,0.2); }
.td-att-delete { background:rgba(239,68,68,0.1); color:#ef4444; }
.td-att-delete:hover { background:rgba(239,68,68,0.2); }

/* ── Notes ── */
.td-note-form { gap:10px; }
.td-note-list { display:flex; flex-direction:column; gap:10px; }
.td-note-card {
    display:flex; gap:12px; padding:14px 16px; border-radius:10px;
    background:rgba(255,255,255,0.015); border:1px solid rgba(255,255,255,0.04);
    transition:all 0.25s ease;
}
.td-note-card:hover { background:rgba(255,255,255,0.03); }
.td-note-pinned { border-color:rgba(245,158,11,0.2); background:rgba(245,158,11,0.02); }
.td-note-pin-wrap { flex-shrink:0; }
.td-note-pin {
    width:28px; height:28px; border-radius:6px;
    background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08);
    color:rgba(255,255,255,0.2); display:flex; align-items:center; justify-content:center;
    font-size:11px; cursor:pointer; transition:all 0.2s ease;
}
.td-note-pin:hover { background:rgba(245,158,11,0.1); color:#f59e0b; }
.td-note-pin.active { background:rgba(245,158,11,0.15); border-color:rgba(245,158,11,0.3); color:#f59e0b; }
.td-note-body { flex:1; min-width:0; }
.td-note-title { font-size:14px; font-weight:700; color:#fff; margin-bottom:4px; }
.td-note-content { font-size:13px; line-height:1.6; color:var(--text-secondary, #d4dce8); }
.td-note-footer { display:flex; align-items:center; justify-content:space-between; margin-top:10px; gap:8px; }
.td-note-meta { font-size:11px; color:rgba(255,255,255,0.25); }
.td-note-actions { display:flex; gap:6px; opacity:0; transition:opacity 0.2s ease; }
.td-note-card:hover .td-note-actions { opacity:1; }
.td-note-action-btn {
    width:26px; height:26px; border-radius:6px;
    background:rgba(255,255,255,0.04); border:none;
    color:rgba(255,255,255,0.3); display:flex; align-items:center; justify-content:center;
    font-size:10px; cursor:pointer; transition:all 0.2s ease;
}
.td-note-action-btn:hover { background:rgba(59,130,246,0.15); color:#3b82f6; }
.td-note-del:hover { background:rgba(239,68,68,0.15) !important; color:#ef4444 !important; }

/* ── Activity Timeline ── */
.td-timeline { position:relative; padding-left:28px; }
.td-timeline::before {
    content:''; position:absolute; left:11px; top:8px; bottom:8px;
    width:2px; background:rgba(255,255,255,0.06); border-radius:2px;
}
.td-tl-item { display:flex; gap:16px; padding:10px 0; position:relative; }
.td-tl-dot {
    position:absolute; left:-28px; top:12px;
    width:22px; height:22px; border-radius:50%;
    background:color-mix(in srgb, var(--tl-color) 15%, #0a0e1a);
    border:2px solid color-mix(in srgb, var(--tl-color) 40%, transparent);
    display:flex; align-items:center; justify-content:center;
    font-size:9px; color:var(--tl-color); z-index:1;
}
.td-tl-body { flex:1; min-width:0; }
.td-tl-text { font-size:13px; font-weight:500; color:var(--text-secondary, #d4dce8); line-height:1.5; }
.td-tl-meta { font-size:11px; color:rgba(255,255,255,0.25); margin-top:2px; }

/* ── 6. REMINDERS CARD ── */
.td-reminders-card {
    padding:20px 24px; margin-bottom:16px;
    background:rgba(17,21,32,0.8); backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px);
    border:1px solid rgba(255,255,255,0.06); border-radius:14px;
}
.td-reminders-header {
    font-size:15px; font-weight:700; color:#fff; margin-bottom:16px;
    display:flex; align-items:center; gap:8px;
}
.td-reminders-header i { color:#f59e0b; }
.td-reminder-form { display:flex; flex-direction:column; gap:10px; margin-bottom:16px; }
.td-reminder-form-row { display:flex; gap:10px; flex-wrap:wrap; }
.td-reminder-datetime { max-width:220px; color-scheme:dark; }
.td-reminder-list { display:flex; flex-direction:column; gap:8px; }
.td-reminder-item {
    display:flex; align-items:flex-start; gap:12px;
    padding:10px 14px; border-radius:10px;
    background:rgba(255,255,255,0.015); border:1px solid rgba(255,255,255,0.04);
    transition:all 0.25s ease;
}
.td-reminder-item:hover { background:rgba(255,255,255,0.03); }
.td-reminder-sent { opacity:0.5; }
.td-reminder-icon { font-size:14px; color:#f59e0b; margin-top:2px; }
.td-reminder-sent .td-reminder-icon { color:#22c55e; }
.td-reminder-body { flex:1; min-width:0; }
.td-reminder-time { font-size:13px; font-weight:600; color:#fff; }
.td-reminder-msg { font-size:12px; color:rgba(255,255,255,0.4); margin-top:2px; }
.td-reminder-sent-badge {
    display:inline-block; font-size:9px; font-weight:700; color:#22c55e;
    background:rgba(34,197,94,0.1); padding:1px 6px; border-radius:4px; margin-top:4px;
}
.td-reminder-delete {
    width:26px; height:26px; border-radius:6px;
    background:transparent; border:none; color:rgba(255,255,255,0.15);
    display:flex; align-items:center; justify-content:center;
    font-size:11px; cursor:pointer; transition:all 0.2s ease;
}
.td-reminder-delete:hover { background:rgba(239,68,68,0.15); color:#ef4444; }

/* ── 7. SUB-TASKS ── */
.td-subtasks-card {
    padding:20px 24px; margin-bottom:16px;
    background:rgba(17,21,32,0.8); backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px);
    border:1px solid rgba(255,255,255,0.06); border-radius:14px;
}
.td-subtasks-header {
    font-size:15px; font-weight:700; color:#fff; margin-bottom:16px;
    display:flex; align-items:center; gap:8px;
}
.td-subtasks-header i { color:#8b5cf6; }
.td-subtask-list { display:flex; flex-direction:column; gap:6px; }
.td-subtask-row {
    display:flex; align-items:center; gap:12px;
    padding:12px 16px; border-radius:10px;
    background:rgba(255,255,255,0.015); border:1px solid rgba(255,255,255,0.04);
    text-decoration:none; transition:all 0.25s ease;
}
.td-subtask-row:hover { background:rgba(255,255,255,0.04); border-color:rgba(255,255,255,0.08); transform:translateX(4px); }
.td-subtask-title { font-size:13px; font-weight:600; color:#fff; flex:1; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.td-subtask-progress { display:flex; align-items:center; gap:8px; width:120px; flex-shrink:0; }
.td-subtask-bar { flex:1; height:4px; border-radius:4px; background:rgba(255,255,255,0.06); overflow:hidden; }
.td-subtask-fill { height:100%; border-radius:4px; background:linear-gradient(90deg, #22c55e, #06b6d4); }
.td-subtask-pct { font-size:11px; font-weight:700; color:rgba(255,255,255,0.4); min-width:28px; text-align:right; }
.td-subtask-arrow { color:rgba(255,255,255,0.15); font-size:11px; flex-shrink:0; }

/* ── Empty States ── */
.td-empty-state {
    text-align:center; padding:32px 20px;
}
.td-empty-state i { font-size:32px; color:rgba(255,255,255,0.06); margin-bottom:12px; display:block; }
.td-empty-state p { margin:0; font-size:13px; color:rgba(255,255,255,0.25); }
.td-empty-sm { padding:20px 16px; }
.td-empty-sm i { font-size:24px; }
.td-empty-full { grid-column:1 / -1; }

/* ── Note Edit Modal ── */
.td-modal-overlay {
    position:fixed; inset:0; z-index:9999;
    background:rgba(0,0,0,0.7); backdrop-filter:blur(4px);
    display:flex; align-items:center; justify-content:center;
    padding:20px;
}
.td-modal {
    width:100%; max-width:520px; border-radius:16px;
    background:rgba(17,21,32,0.98); border:1px solid rgba(255,255,255,0.1);
    box-shadow:0 24px 80px rgba(0,0,0,0.6);
    overflow:hidden;
}
.td-modal-header {
    display:flex; align-items:center; justify-content:space-between;
    padding:16px 20px; border-bottom:1px solid rgba(255,255,255,0.06);
}
.td-modal-header h3 { margin:0; font-size:15px; font-weight:700; color:#fff; display:flex; align-items:center; gap:8px; }
.td-modal-header h3 i { color:rgba(255,255,255,0.4); font-size:13px; }
.td-modal-close {
    width:30px; height:30px; border-radius:8px; background:rgba(255,255,255,0.04);
    border:none; color:rgba(255,255,255,0.4); display:flex; align-items:center; justify-content:center;
    font-size:13px; cursor:pointer; transition:all 0.2s ease;
}
.td-modal-close:hover { background:rgba(239,68,68,0.15); color:#ef4444; }
.td-modal-body { padding:20px; }
.td-modal-footer { display:flex; justify-content:flex-end; gap:10px; padding:16px 20px; border-top:1px solid rgba(255,255,255,0.06); }

/* ── Toast Notification ── */
.td-toast {
    position:fixed; bottom:24px; right:24px; z-index:10000;
    padding:12px 20px; border-radius:10px;
    font-size:13px; font-weight:600; color:#fff;
    backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px);
    box-shadow:0 8px 32px rgba(0,0,0,0.4);
    transform:translateY(20px); opacity:0;
    transition:all 0.35s cubic-bezier(0.4, 0, 0.2, 1);
    pointer-events:none; display:flex; align-items:center; gap:8px;
}
.td-toast.show { transform:translateY(0); opacity:1; pointer-events:auto; }
.td-toast-success { background:rgba(34,197,94,0.2); border:1px solid rgba(34,197,94,0.3); }
.td-toast-error { background:rgba(239,68,68,0.2); border:1px solid rgba(239,68,68,0.3); }

/* ── ANIMATIONS ── */
@@keyframes tdFlameGlow {
    0%, 100% { box-shadow:0 0 8px rgba(239,68,68,0.2); }
    50% { box-shadow:0 0 18px rgba(239,68,68,0.4); }
}
@@keyframes tdDotPulse {
    0%, 100% { opacity:1; }
    50% { opacity:0.3; }
}
@@keyframes tdShimmer {
    0% { transform:translateX(-100%); }
    100% { transform:translateX(200%); }
}
@@keyframes tdFadeIn {
    from { opacity:0; transform:translateY(8px); }
    to { opacity:1; transform:translateY(0); }
}

/* ── Drag-and-drop active state ── */
.td-step-row.td-dragging {
    opacity:0.5; background:rgba(59,130,246,0.08); border-color:rgba(59,130,246,0.3);
}
.td-step-row.td-drag-over {
    border-top:2px solid #3b82f6;
}

/* ── RESPONSIVE ── */
@@media (max-width: 900px) {
    .td-header { flex-direction:column; gap:12px; }
    .td-header-right { width:100%; justify-content:flex-end; }
    .td-info-strip { flex-direction:column; gap:4px; }
    .td-info-divider { width:100%; height:1px; }
    .td-info-item { padding:8px 0; }
    .td-tab-btn span { display:none; }
    .td-tab-btn i { font-size:16px; }
    #tdAddStepForm { flex-direction:column; }
    .td-attachment-grid { grid-template-columns:1fr; }
    .td-comment-form-footer { flex-direction:column; align-items:flex-start; }
    .td-upload-row { flex-direction:column; }
    .td-reminder-form-row { flex-direction:column; }
    .td-reminder-datetime { max-width:100%; }
    .td-subtask-progress { width:80px; }
}
@@media (max-width: 600px) {
    .td-header-title { font-size:18px; }
    .td-progress-pct { font-size:20px; }
}
</style>
@endpush

@push('scripts')
<script>
(function(){
    'use strict';

    /* ═══════════════════════════════════════ */
    /* CSRF + helpers                          */
    /* ═══════════════════════════════════════ */
    var CSRF = document.querySelector('meta[name="csrf-token"]').content;

    var ROUTES = {
        stepsStore:     '{{ route("nexcore.clients.show.tasks.steps.store", [$client->id, $task->id]) }}',
        stepToggle:     '{{ route("nexcore.clients.show.tasks.steps.toggle", [$client->id, $task->id, "__STEP_ID__"]) }}',
        stepDestroy:    '{{ route("nexcore.clients.show.tasks.steps.destroy", [$client->id, $task->id, "__STEP_ID__"]) }}',
        stepsReorder:   '{{ route("nexcore.clients.show.tasks.steps.reorder", [$client->id, $task->id]) }}',
        commentsStore:  '{{ route("nexcore.clients.show.tasks.comments.store", [$client->id, $task->id]) }}',
        commentDestroy: '{{ route("nexcore.clients.show.tasks.comments.destroy", [$client->id, $task->id, "__COMMENT_ID__"]) }}',
        attachStore:    '{{ route("nexcore.clients.show.tasks.attachments.store", [$client->id, $task->id]) }}',
        attachDestroy:  '{{ route("nexcore.clients.show.tasks.attachments.destroy", [$client->id, $task->id, "__ATTACHMENT_ID__"]) }}',
        notesStore:     '{{ route("nexcore.clients.show.tasks.notes.store", [$client->id, $task->id]) }}',
        noteUpdate:     '{{ route("nexcore.clients.show.tasks.notes.update", [$client->id, $task->id, "__NOTE_ID__"]) }}',
        noteDestroy:    '{{ route("nexcore.clients.show.tasks.notes.destroy", [$client->id, $task->id, "__NOTE_ID__"]) }}',
        notePin:        '{{ route("nexcore.clients.show.tasks.notes.pin", [$client->id, $task->id, "__NOTE_ID__"]) }}',
        remindersStore: '{{ route("nexcore.clients.show.tasks.reminders.store", [$client->id, $task->id]) }}',
        reminderDestroy:'{{ route("nexcore.clients.show.tasks.reminders.destroy", [$client->id, $task->id, "__REMINDER_ID__"]) }}',
        progressUpdate: '{{ route("nexcore.clients.show.tasks.progress", [$client->id, $task->id]) }}'
    };

    function jsonHeaders() {
        return { 'X-CSRF-TOKEN': CSRF, 'Accept': 'application/json', 'Content-Type': 'application/json' };
    }

    function fileHeaders() {
        return { 'X-CSRF-TOKEN': CSRF, 'Accept': 'application/json' };
    }

    /* ── Toast ── */
    var toastEl = null;
    var toastTimer = null;

    function tdToast(msg, type) {
        if (!toastEl) {
            toastEl = document.createElement('div');
            toastEl.className = 'td-toast';
            document.body.appendChild(toastEl);
        }
        clearTimeout(toastTimer);
        toastEl.className = 'td-toast td-toast-' + (type || 'success');
        toastEl.innerHTML = '<i class="fas ' + (type === 'error' ? 'fa-exclamation-circle' : 'fa-check-circle') + '"></i> ' + msg;
        requestAnimationFrame(function() { toastEl.classList.add('show'); });
        toastTimer = setTimeout(function() { toastEl.classList.remove('show'); }, 3500);
    }

    /* ═══════════════════════════════════════ */
    /* TAB SWITCHING                           */
    /* ═══════════════════════════════════════ */
    window.tdSwitchTab = function(tabId, btn) {
        document.querySelectorAll('.td-tab-btn').forEach(function(b) { b.classList.remove('active'); });
        document.querySelectorAll('.td-tab-panel').forEach(function(p) { p.classList.remove('active'); });
        btn.classList.add('active');
        var panel = document.getElementById('tdPanel-' + tabId);
        if (panel) panel.classList.add('active');
    };

    /* ═══════════════════════════════════════ */
    /* PROGRESS                                */
    /* ═══════════════════════════════════════ */
    window.tdUpdateProgressPreview = function(val) {
        document.getElementById('tdProgressRangeVal').textContent = val + '%';
        document.getElementById('tdProgressPct').textContent = val + '%';
        document.getElementById('tdProgressFill').style.width = val + '%';
        document.getElementById('tdProgressGlow').style.left = val + '%';
    };

    window.tdSaveProgress = function(val) {
        fetch(ROUTES.progressUpdate, {
            method: 'PATCH',
            headers: jsonHeaders(),
            body: JSON.stringify({ progress_percent: parseInt(val) })
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success || d.status === 'ok' || d.message) {
                tdToast('Progress updated', 'success');
            } else {
                tdToast('Failed to update progress', 'error');
            }
        })
        .catch(function() { tdToast('Network error', 'error'); });
    };

    /* ═══════════════════════════════════════ */
    /* CHECKLIST STEPS                         */
    /* ═══════════════════════════════════════ */
    window.tdAddStep = function() {
        var input = document.getElementById('tdNewStepTitle');
        var title = input.value.trim();
        if (!title) { input.focus(); return; }

        fetch(ROUTES.stepsStore, {
            method: 'POST',
            headers: jsonHeaders(),
            body: JSON.stringify({ title: title })
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.step || d.success || d.id) {
                var step = d.step || d;
                var emptyEl = document.getElementById('tdStepEmpty');
                if (emptyEl) emptyEl.remove();

                var row = document.createElement('div');
                row.className = 'td-step-row';
                row.setAttribute('data-step-id', step.id);
                row.setAttribute('data-sort', step.sort_order || 0);
                row.style.animation = 'tdFadeIn 0.3s ease forwards';
                row.innerHTML =
                    '<div class="td-step-drag" title="Drag to reorder"><i class="fas fa-grip-vertical"></i></div>' +
                    '<label class="td-step-check"><input type="checkbox" onchange="tdToggleStep(' + step.id + ', this)"><span class="td-step-checkmark"><i class="fas fa-check"></i></span></label>' +
                    '<div class="td-step-content"><span class="td-step-title">' + tdEscape(step.title || title) + '</span></div>' +
                    '<button class="td-step-delete" onclick="tdDeleteStep(' + step.id + ', this)" title="Remove step"><i class="fas fa-times"></i></button>';
                document.getElementById('tdStepList').appendChild(row);
                initDragForRow(row);
                input.value = '';
                tdUpdateStepCount(1);
                tdToast('Step added', 'success');
            } else {
                tdToast(d.message || 'Failed to add step', 'error');
            }
        })
        .catch(function() { tdToast('Network error', 'error'); });
    };

    window.tdToggleStep = function(stepId, checkbox) {
        var url = ROUTES.stepToggle.replace('__STEP_ID__', stepId);
        var row = checkbox.closest('.td-step-row');

        fetch(url, {
            method: 'PATCH',
            headers: jsonHeaders(),
            body: JSON.stringify({})
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            var isCompleted = d.is_completed || false;
            if (d.step) isCompleted = d.step.is_completed;

            if (isCompleted) {
                row.classList.add('td-step-done');
            } else {
                row.classList.remove('td-step-done');
            }

            /* Update progress from response */
            if (typeof d.progress_percent !== 'undefined') {
                tdUpdateProgressPreview(d.progress_percent);
                document.getElementById('tdProgressRange').value = d.progress_percent;
            }
            if (typeof d.completed_steps !== 'undefined' && typeof d.total_steps !== 'undefined') {
                document.getElementById('tdProgressStepsText').textContent = d.completed_steps + ' of ' + d.total_steps + ' steps completed';
            }

            tdToast(isCompleted ? 'Step completed' : 'Step reopened', 'success');
        })
        .catch(function() {
            checkbox.checked = !checkbox.checked;
            tdToast('Network error', 'error');
        });
    };

    window.tdDeleteStep = function(stepId, btn) {
        if (!confirm('Delete this step?')) return;
        var url = ROUTES.stepDestroy.replace('__STEP_ID__', stepId);
        var row = btn.closest('.td-step-row');

        fetch(url, {
            method: 'DELETE',
            headers: jsonHeaders()
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            row.style.opacity = '0';
            row.style.transform = 'translateX(20px)';
            row.style.transition = 'all 0.3s ease';
            setTimeout(function() { row.remove(); tdCheckStepEmpty(); }, 300);
            tdUpdateStepCount(-1);
            if (typeof d.progress_percent !== 'undefined') {
                tdUpdateProgressPreview(d.progress_percent);
                document.getElementById('tdProgressRange').value = d.progress_percent;
            }
            tdToast('Step removed', 'success');
        })
        .catch(function() { tdToast('Network error', 'error'); });
    };

    function tdUpdateStepCount(delta) {
        var el = document.getElementById('tdChecklistCount');
        if (el) {
            var c = parseInt(el.textContent) + delta;
            el.textContent = c;
        }
    }

    function tdCheckStepEmpty() {
        var list = document.getElementById('tdStepList');
        if (list && list.querySelectorAll('.td-step-row').length === 0) {
            list.innerHTML = '<div class="td-empty-state" id="tdStepEmpty"><i class="fas fa-list-check"></i><p>No checklist steps yet. Add your first step above.</p></div>';
        }
    }

    /* ── Drag & Drop for Steps ── */
    var dragSrcRow = null;

    function initDragForRow(row) {
        var handle = row.querySelector('.td-step-drag');
        if (!handle) return;

        handle.addEventListener('mousedown', function() { row.setAttribute('draggable', 'true'); });
        row.addEventListener('dragstart', function(e) {
            dragSrcRow = row;
            row.classList.add('td-dragging');
            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('text/plain', row.getAttribute('data-step-id'));
        });
        row.addEventListener('dragend', function() {
            row.classList.remove('td-dragging');
            row.removeAttribute('draggable');
            document.querySelectorAll('.td-step-row').forEach(function(r) { r.classList.remove('td-drag-over'); });
        });
        row.addEventListener('dragover', function(e) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            if (row !== dragSrcRow) {
                row.classList.add('td-drag-over');
            }
        });
        row.addEventListener('dragleave', function() { row.classList.remove('td-drag-over'); });
        row.addEventListener('drop', function(e) {
            e.preventDefault();
            row.classList.remove('td-drag-over');
            if (dragSrcRow && dragSrcRow !== row) {
                var list = document.getElementById('tdStepList');
                var rows = Array.from(list.querySelectorAll('.td-step-row'));
                var srcIdx = rows.indexOf(dragSrcRow);
                var dstIdx = rows.indexOf(row);
                if (srcIdx < dstIdx) {
                    row.parentNode.insertBefore(dragSrcRow, row.nextSibling);
                } else {
                    row.parentNode.insertBefore(dragSrcRow, row);
                }
                tdSaveStepOrder();
            }
        });
    }

    function tdSaveStepOrder() {
        var rows = document.querySelectorAll('#tdStepList .td-step-row');
        var ordered = [];
        rows.forEach(function(r, i) {
            ordered.push({ id: parseInt(r.getAttribute('data-step-id')), sort_order: i });
        });

        fetch(ROUTES.stepsReorder, {
            method: 'POST',
            headers: jsonHeaders(),
            body: JSON.stringify({ steps: ordered })
        })
        .then(function(r) { return r.json(); })
        .then(function() { tdToast('Order saved', 'success'); })
        .catch(function() { tdToast('Failed to save order', 'error'); });
    }

    /* Init drag on existing rows */
    document.querySelectorAll('#tdStepList .td-step-row').forEach(initDragForRow);

    /* ═══════════════════════════════════════ */
    /* COMMENTS                                */
    /* ═══════════════════════════════════════ */
    window.tdAddComment = function() {
        var textarea = document.getElementById('tdNewComment');
        var comment = textarea.value.trim();
        if (!comment) { textarea.focus(); return; }
        var isInternal = document.getElementById('tdCommentInternal').checked;

        fetch(ROUTES.commentsStore, {
            method: 'POST',
            headers: jsonHeaders(),
            body: JSON.stringify({ comment: comment, is_internal: isInternal ? 1 : 0 })
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.comment || d.success || d.id) {
                var c = d.comment || d;
                var emptyEl = document.getElementById('tdCommentEmpty');
                if (emptyEl) emptyEl.remove();

                var hue = ({{ auth()->id() ?? 0 }}) * 47 % 360;
                var initials = '{{ auth()->user() ? strtoupper(substr(auth()->user()->first_name, 0, 1) . substr(auth()->user()->last_name, 0, 1)) : "??" }}';
                var userName = '{{ auth()->user() ? auth()->user()->first_name . " " . auth()->user()->last_name : "You" }}';

                var item = document.createElement('div');
                item.className = 'td-comment-item';
                item.setAttribute('data-comment-id', c.id);
                item.style.animation = 'tdFadeIn 0.3s ease forwards';
                item.innerHTML =
                    '<div class="td-comment-avatar" style="--avatar-hue:' + hue + ';">' + initials + '</div>' +
                    '<div class="td-comment-body">' +
                        '<div class="td-comment-header">' +
                            '<span class="td-comment-author">' + userName + '</span>' +
                            '<span class="td-comment-time">just now</span>' +
                            (isInternal ? '<span class="td-internal-badge"><i class="fas fa-lock"></i> Internal</span>' : '') +
                        '</div>' +
                        '<div class="td-comment-text">' + tdNl2br(tdEscape(comment)) + '</div>' +
                        '<button class="td-comment-delete" onclick="tdDeleteComment(' + c.id + ', this)" title="Delete comment" style="opacity:1;"><i class="fas fa-trash-alt"></i></button>' +
                    '</div>';

                var list = document.getElementById('tdCommentList');
                list.insertBefore(item, list.firstChild);
                textarea.value = '';
                document.getElementById('tdCommentInternal').checked = false;
                tdToast('Comment posted', 'success');
            } else {
                tdToast(d.message || 'Failed to post comment', 'error');
            }
        })
        .catch(function() { tdToast('Network error', 'error'); });
    };

    window.tdDeleteComment = function(commentId, btn) {
        if (!confirm('Delete this comment?')) return;
        var url = ROUTES.commentDestroy.replace('__COMMENT_ID__', commentId);
        var item = btn.closest('.td-comment-item');

        fetch(url, {
            method: 'DELETE',
            headers: jsonHeaders()
        })
        .then(function(r) { return r.json(); })
        .then(function() {
            item.style.opacity = '0';
            item.style.transition = 'opacity 0.3s ease';
            setTimeout(function() { item.remove(); }, 300);
            tdToast('Comment deleted', 'success');
        })
        .catch(function() { tdToast('Network error', 'error'); });
    };

    /* ═══════════════════════════════════════ */
    /* ATTACHMENTS                             */
    /* ═══════════════════════════════════════ */
    var pendingFiles = [];

    window.tdHandleDrop = function(e) {
        if (e.dataTransfer.files.length > 0) {
            pendingFiles = Array.from(e.dataTransfer.files);
            tdShowFileRow();
        }
    };

    window.tdFileSelected = function(input) {
        if (input.files.length > 0) {
            pendingFiles = Array.from(input.files);
            tdShowFileRow();
        }
    };

    function tdShowFileRow() {
        var names = pendingFiles.map(function(f) { return f.name; }).join(', ');
        document.getElementById('tdUploadFilename').textContent = names;
        document.getElementById('tdUploadRow').style.display = 'flex';
    }

    window.tdUploadAttachment = function() {
        if (pendingFiles.length === 0) return;

        var formData = new FormData();
        pendingFiles.forEach(function(f, i) {
            formData.append('file' + (i > 0 ? i : ''), f);
        });
        var desc = document.getElementById('tdFileDesc').value.trim();
        if (desc) formData.append('description', desc);

        fetch(ROUTES.attachStore, {
            method: 'POST',
            headers: fileHeaders(),
            body: formData
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.attachment || d.success || d.id || d.attachments) {
                tdToast('File(s) uploaded', 'success');
                /* Reload page to show new attachments cleanly */
                setTimeout(function() { location.reload(); }, 500);
            } else {
                tdToast(d.message || 'Upload failed', 'error');
            }
        })
        .catch(function() { tdToast('Network error', 'error'); });
    };

    window.tdDeleteAttachment = function(attId, btn) {
        if (!confirm('Delete this attachment?')) return;
        var url = ROUTES.attachDestroy.replace('__ATTACHMENT_ID__', attId);
        var card = btn.closest('.td-att-card');

        fetch(url, {
            method: 'DELETE',
            headers: jsonHeaders()
        })
        .then(function(r) { return r.json(); })
        .then(function() {
            card.style.opacity = '0';
            card.style.transform = 'scale(0.95)';
            card.style.transition = 'all 0.3s ease';
            setTimeout(function() { card.remove(); }, 300);
            tdToast('Attachment deleted', 'success');
        })
        .catch(function() { tdToast('Network error', 'error'); });
    };

    /* ═══════════════════════════════════════ */
    /* NOTES                                   */
    /* ═══════════════════════════════════════ */
    window.tdAddNote = function() {
        var title = document.getElementById('tdNoteTitle').value.trim();
        var content = document.getElementById('tdNoteContent').value.trim();
        if (!title || !content) {
            tdToast('Title and content are required', 'error');
            return;
        }

        fetch(ROUTES.notesStore, {
            method: 'POST',
            headers: jsonHeaders(),
            body: JSON.stringify({ title: title, content: content })
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.note || d.success || d.id) {
                tdToast('Note added', 'success');
                setTimeout(function() { location.reload(); }, 500);
            } else {
                tdToast(d.message || 'Failed to add note', 'error');
            }
        })
        .catch(function() { tdToast('Network error', 'error'); });
    };

    window.tdEditNote = function(noteId, btn) {
        var card = btn.closest('.td-note-card');
        var title = card.querySelector('.td-note-title').textContent;
        var content = card.querySelector('.td-note-content').textContent;

        document.getElementById('tdEditNoteId').value = noteId;
        document.getElementById('tdEditNoteTitle').value = title;
        document.getElementById('tdEditNoteContent').value = content;
        document.getElementById('tdNoteModal').style.display = 'flex';
    };

    window.tdCloseNoteModal = function() {
        document.getElementById('tdNoteModal').style.display = 'none';
    };

    window.tdSaveEditedNote = function() {
        var noteId = document.getElementById('tdEditNoteId').value;
        var title = document.getElementById('tdEditNoteTitle').value.trim();
        var content = document.getElementById('tdEditNoteContent').value.trim();
        if (!title || !content) {
            tdToast('Title and content are required', 'error');
            return;
        }
        var url = ROUTES.noteUpdate.replace('__NOTE_ID__', noteId);

        fetch(url, {
            method: 'PUT',
            headers: jsonHeaders(),
            body: JSON.stringify({ title: title, content: content })
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            tdCloseNoteModal();
            if (d.note || d.success) {
                var card = document.querySelector('.td-note-card[data-note-id="' + noteId + '"]');
                if (card) {
                    card.querySelector('.td-note-title').textContent = title;
                    card.querySelector('.td-note-content').innerHTML = tdNl2br(tdEscape(content));
                }
                tdToast('Note updated', 'success');
            } else {
                tdToast(d.message || 'Failed to update', 'error');
            }
        })
        .catch(function() { tdCloseNoteModal(); tdToast('Network error', 'error'); });
    };

    window.tdDeleteNote = function(noteId, btn) {
        if (!confirm('Delete this note?')) return;
        var url = ROUTES.noteDestroy.replace('__NOTE_ID__', noteId);
        var card = btn.closest('.td-note-card');

        fetch(url, {
            method: 'DELETE',
            headers: jsonHeaders()
        })
        .then(function(r) { return r.json(); })
        .then(function() {
            card.style.opacity = '0';
            card.style.transition = 'opacity 0.3s ease';
            setTimeout(function() { card.remove(); }, 300);
            tdToast('Note deleted', 'success');
        })
        .catch(function() { tdToast('Network error', 'error'); });
    };

    window.tdTogglePin = function(noteId, btn) {
        var url = ROUTES.notePin.replace('__NOTE_ID__', noteId);
        var card = btn.closest('.td-note-card');

        fetch(url, {
            method: 'PATCH',
            headers: jsonHeaders(),
            body: JSON.stringify({})
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            var isPinned = d.is_pinned || false;
            if (d.note) isPinned = d.note.is_pinned;

            if (isPinned) {
                btn.classList.add('active');
                card.classList.add('td-note-pinned');
            } else {
                btn.classList.remove('active');
                card.classList.remove('td-note-pinned');
            }
            tdToast(isPinned ? 'Note pinned' : 'Note unpinned', 'success');
        })
        .catch(function() { tdToast('Network error', 'error'); });
    };

    /* ═══════════════════════════════════════ */
    /* REMINDERS                               */
    /* ═══════════════════════════════════════ */
    window.tdAddReminder = function() {
        var remindAt = document.getElementById('tdReminderAt').value;
        var message = document.getElementById('tdReminderMsg').value.trim();
        if (!remindAt) {
            tdToast('Please select a date and time', 'error');
            return;
        }

        fetch(ROUTES.remindersStore, {
            method: 'POST',
            headers: jsonHeaders(),
            body: JSON.stringify({ remind_at: remindAt, message: message })
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.reminder || d.success || d.id) {
                tdToast('Reminder set', 'success');
                setTimeout(function() { location.reload(); }, 500);
            } else {
                tdToast(d.message || 'Failed to set reminder', 'error');
            }
        })
        .catch(function() { tdToast('Network error', 'error'); });
    };

    window.tdDeleteReminder = function(remId, btn) {
        if (!confirm('Remove this reminder?')) return;
        var url = ROUTES.reminderDestroy.replace('__REMINDER_ID__', remId);
        var item = btn.closest('.td-reminder-item');

        fetch(url, {
            method: 'DELETE',
            headers: jsonHeaders()
        })
        .then(function(r) { return r.json(); })
        .then(function() {
            item.style.opacity = '0';
            item.style.transition = 'opacity 0.3s ease';
            setTimeout(function() { item.remove(); }, 300);
            tdToast('Reminder removed', 'success');
        })
        .catch(function() { tdToast('Network error', 'error'); });
    };

    /* ═══════════════════════════════════════ */
    /* UTILITY                                 */
    /* ═══════════════════════════════════════ */
    function tdEscape(str) {
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(str));
        return div.innerHTML;
    }

    function tdNl2br(str) {
        return str.replace(/\n/g, '<br>');
    }

    /* Expose tdEscape globally for inline handlers */
    window.tdEscape = tdEscape;

    /* ── Close modal on Escape key ── */
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            tdCloseNoteModal();
        }
    });

    /* ── Close modal on overlay click ── */
    document.getElementById('tdNoteModal').addEventListener('click', function(e) {
        if (e.target === this) {
            tdCloseNoteModal();
        }
    });

})();
</script>
@endpush
