@extends('nexcore_client_manager::layouts.nerve-centre')

@section('sidebar')
    @include('nexcore_client_manager::partials.nerve-centre-sidebar')
@endsection

@section('title', 'Task Command Centre - ' . $client->company_name)
@section('topbar_module', 'Task Manager')
@section('topbar_page', 'Task Command Centre')

@section('content')

@php
    $today = \Carbon\Carbon::today();
    $endOfWeek = \Carbon\Carbon::now()->endOfWeek();

    $totalCount     = $tasks->count();
    $overdueCount   = 0;
    $dueWeekCount   = 0;
    $inProgCount    = 0;
    $completedCount = 0;
    $urgentCount    = 0;
    $pendingCount   = 0;
    $reviewCount    = 0;
    $onHoldCount    = 0;

    $catCounts = [];
    foreach ($categories as $ck => $cl) {
        $catCounts[$ck] = 0;
    }

    foreach ($tasks as $t) {
        $isActive = !in_array($t->task_status, ['completed', 'cancelled']);
        if ($t->task_status === 'pending')     $pendingCount++;
        if ($t->task_status === 'in_progress') $inProgCount++;
        if ($t->task_status === 'review')      $reviewCount++;
        if ($t->task_status === 'completed')   $completedCount++;
        if ($t->task_status === 'on_hold')     $onHoldCount++;
        if ($t->due_date && $t->due_date->lt($today) && $isActive) $overdueCount++;
        if ($t->due_date && $t->due_date->gte($today) && $t->due_date->lte($endOfWeek) && $isActive) $dueWeekCount++;
        if ($t->is_urgent && $isActive) $urgentCount++;
        $cat = $t->category ?: 'general';
        if (isset($catCounts[$cat])) $catCounts[$cat]++;
    }

    $statusCounts = [
        'pending'     => $pendingCount,
        'in_progress' => $inProgCount,
        'review'      => $reviewCount,
        'completed'   => $completedCount,
        'on_hold'     => $onHoldCount,
    ];
@endphp

{{-- ══════════════════════════════════════════════════════════════════════ --}}
{{--  1. HERO HEADER                                                       --}}
{{-- ══════════════════════════════════════════════════════════════════════ --}}
<div class="tcc-hero sl-animate d1">
    <div class="tcc-hero-left">
        <div class="tcc-hero-icon">
            <i class="fas fa-bullseye"></i>
            <div class="tcc-hero-pulse"></div>
        </div>
        <div>
            <h1 class="tcc-hero-title">Task Command Centre</h1>
            <p class="tcc-hero-sub">{{ $client->company_name }} <span class="tcc-hero-dot"></span> {{ $totalCount }} {{ $totalCount === 1 ? 'task' : 'tasks' }}</p>
        </div>
    </div>
    <div class="tcc-hero-right">
        <div class="tcc-view-toggles">
            <a href="{{ route('nexcore.clients.show.tasks', $client->id) }}" class="tcc-view-btn tcc-view-active" title="List View">
                <i class="fas fa-list"></i>
            </a>
            <a href="{{ route('nexcore.clients.show.tasks.kanban', $client->id) }}" class="tcc-view-btn" title="Kanban Board">
                <i class="fas fa-columns"></i>
            </a>
            <a href="{{ route('nexcore.clients.show.tasks.calendar', $client->id) }}" class="tcc-view-btn" title="Calendar View">
                <i class="fas fa-calendar-alt"></i>
            </a>
        </div>
        <a href="{{ route('nexcore.clients.show.tasks.create', $client->id) }}" class="neon-btn neon-btn-green">
            <i class="fas fa-plus"></i> <span>New Task</span>
        </a>
    </div>
</div>

{{-- ══════════════════════════════════════════════════════════════════════ --}}
{{--  2. STATS ROW                                                         --}}
{{-- ══════════════════════════════════════════════════════════════════════ --}}
<div class="tcc-stats sl-animate d2">
    <div class="tcc-stat" style="--stat-color:#94a3b8;">
        <div class="tcc-stat-icon"><i class="fas fa-layer-group"></i></div>
        <div class="tcc-stat-num">{{ $totalCount }}</div>
        <div class="tcc-stat-label">Total Tasks</div>
    </div>
    <div class="tcc-stat {{ $overdueCount > 0 ? 'tcc-stat-alert' : '' }}" style="--stat-color:#ef4444;">
        <div class="tcc-stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
        <div class="tcc-stat-num">{{ $overdueCount }}</div>
        <div class="tcc-stat-label">Overdue</div>
        @if($overdueCount > 0)<div class="tcc-stat-pulse-ring"></div>@endif
    </div>
    <div class="tcc-stat" style="--stat-color:#f59e0b;">
        <div class="tcc-stat-icon"><i class="fas fa-clock"></i></div>
        <div class="tcc-stat-num">{{ $dueWeekCount }}</div>
        <div class="tcc-stat-label">Due This Week</div>
    </div>
    <div class="tcc-stat" style="--stat-color:#3b82f6;">
        <div class="tcc-stat-icon"><i class="fas fa-spinner"></i></div>
        <div class="tcc-stat-num">{{ $inProgCount }}</div>
        <div class="tcc-stat-label">In Progress</div>
    </div>
    <div class="tcc-stat" style="--stat-color:#22c55e;">
        <div class="tcc-stat-icon"><i class="fas fa-check-circle"></i></div>
        <div class="tcc-stat-num">{{ $completedCount }}</div>
        <div class="tcc-stat-label">Completed</div>
    </div>
    <div class="tcc-stat {{ $urgentCount > 0 ? 'tcc-stat-urgent' : '' }}" style="--stat-color:#8b5cf6;">
        <div class="tcc-stat-icon"><i class="fas fa-fire"></i></div>
        <div class="tcc-stat-num">{{ $urgentCount }}</div>
        <div class="tcc-stat-label">Urgent</div>
    </div>
</div>

{{-- ══════════════════════════════════════════════════════════════════════ --}}
{{--  3. FILTER BAR                                                        --}}
{{-- ══════════════════════════════════════════════════════════════════════ --}}
<div class="tcc-filters sl-animate d3">
    {{-- Category pills --}}
    <div class="tcc-filter-row">
        <div class="tcc-filter-label"><i class="fas fa-folder"></i> Category</div>
        <div class="tcc-pills" id="tccCatPills">
            <button class="tcc-pill active" data-cat="all" onclick="tccFilterCat('all', this)">
                <span class="tcc-pill-dot" style="background:#94a3b8;"></span> All <span class="tcc-pill-count">{{ $totalCount }}</span>
            </button>
            @foreach($categories as $catKey => $catLabel)
            <button class="tcc-pill" data-cat="{{ $catKey }}" onclick="tccFilterCat('{{ $catKey }}', this)">
                <span class="tcc-pill-dot" style="background:{{ $categoryColors[$catKey] ?? '#94a3b8' }};"></span> {{ $catLabel }} <span class="tcc-pill-count">{{ $catCounts[$catKey] ?? 0 }}</span>
            </button>
            @endforeach
        </div>
    </div>

    {{-- Status pills --}}
    <div class="tcc-filter-row">
        <div class="tcc-filter-label"><i class="fas fa-filter"></i> Status</div>
        <div class="tcc-pills" id="tccStatusPills">
            <button class="tcc-pill active" data-status="all" onclick="tccFilterStatus('all', this)">All</button>
            <button class="tcc-pill" data-status="pending" onclick="tccFilterStatus('pending', this)"><i class="fas fa-clock" style="font-size:10px;"></i> Pending <span class="tcc-pill-count">{{ $pendingCount }}</span></button>
            <button class="tcc-pill" data-status="in_progress" onclick="tccFilterStatus('in_progress', this)"><i class="fas fa-spinner" style="font-size:10px;"></i> In Progress <span class="tcc-pill-count">{{ $inProgCount }}</span></button>
            <button class="tcc-pill" data-status="review" onclick="tccFilterStatus('review', this)"><i class="fas fa-eye" style="font-size:10px;"></i> In Review <span class="tcc-pill-count">{{ $reviewCount }}</span></button>
            <button class="tcc-pill" data-status="completed" onclick="tccFilterStatus('completed', this)"><i class="fas fa-check" style="font-size:10px;"></i> Completed <span class="tcc-pill-count">{{ $completedCount }}</span></button>
            <button class="tcc-pill" data-status="on_hold" onclick="tccFilterStatus('on_hold', this)"><i class="fas fa-pause" style="font-size:10px;"></i> On Hold <span class="tcc-pill-count">{{ $onHoldCount }}</span></button>
            <button class="tcc-pill" data-status="overdue" onclick="tccFilterStatus('overdue', this)"><i class="fas fa-exclamation-triangle" style="font-size:10px;color:#ef4444;"></i> Overdue <span class="tcc-pill-count">{{ $overdueCount }}</span></button>
        </div>
    </div>

    {{-- Priority pills --}}
    <div class="tcc-filter-row">
        <div class="tcc-filter-label"><i class="fas fa-flag"></i> Priority</div>
        <div class="tcc-pills" id="tccPriorityPills">
            <button class="tcc-pill active" data-priority="all" onclick="tccFilterPriority('all', this)">All</button>
            <button class="tcc-pill" data-priority="urgent" onclick="tccFilterPriority('urgent', this)"><span class="tcc-priority-ind tcc-pri-urgent"></span> Urgent</button>
            <button class="tcc-pill" data-priority="high" onclick="tccFilterPriority('high', this)"><span class="tcc-priority-ind tcc-pri-high"></span> High</button>
            <button class="tcc-pill" data-priority="medium" onclick="tccFilterPriority('medium', this)"><span class="tcc-priority-ind tcc-pri-medium"></span> Medium</button>
            <button class="tcc-pill" data-priority="low" onclick="tccFilterPriority('low', this)"><span class="tcc-priority-ind tcc-pri-low"></span> Low</button>
        </div>
    </div>

    {{-- Search --}}
    <div class="tcc-filter-row">
        <div class="tcc-filter-label"><i class="fas fa-search"></i> Search</div>
        <input type="text" class="tcc-search" id="tccSearch" placeholder="Search tasks by title, description, assignee..." oninput="tccApplyFilters()">
    </div>
</div>

{{-- ══════════════════════════════════════════════════════════════════════ --}}
{{--  4. TASK CARDS LIST                                                   --}}
{{-- ══════════════════════════════════════════════════════════════════════ --}}
<div class="tcc-list" id="tccTaskList">
    @forelse($tasks as $task)
    @php
        $cat      = $task->category ?: 'general';
        $catColor = $categoryColors[$cat] ?? '#94a3b8';
        $catIcon  = $categoryIcons[$cat] ?? 'fa-tasks';
        $catLabel = $categories[$cat] ?? 'General';
        $isOverdue = $task->due_date && $task->due_date->lt($today) && !in_array($task->task_status, ['completed', 'cancelled']);
        $isDueWeek = $task->due_date && $task->due_date->gte($today) && $task->due_date->lte($endOfWeek) && !in_array($task->task_status, ['completed', 'cancelled']);
        $isCompleted = ($task->task_status === 'completed');
        $progress = (int) ($task->progress_percent ?? 0);

        // Resolve assigned user name
        $assignedName = '';
        if ($task->assigned_to) {
            $assignedUser = $teamUsers->firstWhere('id', $task->assigned_to);
            $assignedName = $assignedUser ? trim($assignedUser->first_name . ' ' . $assignedUser->last_name) : $task->assigned_to;
        }

        // Due date label
        $dueLabel   = '';
        $dueDateFmt = '';
        if ($task->due_date) {
            $dueDateFmt = $task->due_date->format('j M Y');
            $diff = (int) $today->diffInDays($task->due_date, false);
            if ($isCompleted) {
                $dueLabel = $dueDateFmt;
            } elseif ($diff < 0) {
                $dueLabel = abs($diff) . ' day' . (abs($diff) > 1 ? 's' : '') . ' overdue';
            } elseif ($diff === 0) {
                $dueLabel = 'Due today';
            } elseif ($diff === 1) {
                $dueLabel = 'Due tomorrow';
            } elseif ($diff <= 7) {
                $dueLabel = $diff . ' days left';
            } else {
                $dueLabel = $dueDateFmt;
            }
        }

        // Step counts
        $stepsTotal     = $task->steps ? $task->steps->count() : 0;
        $stepsCompleted = $task->steps ? $task->steps->where('is_completed', true)->count() : 0;
        $commentCount   = $task->comments ? $task->comments->count() : 0;
        $attachCount    = $task->attachments ? $task->attachments->count() : 0;

        // Progress from steps if available
        if ($stepsTotal > 0) {
            $progress = (int) round(($stepsCompleted / $stepsTotal) * 100);
        }

        // Status display
        $statusLabels = [
            'pending'     => 'Pending',
            'in_progress' => 'In Progress',
            'review'      => 'In Review',
            'completed'   => 'Completed',
            'on_hold'     => 'On Hold',
            'cancelled'   => 'Cancelled',
        ];
        $statusIcons = [
            'pending'     => 'fa-clock',
            'in_progress' => 'fa-spinner fa-pulse',
            'review'      => 'fa-search',
            'completed'   => 'fa-check-circle',
            'on_hold'     => 'fa-pause-circle',
            'cancelled'   => 'fa-ban',
        ];

        // Progress bar color
        $progressColor = '#3b82f6';
        if ($progress >= 100) $progressColor = '#22c55e';
        elseif ($progress >= 60) $progressColor = '#06b6d4';
        elseif ($progress >= 30) $progressColor = '#f59e0b';
    @endphp
    <div class="tcc-card sl-animate d4 {{ $isOverdue ? 'tcc-card-overdue' : '' }} {{ $isCompleted ? 'tcc-card-completed' : '' }}"
         data-cat="{{ $cat }}"
         data-status="{{ $task->task_status }}"
         data-priority="{{ $task->priority }}"
         data-overdue="{{ $isOverdue ? '1' : '0' }}"
         data-urgent="{{ $task->is_urgent ? '1' : '0' }}"
         data-search="{{ strtolower($task->title . ' ' . ($task->description ?? '') . ' ' . $assignedName) }}"
         style="--card-accent:{{ $catColor }};">

        {{-- Left accent bar --}}
        <div class="tcc-card-accent"></div>

        {{-- Priority indicator --}}
        <div class="tcc-card-priority-col">
            <span class="tcc-pri-dot tcc-pri-{{ $task->priority }}"></span>
        </div>

        {{-- Main content: category icon + title/desc + tags --}}
        <div class="tcc-card-main">
            <div class="tcc-card-cat-icon" style="background:{{ $catColor }}15; border-color:{{ $catColor }}30; color:{{ $catColor }};">
                <i class="fas {{ $catIcon }}"></i>
            </div>
            <div class="tcc-card-content">
                <a href="{{ route('nexcore.clients.show.tasks.show', [$client->id, $task->id]) }}" class="tcc-card-title">{{ $task->title }}</a>
                @if($task->description)
                    <p class="tcc-card-desc">{{ \Illuminate\Support\Str::limit(strip_tags($task->description), 100) }}</p>
                @endif
                <div class="tcc-card-tags">
                    <span class="tcc-tag tcc-tag-cat" style="--tag-color:{{ $catColor }};">
                        <i class="fas {{ $catIcon }}"></i> {{ $catLabel }}
                    </span>
                    <span class="tcc-tag tcc-tag-priority tcc-pri-tag-{{ $task->priority }}">
                        <span class="tcc-pri-dot-sm tcc-pri-{{ $task->priority }}"></span> {{ ucfirst($task->priority) }}
                    </span>
                    @if($task->is_urgent)
                    <span class="tcc-tag tcc-tag-urgent">
                        <i class="fas fa-fire"></i> Urgent
                    </span>
                    @endif
                </div>
            </div>
        </div>

        {{-- Status + Progress --}}
        <div class="tcc-card-status-col">
            <span class="tcc-status-badge tcc-st-{{ $task->task_status }}">
                <i class="fas {{ $statusIcons[$task->task_status] ?? 'fa-circle' }}"></i>
                {{ $statusLabels[$task->task_status] ?? ucfirst($task->task_status) }}
            </span>
            <div class="tcc-mini-progress" title="{{ $progress }}% complete">
                <div class="tcc-mini-progress-bar" style="width:{{ $progress }}%; background:{{ $progressColor }};"></div>
            </div>
            <span class="tcc-progress-text">{{ $progress }}%</span>
        </div>

        {{-- Due date + Assigned --}}
        <div class="tcc-card-due-col">
            @if($task->due_date)
            <span class="tcc-due-date {{ $isOverdue ? 'tcc-due-overdue' : ($isDueWeek ? 'tcc-due-soon' : '') }}">
                <i class="far fa-calendar-alt"></i> {{ $dueDateFmt }}
            </span>
            @if(!$isCompleted && ($isOverdue || $isDueWeek))
            <span class="tcc-due-label {{ $isOverdue ? 'tcc-due-red' : 'tcc-due-amber' }}">{{ $dueLabel }}</span>
            @endif
            @else
            <span class="tcc-due-date tcc-no-due">No due date</span>
            @endif
            @if($assignedName)
            <span class="tcc-assigned"><i class="fas fa-user-circle"></i> {{ $assignedName }}</span>
            @endif
        </div>

        {{-- Counts: steps/comments/attachments --}}
        <div class="tcc-card-counts-col">
            <span class="tcc-count-item" title="{{ $stepsCompleted }}/{{ $stepsTotal }} steps">
                <i class="fas fa-list-check"></i> {{ $stepsCompleted }}/{{ $stepsTotal }}
            </span>
            <span class="tcc-count-item" title="{{ $commentCount }} comments">
                <i class="fas fa-comment"></i> {{ $commentCount }}
            </span>
            <span class="tcc-count-item" title="{{ $attachCount }} attachments">
                <i class="fas fa-paperclip"></i> {{ $attachCount }}
            </span>
        </div>

        {{-- Actions --}}
        <div class="tcc-card-actions-col">
            <a href="{{ route('nexcore.clients.show.tasks.show', [$client->id, $task->id]) }}" class="tcc-act tcc-act-view" title="View Task">
                <i class="fas fa-eye"></i>
            </a>
            <a href="{{ route('nexcore.clients.show.tasks.edit', [$client->id, $task->id]) }}" class="tcc-act tcc-act-edit" title="Edit Task">
                <i class="fas fa-pen"></i>
            </a>
            <form method="POST" action="{{ route('nexcore.clients.show.tasks.destroy', [$client->id, $task->id]) }}" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this task?')">
                @csrf @method('DELETE')
                <button type="submit" class="tcc-act tcc-act-delete" title="Delete Task">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </form>
        </div>
    </div>
    @empty
    <div class="tcc-empty" id="tccEmpty">
        <div class="tcc-empty-icon"><i class="fas fa-bullseye"></i></div>
        <h3>No Tasks Found</h3>
        <p>Create your first task to get started. Organise by category, assign team members, set deadlines and track progress.</p>
        <a href="{{ route('nexcore.clients.show.tasks.create', $client->id) }}" class="neon-btn neon-btn-green" style="margin-top:20px;">
            <i class="fas fa-plus"></i> <span>Create First Task</span>
        </a>
    </div>
    @endforelse
</div>

{{-- No results state (hidden by default) --}}
<div class="tcc-empty" id="tccNoResults" style="display:none;">
    <div class="tcc-empty-icon" style="opacity:0.3;"><i class="fas fa-search"></i></div>
    <h3>No Matching Tasks</h3>
    <p>Try adjusting your filters or search terms.</p>
</div>

{{-- ══════════════════════════════════════════════════════════════════════ --}}
{{--  5. PAGINATION / SUMMARY                                              --}}
{{-- ══════════════════════════════════════════════════════════════════════ --}}
@if($tasks->count() > 0)
<div class="tcc-summary sl-animate d5">
    <span class="tcc-summary-text">Showing <strong id="tccVisibleCount">{{ $totalCount }}</strong> of <strong>{{ $totalCount }}</strong> tasks</span>
</div>
@endif

@endsection

@push('styles')
<style>
/* ═══════════════════════════════════════════════════════════════════════ */
/*  TASK COMMAND CENTRE - ENHANCED PREMIUM DESIGN                        */
/* ═══════════════════════════════════════════════════════════════════════ */

/* ── Hero Header ── */
.tcc-hero {
    display:flex; align-items:center; justify-content:space-between; gap:20px;
    padding:22px 28px; margin-bottom:22px;
    background:linear-gradient(135deg, rgba(16,185,129,0.06), rgba(59,130,246,0.04), rgba(139,92,246,0.03));
    border:1px solid rgba(255,255,255,0.06);
    border-radius:16px;
    position:relative; overflow:hidden;
    backdrop-filter:blur(12px);
    -webkit-backdrop-filter:blur(12px);
}
.tcc-hero::before {
    content:''; position:absolute; top:-50%; right:-15%; width:350px; height:350px;
    background:radial-gradient(circle, rgba(16,185,129,0.08), transparent 70%);
    pointer-events:none;
}
.tcc-hero::after {
    content:''; position:absolute; bottom:-40%; left:-10%; width:250px; height:250px;
    background:radial-gradient(circle, rgba(59,130,246,0.06), transparent 70%);
    pointer-events:none;
}
.tcc-hero-left { display:flex; align-items:center; gap:18px; position:relative; z-index:1; }
.tcc-hero-icon {
    width:56px; height:56px; border-radius:16px;
    background:linear-gradient(135deg, rgba(16,185,129,0.2), rgba(59,130,246,0.15));
    border:1px solid rgba(16,185,129,0.3);
    display:flex; align-items:center; justify-content:center;
    font-size:22px; color:#10b981; position:relative;
}
.tcc-hero-pulse {
    position:absolute; inset:-5px; border-radius:20px;
    border:2px solid rgba(16,185,129,0.3);
    animation:tccPulse 2.5s ease-in-out infinite;
}
.tcc-hero-title { margin:0; font-size:24px; font-weight:800; color:#fff; letter-spacing:0.5px; font-family:'Montserrat',sans-serif; }
.tcc-hero-sub { margin:5px 0 0; font-size:13px; color:#a8b5c8; font-weight:500; }
.tcc-hero-dot { display:inline-block; width:4px; height:4px; border-radius:50%; background:rgba(255,255,255,0.25); vertical-align:middle; margin:0 8px; }
.tcc-hero-right { display:flex; align-items:center; gap:14px; position:relative; z-index:1; }

/* View toggle buttons */
.tcc-view-toggles {
    display:flex; border-radius:10px; overflow:hidden;
    border:1px solid rgba(255,255,255,0.08);
    background:rgba(255,255,255,0.02);
}
.tcc-view-btn {
    width:40px; height:38px; display:flex; align-items:center; justify-content:center;
    font-size:14px; color:rgba(255,255,255,0.35); text-decoration:none;
    transition:all 0.25s ease; border-right:1px solid rgba(255,255,255,0.06);
}
.tcc-view-btn:last-child { border-right:none; }
.tcc-view-btn:hover { color:rgba(255,255,255,0.7); background:rgba(255,255,255,0.04); }
.tcc-view-active {
    color:#10b981 !important; background:rgba(16,185,129,0.1) !important;
    box-shadow:inset 0 -2px 0 #10b981;
}

/* ── Stats Row ── */
.tcc-stats { display:grid; grid-template-columns:repeat(6, 1fr); gap:12px; margin-bottom:22px; }
.tcc-stat {
    padding:20px 16px; border-radius:14px;
    background:rgba(17,21,32,0.8);
    border:1px solid rgba(255,255,255,0.06);
    text-align:center; position:relative; overflow:hidden;
    transition:all 0.3s ease;
    backdrop-filter:blur(12px);
    -webkit-backdrop-filter:blur(12px);
}
.tcc-stat::after {
    content:''; position:absolute; bottom:0; left:0; right:0; height:3px;
    background:var(--stat-color); opacity:0.6;
    border-radius:0 0 14px 14px;
}
.tcc-stat:hover { background:rgba(17,21,32,0.95); transform:translateY(-3px); box-shadow:0 8px 24px rgba(0,0,0,0.2); }
.tcc-stat-icon { font-size:18px; color:var(--stat-color); margin-bottom:10px; opacity:0.85; }
.tcc-stat-num { font-size:30px; font-weight:800; color:#fff; font-family:'Montserrat',sans-serif; line-height:1; }
.tcc-stat-label { font-size:10px; font-weight:700; color:#a8b5c8; text-transform:uppercase; letter-spacing:1px; margin-top:8px; }
.tcc-stat-alert {
    border-color:rgba(239,68,68,0.3) !important;
    background:rgba(239,68,68,0.04);
    animation:tccAlertPulse 2s ease-in-out infinite;
}
.tcc-stat-alert .tcc-stat-num { color:#ef4444; }
.tcc-stat-pulse-ring {
    position:absolute; top:10px; right:10px; width:8px; height:8px;
    border-radius:50%; background:#ef4444;
    animation:tccStatPulse 1.5s ease-in-out infinite;
}
.tcc-stat-urgent .tcc-stat-num { color:#8b5cf6; }

/* ── Filter Bar ── */
.tcc-filters {
    padding:18px 22px; border-radius:14px;
    background:rgba(17,21,32,0.8);
    border:1px solid rgba(255,255,255,0.06);
    margin-bottom:22px;
    display:flex; flex-direction:column; gap:14px;
    backdrop-filter:blur(12px);
    -webkit-backdrop-filter:blur(12px);
}
.tcc-filter-row { display:flex; align-items:center; gap:12px; }
.tcc-filter-label {
    font-size:11px; font-weight:700; color:rgba(255,255,255,0.35);
    text-transform:uppercase; letter-spacing:0.5px; min-width:76px;
    display:flex; align-items:center; gap:6px;
}
.tcc-filter-label i { font-size:10px; opacity:0.6; }
.tcc-pills { display:flex; flex-wrap:wrap; gap:6px; }
.tcc-pill {
    display:inline-flex; align-items:center; gap:6px;
    padding:6px 14px; border-radius:20px;
    background:rgba(255,255,255,0.03);
    border:1px solid rgba(255,255,255,0.08);
    color:rgba(255,255,255,0.5); font-size:12px; font-weight:600;
    cursor:pointer; transition:all 0.25s ease;
    font-family:'Poppins','Montserrat',sans-serif;
}
.tcc-pill:hover { background:rgba(255,255,255,0.06); color:rgba(255,255,255,0.8); border-color:rgba(255,255,255,0.15); }
.tcc-pill.active {
    background:rgba(16,185,129,0.12); border-color:rgba(16,185,129,0.3);
    color:#10b981;
}
.tcc-pill-dot { width:7px; height:7px; border-radius:50%; flex-shrink:0; }
.tcc-pill-count {
    font-size:10px; font-weight:700; font-family:'Courier New',monospace;
    background:rgba(255,255,255,0.06); padding:1px 6px; border-radius:8px;
    min-width:18px; text-align:center;
}
.tcc-pill.active .tcc-pill-count { background:rgba(16,185,129,0.2); }

/* Priority filter indicators */
.tcc-priority-ind {
    display:inline-block; width:8px; height:8px; border-radius:50%;
}
.tcc-pri-urgent { background:#ef4444; animation:tccDotPulse 1.2s ease-in-out infinite; }
.tcc-pri-high { background:#f59e0b; }
.tcc-pri-medium { background:#3b82f6; }
.tcc-pri-low { background:#22c55e; }

/* Search */
.tcc-search {
    flex:1; padding:9px 16px; border-radius:10px;
    background:rgba(255,255,255,0.03);
    border:1px solid rgba(255,255,255,0.08);
    color:#fff; font-size:13px; font-family:'Poppins','Montserrat',sans-serif;
    outline:none; transition:all 0.25s ease;
}
.tcc-search:focus { border-color:rgba(16,185,129,0.4); background:rgba(255,255,255,0.05); box-shadow:0 0 0 3px rgba(16,185,129,0.08); }
.tcc-search::placeholder { color:rgba(255,255,255,0.25); }

/* ═══════════════════════════════════════════════════════════════════════ */
/*  TASK CARDS - HORIZONTAL PREMIUM LAYOUT                               */
/* ═══════════════════════════════════════════════════════════════════════ */
.tcc-list { display:flex; flex-direction:column; gap:10px; }

.tcc-card {
    display:flex; align-items:stretch; border-radius:12px;
    background:rgba(17,21,32,0.8);
    border:1px solid rgba(255,255,255,0.06);
    overflow:hidden; transition:all 0.35s cubic-bezier(0.4,0,0.2,1);
    position:relative;
    backdrop-filter:blur(12px);
    -webkit-backdrop-filter:blur(12px);
}
.tcc-card:hover {
    background:rgba(17,21,32,0.95);
    border-color:rgba(255,255,255,0.12);
    transform:translateY(-2px);
    box-shadow:0 8px 32px rgba(0,0,0,0.25), 0 0 0 1px rgba(255,255,255,0.05);
}

/* Left accent bar */
.tcc-card-accent {
    width:4px; min-width:4px; flex-shrink:0;
    background:linear-gradient(180deg, var(--card-accent), color-mix(in srgb, var(--card-accent) 50%, transparent));
}

/* Priority column */
.tcc-card-priority-col {
    width:36px; min-width:36px; display:flex; align-items:center; justify-content:center;
    border-right:1px solid rgba(255,255,255,0.04);
}
.tcc-pri-dot {
    width:10px; height:10px; border-radius:50%; display:block;
}
.tcc-pri-dot.tcc-pri-urgent { background:#ef4444; box-shadow:0 0 8px rgba(239,68,68,0.5); animation:tccDotPulse 1.2s ease-in-out infinite; }
.tcc-pri-dot.tcc-pri-high { background:#f59e0b; box-shadow:0 0 6px rgba(245,158,11,0.3); }
.tcc-pri-dot.tcc-pri-medium { background:#3b82f6; box-shadow:0 0 6px rgba(59,130,246,0.3); }
.tcc-pri-dot.tcc-pri-low { background:#22c55e; box-shadow:0 0 6px rgba(34,197,94,0.2); }

/* Main content area */
.tcc-card-main {
    flex:1; min-width:0; display:flex; align-items:center; gap:14px;
    padding:16px 18px;
    border-right:1px solid rgba(255,255,255,0.04);
}
.tcc-card-cat-icon {
    width:42px; height:42px; min-width:42px; border-radius:12px;
    display:flex; align-items:center; justify-content:center;
    font-size:16px; border:1px solid;
    transition:all 0.3s ease;
}
.tcc-card:hover .tcc-card-cat-icon { transform:scale(1.08); }
.tcc-card-content { flex:1; min-width:0; }
.tcc-card-title {
    display:block; margin:0; font-size:15px; font-weight:700; color:#fff;
    line-height:1.3; text-decoration:none; transition:color 0.2s ease;
    white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
}
.tcc-card-title:hover { color:#10b981; }
.tcc-card-desc {
    margin:3px 0 0; font-size:12px; color:#a8b5c8; line-height:1.4;
    white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
    opacity:0.7;
}
.tcc-card-tags { display:flex; flex-wrap:wrap; gap:6px; margin-top:8px; }

/* Tags */
.tcc-tag {
    display:inline-flex; align-items:center; gap:4px;
    padding:3px 9px; border-radius:6px;
    font-size:10px; font-weight:600;
    font-family:'Poppins','Montserrat',sans-serif;
}
.tcc-tag i { font-size:9px; }
.tcc-tag-cat {
    background:color-mix(in srgb, var(--tag-color) 12%, transparent);
    color:var(--tag-color);
    border:1px solid color-mix(in srgb, var(--tag-color) 25%, transparent);
}
.tcc-tag-priority { border:1px solid rgba(255,255,255,0.08); }
.tcc-pri-dot-sm { width:5px; height:5px; border-radius:50%; display:inline-block; }
.tcc-pri-tag-urgent { color:#ef4444; background:rgba(239,68,68,0.08); border-color:rgba(239,68,68,0.2); }
.tcc-pri-tag-high { color:#f59e0b; background:rgba(245,158,11,0.08); border-color:rgba(245,158,11,0.2); }
.tcc-pri-tag-medium { color:#3b82f6; background:rgba(59,130,246,0.08); border-color:rgba(59,130,246,0.2); }
.tcc-pri-tag-low { color:#a8b5c8; background:rgba(255,255,255,0.03); border-color:rgba(255,255,255,0.08); }
.tcc-tag-urgent {
    color:#ef4444; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.25);
    animation:tccUrgentGlow 2s ease-in-out infinite;
}

/* Status + progress column */
.tcc-card-status-col {
    width:140px; min-width:140px; display:flex; flex-direction:column; align-items:center; justify-content:center;
    padding:12px 14px; gap:8px;
    border-right:1px solid rgba(255,255,255,0.04);
}
.tcc-status-badge {
    display:inline-flex; align-items:center; gap:5px;
    padding:5px 12px; border-radius:8px;
    font-size:11px; font-weight:700;
    font-family:'Poppins','Montserrat',sans-serif;
    white-space:nowrap;
}
.tcc-status-badge i { font-size:10px; }
.tcc-st-pending { color:#f59e0b; background:rgba(245,158,11,0.1); border:1px solid rgba(245,158,11,0.2); }
.tcc-st-in_progress { color:#3b82f6; background:rgba(59,130,246,0.1); border:1px solid rgba(59,130,246,0.2); }
.tcc-st-review { color:#8b5cf6; background:rgba(139,92,246,0.1); border:1px solid rgba(139,92,246,0.2); }
.tcc-st-completed { color:#22c55e; background:rgba(34,197,94,0.1); border:1px solid rgba(34,197,94,0.2); }
.tcc-st-on_hold { color:#94a3b8; background:rgba(148,163,184,0.08); border:1px solid rgba(148,163,184,0.15); }
.tcc-st-cancelled { color:#ef4444; background:rgba(239,68,68,0.08); border:1px solid rgba(239,68,68,0.15); }

/* Mini progress bar */
.tcc-mini-progress {
    width:100%; height:4px; border-radius:4px;
    background:rgba(255,255,255,0.06); overflow:hidden;
}
.tcc-mini-progress-bar {
    height:100%; border-radius:4px;
    transition:width 0.5s ease;
    position:relative;
}
.tcc-mini-progress-bar::after {
    content:''; position:absolute; inset:0;
    background:linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
    animation:tccShimmer 2s ease-in-out infinite;
}
.tcc-progress-text {
    font-size:10px; font-weight:700; color:rgba(255,255,255,0.35);
    font-family:'Courier New',monospace; letter-spacing:0.5px;
}

/* Due date + Assigned column */
.tcc-card-due-col {
    width:150px; min-width:150px; display:flex; flex-direction:column; align-items:flex-start; justify-content:center;
    padding:12px 14px; gap:5px;
    border-right:1px solid rgba(255,255,255,0.04);
}
.tcc-due-date {
    font-size:12px; font-weight:600; color:#d4dce8;
    display:flex; align-items:center; gap:6px;
    font-family:'Courier New',monospace;
}
.tcc-due-date i { font-size:11px; opacity:0.5; }
.tcc-due-overdue { color:#ef4444 !important; }
.tcc-due-overdue i { opacity:1; color:#ef4444; }
.tcc-due-soon { color:#f59e0b !important; }
.tcc-due-soon i { opacity:1; color:#f59e0b; }
.tcc-no-due { color:rgba(255,255,255,0.2) !important; font-style:italic; font-family:'Poppins','Montserrat',sans-serif; }
.tcc-due-label {
    font-size:10px; font-weight:700; letter-spacing:0.3px;
    padding:2px 8px; border-radius:4px;
}
.tcc-due-red { color:#ef4444; background:rgba(239,68,68,0.1); }
.tcc-due-amber { color:#f59e0b; background:rgba(245,158,11,0.1); }
.tcc-assigned {
    font-size:11px; color:#a8b5c8; display:flex; align-items:center; gap:5px;
    margin-top:2px;
}
.tcc-assigned i { font-size:12px; opacity:0.5; }

/* Counts column */
.tcc-card-counts-col {
    width:90px; min-width:90px; display:flex; flex-direction:column; align-items:center; justify-content:center;
    padding:12px 10px; gap:6px;
    border-right:1px solid rgba(255,255,255,0.04);
}
.tcc-count-item {
    display:flex; align-items:center; gap:5px;
    font-size:11px; color:rgba(255,255,255,0.35); font-weight:600;
    font-family:'Courier New',monospace;
}
.tcc-count-item i { font-size:10px; opacity:0.5; width:14px; text-align:center; }

/* Actions column */
.tcc-card-actions-col {
    width:110px; min-width:110px; display:flex; align-items:center; justify-content:center;
    gap:6px; padding:12px 10px;
    opacity:0; transition:opacity 0.3s ease;
}
.tcc-card:hover .tcc-card-actions-col { opacity:1; }
.tcc-act {
    width:32px; height:32px; border-radius:8px;
    display:flex; align-items:center; justify-content:center;
    font-size:12px; cursor:pointer; transition:all 0.25s ease;
    text-decoration:none; border:none;
}
.tcc-act-view { background:rgba(6,182,212,0.08); color:#06b6d4; }
.tcc-act-view:hover { background:rgba(6,182,212,0.2); transform:scale(1.1); box-shadow:0 0 12px rgba(6,182,212,0.2); }
.tcc-act-edit { background:rgba(59,130,246,0.08); color:#3b82f6; }
.tcc-act-edit:hover { background:rgba(59,130,246,0.2); transform:scale(1.1); box-shadow:0 0 12px rgba(59,130,246,0.2); }
.tcc-act-delete { background:rgba(239,68,68,0.08); color:#ef4444; }
.tcc-act-delete:hover { background:rgba(239,68,68,0.2); transform:scale(1.1); box-shadow:0 0 12px rgba(239,68,68,0.2); }

/* ── Special Card States ── */
.tcc-card-overdue {
    border-color:rgba(239,68,68,0.2) !important;
    box-shadow:inset 0 0 40px rgba(239,68,68,0.03), 0 0 20px rgba(239,68,68,0.05);
}
.tcc-card-overdue:hover { border-color:rgba(239,68,68,0.35) !important; box-shadow:0 8px 32px rgba(239,68,68,0.1); }
.tcc-card-overdue .tcc-card-accent { background:linear-gradient(180deg, #ef4444, #dc2626) !important; }

.tcc-card-completed {
    opacity:0.6;
}
.tcc-card-completed:hover { opacity:0.85; }
.tcc-card-completed .tcc-card-title { text-decoration:line-through; text-decoration-color:rgba(255,255,255,0.2); }

/* ── Empty State ── */
.tcc-empty {
    text-align:center; padding:70px 24px;
    background:rgba(17,21,32,0.5);
    border:1px dashed rgba(255,255,255,0.08);
    border-radius:16px;
}
.tcc-empty-icon {
    font-size:54px; color:rgba(255,255,255,0.06); margin-bottom:24px;
    position:relative; display:inline-block;
}
.tcc-empty h3 { margin:0; font-size:20px; font-weight:700; color:rgba(255,255,255,0.5); font-family:'Montserrat',sans-serif; }
.tcc-empty p { margin:10px auto 0; font-size:13px; color:rgba(255,255,255,0.3); max-width:420px; line-height:1.7; }

/* ── Summary ── */
.tcc-summary {
    margin-top:16px; padding:12px 20px; border-radius:10px;
    background:rgba(17,21,32,0.5);
    border:1px solid rgba(255,255,255,0.04);
    text-align:center;
}
.tcc-summary-text { font-size:12px; color:#a8b5c8; font-weight:500; }
.tcc-summary-text strong { color:#d4dce8; font-weight:700; }

/* ── Hidden ── */
.tcc-card-hidden { display:none !important; }

/* ═══════════════════════════════════════════════════════════════════════ */
/*  ANIMATIONS                                                           */
/* ═══════════════════════════════════════════════════════════════════════ */
@@keyframes tccPulse {
    0%, 100% { opacity:0.5; transform:scale(1); }
    50% { opacity:0; transform:scale(1.18); }
}
@@keyframes tccStatPulse {
    0%, 100% { opacity:1; transform:scale(1); }
    50% { opacity:0.4; transform:scale(1.6); }
}
@@keyframes tccDotPulse {
    0%, 100% { opacity:1; }
    50% { opacity:0.3; }
}
@@keyframes tccAlertPulse {
    0%, 100% { border-color:rgba(239,68,68,0.3); box-shadow:0 0 0 0 rgba(239,68,68,0); }
    50% { border-color:rgba(239,68,68,0.5); box-shadow:0 0 20px rgba(239,68,68,0.08); }
}
@@keyframes tccShimmer {
    0% { transform:translateX(-100%); }
    100% { transform:translateX(200%); }
}
@@keyframes tccUrgentGlow {
    0%, 100% { box-shadow:0 0 0 0 rgba(239,68,68,0); }
    50% { box-shadow:0 0 8px rgba(239,68,68,0.2); }
}

/* ═══════════════════════════════════════════════════════════════════════ */
/*  RESPONSIVE                                                           */
/* ═══════════════════════════════════════════════════════════════════════ */
@@media (max-width: 1400px) {
    .tcc-card-counts-col { width:70px; min-width:70px; }
    .tcc-card-actions-col { width:90px; min-width:90px; opacity:1; }
}

@@media (max-width: 1200px) {
    .tcc-stats { grid-template-columns:repeat(3, 1fr); }
    .tcc-card { flex-wrap:wrap; }
    .tcc-card-accent { display:none; }
    .tcc-card-priority-col { width:30px; min-width:30px; }
    .tcc-card-main { flex:1 1 100%; min-width:200px; border-right:none; border-bottom:1px solid rgba(255,255,255,0.04); }
    .tcc-card-status-col { width:auto; flex:1; min-width:100px; border-right:1px solid rgba(255,255,255,0.04); padding:10px; }
    .tcc-card-due-col { width:auto; flex:1; min-width:120px; padding:10px; }
    .tcc-card-counts-col { width:auto; min-width:70px; padding:10px; }
    .tcc-card-actions-col { width:auto; min-width:80px; opacity:1; padding:10px; }
}

@@media (max-width: 900px) {
    .tcc-stats { grid-template-columns:repeat(2, 1fr); }
    .tcc-card-status-col, .tcc-card-due-col, .tcc-card-counts-col, .tcc-card-actions-col {
        border-right:none;
    }
}

@@media (max-width: 768px) {
    .tcc-hero { flex-direction:column; align-items:flex-start; gap:14px; padding:18px 20px; }
    .tcc-hero-right { width:100%; justify-content:space-between; }
    .tcc-stats { grid-template-columns:repeat(2, 1fr); }
    .tcc-filter-row { flex-direction:column; align-items:flex-start; gap:8px; }
    .tcc-card {
        flex-direction:column;
    }
    .tcc-card-priority-col { display:none; }
    .tcc-card-main { border-right:none; }
    .tcc-card-status-col, .tcc-card-due-col {
        width:100%; min-width:100%; flex-direction:row; align-items:center; gap:10px;
        border-right:none; border-bottom:1px solid rgba(255,255,255,0.04);
    }
    .tcc-card-counts-col {
        width:100%; min-width:100%; flex-direction:row; gap:16px;
        border-right:none;
    }
    .tcc-card-actions-col {
        width:100%; min-width:100%; opacity:1; justify-content:flex-end;
    }
    .tcc-card-title { white-space:normal; }
}

@@media (max-width: 480px) {
    .tcc-stats { grid-template-columns:1fr 1fr; }
    .tcc-stat-num { font-size:24px; }
    .tcc-hero-title { font-size:20px; }
}
</style>
@endpush

@push('scripts')
<script>
(function() {
    /* ── Filter State ── */
    var _catFilter      = 'all';
    var _statusFilter   = 'all';
    var _priorityFilter = 'all';

    /* ── Category Filter ── */
    window.tccFilterCat = function(cat, btn) {
        _catFilter = cat;
        var pills = document.querySelectorAll('#tccCatPills .tcc-pill');
        for (var i = 0; i < pills.length; i++) pills[i].classList.remove('active');
        btn.classList.add('active');
        tccApplyFilters();
    };

    /* ── Status Filter ── */
    window.tccFilterStatus = function(status, btn) {
        _statusFilter = status;
        var pills = document.querySelectorAll('#tccStatusPills .tcc-pill');
        for (var i = 0; i < pills.length; i++) pills[i].classList.remove('active');
        btn.classList.add('active');
        tccApplyFilters();
    };

    /* ── Priority Filter ── */
    window.tccFilterPriority = function(priority, btn) {
        _priorityFilter = priority;
        var pills = document.querySelectorAll('#tccPriorityPills .tcc-pill');
        for (var i = 0; i < pills.length; i++) pills[i].classList.remove('active');
        btn.classList.add('active');
        tccApplyFilters();
    };

    /* ── Apply All Filters (AND logic) ── */
    window.tccApplyFilters = function() {
        var cards = document.querySelectorAll('#tccTaskList .tcc-card');
        var searchVal = (document.getElementById('tccSearch').value || '').toLowerCase().trim();
        var visibleCount = 0;
        var totalCards = cards.length;

        for (var i = 0; i < cards.length; i++) {
            var card = cards[i];
            var cardCat      = card.getAttribute('data-cat') || '';
            var cardStatus   = card.getAttribute('data-status') || '';
            var cardPriority = card.getAttribute('data-priority') || '';
            var cardOverdue  = card.getAttribute('data-overdue') === '1';
            var cardSearch   = card.getAttribute('data-search') || '';

            /* Category match */
            var matchCat = (_catFilter === 'all' || cardCat === _catFilter);

            /* Status match - special handling for "overdue" virtual status */
            var matchStatus = true;
            if (_statusFilter === 'overdue') {
                matchStatus = cardOverdue;
            } else if (_statusFilter !== 'all') {
                matchStatus = (cardStatus === _statusFilter);
            }

            /* Priority match */
            var matchPriority = (_priorityFilter === 'all' || cardPriority === _priorityFilter);

            /* Search match */
            var matchSearch = (!searchVal || cardSearch.indexOf(searchVal) !== -1);

            if (matchCat && matchStatus && matchPriority && matchSearch) {
                card.classList.remove('tcc-card-hidden');
                visibleCount++;
            } else {
                card.classList.add('tcc-card-hidden');
            }
        }

        /* Update visible count */
        updateVisibleCount(visibleCount, totalCards);

        /* Toggle no-results state */
        var noResults = document.getElementById('tccNoResults');
        var emptyState = document.getElementById('tccEmpty');
        if (noResults) {
            noResults.style.display = (visibleCount === 0 && totalCards > 0) ? 'block' : 'none';
        }
    };

    /* ── Update Visible Count ── */
    function updateVisibleCount(visible, total) {
        var el = document.getElementById('tccVisibleCount');
        if (el) el.textContent = visible;
    }

    /* ── Delete Confirmation ── */
    document.querySelectorAll('.tcc-act-delete').forEach(function(btn) {
        var form = btn.closest('form');
        if (form) {
            form.addEventListener('submit', function(e) {
                if (!confirm('Are you sure you want to delete this task?')) {
                    e.preventDefault();
                }
            });
        }
    });
})();
</script>
@endpush
