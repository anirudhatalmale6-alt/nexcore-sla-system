@extends('nexcore_client_manager::layouts.nerve-centre')

@section('sidebar')
    @include('nexcore_client_manager::partials.nerve-centre-sidebar')
@endsection

@section('title', (isset($task) ? 'Edit' : 'New') . ' Task - ' . $client->company_name)
@section('topbar_module', 'Task Manager')
@section('topbar_page', isset($task) ? 'Edit Task' : 'New Task')

@section('content')
@php $task = $task ?? null; @endphp

{{-- Page Header --}}
<div class="tf-hero sl-animate d1">
    <div class="tf-hero-left">
        <div class="tf-hero-icon">
            <i class="fas {{ isset($task) ? 'fa-pen-to-square' : 'fa-plus-circle' }}"></i>
        </div>
        <div>
            <h1 class="tf-hero-title">{{ isset($task) ? 'Edit Task' : 'New Task' }}</h1>
            <p class="tf-hero-sub">{{ $client->company_name }}</p>
        </div>
    </div>
    <div class="tf-hero-right">
        <a href="{{ route('nexcore.clients.show.tasks', $client->id) }}" class="neon-btn neon-btn-ghost"><i class="fas fa-arrow-left"></i> Back to Tasks</a>
    </div>
</div>

{{-- Validation Errors --}}
@if($errors->any())
<div class="tf-errors sl-animate d2">
    <div class="tf-errors-icon"><i class="fas fa-exclamation-triangle"></i></div>
    <div class="tf-errors-content">
        <div class="tf-errors-title">Please correct the following errors:</div>
        <ul class="tf-errors-list">
            @foreach($errors->all() as $error) <li>{{ $error }}</li> @endforeach
        </ul>
    </div>
</div>
@endif

<form method="POST"
      action="{{ isset($task) ? route('nexcore.clients.show.tasks.update', [$client->id, $task->id]) : route('nexcore.clients.show.tasks.store', $client->id) }}"
      id="tfTaskForm">
    @csrf
    @if(isset($task)) @method('PUT') @endif

    {{-- CARD 1: Task Details --}}
    <div class="tf-card sl-animate d2">
        <div class="tf-card-header">
            <div class="tf-card-icon" style="--ci-color:#d97706;">
                <i class="fas fa-tasks"></i>
            </div>
            <div class="tf-card-label">Task Details</div>
        </div>
        <div class="tf-card-body">
            {{-- Title --}}
            <div class="tf-row">
                <div class="tf-field tf-field-full">
                    <label class="tf-label">Title <span class="tf-req">*</span></label>
                    <input type="text" name="title" class="tf-input" value="{{ old('title', $task?->title ?? '') }}" required placeholder="Enter task title" autocomplete="off">
                </div>
            </div>

            {{-- Description --}}
            <div class="tf-row">
                <div class="tf-field tf-field-full">
                    <label class="tf-label">Description</label>
                    <textarea name="description" class="tf-textarea" rows="4" placeholder="Optional description of the task...">{{ old('description', $task?->description ?? '') }}</textarea>
                </div>
            </div>

            {{-- Category + Priority --}}
            <div class="tf-row tf-row-2">
                <div class="tf-field">
                    <label class="tf-label">Category <span class="tf-req">*</span></label>
                    <select name="category" class="tf-select2" required>
                        <option value="">-- Select Category --</option>
                        @foreach($categories as $key => $label)
                            <option value="{{ $key }}" {{ old('category', $task?->category ?? 'general') == $key ? 'selected' : '' }}>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="tf-field">
                    <label class="tf-label">Priority <span class="tf-req">*</span></label>
                    <select name="priority" class="tf-select2" required>
                        <option value="">-- Select Priority --</option>
                        @foreach($priorities as $key => $label)
                            <option value="{{ $key }}" {{ old('priority', $task?->priority ?? 'medium') == $key ? 'selected' : '' }}>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            {{-- Status + Assigned To --}}
            <div class="tf-row tf-row-2">
                <div class="tf-field">
                    <label class="tf-label">Status <span class="tf-req">*</span></label>
                    <select name="task_status" class="tf-select2" id="tfStatusSelect" required>
                        <option value="">-- Select Status --</option>
                        @foreach($taskStatuses as $key => $label)
                            <option value="{{ $key }}" {{ old('task_status', $task?->task_status ?? 'pending') == $key ? 'selected' : '' }}>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="tf-field">
                    <label class="tf-label">Assigned To</label>
                    <select name="assigned_to" class="tf-select2-tags" id="tfAssignedTo">
                        <option value="">-- Select or type --</option>
                        @foreach($teamUsers as $user)
                            <option value="{{ $user->first_name . ' ' . $user->last_name }}" {{ old('assigned_to', $task?->assigned_to ?? '') == trim($user->first_name . ' ' . $user->last_name) ? 'selected' : '' }}>{{ $user->first_name }} {{ $user->last_name }}</option>
                        @endforeach
                        @if(isset($task) && $task->assigned_to && !$teamUsers->contains(function($u) use ($task) { return trim($u->first_name . ' ' . $u->last_name) === $task->assigned_to; }))
                            <option value="{{ $task->assigned_to }}" selected>{{ $task->assigned_to }}</option>
                        @endif
                    </select>
                </div>
            </div>

            {{-- Color Label + Is Urgent --}}
            <div class="tf-row tf-row-2">
                <div class="tf-field">
                    <label class="tf-label">Color Label</label>
                    <div class="tf-color-picker">
                        @php
                            $presetColors = ['#ef4444', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6', '#ec4899'];
                            $currentColor = old('color_label', $task?->color_label ?? '');
                        @endphp
                        @foreach($presetColors as $pc)
                            <label class="tf-color-swatch {{ $currentColor === $pc ? 'tf-color-active' : '' }}" style="--swatch:{{ $pc }};">
                                <input type="radio" name="color_label" value="{{ $pc }}" {{ $currentColor === $pc ? 'checked' : '' }}>
                                <span class="tf-color-check"><i class="fas fa-check"></i></span>
                            </label>
                        @endforeach
                        <label class="tf-color-swatch tf-color-none {{ !$currentColor ? 'tf-color-active' : '' }}">
                            <input type="radio" name="color_label" value="" {{ !$currentColor ? 'checked' : '' }}>
                            <span class="tf-color-check"><i class="fas fa-ban"></i></span>
                        </label>
                    </div>
                </div>
                <div class="tf-field">
                    <label class="tf-label">Urgent</label>
                    <div class="tf-toggle-wrap">
                        <label class="tf-toggle">
                            <input type="hidden" name="is_urgent" value="0">
                            <input type="checkbox" name="is_urgent" value="1" {{ old('is_urgent', $task?->is_urgent ?? false) ? 'checked' : '' }}>
                            <span class="tf-toggle-slider"></span>
                        </label>
                        <span class="tf-toggle-label">Mark as urgent task</span>
                    </div>
                </div>
            </div>

            {{-- Parent Task --}}
            <div class="tf-row">
                <div class="tf-field tf-field-full">
                    <label class="tf-label">Parent Task <span class="tf-opt">(optional, for sub-tasks)</span></label>
                    <select name="parent_task_id" class="tf-select2">
                        <option value="">-- No Parent (Top-level Task) --</option>
                        @php
                            $parentCandidates = \Modules\NexcoreClientManager\Models\NexcoreClientTask::where('client_id', $client->id)
                                ->when($task, function($q) use ($task) { return $q->where('id', '!=', $task->id); })
                                ->orderBy('title')
                                ->get(['id', 'title']);
                        @endphp
                        @foreach($parentCandidates as $pc)
                            <option value="{{ $pc->id }}" {{ old('parent_task_id', $task?->parent_task_id ?? '') == $pc->id ? 'selected' : '' }}>{{ $pc->title }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
        </div>
    </div>

    {{-- CARD 2: Schedule & Time --}}
    <div class="tf-card sl-animate d3">
        <div class="tf-card-header">
            <div class="tf-card-icon" style="--ci-color:#06b6d4;">
                <i class="fas fa-calendar-clock"></i>
            </div>
            <div class="tf-card-label">Schedule & Time</div>
        </div>
        <div class="tf-card-body">
            <div class="tf-row tf-row-2">
                <div class="tf-field">
                    <label class="tf-label">Start Date</label>
                    <input type="text" name="start_date" class="tf-input tf-datepicker" value="{{ old('start_date', isset($task) && $task->start_date ? $task->start_date->format('Y-m-d') : '') }}" placeholder="Select date..." readonly>
                </div>
                <div class="tf-field">
                    <label class="tf-label">Due Date</label>
                    <input type="text" name="due_date" class="tf-input tf-datepicker" value="{{ old('due_date', isset($task) && $task->due_date ? $task->due_date->format('Y-m-d') : '') }}" placeholder="Select date..." readonly>
                </div>
            </div>
            <div class="tf-row tf-row-2">
                <div class="tf-field">
                    <label class="tf-label">Completed Date</label>
                    <input type="text" name="completed_date" class="tf-input tf-datepicker" id="tfCompletedDate" value="{{ old('completed_date', isset($task) && $task->completed_date ? $task->completed_date->format('Y-m-d') : '') }}" placeholder="Select date..." readonly {{ (!isset($task) || (isset($task) && $task->task_status !== 'completed')) ? 'disabled' : '' }}>
                    <div class="tf-field-hint" id="tfCompletedHint" style="{{ (!$task || ($task && $task->task_status !== 'completed')) ? '' : 'display:none;' }}">
                        <i class="fas fa-info-circle"></i> Enabled when status is "Completed"
                    </div>
                </div>
                <div class="tf-field">
                    <label class="tf-label">Estimated Hours</label>
                    <input type="number" name="estimated_hours" class="tf-input" value="{{ old('estimated_hours', $task?->estimated_hours ?? '') }}" placeholder="e.g. 4.5" step="0.5" min="0">
                </div>
            </div>
        </div>
    </div>

    {{-- CARD 3: Notes --}}
    <div class="tf-card sl-animate d4">
        <div class="tf-card-header">
            <div class="tf-card-icon" style="--ci-color:#8b5cf6;">
                <i class="fas fa-sticky-note"></i>
            </div>
            <div class="tf-card-label">Notes</div>
        </div>
        <div class="tf-card-body">
            <div class="tf-row">
                <div class="tf-field tf-field-full">
                    <label class="tf-label">Internal Notes</label>
                    <textarea name="notes" class="tf-textarea" rows="4" placeholder="Optional internal notes, reminders, or reference information...">{{ old('notes', $task?->notes ?? '') }}</textarea>
                </div>
            </div>
        </div>
    </div>

    {{-- Submit --}}
    <div class="tf-actions sl-animate d5">
        <button type="submit" class="neon-btn neon-btn-green neon-pulse">
            <i class="fas fa-save"></i> {{ isset($task) ? 'Update Task' : 'Save Task' }}
        </button>
        <a href="{{ route('nexcore.clients.show.tasks', $client->id) }}" class="neon-btn neon-btn-ghost">
            <i class="fas fa-times"></i> Cancel
        </a>
    </div>
</form>

@endsection

@push('styles')
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/flatpickr/dist/themes/dark.css" rel="stylesheet">
<style>
/* ═══ TASK FORM - ENHANCED ═══ */

/* ── Hero ── */
.tf-hero {
    display:flex; align-items:center; justify-content:space-between; gap:16px;
    padding:20px 24px; margin-bottom:20px;
    background:linear-gradient(135deg, rgba(217,119,6,0.06), rgba(245,158,11,0.04), rgba(16,185,129,0.03));
    border:1px solid rgba(255,255,255,0.06);
    border-radius:16px;
    position:relative; overflow:hidden;
}
.tf-hero::before {
    content:''; position:absolute; top:-50%; right:-20%; width:300px; height:300px;
    background:radial-gradient(circle, rgba(217,119,6,0.08), transparent 70%);
    pointer-events:none;
}
.tf-hero-left { display:flex; align-items:center; gap:16px; position:relative; z-index:1; }
.tf-hero-icon {
    width:48px; height:48px; border-radius:14px;
    background:linear-gradient(135deg, rgba(217,119,6,0.2), rgba(245,158,11,0.1));
    border:1px solid rgba(217,119,6,0.3);
    display:flex; align-items:center; justify-content:center;
    font-size:18px; color:#d97706;
}
.tf-hero-title { margin:0; font-size:22px; font-weight:800; color:#fff; font-family:'Montserrat',sans-serif; letter-spacing:0.5px; }
.tf-hero-sub { margin:4px 0 0; font-size:13px; color:rgba(255,255,255,0.4); font-weight:500; }
.tf-hero-right { position:relative; z-index:1; }

/* ── Errors ── */
.tf-errors {
    display:flex; align-items:flex-start; gap:14px;
    padding:16px 20px; margin-bottom:20px; border-radius:14px;
    background:rgba(239,68,68,0.06);
    border:1px solid rgba(239,68,68,0.2);
}
.tf-errors-icon {
    width:36px; height:36px; border-radius:10px;
    background:rgba(239,68,68,0.15);
    display:flex; align-items:center; justify-content:center;
    font-size:16px; color:#ef4444; flex-shrink:0;
}
.tf-errors-content { flex:1; }
.tf-errors-title { font-size:14px; font-weight:700; color:#ef4444; margin-bottom:6px; }
.tf-errors-list { margin:0; padding-left:18px; font-size:13px; color:rgba(255,255,255,0.55); line-height:1.8; }
.tf-errors-list li { color:rgba(239,68,68,0.8); }

/* ── Cards ── */
.tf-card {
    background:rgba(17,21,32,0.8);
    border:1px solid rgba(255,255,255,0.06);
    border-radius:16px;
    margin-bottom:20px;
    backdrop-filter:blur(12px);
    overflow:hidden;
}
.tf-card-header {
    display:flex; align-items:center; gap:12px;
    padding:18px 24px;
    border-bottom:1px solid rgba(255,255,255,0.05);
    background:rgba(255,255,255,0.01);
}
.tf-card-icon {
    width:36px; height:36px; border-radius:10px;
    background:color-mix(in srgb, var(--ci-color) 15%, transparent);
    border:1px solid color-mix(in srgb, var(--ci-color) 30%, transparent);
    display:flex; align-items:center; justify-content:center;
    font-size:15px; color:var(--ci-color);
}
.tf-card-label {
    font-size:16px; font-weight:700; color:#fff;
    font-family:'Montserrat',sans-serif; letter-spacing:0.3px;
}
.tf-card-body { padding:24px; }

/* ── Form Fields ── */
.tf-row { margin-bottom:20px; }
.tf-row:last-child { margin-bottom:0; }
.tf-row-2 { display:grid; grid-template-columns:1fr 1fr; gap:20px; }
.tf-field { display:flex; flex-direction:column; gap:6px; }
.tf-field-full { width:100%; }

.tf-label {
    font-size:12px; font-weight:700; color:rgba(255,255,255,0.5);
    text-transform:uppercase; letter-spacing:0.6px;
    font-family:'Montserrat',sans-serif;
}
.tf-req { color:#ef4444; }
.tf-opt { font-size:10px; font-weight:500; text-transform:none; letter-spacing:0; color:rgba(255,255,255,0.3); }

.tf-input {
    width:100%; padding:12px 16px; border-radius:10px;
    background:rgba(255,255,255,0.04);
    border:1px solid rgba(255,255,255,0.09);
    color:#fff; font-size:14px; font-family:'Poppins',sans-serif;
    outline:none; transition:all 0.25s ease;
    box-sizing:border-box;
}
.tf-input:focus {
    border-color:rgba(217,119,6,0.5);
    background:rgba(255,255,255,0.06);
    box-shadow:0 0 0 3px rgba(217,119,6,0.08);
}
.tf-input::placeholder { color:rgba(255,255,255,0.2); }
.tf-input:disabled {
    opacity:0.4; cursor:not-allowed;
}

.tf-textarea {
    width:100%; padding:12px 16px; border-radius:10px;
    background:rgba(255,255,255,0.04);
    border:1px solid rgba(255,255,255,0.09);
    color:#fff; font-size:14px; font-family:'Poppins',sans-serif;
    outline:none; transition:all 0.25s ease;
    resize:vertical; min-height:80px;
    box-sizing:border-box;
}
.tf-textarea:focus {
    border-color:rgba(217,119,6,0.5);
    background:rgba(255,255,255,0.06);
    box-shadow:0 0 0 3px rgba(217,119,6,0.08);
}
.tf-textarea::placeholder { color:rgba(255,255,255,0.2); }

.tf-field-hint {
    font-size:11px; color:rgba(255,255,255,0.3);
    display:flex; align-items:center; gap:5px;
    margin-top:2px;
}
.tf-field-hint i { font-size:10px; }

/* ── Color Picker ── */
.tf-color-picker {
    display:flex; align-items:center; gap:8px; padding-top:4px;
}
.tf-color-swatch {
    width:36px; height:36px; border-radius:10px;
    background:var(--swatch, rgba(255,255,255,0.06));
    display:flex; align-items:center; justify-content:center;
    cursor:pointer; transition:all 0.25s ease;
    border:2px solid transparent;
    position:relative;
}
.tf-color-swatch input { position:absolute; opacity:0; width:0; height:0; }
.tf-color-check {
    font-size:12px; color:#fff; opacity:0;
    transition:opacity 0.2s ease;
}
.tf-color-active { border-color:rgba(255,255,255,0.5); transform:scale(1.1); }
.tf-color-active .tf-color-check { opacity:1; }
.tf-color-swatch:hover { transform:scale(1.1); }
.tf-color-none {
    background:rgba(255,255,255,0.06);
    border:2px dashed rgba(255,255,255,0.15);
}
.tf-color-none .tf-color-check { color:rgba(255,255,255,0.4); font-size:14px; }

/* ── Toggle Switch ── */
.tf-toggle-wrap { display:flex; align-items:center; gap:12px; padding-top:4px; }
.tf-toggle {
    position:relative; display:inline-block;
    width:48px; height:26px; flex-shrink:0;
}
.tf-toggle input { opacity:0; width:0; height:0; }
.tf-toggle-slider {
    position:absolute; cursor:pointer; inset:0;
    background:rgba(255,255,255,0.08);
    border:1px solid rgba(255,255,255,0.12);
    border-radius:26px;
    transition:all 0.3s ease;
}
.tf-toggle-slider::before {
    content:''; position:absolute;
    width:20px; height:20px; border-radius:50%;
    left:2px; bottom:2px;
    background:#fff;
    transition:all 0.3s ease;
    box-shadow:0 1px 4px rgba(0,0,0,0.3);
}
.tf-toggle input:checked + .tf-toggle-slider {
    background:linear-gradient(135deg, #dc2626, #ef4444);
    border-color:rgba(239,68,68,0.5);
    box-shadow:0 0 12px rgba(239,68,68,0.3);
}
.tf-toggle input:checked + .tf-toggle-slider::before {
    transform:translateX(22px);
}
.tf-toggle-label { font-size:13px; color:rgba(255,255,255,0.45); font-weight:500; }

/* ── Actions ── */
.tf-actions { display:flex; gap:12px; margin-bottom:20px; }

/* ── Select2 Dark Theme ── */
.select2-container--default .select2-selection--single {
    background:rgba(255,255,255,0.04) !important;
    border:1px solid rgba(255,255,255,0.09) !important;
    border-radius:10px !important;
    height:44px !important;
    color:#fff !important;
}
.select2-container--default .select2-selection--single .select2-selection__rendered {
    color:#fff !important;
    line-height:44px !important;
    padding-left:16px !important;
    font-size:14px !important;
    font-family:'Poppins',sans-serif !important;
}
.select2-container--default .select2-selection--single .select2-selection__arrow {
    height:44px !important;
    right:8px !important;
}
.select2-container--default .select2-selection--single .select2-selection__arrow b {
    border-color:rgba(255,255,255,0.3) transparent transparent transparent !important;
}
.select2-container--default .select2-selection--single .select2-selection__placeholder {
    color:rgba(255,255,255,0.2) !important;
}
.select2-container--default .select2-selection--single .select2-selection__clear {
    color:rgba(255,255,255,0.3) !important;
    font-size:18px !important;
    margin-right:4px !important;
}
.select2-dropdown {
    background:rgba(17,21,32,0.98) !important;
    border:1px solid rgba(255,255,255,0.12) !important;
    border-radius:10px !important;
    box-shadow:0 12px 40px rgba(0,0,0,0.5) !important;
    backdrop-filter:blur(16px) !important;
    overflow:hidden;
}
.select2-search--dropdown .select2-search__field {
    background:rgba(255,255,255,0.06) !important;
    border:1px solid rgba(255,255,255,0.1) !important;
    color:#fff !important;
    border-radius:8px !important;
    padding:10px 14px !important;
    font-size:13px !important;
    font-family:'Poppins',sans-serif !important;
    outline:none !important;
}
.select2-search--dropdown .select2-search__field:focus {
    border-color:rgba(217,119,6,0.4) !important;
}
.select2-results__option {
    color:rgba(255,255,255,0.6) !important;
    padding:10px 16px !important;
    font-size:13px !important;
    font-family:'Poppins',sans-serif !important;
    transition:all 0.15s ease;
}
.select2-results__option--highlighted,
.select2-results__option--highlighted[aria-selected] {
    background:linear-gradient(135deg, rgba(217,119,6,0.3), rgba(245,158,11,0.2)) !important;
    color:#fff !important;
}
.select2-results__option[aria-selected="true"] {
    background:rgba(217,119,6,0.12) !important;
    color:#d97706 !important;
}
.select2-container--default.select2-container--focus .select2-selection--single {
    border-color:rgba(217,119,6,0.5) !important;
    box-shadow:0 0 0 3px rgba(217,119,6,0.08) !important;
}
/* Tags (for assigned_to) */
.select2-container--default .select2-selection--multiple {
    background:rgba(255,255,255,0.04) !important;
    border:1px solid rgba(255,255,255,0.09) !important;
    border-radius:10px !important;
    min-height:44px !important;
    padding:4px 8px !important;
}
.select2-container--default .select2-selection--multiple .select2-selection__choice {
    background:rgba(217,119,6,0.15) !important;
    border:1px solid rgba(217,119,6,0.3) !important;
    color:#d97706 !important;
    border-radius:6px !important;
    padding:3px 8px !important;
    font-size:12px !important;
}
.select2-container--default .select2-selection--multiple .select2-selection__choice__remove {
    color:rgba(255,255,255,0.4) !important;
}

/* ── Flatpickr Override ── */
.flatpickr-calendar {
    background:rgba(17,21,32,0.98) !important;
    border:1px solid rgba(255,255,255,0.1) !important;
    box-shadow:0 12px 40px rgba(0,0,0,0.5) !important;
    border-radius:12px !important;
}

/* ── Responsive ── */
@@media (max-width: 768px) {
    .tf-hero { flex-direction:column; align-items:flex-start; gap:12px; }
    .tf-row-2 { grid-template-columns:1fr; }
    .tf-actions { flex-direction:column; }
    .tf-actions .neon-btn { width:100%; justify-content:center; }
}
</style>
@endpush

@push('scripts')
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.js"></script>
<script>
$(function() {
    // Select2 - standard dropdowns
    $('.tf-select2').select2({
        width: '100%',
        placeholder: '-- Select --',
        allowClear: true,
        minimumResultsForSearch: 6
    });

    // Select2 - assigned_to with tags (type-ahead + select)
    $('.tf-select2-tags').select2({
        width: '100%',
        placeholder: '-- Select or type a name --',
        allowClear: true,
        tags: true,
        createTag: function(params) {
            var term = $.trim(params.term);
            if (term === '') return null;
            return { id: term, text: term, newTag: true };
        }
    });

    // Flatpickr - CIMS standard date format
    $('.tf-datepicker').flatpickr({
        dateFormat: 'Y-m-d',
        altInput: true,
        altFormat: 'j M Y',
        theme: 'dark',
        allowInput: false
    });

    // Color swatch click handler
    $('.tf-color-swatch').on('click', function() {
        $('.tf-color-swatch').removeClass('tf-color-active');
        $(this).addClass('tf-color-active');
    });

    // Status -> Completed Date toggle
    var completedFp = null;
    var completedEl = document.getElementById('tfCompletedDate');
    if (completedEl && completedEl._flatpickr) {
        completedFp = completedEl._flatpickr;
    }

    $('#tfStatusSelect').on('change', function() {
        var val = $(this).val();
        var cdField = $('#tfCompletedDate');
        var cdHint = $('#tfCompletedHint');

        if (val === 'completed') {
            cdField.prop('disabled', false);
            cdHint.hide();
            // Re-init flatpickr if needed
            if (!cdField[0]._flatpickr) {
                cdField.flatpickr({
                    dateFormat: 'Y-m-d',
                    altInput: true,
                    altFormat: 'j M Y',
                    theme: 'dark',
                    allowInput: false
                });
            }
        } else {
            cdField.prop('disabled', true);
            cdHint.show();
        }
    });
});
</script>
@endpush
