@extends('nexcore_client_manager::layouts.nerve-centre')

@section('sidebar')
    @include('nexcore_client_manager::partials.nerve-centre-sidebar')
@endsection

@section('title', 'Task Kanban - ' . $client->company_name)
@section('topbar_module', 'Task Manager')
@section('topbar_page', 'Kanban Board')

@section('content')

@php
    $today = \Carbon\Carbon::today();
    $totalCount = 0;
    foreach ($columns as $col) { $totalCount += count($col); }

    $statusLabels = [
        'pending'     => 'Pending',
        'in_progress' => 'In Progress',
        'review'      => 'In Review',
        'completed'   => 'Completed',
        'on_hold'     => 'On Hold',
        'cancelled'   => 'Cancelled',
    ];

    $statusColors = [
        'pending'     => '#94a3b8',
        'in_progress' => '#3b82f6',
        'review'      => '#f59e0b',
        'completed'   => '#22c55e',
        'on_hold'     => '#8b5cf6',
        'cancelled'   => '#ef4444',
    ];

    $statusIcons = [
        'pending'     => 'fa-clock',
        'in_progress' => 'fa-spinner',
        'review'      => 'fa-eye',
        'completed'   => 'fa-check-circle',
        'on_hold'     => 'fa-pause-circle',
        'cancelled'   => 'fa-ban',
    ];

    $priorityColors = [
        'low'    => '#94a3b8',
        'medium' => '#3b82f6',
        'high'   => '#f59e0b',
        'urgent' => '#ef4444',
    ];
@endphp

{{-- Page Header --}}
<div class="kb-hero sl-animate d1">
    <div class="kb-hero-left">
        <div class="kb-hero-icon">
            <i class="fas fa-columns"></i>
            <div class="kb-hero-pulse"></div>
        </div>
        <div>
            <h1 class="kb-hero-title">Kanban Board</h1>
            <p class="kb-hero-sub">{{ $client->company_name }} <span class="kb-hero-dot"></span> {{ $totalCount }} {{ $totalCount === 1 ? 'task' : 'tasks' }}</p>
        </div>
    </div>
    <div class="kb-hero-right">
        <div class="kb-view-toggle">
            <a href="{{ route('nexcore.clients.show.tasks', $client->id) }}" class="kb-view-btn" title="List View">
                <i class="fas fa-list"></i>
            </a>
            <a href="{{ route('nexcore.clients.show.tasks.kanban', $client->id) }}" class="kb-view-btn kb-view-active" title="Kanban View">
                <i class="fas fa-columns"></i>
            </a>
            <a href="{{ route('nexcore.clients.show.tasks.calendar', $client->id) }}" class="kb-view-btn" title="Calendar View">
                <i class="fas fa-calendar-alt"></i>
            </a>
        </div>
        <a href="{{ route('nexcore.clients.show.tasks.create', $client->id) }}" class="kb-btn-add">
            <i class="fas fa-plus"></i> New Task
        </a>
    </div>
</div>

{{-- Kanban Board --}}
<div class="kb-board sl-animate d2">
    @foreach($columns as $statusKey => $tasks)
    @php
        $colColor = $statusColors[$statusKey] ?? '#94a3b8';
        $colLabel = $statusLabels[$statusKey] ?? ucfirst(str_replace('_', ' ', $statusKey));
        $colIcon  = $statusIcons[$statusKey] ?? 'fa-circle';
        $colCount = count($tasks);
    @endphp
    <div class="kb-column" data-status="{{ $statusKey }}" style="--col-color:{{ $colColor }};">
        <div class="kb-column-header">
            <div class="kb-column-header-left">
                <i class="fas {{ $colIcon }} kb-column-icon"></i>
                <span class="kb-column-title">{{ $colLabel }}</span>
                <span class="kb-column-count">{{ $colCount }}</span>
            </div>
        </div>

        <div class="kb-drop-zone"
             data-status="{{ $statusKey }}"
             ondragover="onDragOver(event)"
             ondragleave="onDragLeave(event)"
             ondrop="onDrop(event)">
            <div class="kb-cards">
                @foreach($tasks as $task)
                @php
                    $cat      = $task->category ?: 'general';
                    $catColor = $categoryColors[$cat] ?? '#94a3b8';
                    $catIcon  = $categoryIcons[$cat] ?? 'fa-tasks';
                    $catLabel = $categories[$cat] ?? 'General';
                    $pColor   = $priorityColors[$task->priority] ?? '#94a3b8';
                    $isOverdue = $task->due_date && $task->due_date->lt($today) && !in_array($task->task_status, ['completed', 'cancelled']);
                    $isUrgent  = $task->is_urgent || $task->priority === 'urgent';
                    $stepTotal = $task->steps->count();
                    $stepDone  = $task->steps->where('is_completed', true)->count();
                    $progress  = $stepTotal > 0 ? round(($stepDone / $stepTotal) * 100) : 0;
                @endphp
                <div class="kb-card {{ $isUrgent ? 'kb-card-urgent' : '' }} {{ $isOverdue ? 'kb-card-overdue' : '' }}"
                     data-task-id="{{ $task->id }}"
                     draggable="true"
                     ondragstart="onDragStart(event)"
                     ondragend="onDragEnd(event)">

                    {{-- Category --}}
                    <div class="kb-card-category">
                        <span class="kb-card-cat-dot" style="background:{{ $catColor }};"></span>
                        <span class="kb-card-cat-label" style="color:{{ $catColor }};">{{ $catLabel }}</span>
                        <span class="kb-card-priority" style="--pri-color:{{ $pColor }};">{{ ucfirst($task->priority) }}</span>
                    </div>

                    {{-- Title --}}
                    <a href="{{ route('nexcore.clients.show.tasks.show', [$client->id, $task->id]) }}" class="kb-card-title">
                        {{ $task->title }}
                    </a>

                    {{-- Progress bar --}}
                    @if($stepTotal > 0)
                    <div class="kb-card-progress">
                        <div class="kb-card-progress-bar">
                            <div class="kb-card-progress-fill" style="width:{{ $progress }}%; background:{{ $progress >= 100 ? '#22c55e' : ($progress >= 50 ? '#3b82f6' : '#f59e0b') }};"></div>
                        </div>
                        <span class="kb-card-progress-text">{{ $progress }}%</span>
                    </div>
                    @endif

                    {{-- Due date --}}
                    @if($task->due_date)
                    <div class="kb-card-due {{ $isOverdue ? 'kb-card-due-overdue' : '' }}">
                        <i class="far fa-calendar-alt"></i>
                        {{ $task->due_date->format('j M Y') }}
                        @if($isOverdue)
                            <span class="kb-card-due-badge">Overdue</span>
                        @endif
                    </div>
                    @endif

                    {{-- Assigned to --}}
                    @if($task->assigned_to)
                    <div class="kb-card-assignee">
                        <div class="kb-card-avatar">{{ strtoupper(substr($task->assigned_to, 0, 1)) }}</div>
                        <span>{{ $task->assigned_to }}</span>
                    </div>
                    @endif

                    {{-- Footer counters --}}
                    <div class="kb-card-footer">
                        @if($stepTotal > 0)
                        <span class="kb-card-counter" title="{{ $stepDone }}/{{ $stepTotal }} steps">
                            <i class="fas fa-list-check"></i> {{ $stepDone }}/{{ $stepTotal }}
                        </span>
                        @endif
                        @if($task->comments->count() > 0)
                        <span class="kb-card-counter" title="{{ $task->comments->count() }} comments">
                            <i class="fas fa-comment"></i> {{ $task->comments->count() }}
                        </span>
                        @endif
                        @if($task->attachments->count() > 0)
                        <span class="kb-card-counter" title="{{ $task->attachments->count() }} files">
                            <i class="fas fa-paperclip"></i> {{ $task->attachments->count() }}
                        </span>
                        @endif
                    </div>
                </div>
                @endforeach
            </div>

            @if($colCount === 0)
            <div class="kb-empty-col">
                <i class="fas {{ $colIcon }}"></i>
                <span>No tasks</span>
            </div>
            @endif
        </div>
    </div>
    @endforeach
</div>

@endsection

@push('styles')
<style>
/* ═══════════════════════════════════════════════════════════
   KANBAN BOARD — NexCore Dark Theme
   Prefix: kb-
   ═══════════════════════════════════════════════════════════ */

/* ── Hero / Header ── */
.kb-hero {
    display:flex; align-items:center; justify-content:space-between; gap:16px;
    padding:20px 24px; margin-bottom:20px;
    background:linear-gradient(135deg, rgba(139,92,246,0.06), rgba(59,130,246,0.04), rgba(20,184,166,0.03));
    border:1px solid rgba(255,255,255,0.06);
    border-radius:16px;
    position:relative; overflow:hidden;
}
.kb-hero::before {
    content:''; position:absolute; top:-50%; right:-20%; width:300px; height:300px;
    background:radial-gradient(circle, rgba(139,92,246,0.08), transparent 70%);
    pointer-events:none;
}
.kb-hero-left { display:flex; align-items:center; gap:16px; position:relative; z-index:1; }
.kb-hero-icon {
    width:52px; height:52px; border-radius:14px;
    background:linear-gradient(135deg, rgba(139,92,246,0.2), rgba(59,130,246,0.15));
    border:1px solid rgba(139,92,246,0.3);
    display:flex; align-items:center; justify-content:center;
    font-size:20px; color:#8b5cf6; position:relative;
}
.kb-hero-pulse {
    position:absolute; inset:-4px; border-radius:18px;
    border:2px solid rgba(139,92,246,0.3);
    animation:kbPulse 2.5s ease-in-out infinite;
}
.kb-hero-title { margin:0; font-size:22px; font-weight:800; color:#fff; letter-spacing:0.5px; font-family:'Montserrat',sans-serif; }
.kb-hero-sub { margin:4px 0 0; font-size:13px; color:rgba(255,255,255,0.45); font-weight:500; }
.kb-hero-dot { display:inline-block; width:4px; height:4px; border-radius:50%; background:rgba(255,255,255,0.25); vertical-align:middle; margin:0 6px; }
.kb-hero-right { display:flex; align-items:center; gap:12px; position:relative; z-index:1; }

/* ── View Toggle ── */
.kb-view-toggle {
    display:inline-flex; align-items:center; gap:2px;
    background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08);
    border-radius:10px; padding:3px;
}
.kb-view-btn {
    display:flex; align-items:center; justify-content:center;
    width:36px; height:32px; border-radius:8px;
    color:rgba(255,255,255,0.4); font-size:13px;
    text-decoration:none; transition:all 0.25s ease;
}
.kb-view-btn:hover { color:rgba(255,255,255,0.7); background:rgba(255,255,255,0.05); }
.kb-view-active {
    color:#8b5cf6 !important;
    background:rgba(139,92,246,0.15) !important;
    box-shadow:0 0 12px rgba(139,92,246,0.15);
}

/* ── New Task Button ── */
.kb-btn-add {
    display:inline-flex; align-items:center; gap:8px;
    padding:11px 22px; border-radius:10px;
    background:linear-gradient(135deg, #059669, #10b981);
    color:#fff; font-size:13px; font-weight:700;
    text-decoration:none; border:none; cursor:pointer;
    box-shadow:0 0 20px rgba(16,185,129,0.25), inset 0 1px 0 rgba(255,255,255,0.1);
    transition:all 0.3s ease; letter-spacing:0.3px;
}
.kb-btn-add:hover {
    transform:translateY(-1px);
    box-shadow:0 0 30px rgba(16,185,129,0.4), inset 0 1px 0 rgba(255,255,255,0.15);
}

/* ═══ KANBAN BOARD CONTAINER ═══ */
.kb-board {
    display:flex; gap:16px;
    overflow-x:auto; overflow-y:hidden;
    padding-bottom:20px;
    scroll-behavior:smooth;
    scrollbar-width:thin;
    scrollbar-color:rgba(255,255,255,0.08) transparent;
}
.kb-board::-webkit-scrollbar { height:6px; }
.kb-board::-webkit-scrollbar-track { background:transparent; }
.kb-board::-webkit-scrollbar-thumb { background:rgba(255,255,255,0.08); border-radius:3px; }
.kb-board::-webkit-scrollbar-thumb:hover { background:rgba(255,255,255,0.15); }

/* ═══ COLUMN ═══ */
.kb-column {
    flex:0 0 300px; width:300px; min-width:300px;
    display:flex; flex-direction:column;
    background:rgba(17,21,32,0.8);
    border:1px solid rgba(255,255,255,0.06);
    border-radius:14px;
    overflow:hidden;
    transition:all 0.3s ease;
}
.kb-column:hover {
    border-color:rgba(255,255,255,0.1);
}

/* ── Column Header ── */
.kb-column-header {
    padding:14px 16px;
    border-top:4px solid var(--col-color);
    background:linear-gradient(180deg, color-mix(in srgb, var(--col-color) 6%, transparent), transparent);
    border-bottom:1px solid rgba(255,255,255,0.04);
}
.kb-column-header-left {
    display:flex; align-items:center; gap:8px;
}
.kb-column-icon {
    font-size:13px; color:var(--col-color); opacity:0.8;
}
.kb-column-title {
    font-size:13px; font-weight:700; color:rgba(255,255,255,0.8);
    letter-spacing:0.3px; font-family:'Montserrat',sans-serif;
    text-transform:uppercase;
}
.kb-column-count {
    font-size:10px; font-weight:800;
    font-family:'Courier New',monospace;
    color:var(--col-color);
    background:color-mix(in srgb, var(--col-color) 15%, transparent);
    padding:2px 8px; border-radius:10px;
    min-width:22px; text-align:center;
}

/* ═══ DROP ZONE ═══ */
.kb-drop-zone {
    flex:1; padding:10px;
    min-height:400px;
    transition:all 0.3s ease;
    position:relative;
}
.kb-drop-active {
    background:color-mix(in srgb, var(--col-color) 6%, transparent);
    box-shadow:inset 0 0 30px color-mix(in srgb, var(--col-color) 8%, transparent);
    border-radius:0 0 14px 14px;
}
.kb-drop-active::after {
    content:'';
    position:absolute; inset:10px;
    border:2px dashed color-mix(in srgb, var(--col-color) 40%, transparent);
    border-radius:10px;
    pointer-events:none;
    animation:kbDropGlow 1.5s ease-in-out infinite;
}

/* ═══ CARDS CONTAINER ═══ */
.kb-cards {
    display:flex; flex-direction:column; gap:10px;
}

/* ═══ SINGLE CARD ═══ */
.kb-card {
    padding:14px 16px;
    background:rgba(255,255,255,0.025);
    border:1px solid rgba(255,255,255,0.06);
    border-radius:10px;
    cursor:grab;
    transition:all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
    position:relative;
    backdrop-filter:blur(8px);
    -webkit-backdrop-filter:blur(8px);
}
.kb-card:hover {
    background:rgba(255,255,255,0.05);
    border-color:rgba(255,255,255,0.12);
    transform:translateY(-2px);
    box-shadow:0 8px 32px rgba(0,0,0,0.3), 0 0 0 1px rgba(255,255,255,0.06);
}
.kb-card:active {
    cursor:grabbing;
}

/* Dragging state */
.kb-dragging {
    opacity:0.5;
    transform:rotate(2deg) scale(1.02);
    box-shadow:0 16px 48px rgba(0,0,0,0.4);
    z-index:1000;
}

/* Urgent card - pulsing red left border */
.kb-card-urgent {
    border-left:3px solid #ef4444;
    animation:kbUrgentPulse 2s ease-in-out infinite;
}

/* Overdue card - subtle red glow */
.kb-card-overdue {
    border-color:rgba(239,68,68,0.2);
    box-shadow:inset 0 0 20px rgba(239,68,68,0.03);
}

/* ── Card: Category Row ── */
.kb-card-category {
    display:flex; align-items:center; gap:6px; margin-bottom:8px;
}
.kb-card-cat-dot {
    width:7px; height:7px; border-radius:50%; flex-shrink:0;
}
.kb-card-cat-label {
    font-size:11px; font-weight:600; letter-spacing:0.3px;
}
.kb-card-priority {
    margin-left:auto;
    font-size:10px; font-weight:700;
    color:var(--pri-color);
    background:color-mix(in srgb, var(--pri-color) 12%, transparent);
    border:1px solid color-mix(in srgb, var(--pri-color) 25%, transparent);
    padding:2px 8px; border-radius:6px;
    text-transform:uppercase; letter-spacing:0.5px;
}

/* ── Card: Title ── */
.kb-card-title {
    display:block;
    font-size:13.5px; font-weight:700; color:#fff;
    line-height:1.4; margin-bottom:8px;
    text-decoration:none;
    transition:color 0.2s ease;
    word-wrap:break-word;
}
.kb-card-title:hover {
    color:#c4b5fd;
}

/* ── Card: Progress Bar ── */
.kb-card-progress {
    display:flex; align-items:center; gap:8px; margin-bottom:8px;
}
.kb-card-progress-bar {
    flex:1; height:4px; background:rgba(255,255,255,0.06);
    border-radius:2px; overflow:hidden;
}
.kb-card-progress-fill {
    height:100%; border-radius:2px;
    transition:width 0.5s cubic-bezier(0.4, 0, 0.2, 1);
}
.kb-card-progress-text {
    font-size:10px; font-weight:700; color:rgba(255,255,255,0.4);
    font-family:'Courier New',monospace; min-width:30px; text-align:right;
}

/* ── Card: Due Date ── */
.kb-card-due {
    display:flex; align-items:center; gap:6px;
    font-size:11px; color:rgba(255,255,255,0.4);
    font-family:'Courier New',monospace; margin-bottom:8px;
}
.kb-card-due i { font-size:10px; opacity:0.6; }
.kb-card-due-overdue { color:#ef4444; }
.kb-card-due-overdue i { color:#ef4444; opacity:1; }
.kb-card-due-badge {
    font-size:9px; font-weight:800;
    color:#ef4444; background:rgba(239,68,68,0.12);
    border:1px solid rgba(239,68,68,0.25);
    padding:1px 6px; border-radius:4px;
    text-transform:uppercase; letter-spacing:0.5px;
    animation:kbOverdueBlink 2s ease-in-out infinite;
}

/* ── Card: Assignee ── */
.kb-card-assignee {
    display:flex; align-items:center; gap:8px;
    margin-bottom:8px;
}
.kb-card-avatar {
    width:22px; height:22px; border-radius:6px;
    background:linear-gradient(135deg, rgba(139,92,246,0.3), rgba(59,130,246,0.2));
    border:1px solid rgba(139,92,246,0.25);
    display:flex; align-items:center; justify-content:center;
    font-size:9px; font-weight:800; color:rgba(255,255,255,0.7);
    letter-spacing:0.5px;
}
.kb-card-assignee span {
    font-size:11px; font-weight:600; color:rgba(255,255,255,0.45);
}

/* ── Card: Footer Counters ── */
.kb-card-footer {
    display:flex; align-items:center; gap:12px;
    padding-top:8px;
    border-top:1px solid rgba(255,255,255,0.04);
    margin-top:4px;
}
.kb-card-counter {
    display:flex; align-items:center; gap:4px;
    font-size:10px; font-weight:600; color:rgba(255,255,255,0.3);
}
.kb-card-counter i {
    font-size:10px; opacity:0.6;
}
.kb-card-counter:hover {
    color:rgba(255,255,255,0.5);
}

/* ═══ EMPTY COLUMN ═══ */
.kb-empty-col {
    display:flex; flex-direction:column; align-items:center; justify-content:center;
    gap:8px; padding:40px 16px;
    color:rgba(255,255,255,0.12);
    font-size:12px; font-weight:600;
}
.kb-empty-col i { font-size:24px; opacity:0.4; }

/* ═══ TOAST NOTIFICATIONS ═══ */
.kb-toast {
    position:fixed; top:20px; right:20px;
    padding:14px 24px; border-radius:10px;
    font-size:13px; font-weight:600; font-family:'Montserrat',sans-serif;
    color:#fff; z-index:9999;
    transform:translateX(120%);
    transition:transform 0.35s cubic-bezier(0.4, 0, 0.2, 1);
    box-shadow:0 8px 32px rgba(0,0,0,0.4);
    backdrop-filter:blur(12px);
    -webkit-backdrop-filter:blur(12px);
    max-width:340px;
}
.kb-toast-show {
    transform:translateX(0);
}
.kb-toast-success {
    background:rgba(5,150,105,0.9);
    border:1px solid rgba(16,185,129,0.4);
}
.kb-toast-error {
    background:rgba(220,38,38,0.9);
    border:1px solid rgba(239,68,68,0.4);
}

/* ═══ ANIMATIONS ═══ */
@@keyframes kbPulse {
    0%, 100% { opacity:0.5; transform:scale(1); }
    50% { opacity:0; transform:scale(1.15); }
}
@@keyframes kbDropGlow {
    0%, 100% { opacity:0.5; }
    50% { opacity:1; }
}
@@keyframes kbUrgentPulse {
    0%, 100% { border-left-color:#ef4444; }
    50% { border-left-color:rgba(239,68,68,0.3); }
}
@@keyframes kbOverdueBlink {
    0%, 100% { opacity:1; }
    50% { opacity:0.5; }
}

/* ═══ RESPONSIVE ═══ */
@@media (max-width: 900px) {
    .kb-hero { flex-direction:column; align-items:flex-start; gap:12px; }
    .kb-hero-right { width:100%; justify-content:space-between; }
    .kb-board {
        flex-direction:column;
        overflow-x:hidden;
        overflow-y:visible;
    }
    .kb-column {
        flex:0 0 auto; width:100%; min-width:100%;
    }
    .kb-drop-zone {
        min-height:120px;
    }
}
@@media (max-width: 600px) {
    .kb-hero-title { font-size:18px; }
    .kb-view-toggle { gap:1px; }
    .kb-view-btn { width:32px; height:28px; font-size:12px; }
    .kb-btn-add { padding:9px 16px; font-size:12px; }
    .kb-column { min-width:100%; }
    .kb-card { padding:12px 14px; }
    .kb-card-title { font-size:13px; }
}
</style>
@endpush

@push('scripts')
<script>
(function() {
    /* ═══ Kanban Update URL Template ═══ */
    var kanbanUpdateUrl = "{{ route('nexcore.clients.show.tasks.kanban-update', [$client->id, '__TASK_ID__']) }}";

    /* ═══ Toast Notification ═══ */
    window.showToast = function(msg, type) {
        var t = document.createElement('div');
        t.className = 'kb-toast kb-toast-' + type;
        t.textContent = msg;
        document.body.appendChild(t);
        setTimeout(function() { t.classList.add('kb-toast-show'); }, 10);
        setTimeout(function() {
            t.classList.remove('kb-toast-show');
            setTimeout(function() { t.remove(); }, 350);
        }, 3000);
    };

    /* ═══ Update Column Counts ═══ */
    window.updateColumnCounts = function() {
        var columns = document.querySelectorAll('.kb-column');
        for (var i = 0; i < columns.length; i++) {
            var col = columns[i];
            var cards = col.querySelectorAll('.kb-card');
            var badge = col.querySelector('.kb-column-count');
            if (badge) badge.textContent = cards.length;

            /* Toggle empty state */
            var emptyEl = col.querySelector('.kb-empty-col');
            if (cards.length === 0 && !emptyEl) {
                var zone = col.querySelector('.kb-drop-zone');
                var ico = col.querySelector('.kb-column-icon');
                var iconClass = ico ? ico.className.replace('fas ', '').replace('kb-column-icon', '').trim() : 'fa-circle';
                var d = document.createElement('div');
                d.className = 'kb-empty-col';
                d.innerHTML = '<i class="fas ' + iconClass + '"></i><span>No tasks</span>';
                zone.appendChild(d);
            } else if (cards.length > 0 && emptyEl) {
                emptyEl.remove();
            }
        }
    };

    /* ═══ HTML5 Drag and Drop ═══ */
    window.onDragStart = function(e) {
        e.dataTransfer.setData('text/plain', e.target.dataset.taskId);
        e.dataTransfer.effectAllowed = 'move';
        e.target.classList.add('kb-dragging');
    };

    window.onDragEnd = function(e) {
        e.target.classList.remove('kb-dragging');
        /* Clean up any lingering drop-active states */
        var zones = document.querySelectorAll('.kb-drop-active');
        for (var i = 0; i < zones.length; i++) {
            zones[i].classList.remove('kb-drop-active');
        }
    };

    window.onDragOver = function(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        e.currentTarget.classList.add('kb-drop-active');
    };

    window.onDragLeave = function(e) {
        e.currentTarget.classList.remove('kb-drop-active');
    };

    window.onDrop = function(e) {
        e.preventDefault();
        e.currentTarget.classList.remove('kb-drop-active');

        var taskId = e.dataTransfer.getData('text/plain');
        var newStatus = e.currentTarget.dataset.status;
        var card = document.querySelector('[data-task-id="' + taskId + '"]');

        if (!card) return;

        /* Move card in DOM */
        e.currentTarget.querySelector('.kb-cards').appendChild(card);

        /* Update counts */
        updateColumnCounts();

        /* AJAX call to update status */
        var url = kanbanUpdateUrl.replace('__TASK_ID__', taskId);

        fetch(url, {
            method: 'PATCH',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({ task_status: newStatus })
        })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (data.success) {
                showToast(data.message || 'Status updated', 'success');
            } else {
                showToast(data.message || 'Failed to update', 'error');
                location.reload();
            }
        })
        .catch(function(err) {
            showToast('Failed to update status', 'error');
            location.reload();
        });
    };
})();
</script>
@endpush
