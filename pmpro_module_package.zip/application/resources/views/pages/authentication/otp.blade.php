<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="{{ asset('images/' . ($app_settings->favicon ?? 'favicon.ico')) }}">
    <title>NexCore ERP | Verification</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
    :root {
        --cyan: #06b6d4;
        --cyan-bright: #22d3ee;
        --blue: #3b82f6;
        --green: #10b981;
        --red: #ef4444;
        --amber: #f59e0b;
        --text-primary: #e2e8f0;
        --text-secondary: #94a3b8;
        --text-dim: #475569;
        --font-display: 'Montserrat', sans-serif;
        --font-mono: 'JetBrains Mono', monospace;
    }

    *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }

    body {
        font-family: var(--font-display);
        background: #060a14;
        color: var(--text-primary);
        min-height: 100dvh;
        overflow-x: hidden;
        -webkit-font-smoothing: antialiased;
    }

    .nx-page {
        min-height: 100dvh;
        background: url('{{ url("/") }}/public/images/nexcore-login-bg.jpg') center center / contain no-repeat;
        background-color: #060a14;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 40px;
        position: relative;
    }

    .nx-page::before {
        content: '';
        position: absolute;
        inset: 0;
        background: transparent;
        pointer-events: none;
    }

    .nx-card {
        position: relative;
        z-index: 2;
        width: 100%;
        max-width: 320px;
        background: rgba(10,15,30,0.75);
        backdrop-filter: blur(30px);
        -webkit-backdrop-filter: blur(30px);
        border: 3px solid rgba(255,255,255,0.85);
        border-radius: 16px;
        padding: 24px 22px;
        overflow: hidden;
        animation: cardIn 0.8s cubic-bezier(0.16, 1, 0.3, 1) both;
        margin-left: 25vw;
        margin-bottom: 8vh;
    }

    .nx-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 1px;
        background: linear-gradient(90deg, transparent, var(--cyan), transparent);
        opacity: 0.4;
    }

    @@keyframes cardIn {
        0% { opacity: 0; transform: translateY(24px) scale(0.97); }
        100% { opacity: 1; transform: translateY(0) scale(1); }
    }

    /* Shield icon */
    .nx-shield {
        display: flex;
        justify-content: center;
        margin-bottom: 14px;
    }

    .nx-shield-icon {
        width: 48px;
        height: 48px;
        border-radius: 50%;
        background: radial-gradient(circle, rgba(6,182,212,0.12) 0%, rgba(6,182,212,0.03) 70%);
        border: 1px solid rgba(6,182,212,0.2);
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        animation: shieldPulse 3s ease-in-out infinite;
    }

    .nx-shield-icon::before {
        content: '';
        position: absolute;
        inset: -5px;
        border-radius: 50%;
        border: 1px solid rgba(6,182,212,0.08);
        animation: ringExpand 3s ease-in-out infinite;
    }

    .nx-shield-icon i {
        font-size: 20px;
        color: var(--cyan);
        filter: drop-shadow(0 0 10px rgba(6,182,212,0.4));
    }

    @@keyframes shieldPulse {
        0%, 100% { box-shadow: 0 0 20px rgba(6,182,212,0.08); }
        50% { box-shadow: 0 0 30px rgba(6,182,212,0.15); }
    }

    @@keyframes ringExpand {
        0%, 100% { transform: scale(1); opacity: 0.5; }
        50% { transform: scale(1.08); opacity: 0.2; }
    }

    /* Header */
    .nx-header {
        text-align: center;
        margin-bottom: 12px;
    }

    .nx-header h2 {
        font-size: 15px;
        font-weight: 700;
        color: #fff;
        margin-bottom: 3px;
    }

    .nx-header p {
        font-size: 10px;
        color: var(--text-secondary);
        font-weight: 400;
    }

    /* Alert boxes */
    .nx-alert {
        padding: 12px 16px;
        border-radius: 10px;
        font-size: 13px;
        line-height: 1.5;
        margin-bottom: 18px;
        display: none;
    }

    .nx-alert.is-visible { display: block; }

    .nx-alert-error {
        background: rgba(239,68,68,0.08);
        border: 1px solid rgba(239,68,68,0.2);
        color: #fca5a5;
    }

    .nx-alert-success {
        background: rgba(16,185,129,0.08);
        border: 1px solid rgba(16,185,129,0.2);
        color: #6ee7b7;
    }

    /* Dev mode OTP display */
    .nx-dev-otp {
        background: rgba(6,182,212,0.06);
        border: 1px solid rgba(6,182,212,0.25);
        border-radius: 8px;
        padding: 8px 10px;
        margin-bottom: 12px;
        text-align: center;
    }

    .nx-dev-otp-label {
        font-size: 8px;
        font-weight: 600;
        letter-spacing: 1.2px;
        text-transform: uppercase;
        color: var(--cyan);
        margin-bottom: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
    }

    .nx-dev-otp-label i {
        font-size: 9px;
    }

    .nx-dev-otp-code {
        font-family: var(--font-mono);
        font-size: 16px;
        font-weight: 600;
        letter-spacing: 6px;
        color: var(--cyan-bright);
        text-shadow: 0 0 20px rgba(6,182,212,0.3);
    }

    /* OTP digit inputs */
    .nx-otp-row {
        display: flex;
        justify-content: center;
        gap: 6px;
        margin-bottom: 10px;
    }

    .nx-otp-digit {
        width: 36px;
        height: 42px;
        border: 1px solid rgba(6,182,212,0.15);
        border-radius: 8px;
        background: rgba(15,20,36,0.7);
        color: #fff;
        font-family: var(--font-mono);
        font-size: 16px;
        font-weight: 600;
        text-align: center;
        outline: none;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        caret-color: var(--cyan);
    }

    .nx-otp-digit:focus {
        border-color: rgba(6,182,212,0.5);
        box-shadow: 0 0 0 3px rgba(6,182,212,0.08), 0 0 20px rgba(6,182,212,0.06);
        background: rgba(20,26,46,0.8);
    }

    .nx-otp-digit.has-value {
        border-color: rgba(6,182,212,0.3);
        background: rgba(6,182,212,0.05);
    }

    .nx-otp-digit.is-error {
        border-color: rgba(239,68,68,0.5);
        box-shadow: 0 0 0 3px rgba(239,68,68,0.08);
        animation: inputShake 0.5s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
    }

    @@keyframes inputShake {
        10%, 90% { transform: translateX(-1px); }
        20%, 80% { transform: translateX(2px); }
        30%, 50%, 70% { transform: translateX(-3px); }
        40%, 60% { transform: translateX(3px); }
    }

    /* Timer */
    .nx-timer {
        text-align: center;
        margin-bottom: 10px;
        font-size: 10px;
        color: var(--text-secondary);
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
    }

    .nx-timer i {
        font-size: 11px;
        color: var(--text-dim);
    }

    .nx-timer-value {
        font-family: var(--font-mono);
        font-weight: 500;
        color: var(--cyan);
        letter-spacing: 1px;
    }

    .nx-timer.is-expiring .nx-timer-value {
        color: var(--red);
    }

    .nx-timer.is-expiring i {
        color: var(--red);
        animation: timerBlink 1s ease-in-out infinite;
    }

    @@keyframes timerBlink {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.3; }
    }

    /* Submit button */
    .nx-submit {
        width: 100%;
        padding: 9px 18px;
        font-size: 11px;
        font-weight: 700;
        font-family: var(--font-display);
        letter-spacing: 1.5px;
        text-transform: uppercase;
        color: #fff;
        background: linear-gradient(135deg, var(--cyan) 0%, var(--blue) 100%);
        border: none;
        border-radius: 10px;
        cursor: pointer;
        overflow: hidden;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        margin-top: 4px;
    }

    .nx-submit:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 30px rgba(6,182,212,0.25), 0 0 50px rgba(6,182,212,0.08);
    }

    .nx-submit:active { transform: translateY(0) scale(0.98); }
    .nx-submit:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }

    .nx-submit .nx-spinner {
        display: none;
        width: 18px;
        height: 18px;
        border: 2px solid rgba(255,255,255,0.3);
        border-top-color: #fff;
        border-radius: 50%;
        animation: spinRotate 0.7s linear infinite;
    }

    @@keyframes spinRotate { to { transform: rotate(360deg); } }

    .nx-submit.is-loading .nx-btn-label { display: none; }
    .nx-submit.is-loading .nx-spinner { display: block; }
    .nx-submit.is-loading .nx-loading-text { display: inline; }
    .nx-loading-text { display: none; }

    /* Resend link */
    .nx-resend {
        text-align: center;
        margin-top: 10px;
        font-size: 10px;
        color: var(--text-secondary);
    }

    .nx-resend-link {
        color: var(--cyan);
        font-weight: 600;
        text-decoration: none;
        cursor: pointer;
        transition: color 0.2s;
        border: none;
        background: none;
        font-family: var(--font-display);
        font-size: 10px;
        padding: 0;
    }

    .nx-resend-link:hover { color: var(--cyan-bright); }
    .nx-resend-link:disabled {
        color: var(--text-dim);
        cursor: not-allowed;
    }

    .nx-resend-cooldown {
        font-family: var(--font-mono);
        font-size: 10px;
        color: var(--text-dim);
        margin-left: 4px;
    }

    /* Security footer */
    .nx-security {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        margin-top: 14px;
        padding-top: 12px;
        border-top: 1px solid rgba(6,182,212,0.08);
        font-size: 9px;
        font-family: var(--font-mono);
        color: var(--text-dim);
        letter-spacing: 1px;
        text-transform: uppercase;
    }

    .nx-security i { font-size: 10px; color: var(--green); }

    /* Mobile brand */
    .nx-mobile-brand {
        display: none;
        align-items: center;
        justify-content: center;
        gap: 12px;
        margin-bottom: 20px;
    }

    .nx-mobile-brand .nx-m-logo {
        width: 36px;
        height: 36px;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 3px;
    }

    .nx-mobile-brand .nx-m-logo .q { border-radius: 3px; }
    .nx-mobile-brand .nx-m-logo .q1 { background: #059669; }
    .nx-mobile-brand .nx-m-logo .q2 { background: #2563eb; }
    .nx-mobile-brand .nx-m-logo .q3 { background: #d97706; }
    .nx-mobile-brand .nx-m-logo .q4 { background: #7c3aed; }

    .nx-mobile-brand .nx-m-text {
        font-size: 18px;
        font-weight: 800;
        letter-spacing: 3px;
        text-transform: uppercase;
        background: linear-gradient(135deg, var(--cyan-bright), var(--blue));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }

    /* Success checkmark animation */
    .nx-success-overlay {
        display: none;
        position: absolute;
        inset: 0;
        background: rgba(10,15,30,0.95);
        backdrop-filter: blur(10px);
        z-index: 10;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        border-radius: 13px;
    }

    .nx-success-overlay.is-visible {
        display: flex;
        animation: fadeIn 0.3s ease both;
    }

    @@keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    .nx-success-check {
        width: 64px;
        height: 64px;
        border-radius: 50%;
        background: rgba(16,185,129,0.1);
        border: 2px solid var(--green);
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 16px;
        animation: scaleIn 0.4s cubic-bezier(0.16, 1, 0.3, 1) 0.1s both;
    }

    @@keyframes scaleIn {
        from { transform: scale(0); opacity: 0; }
        to { transform: scale(1); opacity: 1; }
    }

    .nx-success-check i {
        font-size: 28px;
        color: var(--green);
        animation: checkPop 0.3s cubic-bezier(0.16, 1, 0.3, 1) 0.4s both;
    }

    @@keyframes checkPop {
        from { transform: scale(0); }
        to { transform: scale(1); }
    }

    .nx-success-text {
        font-size: 14px;
        font-weight: 600;
        color: #fff;
        animation: fadeIn 0.3s ease 0.5s both;
    }

    .nx-success-sub {
        font-size: 11px;
        color: var(--text-secondary);
        margin-top: 4px;
        animation: fadeIn 0.3s ease 0.6s both;
    }

    /* Responsive */
    @@media (max-width: 1024px) {
        .nx-page {
            padding: 40px 30px;
        }
        .nx-page::before { background: transparent; }
        .nx-card { margin-left: 0; }
    }

    @@media (max-width: 768px) {
        .nx-page {
            padding: 24px 16px;
            align-items: flex-start;
            padding-top: 50px;
        }
        .nx-page::before { background: transparent; }
        .nx-card {
            padding: 30px 24px;
            border-radius: 16px;
            max-width: 100%;
        }
        .nx-mobile-brand { display: flex !important; }
    }

    @@media (max-width: 480px) {
        .nx-card { padding: 26px 20px; }
        .nx-header h2 { font-size: 20px; }
        .nx-otp-digit {
            width: 40px;
            height: 48px;
            font-size: 18px;
        }
        .nx-otp-row { gap: 6px; }
        .nx-submit { padding: 13px 20px; font-size: 13px; }
        .nx-shield-icon { width: 60px; height: 60px; }
        .nx-shield-icon i { font-size: 24px; }
        .nx-dev-otp-code { font-size: 18px; letter-spacing: 6px; }
    }
    </style>
</head>
<body>
    <div class="nx-page">
        <div class="nx-card">
            <!-- Success overlay -->
            <div class="nx-success-overlay" id="nxSuccessOverlay">
                <div class="nx-success-check">
                    <i class="fas fa-check"></i>
                </div>
                <div class="nx-success-text">Verified!</div>
                <div class="nx-success-sub">Redirecting to dashboard...</div>
            </div>

            <!-- Mobile brand -->
            <div class="nx-mobile-brand">
                <div class="nx-m-logo">
                    <div class="q q1"></div>
                    <div class="q q2"></div>
                    <div class="q q3"></div>
                    <div class="q q4"></div>
                </div>
                <span class="nx-m-text">NexCore</span>
            </div>

            <!-- Shield icon -->
            <div class="nx-shield">
                <div class="nx-shield-icon">
                    <i class="fas fa-lock"></i>
                </div>
            </div>

            <!-- Header -->
            <div class="nx-header">
                <h2>Verification Required</h2>
                <p>Enter the code sent to your device</p>
            </div>

            <!-- Alert boxes -->
            <div class="nx-alert nx-alert-error" id="nxError"></div>
            <div class="nx-alert nx-alert-success" id="nxSuccess"></div>

            <!-- Dev mode OTP display -->
            <div class="nx-dev-otp" id="nxDevOtp">
                <div class="nx-dev-otp-label">
                    <i class="fas fa-flask"></i>
                    Development Mode - Your OTP code is
                </div>
                <div class="nx-dev-otp-code" id="nxDevOtpCode">{{ $otp_code }}</div>
            </div>

            <!-- OTP form -->
            <form id="nxOtpForm" autocomplete="off">
                <input type="hidden" name="_token" value="{{ csrf_token() }}">

                <!-- 6 digit inputs -->
                <div class="nx-otp-row" id="nxOtpRow">
                    <input type="text" class="nx-otp-digit" data-index="0" maxlength="1" inputmode="numeric" pattern="[0-9]*" autocomplete="one-time-code">
                    <input type="text" class="nx-otp-digit" data-index="1" maxlength="1" inputmode="numeric" pattern="[0-9]*">
                    <input type="text" class="nx-otp-digit" data-index="2" maxlength="1" inputmode="numeric" pattern="[0-9]*">
                    <input type="text" class="nx-otp-digit" data-index="3" maxlength="1" inputmode="numeric" pattern="[0-9]*">
                    <input type="text" class="nx-otp-digit" data-index="4" maxlength="1" inputmode="numeric" pattern="[0-9]*">
                    <input type="text" class="nx-otp-digit" data-index="5" maxlength="1" inputmode="numeric" pattern="[0-9]*">
                </div>

                <!-- Countdown timer -->
                <div class="nx-timer" id="nxTimer">
                    <i class="far fa-clock"></i>
                    <span>Code expires in <span class="nx-timer-value" id="nxTimerValue">4:59</span></span>
                </div>

                <!-- Verify button -->
                <button type="submit" class="nx-submit" id="nxSubmit">
                    <span class="nx-btn-label">Verify <i class="fas fa-shield-halved" style="margin-left:6px;"></i></span>
                    <span class="nx-spinner"></span>
                    <span class="nx-loading-text">Verifying...</span>
                </button>
            </form>

            <!-- Resend link -->
            <div class="nx-resend">
                <span>Didn't receive the code? </span>
                <button type="button" class="nx-resend-link" id="nxResend" disabled>Resend Code</button>
                <span class="nx-resend-cooldown" id="nxResendCooldown">(30s)</span>
            </div>

            <!-- Security footer -->
            <div class="nx-security">
                <i class="fas fa-shield-halved"></i>
                <span>Two-Factor Authentication</span>
            </div>
        </div>
    </div>

    <script>
    (function(){
        var digits = document.querySelectorAll('.nx-otp-digit');
        var form = document.getElementById('nxOtpForm');
        var btn = document.getElementById('nxSubmit');
        var errBox = document.getElementById('nxError');
        var successBox = document.getElementById('nxSuccess');
        var timerEl = document.getElementById('nxTimerValue');
        var timerWrap = document.getElementById('nxTimer');
        var resendBtn = document.getElementById('nxResend');
        var resendCooldown = document.getElementById('nxResendCooldown');
        var devOtpCode = document.getElementById('nxDevOtpCode');
        var successOverlay = document.getElementById('nxSuccessOverlay');
        var csrfToken = document.querySelector('input[name="_token"]').value;

        // ---- OTP Digit Input Handling ----
        var digitArray = Array.prototype.slice.call(digits);

        digitArray.forEach(function(input, idx) {
            // Handle typing
            input.addEventListener('input', function(e) {
                var val = this.value.replace(/[^0-9]/g, '');
                this.value = val.charAt(0) || '';

                if (val.length > 0) {
                    this.classList.add('has-value');
                    this.classList.remove('is-error');
                    // Auto-advance to next
                    if (idx < 5) {
                        digitArray[idx + 1].focus();
                    }
                } else {
                    this.classList.remove('has-value');
                }

                checkAllFilled();
            });

            // Handle backspace
            input.addEventListener('keydown', function(e) {
                if (e.key === 'Backspace') {
                    if (this.value === '' && idx > 0) {
                        digitArray[idx - 1].focus();
                        digitArray[idx - 1].value = '';
                        digitArray[idx - 1].classList.remove('has-value');
                    } else {
                        this.value = '';
                        this.classList.remove('has-value');
                    }
                }
                // Arrow keys
                if (e.key === 'ArrowLeft' && idx > 0) {
                    e.preventDefault();
                    digitArray[idx - 1].focus();
                }
                if (e.key === 'ArrowRight' && idx < 5) {
                    e.preventDefault();
                    digitArray[idx + 1].focus();
                }
            });

            // Handle paste
            input.addEventListener('paste', function(e) {
                e.preventDefault();
                var pastedData = (e.clipboardData || window.clipboardData).getData('text');
                var cleaned = pastedData.replace(/[^0-9]/g, '').substring(0, 6);
                if (cleaned.length > 0) {
                    for (var i = 0; i < 6; i++) {
                        if (i < cleaned.length) {
                            digitArray[i].value = cleaned.charAt(i);
                            digitArray[i].classList.add('has-value');
                            digitArray[i].classList.remove('is-error');
                        }
                    }
                    // Focus the next empty or last
                    var focusIdx = Math.min(cleaned.length, 5);
                    digitArray[focusIdx].focus();
                    checkAllFilled();
                }
            });

            // Select on focus
            input.addEventListener('focus', function() {
                this.select();
            });
        });

        // Focus first digit on load
        if (digitArray[0]) {
            digitArray[0].focus();
        }

        function checkAllFilled() {
            var code = getOtpCode();
            if (code.length === 6) {
                // Brief delay then auto-submit
                // (Let user see all digits filled first)
            }
        }

        function getOtpCode() {
            var code = '';
            digitArray.forEach(function(d) {
                code += d.value;
            });
            return code;
        }

        function clearDigits() {
            digitArray.forEach(function(d) {
                d.value = '';
                d.classList.remove('has-value', 'is-error');
            });
            digitArray[0].focus();
        }

        function shakeDigits() {
            digitArray.forEach(function(d) {
                d.classList.add('is-error');
            });
            setTimeout(function() {
                digitArray.forEach(function(d) {
                    d.classList.remove('is-error');
                });
            }, 600);
        }

        function hideAlerts() {
            errBox.classList.remove('is-visible');
            errBox.textContent = '';
            successBox.classList.remove('is-visible');
            successBox.textContent = '';
        }

        function showError(msg) {
            errBox.innerHTML = '<i class="fas fa-exclamation-triangle" style="margin-right:8px;"></i>' + msg;
            errBox.classList.add('is-visible');
            successBox.classList.remove('is-visible');
        }

        function showSuccess(msg) {
            successBox.innerHTML = '<i class="fas fa-check-circle" style="margin-right:8px;"></i>' + msg;
            successBox.classList.add('is-visible');
            errBox.classList.remove('is-visible');
        }

        // ---- Countdown Timer (5 min) ----
        var totalSeconds = 299; // 4:59 display
        var timerInterval = null;

        function startTimer() {
            totalSeconds = 299;
            updateTimerDisplay();
            if (timerInterval) clearInterval(timerInterval);
            timerInterval = setInterval(function() {
                totalSeconds--;
                if (totalSeconds <= 0) {
                    clearInterval(timerInterval);
                    totalSeconds = 0;
                    updateTimerDisplay();
                    showError('OTP has expired. Please request a new code.');
                    btn.disabled = true;
                    return;
                }
                updateTimerDisplay();
            }, 1000);
        }

        function updateTimerDisplay() {
            var mins = Math.floor(totalSeconds / 60);
            var secs = totalSeconds % 60;
            var display = mins + ':' + (secs < 10 ? '0' : '') + secs;
            timerEl.textContent = display;

            // Under 60 seconds - show warning state
            if (totalSeconds <= 60) {
                timerWrap.classList.add('is-expiring');
            } else {
                timerWrap.classList.remove('is-expiring');
            }
        }

        startTimer();

        // ---- Resend Cooldown (30 sec) ----
        var resendSeconds = 30;
        var resendInterval = null;

        function startResendCooldown() {
            resendSeconds = 30;
            resendBtn.disabled = true;
            resendCooldown.textContent = '(' + resendSeconds + 's)';
            resendCooldown.style.display = 'inline';

            if (resendInterval) clearInterval(resendInterval);
            resendInterval = setInterval(function() {
                resendSeconds--;
                if (resendSeconds <= 0) {
                    clearInterval(resendInterval);
                    resendBtn.disabled = false;
                    resendCooldown.style.display = 'none';
                    return;
                }
                resendCooldown.textContent = '(' + resendSeconds + 's)';
            }, 1000);
        }

        startResendCooldown();

        // ---- Resend Handler ----
        resendBtn.addEventListener('click', function() {
            if (resendBtn.disabled) return;
            hideAlerts();

            fetch('{{ url("nexcore/otp/resend") }}', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': csrfToken,
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({}),
                credentials: 'same-origin'
            })
            .then(function(response) {
                return response.json();
            })
            .then(function(data) {
                if (data.success) {
                    showSuccess(data.message || 'New verification code sent.');
                    // Update dev mode display
                    if (data.otp_code && devOtpCode) {
                        devOtpCode.textContent = data.otp_code;
                    }
                    // Restart timers
                    startTimer();
                    startResendCooldown();
                    clearDigits();
                    btn.disabled = false;
                } else {
                    showError(data.message || 'Failed to resend code.');
                }
            })
            .catch(function(err) {
                showError('Network error. Please try again.');
            });
        });

        // ---- Form Submit (Verify) ----
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            hideAlerts();

            var code = getOtpCode();
            if (code.length !== 6) {
                showError('Please enter all 6 digits.');
                shakeDigits();
                return;
            }

            btn.disabled = true;
            btn.classList.add('is-loading');

            fetch('{{ url("nexcore/otp/verify") }}', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': csrfToken,
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ otp_code: code }),
                credentials: 'same-origin'
            })
            .then(function(response) {
                return response.json().then(function(data) {
                    return { ok: response.ok, data: data };
                });
            })
            .then(function(result) {
                if (result.data.success) {
                    // Show success overlay with animation
                    successOverlay.classList.add('is-visible');
                    // Redirect after animation
                    setTimeout(function() {
                        var redirectUrl = result.data.redirect_url || '{{ url("nexcore/clients") }}';
                        window.location.href = redirectUrl;
                    }, 1200);
                } else {
                    showError(result.data.message || 'Invalid verification code.');
                    shakeDigits();
                    btn.disabled = false;
                    btn.classList.remove('is-loading');
                }
            })
            .catch(function(err) {
                showError('Network error. Please try again.');
                btn.disabled = false;
                btn.classList.remove('is-loading');
            });
        });

    })();
    </script>
</body>
</html>
