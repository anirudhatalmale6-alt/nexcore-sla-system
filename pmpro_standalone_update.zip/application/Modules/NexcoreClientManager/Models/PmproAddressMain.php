<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PmproAddressMain extends Model
{
    use SoftDeletes;

    protected $table = 'pmpro_address_main';

    protected $fillable = [
        'unit_number',
        'complex_name',
        'street_number',
        'street_name',
        'suburb_id',
        'city',
        'postal_code',
        'province_id',
        'municipality_id',
        'ward_id',
        'country',
        'latitude',
        'longitude',
        'google_formatted_address',
        'address_category',
        'is_active',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'latitude' => 'decimal:8',
        'longitude' => 'decimal:8',
    ];

    public function province(): BelongsTo
    {
        return $this->belongsTo(PmproProvince::class, 'province_id');
    }

    public function localMunicipality(): BelongsTo
    {
        return $this->belongsTo(PmproLocalMunicipality::class, 'municipality_id');
    }

    public function metro(): BelongsTo
    {
        return $this->belongsTo(PmproMetro::class, 'municipality_id');
    }

    public function ward(): BelongsTo
    {
        return $this->belongsTo(PmproWard::class, 'ward_id');
    }

    public function suburb(): BelongsTo
    {
        return $this->belongsTo(PmproSuburb::class, 'suburb_id');
    }

    public function secondary(): HasOne
    {
        return $this->hasOne(PmproAddressSecondary::class, 'address_id');
    }

    public function links(): HasMany
    {
        return $this->hasMany(PmproAddressLink::class, 'address_id');
    }

    public function getMunicipalityNameAttribute()
    {
        if ($this->localMunicipality) {
            return $this->localMunicipality->name;
        }

        if ($this->metro) {
            return $this->metro->name;
        }

        return null;
    }

    public function getMunicipalityTypeAttribute()
    {
        if ($this->localMunicipality) {
            return 'local';
        }

        if ($this->metro) {
            return 'metro';
        }

        return null;
    }

    public function getMunicipalityCodeAttribute()
    {
        if ($this->localMunicipality) {
            return $this->localMunicipality->code;
        }

        if ($this->metro) {
            return $this->metro->code;
        }

        return null;
    }
}
