<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PmproDistrict extends Model
{
    protected $table = 'pmpro_districts';

    public $timestamps = false;

    protected $fillable = [
        'province_id',
        'name',
        'code',
        'is_active',
    ];

    public function province(): BelongsTo
    {
        return $this->belongsTo(PmproProvince::class, 'province_id');
    }

    public function localMunicipalities(): HasMany
    {
        return $this->hasMany(PmproLocalMunicipality::class, 'district_id');
    }
}
