<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class PmproAddressLink extends Model
{
    protected $table = 'pmpro_address_links';

    protected $fillable = [
        'address_id',
        'linkable_type',
        'linkable_id',
        'address_type_id',
        'address_label',
        'notes',
        'is_primary',
        'is_active',
    ];

    protected $casts = [
        'is_primary' => 'boolean',
        'is_active' => 'boolean',
    ];

    public function address(): BelongsTo
    {
        return $this->belongsTo(PmproAddressMain::class, 'address_id');
    }

    public function addressType(): BelongsTo
    {
        return $this->belongsTo(PmproAddressType::class, 'address_type_id');
    }

    public function linkable(): MorphTo
    {
        return $this->morphTo();
    }
}
