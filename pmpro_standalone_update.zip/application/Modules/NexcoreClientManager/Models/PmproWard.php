<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PmproWard extends Model
{
    protected $table = 'pmpro_wards';

    public $timestamps = false;

    protected $fillable = [
        'local_municipality_id',
        'metro_id',
        'ward_number',
        'code',
        'ward_id_official',
        'ward_label',
        'municipality_name',
        'district_name',
        'district_code',
        'province_name',
        'cat_b',
        'demarcation_date',
        'objectid',
        'objectid_1',
        'shape_length',
        'shape_area',
        'shape_perimeter',
        'is_active',
        'is_deleted',
    ];

    protected $casts = [
        'demarcation_date' => 'date',
        'is_active' => 'boolean',
        'is_deleted' => 'boolean',
    ];

    public function localMunicipality(): BelongsTo
    {
        return $this->belongsTo(PmproLocalMunicipality::class, 'local_municipality_id');
    }

    public function metro(): BelongsTo
    {
        return $this->belongsTo(PmproMetro::class, 'metro_id');
    }
}
