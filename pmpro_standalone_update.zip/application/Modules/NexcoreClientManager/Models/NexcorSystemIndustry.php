<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class NexcorSystemIndustry extends Model
{
    protected $table = 'nexcore_system_industries';

    protected $fillable = [
        'name',
        'code',
        'sic_code_id',
        'description',
        'is_active',
        'is_deleted',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'is_deleted' => 'boolean',
    ];

    public function sicCode(): BelongsTo
    {
        return $this->belongsTo(NexcorSicCode::class, 'sic_code_id');
    }
}
