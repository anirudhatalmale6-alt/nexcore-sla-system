<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PmproLocalMunicipality extends Model
{
    protected $table = 'pmpro_local_municipalities';

    public $timestamps = false;

    protected $fillable = [
        'district_id',
        'name',
        'code',
        'is_active',
    ];

    public function district(): BelongsTo
    {
        return $this->belongsTo(PmproDistrict::class, 'district_id');
    }

    public function wards(): HasMany
    {
        return $this->hasMany(PmproWard::class, 'local_municipality_id');
    }

    public function cities(): HasMany
    {
        return $this->hasMany(PmproCity::class, 'local_municipality_id');
    }
}
