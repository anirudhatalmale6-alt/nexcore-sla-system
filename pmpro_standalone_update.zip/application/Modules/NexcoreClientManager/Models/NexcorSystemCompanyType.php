<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;

class NexcorSystemCompanyType extends Model
{
    protected $table = 'nexcore_system_company_types';

    protected $fillable = [
        'name',
        'code',
        'description',
        'is_active',
        'is_deleted',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'is_deleted' => 'boolean',
    ];
}
