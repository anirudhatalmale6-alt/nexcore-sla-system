<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PmproSuburb extends Model
{
    protected $table = 'pmpro_suburbs';

    public $timestamps = false;

    protected $fillable = [
        'city_id',
        'municipality_id',
        'name',
        'postal_code',
        'is_active',
    ];

    public function city(): BelongsTo
    {
        return $this->belongsTo(PmproCity::class, 'city_id');
    }
}
