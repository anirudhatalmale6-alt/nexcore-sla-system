<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PmproAddressSecondary extends Model
{
    protected $table = 'pmpro_address_secondary';

    protected $fillable = [
        'address_id',
        'floor_level',
        'building_name',
        'estate_name',
        'section_number',
        'farm_name',
        'farm_number',
        'stand_number',
        'erf_number',
        'sg_code',
        'municipal_account_number',
        'plus_code',
        'what3words',
        'google_place_id',
        'map_url',
        'address_source',
        'is_verified',
        'verified_date',
    ];

    protected $casts = [
        'is_verified' => 'boolean',
        'verified_date' => 'date',
    ];

    public function address(): BelongsTo
    {
        return $this->belongsTo(PmproAddressMain::class, 'address_id');
    }
}
