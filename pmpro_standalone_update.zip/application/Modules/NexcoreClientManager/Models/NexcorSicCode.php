<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class NexcorSicCode extends Model
{
    protected $table = 'nexcore_sic_codes';

    protected $fillable = [
        'sic_code',
        'description',
        'section_code',
        'section_name',
        'profit_code',
        'loss_code',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function industries(): HasMany
    {
        return $this->hasMany(NexcorSystemIndustry::class, 'sic_code_id');
    }
}
