<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;

class PmproAddressType extends Model
{
    protected $table = 'pmpro_address_types';

    public $timestamps = false;

    protected $fillable = [
        'name',
        'description',
        'is_active',
    ];
}
