<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PmproCity extends Model
{
    protected $table = 'pmpro_cities';

    public $timestamps = false;

    protected $fillable = [
        'province_id',
        'metropolitan_municipality_id',
        'district_id',
        'local_municipality_id',
        'name',
        'is_active',
    ];

    public function province(): BelongsTo
    {
        return $this->belongsTo(PmproProvince::class, 'province_id');
    }

    public function localMunicipality(): BelongsTo
    {
        return $this->belongsTo(PmproLocalMunicipality::class, 'local_municipality_id');
    }

    public function metro(): BelongsTo
    {
        return $this->belongsTo(PmproMetro::class, 'metropolitan_municipality_id');
    }

    public function district(): BelongsTo
    {
        return $this->belongsTo(PmproDistrict::class, 'district_id');
    }

    public function suburbs(): HasMany
    {
        return $this->hasMany(PmproSuburb::class, 'city_id');
    }
}
