<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;

class DocumentCategory extends Model
{
    protected $table = 'cims_document_categories';

    protected $fillable = [
        'name',
        'description',
        'is_active',
        'show_in_tab',
        'tab_name',
        'display_order',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'show_in_tab' => 'boolean',
    ];

    public function types()
    {
        return $this->hasMany(DocumentType::class, 'category_id');
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }
}
