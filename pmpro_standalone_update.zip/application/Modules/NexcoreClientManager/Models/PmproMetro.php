<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PmproMetro extends Model
{
    protected $table = 'pmpro_metropolitan_municipalities';

    public $timestamps = false;

    protected $fillable = [
        'province_id',
        'name',
        'code',
        'description',
        'is_active',
    ];

    public function province(): BelongsTo
    {
        return $this->belongsTo(PmproProvince::class, 'province_id');
    }

    public function wards(): HasMany
    {
        return $this->hasMany(PmproWard::class, 'metro_id');
    }

    public function cities(): HasMany
    {
        return $this->hasMany(PmproCity::class, 'metropolitan_municipality_id');
    }
}
