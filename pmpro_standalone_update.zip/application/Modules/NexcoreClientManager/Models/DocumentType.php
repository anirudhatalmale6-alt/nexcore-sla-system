<?php

namespace Modules\NexcoreClientManager\Models;

use Illuminate\Database\Eloquent\Model;

class DocumentType extends Model
{
    protected $table = 'cims_document_types';

    protected $fillable = [
        'name',
        'is_active',
        'category_id',
        'doc_ref',
        'doc_group',
        'description',
        'lead_time_days',
        'has_expiry',
        'days_to_expire',
        'client_id',
        'document_required',
        'show_types_in_tab',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'has_expiry' => 'boolean',
        'document_required' => 'boolean',
        'show_types_in_tab' => 'boolean',
    ];

    public function category()
    {
        return $this->belongsTo(DocumentCategory::class, 'category_id');
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeByCategory($query, $categoryId)
    {
        return $query->where('category_id', $categoryId);
    }
}
